var gulp = require('gulp');
var runSequence =require('run-sequence');
var through = require('through2');
var rimraf = require('gulp-rimraf');
var validator = require('json-dup-key-validator');
var jsonKeyDupCheck = require('./tools/gulp-json-key-dup-check');
var merge = require('gulp-merge-json');

gulp.task('i18n-json-key-dup-check', function() {
  return gulp.src('./src/client/assets/i18n/micro-service/*.json')
    .pipe(through.obj(function(file, enc, cb){
      this.push(file);
      cb();
    }))
    .pipe(jsonKeyDupCheck({ allowDuplicatedKeys: false }));
});

gulp.task('i18n-json-merge-watch',function(){
  gulp.watch('./src/client/assets/i18n/micro-service/*.json',function () {
    runSequence(
      'i18n-json-merge'
    )
  });
});

gulp.task('i18n-json-merge',function(){
  runSequence(
    'i18n-json-clean',
    'i18n-zh-json-merge',
    'i18n-en-json-merge'
  );
});

gulp.task('i18n-json-clean', function() {
  return gulp.src('./src/client/assets/i18n/*.json', { read: false })
    .pipe(rimraf({ force: true }));
});

gulp.task('i18n-zh-json-merge',function(){
  gulp.src('./src/client/assets/i18n/micro-service/zh*.json')
    .pipe(merge({fileName: 'zh.json'}))
    .pipe(gulp.dest('./src/client/assets/i18n/'));
});

gulp.task('i18n-en-json-merge',function(){
  gulp.src('./src/client/assets/i18n/micro-service/en*.json')
    .pipe(merge({fileName: 'en.json'}))
    .pipe(gulp.dest('./src/client/assets/i18n/'));
});
