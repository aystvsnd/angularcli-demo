var tools = require('./tools/tools.js');
var proxyPath = './tools/proxy.conf.json';
var proxyJson, proxyStr;

//========================================================
//设置你常用的环境并选择你需要的环境
//========================================================
var proxies = {
  0: 'http://localhost:8101',
  1: 'http://10.62.49.204:10080',
  2: 'http://10.62.107.81:10080',
  3: 'http://10.62.107.136:10080',
  4: 'http://10.93.128.180:10080'


};

var proxyTarget = proxies[ 1 ];


//========================================================
//重写proxyJson文件，并在控制台打印设置
//========================================================
proxyJson = JSON.stringify({"/api": {"secure": false, "target": proxyTarget}});
proxyStr = 'The Http-Proxy is ' + proxyTarget;

tools.reWriteFile(proxyPath, proxyJson);
tools.valueLooker(proxyStr);
