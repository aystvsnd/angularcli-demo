import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import {StorageService} from './storage.service';
import { Headers, Http, Response} from '@angular/http';
import { SendMessageService } from './sendMessage.service';
import './rxjs-operators';

@Injectable()
export class AjaxSetupService {
  accessToken: any;
  headers: any = null;
  operateuser: any;
  language = '';

  constructor(private router: Router, private storageService: StorageService, private http: Http,
              public sendMessageService: SendMessageService) {
    if (storageService.getCurrentLang() === 'en') {
      this.language = 'en-US';
    } else {
      this.language = 'zh-CN';
    }
    this.accessToken = storageService.getAccessToken();
    this.operateuser = storageService.getOperateuser();
    this.headers = new Headers({
      'Content-Type': 'application/json',
      'Access-Token': this.accessToken,
      'Accept-Language': this.language,
      'operateuser': this.operateuser,
    });
  }

  _ajaxSetup() {
    const that = this;
    $.ajaxSetup({
      contentType: 'application/json;charset=utf-8',
      beforeSend: function (xhr) {
        const accessToken = window.localStorage.getItem('directoraccessToken');
        const username = window.localStorage.getItem('directorusername');
        xhr.setRequestHeader('Access-Token', accessToken);
        xhr.setRequestHeader('operateuser', username);
      },
      complete: function (xhr, status) {
        if (xhr.status === 403 || status === 'timeout') {
          window.localStorage.removeItem('directorlatestSiderbarMsg');
          window.localStorage.removeItem('directorhasShowSiderbar');
          that.router.navigate(['/login']);
        }
        if (xhr.status === 401 && xhr.responseJSON.error === 'access token is expired') {
          that.refreshTokenAndTip();
        }
      }
    });
  }

  refreshTokenAndTip() {
    const that = this;
    const refresh_token = that.storageService.getRefreshToken();
    const postData = {'refresh_token': refresh_token};
    return that.http.post('/api/v1.0/auth/user_token/freshToken', JSON.stringify(postData), {headers: this.headers}).toPromise()
      .then((res: Response) => {
        that.storageService.setAccessToken(res.json().access_token);
        that.storageService.setRefreshToken(res.json().refresh_token);
        that.headers = new Headers({
          'Content-Type': 'application/json',
          'Access-Token': res.json().access_token,
          'Accept-Language': that.language,
          'operateuser': that.operateuser,
        });
        that.sendMessageService.sendTableRefreshMsgSbg.next('expired');
      }).catch((err) => {
        that.router.navigate(['/login']);
      });
  }
}
