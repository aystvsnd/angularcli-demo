import {Injectable} from '@angular/core';
import {Headers, Http, ResponseContentType} from '@angular/http';
import './rxjs-operators';
import {StorageService} from './storage.service';
import {Router} from '@angular/router';
import {SendMessageService} from './sendMessage.service';
import {Observable} from 'rxjs/Observable';


@Injectable()
export class ApiResourceService {
  accessToken: any;
  headers: any = null;
  operateuser: any;
  language: any;

  constructor(public http: Http,
              public storageService: StorageService,
              public router: Router,
              public sendMessageService: SendMessageService) {
    this.accessToken = storageService.getAccessToken();
    this.operateuser = storageService.getOperateuser();

    if (storageService.getCurrentLang() === 'en') {
      this.language = 'en-US';
    } else {
      this.language = 'zh-CN';
    }

    this.headers = new Headers({
      'Content-Type': 'application/json',
      'Access-Token': this.accessToken,
      'Accept-Language': this.language,
      'operateuser': this.operateuser,
    });

  }

  get(uri: any) {
    return this.getHttpByOpt('get', uri, {});
  }

  post(uri: any, data: any) {
    return this.getHttpByOpt('post', uri, data);
  }

  delete(uri: any) {
    return this.getHttpByOpt('delete', uri, {});
  }

  put(uri: any, data: any) {
    return this.getHttpByOpt('put', uri, data);
  }


  //若要增加其他header时，使用完后要恢复下header，recoverHeader()
  setHeader(newHeader: Headers) {
    this.headers = newHeader;
  }

  download(url: string, data: any, filename: string) {
    const  headers = new Headers({
        'Access-Token': this.storageService.getAccessToken()});
    return this.http.post(url, JSON.stringify(data),
      {headers: headers, responseType: ResponseContentType.Blob}).map(res => {
      const blob = new Blob([res.blob()]);
      const a = document.createElement('a');
      document.body.appendChild(a);
      a.download = filename;
      a.href = URL.createObjectURL(blob);
      a.click();
    });
  }

  getHeader() {
    return this.headers;
  }

  recoverHeader() {
    this.headers = new Headers({
      'Content-Type': 'application/json',
      'Access-Token': this.storageService.getAccessToken(),
      'Accept-Language': this.language,
      'operateuser': this.storageService.getOperateuser(),
    });
  }

  updateHeaders(accessTokenStr: any, operateuserStr: any) {
    this.accessToken = accessTokenStr;
    this.operateuser = operateuserStr;
    if (this.headers !== null) {
      delete this.headers;
    }
    this.headers = new Headers({
      'Content-Type': 'application/json',
      'Access-Token': this.accessToken,
      'Accept-Language': this.language,
      'operateuser': this.operateuser,
    });
  }

  refreshTokenAndHttpDataAgain(opt: any, uri: any, data: any) {
    const that = this;
    const refresh_token = that.storageService.getRefreshToken();
    const postData = {'refresh_token': refresh_token};
    return that.http.post('/api/v1.0/auth/user_token/freshToken', JSON.stringify(postData), {headers: this.headers}).flatMap(res => {
      that.storageService.setAccessToken(res.json().access_token);
      that.storageService.setRefreshToken(res.json().refresh_token);
      that.headers = new Headers({
        'Content-Type': 'application/json',
        'Access-Token': res.json().access_token,
        'Accept-Language': this.language,
        'operateuser': that.operateuser,
      });
      return that.http[opt](uri, JSON.stringify(data), {headers: that.headers}).map(res => {
        return res;
      });
    }).catch((err) => {
      that.backToLogin();
    });
  }

  refreshTokenAndHttpAgain(opt: any, uri: any) {
    const that = this;
    const refresh_token = that.storageService.getRefreshToken();
    const postData = {'refresh_token': refresh_token};
    return that.http.post('/api/v1.0/auth/user_token/freshToken', JSON.stringify(postData), {headers: this.headers}).flatMap(res => {
      that.storageService.setAccessToken(res.json().access_token);
      that.storageService.setRefreshToken(res.json().refresh_token);
      that.headers = new Headers({
        'Content-Type': 'application/json',
        'Access-Token': res.json().access_token,
        'Accept-Language': this.language,
        'operateuser': that.operateuser,
      });
      return that.http[opt](uri, {headers: that.headers}).map(res => {
        return res;
      });
    }).catch((err) => {
      that.backToLogin();
    });
  }

  backToLogin() {
    this.storageService.clearMenuRelate();
    this.router.navigate(['/login']);
  }

  getHttpByOpt(opt: any, uri: any, data: any) {
    const that = this;

    if (opt === 'post' || opt === 'put') {
      return that.http[opt](uri, JSON.stringify(data), {headers: this.headers}).catch(res => {
        if (res.status === 401 && res.json().error === 'access token is expired') {
          return that.refreshTokenAndHttpDataAgain(opt, uri, data);
        } else if (res.status === 500) {
          that.sendMessageService.sendInnerMsgSbg.next('500');
          return Observable.throw(res);
        } else if (res.status === 403
          && (res.json().error === 'access token not exist' || res.json().error === 'token not exist')) {
          that.backToLogin();
        } else if (res.status === 403
          && (res.json().error === 'access token is invalid' || res.json().error === 'token is invalid')) {
          that.backToLogin();
        } else {
          if (that.isRequireSend(uri)) {
            that.sendMessageService.sendResponseMsg(res.json().error || res.json().message ||
              _.values(res.json())[0].message || uri);
          }
          return Observable.throw(res);
        }
      });
    } else {
      return that.http[opt](uri, {headers: this.headers}).catch(res => {
        if (res.status === 401 && res.json().error === 'access token is expired') {
          return that.refreshTokenAndHttpAgain(opt, uri);
        } else if (res.status === 500) {
          that.sendMessageService.sendInnerMsgSbg.next('500');
          return Observable.throw(res);
        } else if (res.status === 403
          && ( res.json().error === 'access token not exist' || res.json().error === 'token not exist')) {
          that.backToLogin();
        } else if (res.status === 403
          && ( res.json().error === 'access token is invalid' || res.json().error === 'token is invalid')) {
          that.backToLogin();
        } else if (res.status === 403 && res.json().error === 'User not exist.') {
          return that.http[opt](uri, {headers: this.headers});
        } else {
          that.sendMessageService.sendResponseMsg(res.json().error || res.json().message ||
            _.values(res.json())[0].message || uri);
          return Observable.throw(res);
        }
      });
    }
  }

  isRequireSend(uri: any) {
    if (uri === '/api/v2.0/volumeServiceaa/login') {
      return false;
    } else {
      return true;
    }
  }

  //=========================================
  //读取系统配置
  //=========================================
  getConfigByName(name: string) {
    return this.http.get('/api/v2.0/operateService/configs/' + name, {headers: this.headers}).map(res => {
      return res.json() || res;
    }).catch((err) => {
      console.log(err);
    });
  }
}
