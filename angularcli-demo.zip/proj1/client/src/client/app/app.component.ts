import { Component, AfterContentChecked, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {  Http } from '@angular/http';
import { StorageService } from './storage.service';
import { TablePaginationModeService } from './tablePaginationMode.service';

@Component({
  moduleId: module.id,
  selector: 'my-app',
  templateUrl: 'app.component.html'
})

export class AppComponent implements AfterContentChecked, OnInit {
  lang: string;
  oldLg = 'cn';
  constructor(private translate: TranslateService, public http: Http,
              private storageService: StorageService, private tablePaginationModeService: TablePaginationModeService) {

    if (storageService.getCurrentLang() !== undefined) {
      this.lang = storageService.getCurrentLang();
    }else {
      this.lang = translate.getBrowserLang();
    }

    translate.setDefaultLang(this.lang);
    translate.use(this.lang);
    $('#langTranslate').attr('lang', this.lang);
    tablePaginationModeService.reInitPagination();
    //this.getTranslationInfoService.getTranslations('en').subscribe(res=>{
    //  for(let re of res){
    //    translate.setTranslation('en',re,true);
    //  }
    //});
  }

  ngOnInit() {
    this.oldLg = this.storageService.getCurrentLang();
    this.setBootstrapTableLg(this.oldLg);
  }

  ngAfterContentChecked() {
    const curLg = this.storageService.getCurrentLang();
    if (curLg === this.oldLg) return;
    this.setBootstrapTableLg(curLg);
    this.oldLg = curLg;
  }

  setBootstrapTableLg(lg: string) {
    if (lg === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }
  }
}
