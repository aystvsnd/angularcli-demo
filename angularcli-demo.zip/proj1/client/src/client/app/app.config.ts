const BASEURL = '/api/v1.0';
const BASEURL2 = '/api/v2.0';
const SDCBASEURL = 'http://localhost/sdc1';

export const appConfig = {
  vManagerUrl: `${BASEURL}/vrm/`,
  vdcServiceUrl: `${BASEURL}/vdclcm/`,
  vdcsServiceUrl: `${BASEURL}/vdcs/`,
  vdcOperServiceUrl: `${BASEURL}/auth/org/`,
  vdcOrgServiceUrl: `${BASEURL}/vdclcm/vdcs`,
  vrmServiceUrl: `${BASEURL}/vrm/`,
  dciServiceUrl: `${BASEURL}/dcisvc/`,
  aggreServiceUrl: `${BASEURL}/aggregator/`,     // '/api/aggregator/v1.0/',
  userServiceUrl: `${BASEURL}/auth/users`,
  userLockServiceUrl: `${BASEURL}/auth/lockTime`,
  roleServiceUrl: `${BASEURL}/auth/roles`,
  tpcServiceUrl: `${BASEURL}/auth/authServers`,
  radiusSrviceUrl: `${BASEURL}/auth/radiusServers`,
  tpcUserUrl: `${BASEURL}/auth/thirdPartUser`,
  privilegeUrl: `${BASEURL}/auth/privileges`,
  openstackAgentUrl: `${BASEURL}/openstackAgentService`,
  templateApiUrl: `${BASEURL}/templateService`,
  imageUrl: `${BASEURL}/imagesvc/`,
  myImageUrl: `${BASEURL}/myimage/`,
  fmServiceUrl: `${BASEURL}/fm/`,
  pmServiceUrl: `${BASEURL}/pm/`,
  logmServiceUrl: `${BASEURL}/LOG/`,
  dsbServiceUrl: `${BASEURL}/dsbsvc/`,
  hwvServiceUrl: `${BASEURL}/hwv/`,
  orgServiceUrl: `${BASEURL2}/orgService/`,
  nautilusUrl: `${BASEURL}/nautilus/`,
  appUrl: `${BASEURL}/ResourceService/`,
  volumeServiceUrl: `${BASEURL2}/volumeService/`,
  backupServiceUrl: `${BASEURL2}/backupService/`,
  operateServiceUrl: `${BASEURL2}/operateService/`,
  physicalResourceUrl: `${BASEURL}/hwv/`,
  dcUrl: `${BASEURL2}/dataCenter/`,
  iksUrl: `${BASEURL}/iks/`,
  interconnects: `${BASEURL}/dcisvc/interconnects`,
  subnetpool: `${BASEURL}/dcisvc/subnetpools`,
  frpt: `${BASEURL}/frpt/`,
  sdcUrl: `${SDCBASEURL}/?`
};


