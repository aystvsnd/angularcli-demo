import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpModule, Http } from '@angular/http';

import { AppComponent } from './app.component';
import { routing } from './app.routes';
import { FullModule } from './full.module';
import { IdlePreloadModule } from '@angularclass/idle-preload';
import { PxConfirmModule } from '../assets/libs/paletxUI';

import { StorageService } from './storage.service';
import { ApiResourceService } from './apiResource.service';
import { FullComponetToSiderbarService } from './fullComponetToSiderbar.service';
import { SendMessageService } from './sendMessage.service';
import { AuthService, AuthGuard } from './core/index';
import { TranslateModule, TranslateLoader} from '@ngx-translate/core';
import { TranslateHttpLoader} from '@ngx-translate/http-loader';
import { OrgService } from './orgManage/org.service';
import { OrgVdcService } from './orgManage/org-vdc.service';
import { TablePaginationModeService } from './tablePaginationMode.service';

import { LoginModule } from './login/index';

export function translateLoader(http: Http) { return new TranslateHttpLoader(http, 'assets/i18n/', '.json'); }

@NgModule({
  imports: [BrowserModule, BrowserAnimationsModule, HttpModule, routing, FullModule, LoginModule,
    IdlePreloadModule.forRoot(),
    PxConfirmModule.forRoot(),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (translateLoader),
        deps: [Http]}
    })],
  declarations: [AppComponent],
  providers: [StorageService, ApiResourceService, FullComponetToSiderbarService,
    SendMessageService, AuthService, AuthGuard, OrgService, OrgVdcService, TablePaginationModeService],
  bootstrap: [AppComponent]
})

export class AppModule { }
