import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { environment } from '../environments/environment';
import { IdlePreload } from '@angularclass/idle-preload';

import { FullComponent } from './full.component';
import { IntervalComponent } from './interval.component';
import {AuthGuard} from './core/index';

import {LoginComponent} from './login/index';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full'},
  { path: 'login', component: LoginComponent },
  { path: 'interval', component: IntervalComponent},
   { path: 'main', component: FullComponent,
     canActivateChild: [AuthGuard],
     children: [
     { path: 'dc', loadChildren: 'app/dataCenter/data-center.module#DataCenterModule'},
     { path: 'computeResource', loadChildren: 'app/computeResource/compute-resource.module#ComputeResourceModule'},
     { path: 'networkResource', loadChildren: 'app/netResource/netResource.module#NetworkResourceModule'},
     { path: 'storageResource', loadChildren: 'app/storageResource/storage-resource.module#StorageResourceModule'},
     { path: 'flavor', loadChildren: 'app/flavor/flavor.module#FlavorModule'},
     { path: 'image', loadChildren: 'app/imageManager/image.module#ImageModule'},
     { path: 'systemManage', loadChildren: 'app/system-manage/system-manage.module#SystemManageModule'},
     { path: 'selfService', loadChildren: 'app/selfService/self-service.module#SelfServiceModule'},
     { path: 'vManager', loadChildren: 'app/vManager/vmanager.module#VmanagerModule'},
     { path: 'alarm', loadChildren: 'app/fm/alarm.module#AlarmModule'},
     { path: 'myResource', loadChildren: 'app/my-resource/my-resource.module#MyResourceModule'},
     { path: 'pm', loadChildren: 'app/pm/pm.module#PmModule'},
     { path: 'logmManage', loadChildren: 'app/logm/logm.module#LogmModule'},
     { path: 'monitor', loadChildren: 'app/monitor/monitor.module#MonitorModule'},
     { path: 'sheet', loadChildren: 'app/sheet/sheet.module#SheetModule'},
     { path: 'orgCenter', loadChildren: 'app/orgCenter/org-center.module#OrgCenterModule'},
     { path: 'org', loadChildren: 'app/orgManage/org.module#OrgModule'},
     { path: 'resource', loadChildren: 'app/resource/resource.module#ResourceModule'},
     { path: 'physicalResource', loadChildren: 'app/physicalResource/physical-resource.module#PhysicalResourceModule'},
     { path: 'orderManage', loadChildren: 'app/orderManage/order-manage.module#OrderManageModule'},
     { path: 'serviceMarket', loadChildren: 'app/serviceMarket/service-market.module#ServiceMarketModule'},
     { path: 'insight', loadChildren: 'app/insight/insight.module#InsightModule'},
     { path: 'orderAudit', loadChildren: 'app/orderAudit/order-audit.module#OrderAuditModule'},
     { path: 'operation', loadChildren: 'app/operation/operation.module#OperationModule'},
     { path: 'resourceCenter', loadChildren: 'app/resourceCenter/resource-center.module#ResourceCenterModule'}
  ]}
];

export const routing: ModuleWithProviders = environment.production ?
    RouterModule.forRoot(routes, { preloadingStrategy: IdlePreload }) : RouterModule.forRoot(routes);
