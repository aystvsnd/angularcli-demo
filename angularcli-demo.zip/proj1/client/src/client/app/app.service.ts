export class AppService {
  uploader: any;
  dcNames: any;

  createdPmJob: any = {
    'name': null,
    'objectType': null
  };

  pmRow: any = {
    'name': '',
    'objectType': '',
    'period': 0,
    'meterItems': [],
    'objectPath': [],
    'link': ''
  };
  dataBackupConfig: any = {
    'disabled': '',
    'startTime': '',
    'intervalTime':
    {
      'value': '1',
      'unit': 'hour'
    }
  };
  logmCfgData: any = {
    'curlogStorageDay': '',
    'testStorageDay': ''
  };

  setUploader(uploader: any) {
    this.uploader = uploader;
  }

  getUploader() {
    return this.uploader;
  }

  setDcNames(dcNames: any) {
    this.dcNames = dcNames;
  }

  getDcNames() {
    return this.dcNames;
  }

  setCreatedPmJob(name: string, objectType: string) {
    this.createdPmJob.name = name;
    this.createdPmJob.objectType = objectType;
  }

  getCreatedPmJob() {
    return this.createdPmJob;
  }
}
