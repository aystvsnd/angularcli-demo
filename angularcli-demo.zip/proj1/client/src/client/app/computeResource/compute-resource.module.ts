import { NgModule } from '@angular/core';

import {GlobalBareMetalModule} from './globalBareMetal/global-bare-metals.module';
import {GlobalBareMetalServerModule} from './globalBareMetalServer/global-bare-metal-servers.module';
import {GlobalCloudenvModule} from './globalCloudenvs/global-cloudenvs.module';
import {GlobalHostAggrateModule} from './globalHostAggrates/global-hostaggrates.module';
import {GlobalHostModule} from './globalHosts/global-hosts.module';
import {GlobalVmModule} from './globalVms/global-vms.module';

import { ComputeResourceService } from './compute-resource.service';

@NgModule({
  imports: [GlobalBareMetalModule, GlobalBareMetalServerModule, GlobalCloudenvModule, GlobalHostAggrateModule,
    GlobalHostAggrateModule, GlobalHostModule, GlobalVmModule],
  providers: [ComputeResourceService]
})

export class ComputeResourceModule { }
