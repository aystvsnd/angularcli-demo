import { Injectable } from '@angular/core';
import { AuthService } from '../core/index';

@Injectable()
export class ComputeResourceService {

    constructor(private authService: AuthService) {}

    getDashboardUrl() {

        let dashboardUrl = '/main/monitor/dashboard';

        if (this.authService.containAllRights([['Smart Object Management#View'], '||', ['Smart Config#View'], '||',
            ['Smart Alarm Analysis#View']])) {
            dashboardUrl = '/main/insight/dashboard/all';
        }

        return dashboardUrl;

    }
}
