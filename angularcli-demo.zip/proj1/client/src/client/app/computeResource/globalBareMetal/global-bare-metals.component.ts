import { Component, OnInit, OnDestroy } from '@angular/core';
import { appConfig } from '../../app.config';
//import { ActivatedRoute } from '@angular/router';
import {TranslateService} from '@ngx-translate/core';
import { StorageService } from '../../storage.service';

@Component({
    moduleId: module.id,
    templateUrl: 'global-bare-metals.component.html',
})

export class GlobalBareMetalListComponent implements OnInit, OnDestroy {
    status : any;
    isShowLinks = false;
    links : any;
    isShowLoading = false;
    timerHandle : any = undefined;
    window: window = window;
    columnDefs: any[] = [
        {
            field: 'name',
            sortable: true,
            title: this.translate.instant('Name'),
            class: 'table-wrap'
        },
        {
            field: 'dcName',
            sortable: true,
            title: this.translate.instant('computeRes.dcName'),
            class: 'table-wrap'
        },
        {
            field: 'cloudEnvName',
            sortable: true,
            title: this.translate.instant('computeRes.homeEnv'),
            class: 'table-wrap'
        },
        {
            field: 'vmName',
            sortable: true,
            title: this.translate.instant('gengyun.bareMetal.instanceName'),
            class: 'table-wrap',
            formatter: (value, row, index) => {
                if ((value === undefined) || (value === null)) {
                    return '';
                }
                return value;
            }
        },
        {
            field: 'driver',
            sortable: true,
            title: this.translate.instant('gengyun.bareMetal.driver'),
            class: 'table-wrap'
        },
        {
            field: 'maintenance',
            sortable: true,
            title: this.translate.instant('gengyun.bareMetal.maintance')
        },
        {
            field: 'ports',
            sortable: true,
            title: this.translate.instant('gengyun.bareMetal.port')
        },
        {
            field: 'provisionState',
            title: this.translate.instant('Status'),
            width: '160',
            sortable: true,
            searchFormatter: false,
            formatter: (value, row, index) => {
              if (row.provisionState) {
                if (value.indexOf('ing') >= 0) {
                  return '<img class="status-img" ' +
                    'src="assets/images/loading_grey_s2.gif" />' + value;
                } else {
                  switch (value) {
                    case 'available':
                      return '<img class="status-img" style="margin-right: 6px;"' +
                        'src="assets/images/status/icon_status_blue.png" />' + value;
                    case 'active':
                      return '<img class="status-img" style="margin-right: 6px;"' +
                        'src="assets/images/status/icon_status_green.png" />' + value;
                    case 'error':
                      return '<img class="status-img" style="margin-right: 6px;"' +
                        'src="assets/images/status/icon_status_red.png" />' + value;
                    default:
                      return '<img class="status-img" style="margin-right: 6px;"' +
                        'src="assets/images/status/icon_status_grey.png" />' + value;
                  }
                }
              } else {
                return '<img class="status-img" src="assets/images/status/icon_status_grey.png" />';
              }
            }
        },
        {
            field: 'powerState',
            title: this.translate.instant('computeRes.powerState'),
            width: '140',
            sortable: true,
            searchFormatter: false,
            formatter: (value, row, index) => {
                if (row.powerState) {
                    if (value === 'power on') {
                        return `<img class="status-img" style="margin-right: 6px;"
                    src="assets/images/status/icon_power_status_green.png" />` + value;
                    } else {
                        return `<img class="status-img" style="margin-right: 6px;"
                        src="assets/images/status/icon_power_status_grey.png" />` + value;
                    }
                } else {
                    return '<img class="status-img" src="assets/images/status/icon_power_status_grey.png" />';
                }
            }
        }
    ];

    gridOptions: any = {
        pagination: true,
        escape: true,
        //sidePagination: 'server',
        pageSize: 10,
        pageList: [10, 25, 50, 100],
        search: true,
        strictSearch: false,
        searchText: '',
        paginationDetailHAlign: 'left',
        paginationHAlign: 'left',
        clickToSelect: false,
        sortable: true,
        sortName:'name',
        sortOrder:'asc'
    };

    constructor(private translate: TranslateService,
                private storageService: StorageService) {
        if (this.storageService.getCurrentLang() === 'en') {
            $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
        } else {
            $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
        }
    }

    ngOnInit() {
        const that = this;
        that.isShowLoading = true;
        setTimeout(function () {
            that.isShowLoading = false;
        }, 8000);
        that.initTable();
        that.startReloadInterval();
    }

    initTable() {
        const that = this;
        const $table = $('#table-global-bare-metals');
        $table.bootstrapTable($.extend(this.gridOptions, {
            url: `${appConfig.vrmServiceUrl}domainNodes`,
            ajaxOptions: {
                beforeSend: function (xhr) {
                    const accessToken = window.localStorage.directoraccessToken;
                    const username = window.localStorage.directorusername;
                    xhr.setRequestHeader('Access-Token', accessToken);
                    xhr.setRequestHeader('operateuser', username);
                }
            },
            toolbar: '#toolbar-table-global-bare-metals',
            columns: that.columnDefs,
            responseHandler: function (res) {
                return res.nodes;
            },
            onLoadSuccess: function (result) {
                that.isShowLoading = false;
            }
        }));

        $('.bootstrap-table .search input').attr('placeholder', that.translate.instant('WordForFilter'))
            .parent().append(`<span></span>`);
    }

    refreshGlobalBareMetals() {
        const $table = $('#table-global-bare-metals');
        $table.bootstrapTable('refresh', {silent: true});
    }

    startReloadInterval() {
        const that = this;
        if (that.timerHandle === undefined) {
            that.timerHandle = setInterval(function(){
                that.refreshGlobalBareMetals();
            }, 15000);
        }
    }

    stopReloadInterval() {
        if (this.timerHandle !== undefined) {
            clearInterval(this.timerHandle);
            this.timerHandle = undefined;
        }
    }

    ngOnDestroy() {
        this.stopReloadInterval();
    }
}


