/**
 * Created by root on 4/1/17.
 */
import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/index';

import { routing } from './global-bare-metals.routes';

import { GlobalBareMetalListComponent } from './global-bare-metals.component';

@NgModule({
    imports: [SharedModule, routing],
    declarations: [GlobalBareMetalListComponent]
})

export class GlobalBareMetalModule { }

