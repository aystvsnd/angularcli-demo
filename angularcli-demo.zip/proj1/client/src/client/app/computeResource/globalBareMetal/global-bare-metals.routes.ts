/**
 * Created by root on 4/1/17.
 */
import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GlobalBareMetalListComponent } from './global-bare-metals.component';

const routes: Routes = [
    {
        path: 'globalbaremetals',
        children: [
            {path: '', component: GlobalBareMetalListComponent},
            {path: ':status', component: GlobalBareMetalListComponent},
        ]
    }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);

