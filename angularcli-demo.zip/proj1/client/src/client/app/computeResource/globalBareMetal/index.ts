/**
 * Created by root on 4/1/17.
 */
export * from './global-bare-metals.module';
export * from './global-bare-metals.component';

