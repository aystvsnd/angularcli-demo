/**
 * Created by root on 4/15/17.
 */
import { Component, OnInit, OnDestroy } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { StorageService } from '../../storage.service';
import { appConfig } from '../../app.config';

@Component({
    moduleId: module.id,
    templateUrl: 'global-bare-metal-servers.component.html',
})

export class GlobalBareMetalServersComponent implements OnInit, OnDestroy {
    isShowLoading = false;
    timerHandle : any;
    status : any = 'all';
    searchFields : any = 'name;dc;cloudEnv;ip;state;powerState';
    window: window = window;
    columnDefs: any[] = [
        {
            field: 'name',
            title: this.translate.instant('Name'),
            class: 'table-wrap',
            sortable: true
        },
        {
            field: 'dc',
            title: this.translate.instant('computeRes.dcName'),
            class: 'table-wrap',
            sortable: true
        },
        {
            field: 'cloudEnv',
            title: this.translate.instant('computeRes.homeEnv'),
            class: 'table-wrap',
            sortable: true
        },
        {
            field: 'ip',
            title: this.translate.instant('computeRes.ip'),
            sortable: true
        },
        {
            field: 'state',
            title: this.translate.instant('Status'),
            width: '165',
            sortable: true,
            formatter: (value, row, index) => {
                if (row.state) {
                    if ((value.indexOf('ing') >= 0) && (value !== 'building') && (value !== 'migrating')) {
                        return '<img class="status-img" style="margin-right:6px;width:30px;height:13px;"' +
                            'src="assets/images/loading_grey.gif" />' + value;
                    } else {
                        switch (value) {
                            case 'active':
                                return '<img class="status-img" style="margin-right: 6px;"' +
                                    'src="assets/images/status/icon_status_green.png" />' + value;
                            case 'paused':
                                return '<img class="status-img" style="margin-right: 6px;"' +
                                    'src="assets/images/status/icon_status_grey.png" />' + value;
                            case 'building':
                            case 'migrating':
                                return '<img class="status-img" style="margin-right: 6px;"' +
                                    'src="assets/images/status/icon_status_blue.png" />' + value;
                            case 'error':
                                return '<img class="status-img" style="margin-right: 6px;"' +
                                    'src="assets/images/status/icon_status_red.png" />' + value;
                            default:
                                return '<img class="status-img" style="margin-right: 6px;"' +
                                    'src="assets/images/status/icon_status_grey.png" />' + value;
                        }
                    }
                } else {
                    return '<img class="status-img" src="assets/images/status/icon_status_grey.png" />';
                }
            }
        },
        {
            field: 'powerState',
            title: this.translate.instant('computeRes.powerState'),
            width: '140',
            sortable: true,
            formatter: function (value, row, index) {
                if (row.powerState) {
                    if (value === 'running') {
                        return `<img class="status-img" style="margin-right: 6px;"
                            src="assets/images/status/icon_power_status_green.png" />` + value;
                    } else if ((value === 'paused') || (value === 'shutdown') || (value === 'no state')) {
                        return `<img class="status-img" style="margin-right: 6px;"
                            src="assets/images/status/icon_power_status_grey.png" />` + value;
                    } else {
                        return `<img class="status-img" style="margin-right: 6px;"
                     src="assets/images/status/icon_power_status_red.png" />` + value;
                    }
                } else {
                    return '<img class="status-img" src="assets/images/status/icon_power_status_grey.png" />';
                }
            }
        }
    ];

    gridOptions: any = {
        pagination: true,
        escape: true,
        sidePagination: 'server',
        pageSize: 10,
        pageList: [10, 25, 50, 100],
        search: true,
        strictSearch: true,
        searchText: '',
        paginationDetailHAlign: 'left',
        paginationHAlign: 'left',
        clickToSelect: false,
        sortable: true,
        sortName: 'name',
        sortOrder: 'asc'
    };

    constructor(private translate: TranslateService,
                private storageService: StorageService) {
        this.timerHandle = undefined;
        if (this.storageService.getCurrentLang() === 'en') {
            $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
        } else {
            $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
        }
    }

    ngOnInit() {
        const that = this;
        that.isShowLoading = true;
        setTimeout(function () {
            that.isShowLoading = false;
        }, 10000);
        that.initTable();
        that.startReloadInterval();
    }

    initTable() {
        const that = this;
        const $table = $('#table-global-baremetal-servers');
        $table.bootstrapTable($.extend(this.gridOptions, {
            url: `${appConfig.vrmServiceUrl}vms?state=${that.status}&type=ironic`,
            sidePagination: 'server',
            ajaxOptions: {
                beforeSend: function (xhr) {
                    const accessToken = window.localStorage.directoraccessToken;
                    const username = window.localStorage.directorusername;
                    xhr.setRequestHeader('Access-Token', accessToken);
                    xhr.setRequestHeader('operateuser', username);
                }
            },
            queryParams: function(params){
                return {
                    search: params.search,
                    pagesize : params.limit,
                    currentpage: params.offset / params.limit + 1,
                    sort: params.sort,
                    order: params.order,
                    fuzzy: that.searchFields
                };
            },
            dataField: 'vmInfo',
            //toolbar: '#toolbar1',
            columns: this.columnDefs
        }));

        $('.bootstrap-table .search input').attr('placeholder', that.translate.instant('WordForFilter'))
            .parent().append(`<span></span>`);

        that.setTableFooter();
    }

    setTableFooter() {
        const that = this;
        const $table = $('#table-global-baremetal-servers');
        $table.on('load-success.bs.table', function (result) {
            that.isShowLoading = false;
        });
    }

    refreshGlobalBareMetalServerList() {
        const $table = $('#table-global-baremetal-servers');
        $table.bootstrapTable('refresh', {silent: true});
    }

    startReloadInterval() {
        const that = this;
        if (that.timerHandle === undefined) {
            that.timerHandle = setInterval(function(){
                that.refreshGlobalBareMetalServerList();
            }, 15000);
        }
    }

    stopReloadInterval() {
        if (this.timerHandle !== undefined) {
            clearInterval(this.timerHandle);
            this.timerHandle = undefined;
        }
    }

    ngOnDestroy() {
        this.stopReloadInterval();
    }
}

