/**
 * Created by root on 4/15/17.
 */
import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/index';

import { routing } from './global-bare-metal-servers.routes';

import { GlobalBareMetalServersComponent } from './global-bare-metal-servers.component';

@NgModule({
    imports: [SharedModule, routing],
    declarations: [GlobalBareMetalServersComponent]
})

export class GlobalBareMetalServerModule { }

