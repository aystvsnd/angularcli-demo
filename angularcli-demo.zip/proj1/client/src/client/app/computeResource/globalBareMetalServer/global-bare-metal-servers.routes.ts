/**
 * Created by root on 4/15/17.
 */
import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GlobalBareMetalServersComponent } from './global-bare-metal-servers.component';

const routes: Routes = [
    {
        path: 'globalbaremetalservers',
        children: [
            {path: '', component: GlobalBareMetalServersComponent},
            {path: ':status', component: GlobalBareMetalServersComponent}
        ]
    }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);

