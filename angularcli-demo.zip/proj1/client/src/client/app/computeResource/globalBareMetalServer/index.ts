/**
 * Created by root on 4/15/17.
 */
export * from './global-bare-metal-servers.component';
export * from './global-bare-metal-servers.module';
