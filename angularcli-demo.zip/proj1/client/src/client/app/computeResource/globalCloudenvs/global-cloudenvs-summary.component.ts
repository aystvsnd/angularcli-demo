import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { appConfig } from '../../app.config';
import {TranslateService} from '@ngx-translate/core';
import { StorageService } from '../../storage.service';
import { ApiResourceService as Http } from '../../apiResource.service';
import { ComputeResourceService } from '../compute-resource.service';

@Component({
    moduleId: module.id,
    templateUrl: 'global-cloudenvs-summary.component.html',
})

export class GlobalCloudenvsummaryComponent implements OnInit {
    //tryDelCloudenv : any;
    delglobalCloudenvMessage : any = {
        title: this.translate.instant('computeRes.delEnv'),
        message: this.translate.instant('computeRes.delEnvMsg1') + this.translate.instant('computeRes.delEnvMsg2'),
        confirmText: this.translate.instant('computeRes.confirmText'),
        cancelText: this.translate.instant('computeRes.cancelText'),
        type: 'exclamation'
    };
    isShowInfo = false;
    infoMsgs: string[] = [this.translate.instant('computeRes.delEnvSucc')];
    isShowLoading = false;
    status : any;
    isShowLinks = false;
    links : any ;
    window: window= window;
    rowData : Array<any> = [];
    columnDefs : any[] = [
        {
            field: 'envName',
            sortable: true,
            title: this.translate.instant('computeRes.envName'),
            class: 'table-wrap'
        },
        {
            field: 'envType',
            sortable: true,
            title: this.translate.instant('computeRes.envType'),
            class: 'table-wrap',
            formatter: function(value, row, index) {
                if (row.envType && (row.envType !== null) && (row.envType !== '')) {
                    if (value === 'openstack') {
                        return 'openstack + kvm';
                    } else {
                        return 'openstack + vcenter';
                    }
                } else {
                    return '';
                }
            }
        },
        {
          field: 'description',
          sortable: true,
          title: this.translate.instant('gengyun.description')
        },
        {
            field: 'dcName',
            sortable: true,
            title: this.translate.instant('computeRes.dcName'),
            class: 'table-wrap'
        },
        {
            field: 'azNum',
            sortable: true,
            title: this.translate.instant('computeRes.az'),
            visible: false
        },
        {
            field: 'haNum',
            sortable: true,
            title: this.translate.instant('computeRes.haNum'),
            visible: false
        },
        {
            field: 'hostNum',
            sortable: true,
            title: this.translate.instant('Host'),
            visible: false
        },
        {
            field: 'vmNum',
            sortable: true,
            title: this.translate.instant('VirMachine'),
            visible: false
        },
        {
            field: 'url',
            title: this.translate.instant('computeRes.url'),
            sortable: true,
            searchFormatter: false,
            events: 'operateEvents',
            formatter: function(value, row, index) {
                return '<a href="javascript:void(0);" class="admin_uri">' + value + '</a>';
            }
        },
        {
            field: 'userName',
            sortable: true,
            title: this.translate.instant('Username'),
            visible: false
        },
        {
            field: 'password',
            title: this.translate.instant('Password'),
            visible: false,
            formatter: function (value, row, index) {
                return '******';
            }
        },
        {
            field: 'status',
            sortable: true,
            title: this.translate.instant('Status'),
            width: '130',
            searchFormatter: false,
            formatter: function (value, row, index) {
                if (row.status) {
                    if (value === 'normal') {
                        return '<img class="status-img" style="margin-right: 6px;" src="assets/images/status/icon_status_green.png" />' + value;
                    } else {
                        return '<img class="status-img" style="margin-right: 6px;" src="assets/images/status/icon_status_red.png" />' + value;
                    }
                } else {
                    return '<img class="status-img" src="assets/images/status/icon_status_grey.png" />';
                }
            }
        }
        /*{
            field: 'oper',
            title: this.translate.instant('Operation'),
            width: '80px',
            formatter: function (value, row, index) {
                return '-';
            }
        }*/
    ];

    gridOptions : any = {
        escape: true,
        pagination: true,
        //sidePagination: 'server',
        pageSize: 10,
        pageList: [10, 25, 50, 100],
        search: true,
        strictSearch: false,
        searchText: '',
        paginationDetailHAlign: 'left',
        paginationHAlign: 'left',
        clickToSelect: false,
        sortable: true,
        sortName: 'envName',
        sortOrder: 'asc',
        showPaginationswitch: true,
        undefinedText: '',
        showColumns: true,
        minimumCountColumns: 6,
        iconSize: 'sm'
    };

    constructor(private route : ActivatedRoute, public http : Http, private computeResourceService: ComputeResourceService,
                private translate: TranslateService, private storageService: StorageService) {
        const that = this;
        const dashboardUrl = this.computeResourceService.getDashboardUrl();

        that.links = [{name: this.translate.instant('computeRes.dashboard'), url: dashboardUrl},
            {name: this.translate.instant('computeRes.abnormalEnv')}];

        if (this.storageService.getCurrentLang() === 'en') {
            $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
        } else {
            $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
        }

      this.window.operateEvents = {
          'click .admin_uri': function(e, value, row, index){
              const i = row.url.indexOf(':');
              const providerprotocol: any = row.url.substring(0, i + 1);
              const ipstr: string = that.window.location.hostname;
              that.http.get(`${appConfig.vrmServiceUrl}users/${window.localStorage.directorid}/cloudenv/${row.id}`)
                  .toPromise().then(function (res) {
                      const msbPort = res.json().msbPort;
                      const userNameEncrypt: any = window.btoa(res.json().aaa);
                      const passwordEncrypt: any = window.btoa(res.json().bbb);
                      const langEncrypt: any = window.btoa(that.storageService.getCurrentLang());
                      if ('0' === msbPort) {
                          const url = row.url + '/#/login?username=' + userNameEncrypt + '&pwd=' +
                              passwordEncrypt + '&lang=' + langEncrypt;
                          that.gotoOpenstack(url);
                      } else {
                          const httpurl = providerprotocol + '//' + ipstr + ':' + msbPort + '/#/login?username=' +
                              userNameEncrypt + '&pwd=' + passwordEncrypt + '&lang=' + langEncrypt;
                          that.gotoOpenstack(httpurl);
                      }
                  });
          }
      };
    }


    ngOnInit() {
        const that = this;
        that.route.params.subscribe(params => {
            that.status = params['status'];
            if (that.status === 'abnormal') {
                that.isShowLinks = true;
            }
        });
        that.isShowLoading = true;
        setTimeout(function () {
            that.isShowLoading = false;
        }, 8000);
        that.initTable();
    }

    initTable() {
        const that = this;
        const $table = $('#table-global-cloudenvs');
        $table.bootstrapTable($.extend(that.gridOptions, {

            url: `${appConfig.vrmServiceUrl}domain/cloudenvs?state=${that.status}`,
            //sidePagination: 'server',
            ajaxOptions: {},
            toolbar: '#toolbar-table-global-cloudenvs',
            columns: that.columnDefs,
            responseHandler: function (res) {
                return res.domainEnvs;
            },
            onLoadSuccess: function (result) {
                that.isShowLoading = false;
            }
        }));
        $('.bootstrap-table .search input').attr('placeholder', that.translate.instant('WordForFilter'))
            .parent().append(`<span></span>`).css('marginRight', '10px');
    }

    gotoOpenstack(url: any) {
        window.open(url);
    }

    sureDel() {
        const that = this;
        console.log('todo-delete');
        that.isShowInfo = !that.isShowInfo;
        setTimeout(function () {
            that.isShowInfo = false;
        }, 2000);
    }
}
