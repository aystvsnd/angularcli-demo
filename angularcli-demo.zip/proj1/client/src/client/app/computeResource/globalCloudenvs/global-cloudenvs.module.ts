import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/index';
import { routing } from './global-cloudenvs.routes';

import { GlobalCloudenvsummaryComponent } from './global-cloudenvs-summary.component';

@NgModule({
  imports: [SharedModule, routing],
  declarations: [GlobalCloudenvsummaryComponent],
})

export class GlobalCloudenvModule { }
