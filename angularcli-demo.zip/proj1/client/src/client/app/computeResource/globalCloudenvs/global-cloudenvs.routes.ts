import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GlobalCloudenvsummaryComponent } from './global-cloudenvs-summary.component';

const routes: Routes = [
  {
    path: 'globalcloudenvs',
    children: [
      {path: '', component: GlobalCloudenvsummaryComponent},
      {path: ':status', component: GlobalCloudenvsummaryComponent},
    ]
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
