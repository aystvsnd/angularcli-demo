import { Injectable } from '@angular/core';
//import { Response } from '@angular/http';
import {ApiResourceService as Http} from '../../apiResource.service';

@Injectable()
export class GlobalCloudenvsService {

    constructor(public http: Http) {}
    /*
     getAllCloudenvs() {

     }
     */
}
