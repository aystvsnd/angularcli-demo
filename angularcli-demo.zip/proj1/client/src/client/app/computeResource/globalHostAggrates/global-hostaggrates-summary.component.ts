import { Component, OnInit } from '@angular/core';
import { appConfig } from '../../app.config';
import {TranslateService} from '@ngx-translate/core';
import { StorageService } from '../../storage.service';

@Component({
    moduleId: module.id,
    templateUrl: 'global-hostaggrates-summary.component.html',
})

export class GlobalHostAggratesummaryComponent implements OnInit {
    tryDelAggrate : any;
    delglobalAggrateMessage : any = {
        title: this.translate.instant('computeRes.delAggrate'),
        message: this.translate.instant('computeRes.delAggMsg1') + this.translate.instant('computeRes.delAggMsg2'),
        confirmText: this.translate.instant('computeRes.confirmText'),
        cancelText: this.translate.instant('computeRes.cancelText'),
        type: 'exclamation'
    };
    isShowInfo = false;
    infoMsgs: string[] = [this.translate.instant('computeRes.delAggSucc')];
    isShowLoading = false;

    window: window= window;
    rowData : Array<any> = [];
    columnDefs : any[] = [
        {
            field: 'haName',
            sortable: true,
            title: this.translate.instant('computeRes.haName'),
            class: 'table-wrap',
            formatter: function (value, row, index) {
                if ((value === undefined) || (value === null)) {
                    return '-';
                }
                return _.first(value.split('.'));
            }
        },
        {
            field: 'description',
            sortable: true,
            title: this.translate.instant('Description'),
            class: 'table-wrap',
            formatter: (value, row, index) => {
                if ((value === undefined) || (value === null)) {
                    return '';
                }
                return value;
            }
        },
        {
            field: 'dcName',
            sortable: true,
            title: this.translate.instant('computeRes.dcName'),
            class: 'table-wrap'
        },
        {
            field: 'envName',
            sortable: true,
            title: this.translate.instant('computeRes.homeEnv'),
            class: 'table-wrap'
        },
        {
            field: 'azName',
            sortable: true,
            title: this.translate.instant('computeRes.homeAz'),
            class: 'table-wrap'
        },
        {
            field: 'attribute',
            title: this.translate.instant('computeRes.attribute'),
          formatter: (value, row, index) => {
            return this.getAttribute(value);
          }
        },
        {
            field: 'hostNum',
            sortable: true,
            title: this.translate.instant('Host')
        },
        {
            field: 'createTime',
            sortable: true,
            title: this.translate.instant('computeRes.createTime'),
            formatter: function (value, row, index) {
                if ((row.createTime === undefined) || (row.createTime === null)) {
                    return '-';
                }
                const time : any = value.substr(0, 19) ;
                const year : any = value.substr(value.length - 4, 4) ;
                return time + ' ' + year;
            }
        }
        /*{
            field: 'oper',
            title: this.translate.instant('Operation'),
            width: '80px',
            formatter: function (value, row, index) {
                return '-';
            }
            events: 'operateEvents',
            formatter: function (value, row, index) {
                return '<div class="btn-group table-operate-float">\
                            <button class="btn btn-default delete table-operate-btn" \
                                data-toggle="modal" data-target="#deleteGlobalAggrateModal">删除</button>\
                            <button class="btn btn-default dropdown-toggle table-operate-btn" id="dropdownMenu" \
                                data-toggle="dropdown" ><span class="caret"></span>\
                            </button>\
                            <ul class="dropdown-menu dropdown-menu-top table-operate-ulfont" role="menu" aria-labelledby="dropdownMenu">\
                                <li role="presentation">\
                                    <a href="javascript:void(0);" class="delete" data-toggle="modal" \
                                        data-target="#deleteGlobalAggrateModal">删除</a>\
                                </li>\
                             </ul>\
                        </div>';
            }
        }*/
    ];

    gridOptions : any = {
        pagination: true,
        escape: true,
        //sidePagination: 'server',
        pageSize: 10,
        pageList: [10, 25, 50, 100],
        search: true,
        strictSearch: false,
        searchText: '',
        paginationDetailHAlign: 'left',
        paginationHAlign: 'left',
        clickToSelect: false,
        sortable: true,
        sortName:'haName',
        sortOrder:'asc',
        showPaginationswitch: true,
        undefinedText: ''
    };

    constructor(private translate: TranslateService, private storageService: StorageService) {
        if (this.storageService.getCurrentLang() === 'en') {
            $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
        } else {
            $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
        }
    }


    ngOnInit() {
        const that = this;
        that.isShowLoading = true;
        setTimeout(function () {
            that.isShowLoading = false;
        }, 8000);
        that.initTable();
    }

    initTable() {
        const that = this;
        const $table = $('#table-global-aggragates');
        $table.bootstrapTable($.extend(that.gridOptions, {
            url: `${appConfig.vrmServiceUrl}os-aggregates`,
            //sidePagination: 'server',
            ajaxOptions: {},
            toolbar: '#toolbar-table-global-aggragates',
            columns: that.columnDefs,
            responseHandler: function (res) {
                return res.domainHas;
            },
            onLoadSuccess: function (result) {
                that.isShowLoading = false;
            }
        }));
        $('.bootstrap-table .search input').attr('placeholder', that.translate.instant('WordForFilter'))
            .parent().append(`<span></span>`);
    }

    getAttribute(attribute : any) {
        const tempAttribute  : any[] = [];
        let keyView : any;
        let valueView : any;
        const newattributes = attribute.substring(0, attribute.length - 1).split(';');
        tempAttribute.push('<span>');
        if ((newattributes !== undefined) && (newattributes !== null)) {
          for (const newattribute of newattributes) {
            keyView = newattribute.substr(0, newattribute.indexOf('='));
            valueView = newattribute.substring(newattribute.indexOf('=') + 1);
            if (keyView === 'hw:compute_type') {
              keyView = this.getKeyView(keyView);
            }  else if (keyView === 'hugepagesize') {
              keyView = this.getKeyView(keyView);
              valueView = valueView + ' kb';
            } else if (keyView === 'Phynets') {
              keyView = this.getKeyView(keyView);
            }

            if (valueView !== '') {
              if (tempAttribute.length === 1) {
                  tempAttribute.push(keyView + ': ' + valueView);
              } else {
                tempAttribute.push('<br/>' + keyView + ': ' + valueView);
             }
            }
          }
        }
      tempAttribute.push('</span>');
      return tempAttribute.join('');
    }

    getKeyView(keyView : any) {
      switch (keyView) {
        case 'hugepagesize':
          return this.translate.instant('flavor.hugepagesize');
        case 'Phynets':
          return this.translate.instant('flavor.Phynets');
        default:
          return keyView;
      }
    }

    sureDel() {
        const that = this;
        console.log('todo-delete');
        that.isShowInfo = !that.isShowInfo;
        setTimeout(function () {
            that.isShowInfo = false;
        }, 2000);
    }
}
