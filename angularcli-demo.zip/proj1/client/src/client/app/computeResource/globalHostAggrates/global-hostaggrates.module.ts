import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/index';

import { routing } from './global-hostaggrates.routes';

import { GlobalHostAggratesummaryComponent } from './global-hostaggrates-summary.component';

@NgModule({
  imports: [SharedModule, routing],
  declarations: [GlobalHostAggratesummaryComponent],
})

export class GlobalHostAggrateModule { }
