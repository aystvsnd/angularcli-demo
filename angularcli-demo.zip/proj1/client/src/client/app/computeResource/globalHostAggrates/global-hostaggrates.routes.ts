import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GlobalHostAggratesummaryComponent } from './global-hostaggrates-summary.component';

const routes: Routes = [
  {
    path: 'globalaggrates',
    children: [
      {path: '', component: GlobalHostAggratesummaryComponent},
    ]
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
