/**
 * Created by root on 9/19/16.
 */
import { Injectable } from '@angular/core';
//import { Response } from '@angular/http';
import {ApiResourceService as Http} from '../../apiResource.service';
//import { appConfig } from '../../AppCfg';

@Injectable()
export class GlobalHostAggratesService {

    constructor(public http: Http) {}
    /*
     getAllHostAggrates() {

     }
     */
}
