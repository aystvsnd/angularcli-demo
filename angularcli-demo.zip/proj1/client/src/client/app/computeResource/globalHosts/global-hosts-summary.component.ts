import { Component, OnInit } from '@angular/core';
import { appConfig } from '../../app.config';
import { ActivatedRoute } from '@angular/router';
import {TranslateService} from '@ngx-translate/core';
import { StorageService } from '../../storage.service';
import { ComputeResourceService } from '../compute-resource.service';

@Component({
  moduleId: module.id,
  templateUrl: 'global-hosts-summary.component.html',
})

export class GlobalHostSummaryComponent implements OnInit {
    status : any;
    isShowLinks = false;
    links : any;
    isShowLoading = false;
    searchFields : any = 'name;dcName;cloudEnv;zone;ha;state;occupied;total';
    window: window = window;
    columnDefs: any[] = [
        {
          field: 'name',
          title: this.translate.instant('computeRes.hostName'),
          class: 'table-wrap',
          sortable: true,
          formatter: function (value, row, index) {
              if ((value === undefined) || (value === null)) {
                  return '-';
              }
              return _.last(value.split(':'));
          }
        },
        {
          field: 'dcName',
          title: this.translate.instant('computeRes.dcName'),
          class: 'table-wrap',
          sortable: true
        },
        {
          field: 'cloudEnv',
          title: this.translate.instant('computeRes.homeEnv'),
          class: 'table-wrap',
          sortable: true
        },
        {
          field: 'zone',
          title: this.translate.instant('computeRes.homeAz'),
          class: 'table-wrap'
        },
        {
          field: 'ha',
          title: this.translate.instant('computeRes.homeAgg'),
          class: 'table-wrap',
          sortable: true,
          formatter: function (value, row, index) {
              if ((value === undefined) || (value === null)) {
                  return '-';
              }
              return _.first(value.split('.'));
          }
        },
        {
          field: '',
          title: this.translate.instant('computeRes.core'),
          formatter: (value, row, index) => {
            return this.getCore(row);
          }
        },
        {
          field: '',
          title: this.translate.instant('computeRes.ram'),
          formatter: (value, row, index) => {
            return this.getRam(row);
          }
        },
        {
          field: '',
          title: this.translate.instant('computeRes.disk'),
          formatter: (value, row, index) => {
            return this.getDisk(row);
          }
        },
        /*
        {
          field: '',
          title: '操作',
          events: 'operateEvents',
           formatter: function (value, row, index) {
           return `<a href="javascript:void(0);" class="allocate">分配VDC</a>&nbsp;&nbsp;
           <a href="javascript:void(0);;" class="free">释放VDC</a>`;
           }
        }*/
        {
            field: 'state',
            title: this.translate.instant('Status'),
            width: '100',
            sortable: true,
            formatter: function (value, row, index) {
                if (row.state) {
                    if (value === 'normal') {
                        return '<img class="status-img" style="margin-right: 6px;" src="assets/images/status/icon_status_green.png" />' + value;
                    } else {
                        return '<img class="status-img" style="margin-right: 6px;" src="assets/images/status/icon_status_red.png" />' + value;
                    }
                } else {
                    return '<img class="status-img" src="assets/images/status/icon_status_grey.png" />';
                }
            }
        }
    ];

    gridOptions: any = {
        pagination: true,
        escape: true,
        sidePagination: 'server',
        pageSize: 10,
        pageList: [10, 25, 50, 100],
        search: true,
        strictSearch: false,
        searchText: '',
        paginationDetailHAlign: 'left',
        paginationHAlign: 'left',
        clickToSelect: false,
        sortable: true,
        sortName: 'name',
        sortOrder: 'asc'
    };

    constructor(private route : ActivatedRoute, private translate: TranslateService,
                private computeResourceService: ComputeResourceService, private storageService: StorageService) {
        // var that = this;
        const dashboardUrl = this.computeResourceService.getDashboardUrl();
        this.links  = [{name: this.translate.instant('computeRes.dashboard'), url: dashboardUrl},
            {name: this.translate.instant('computeRes.abnormalHost')}];

        if (this.storageService.getCurrentLang() === 'en') {
            $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
        } else {
            $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
        }
    }

    ngOnInit() {
        const that = this;
        that.route.params.subscribe(params => {
            that.status = params['status'];
            if (that.status === 'abnormal') {
                that.isShowLinks = true;
            }
        });
        that.isShowLoading = true;
        setTimeout(function () {
          that.isShowLoading = false;
        }, 8000);
        that.initTable();
    }

    getCore(row : any) {
        if (row.resourceInfo) {
          const allPris = row.resourceInfo.core.occupied + '/'
            + Math.round(row.resourceInfo.core.total * row.resourceInfo.core.ratio) + '/'
            + row.resourceInfo.core.total;
          let aa = '';
          aa = this.translate.instant('computeRes.Occupied') + ':' + row.resourceInfo.core.occupied + '\n'
            + this.translate.instant('computeRes.ExcessTotal') + ':' +
            Math.round(row.resourceInfo.core.total * row.resourceInfo.core.ratio) + '\n'
            + this.translate.instant('computeRes.Total') + ':' + row.resourceInfo.core.total;
          return '<span class="tooltipStyle" title="' + aa + '" data-toggle="tooltip">' + allPris + '</span>';
        } else {
          return '-';
        }
      }

    getRam(row : any) {
      if (row.resourceInfo) {
        const allPris = Math.round(row.resourceInfo.memory.occupied / 1024) + '/'
          + Math.round(row.resourceInfo.memory.total * row.resourceInfo.memory.ratio / 1024) + '/'
          + Math.round(row.resourceInfo.memory.total / 1024);
        let aa = '';
        aa = this.translate.instant('computeRes.Occupied') + ':' + Math.round(row.resourceInfo.memory.occupied / 1024) + '\n'
          + this.translate.instant('computeRes.ExcessTotal') + ':' +
          Math.round(row.resourceInfo.memory.total * row.resourceInfo.memory.ratio / 1024) + '\n'
          + this.translate.instant('computeRes.Total') + ':' + Math.round(row.resourceInfo.memory.total / 1024);
        return '<span class="tooltipStyle" title="' + aa + '" data-toggle="tooltip">' + allPris + '</span>';
      } else {
        return '-';
      }
    }

    getDisk(row : any) {
      if (row.resourceInfo) {
        const allPris = row.resourceInfo.disk.occupied + '/'
          + row.resourceInfo.disk.provisioned + '/'
          + Math.round(row.resourceInfo.disk.total * row.resourceInfo.disk.ratio - row.resourceInfo.disk.occupied) + '/'
          + (row.resourceInfo.disk.total - row.resourceInfo.disk.occupied);
        let aa = '';
        aa = this.translate.instant('computeRes.Occupied') + ':' + row.resourceInfo.disk.occupied + '\n'
          + this.translate.instant('computeRes.Provisioned') + ':' + row.resourceInfo.disk.provisioned + '\n'
          + this.translate.instant('computeRes.ExcessFree') + ':' +
          Math.round(row.resourceInfo.disk.total * row.resourceInfo.disk.ratio - row.resourceInfo.disk.occupied) + '\n'
          + this.translate.instant('computeRes.Free') + ':' +
          (row.resourceInfo.disk.total - row.resourceInfo.disk.occupied);
        return '<span class="tooltipStyle" title="' + aa + '" data-toggle="tooltip">' + allPris + '</span>';
      } else {
        return '-';
      }
    }

    initTable() {
    const that = this;
    const $table = $('#table-global-hosts');
    $table.bootstrapTable($.extend(this.gridOptions, {
      //url: AppCfg.vrmServiceUrl + 'domainHosts?state=${that.status}',
      url: `${appConfig.vrmServiceUrl}domainHosts?state=${that.status}`,
      sidePagination: 'server',
      ajaxOptions: {},
        queryParams: function(params){
        return {
          search: params.search,
          pagesize : params.limit,
          currentpage: params.offset / params.limit + 1,
          sort: params.sort,
          order: params.order,
          fuzzy: that.searchFields
        };
        },
        dataField: 'hostInfo',
        //toolbar: '#toolbar1',
        columns: this.columnDefs,
        onLoadSuccess: function (result) {
            that.isShowLoading = false;
        }
    }));

    $('.bootstrap-table .search input').attr('placeholder', that.translate.instant('WordForFilter'))
      .parent().append(`<span></span>`);
    /*
    $table.parents('.fixed-table-container').append(`<div class="fixed-table-footerButtons">
        <input type="checkbox" class="checkAll">
        <!--button disabled>删除</button>-->
    </div>`);

    $table.on('check.bs.table uncheck.bs.table ' +
      'check-all.bs.table uncheck-all.bs.table', function () {
      $('.fixed-table-footerButtons button').prop('disabled', !$table.bootstrapTable('getSelections').length);
    });

      $table.on('check-all.bs.table uncheck-all.bs.table', function () {
          $('.fixed-table-footerButtons .checkAll').prop('checked', $table.bootstrapTable('getSelections').length > 0);
      });

      $('.bootstrap-table .fixed-table-footerButtons .checkAll').change(function () {
          if ($(this).prop('checked')) {
              $table.bootstrapTable('checkAll');
          } else {
              $table.bootstrapTable('uncheckAll');
          }
      });
      */
    }
}
