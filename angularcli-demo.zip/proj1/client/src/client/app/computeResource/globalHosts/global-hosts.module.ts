import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/index';
import { routing } from './global-hosts.routes';
import { GlobalHostSummaryComponent } from './global-hosts-summary.component';

@NgModule({
  imports: [SharedModule, routing],
  declarations: [GlobalHostSummaryComponent],
})

export class GlobalHostModule { }
