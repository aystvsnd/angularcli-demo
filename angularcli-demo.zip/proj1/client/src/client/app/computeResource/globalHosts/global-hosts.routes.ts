import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GlobalHostSummaryComponent } from './global-hosts-summary.component';

const routes: Routes = [
  {
    path: 'globalhosts',
    children: [
      {path: '', component: GlobalHostSummaryComponent},
      {path: ':status', component: GlobalHostSummaryComponent},
    ]
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
