import { Injectable } from '@angular/core';
import { Response } from '@angular/http';
import {ApiResourceService as Http} from '../../apiResource.service';
import { appConfig } from '../../app.config';

@Injectable()
export class GlobalHostsService {

  constructor(public http: Http) {}
  /*
  getAllHosts() {

    return this.http.get(`${appConfig.vrmServiceUrl}cloudenvs/${cloudEnvId}/hosts`)
      .toPromise().then((res:Response)=> {return res.json().hosts;})
  }
   */
  getAllHosts() {

    return this.http.get(`${appConfig.vrmServiceUrl}/domainHosts`)
      .toPromise().then((res: Response) => {return res.json(); });
  }
}
