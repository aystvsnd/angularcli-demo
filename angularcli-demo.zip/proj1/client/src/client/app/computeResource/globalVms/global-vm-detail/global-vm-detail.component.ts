/**
 * Created by root on 1/6/17.
 */
import { Component, OnInit } from '@angular/core';
import { GlobalVmsService } from '../global-vms.service';
import { ActivatedRoute } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { ComputeResourceService } from '../../compute-resource.service';

@Component({
    moduleId: module.id,
    templateUrl: 'global-vm-detail.component.html',
})

export class GlobalVmDetailComponent implements OnInit {
    id : any;
    state : any;
    vmData : any;
    links : any = [];
    isShowLoading = false;

    constructor(private globalVmsService: GlobalVmsService, private computeResourceService: ComputeResourceService,
                private translate: TranslateService, private activatedRoute : ActivatedRoute) {
        const dashboardUrl = this.computeResourceService.getDashboardUrl();

        this.activatedRoute.params.subscribe(params => {
            this.state = params['state'];
            this.id = params['id'];
            if (this.state === 'all') {
                this.links = [
                    {name: this.translate.instant('computeRes.globalVm'), url: '/main/computeResource/globalvms/all'},
                    {name: ''}];
            } else {
                this.links = [
                    {name: this.translate.instant('computeRes.dashboard'), url: dashboardUrl},
                    {name: this.translate.instant('computeRes.abnormalVm'), url: '/main/computeResource/globalvms/abnormal'},
                    {name: ''}];
            }
        });
    }

    ngOnInit() {
        const that = this;
        that.isShowLoading = true;
        that.globalVmsService.getOneVm(that.id).then((res : any) => {
            if (res.length !== 0) {
                that.vmData = res[0];
                that.setVmData();
                if (that.state === 'all') {
                    that.links[1].name = that.vmData.name;
                } else {
                    that.links[2].name = that.vmData.name;
                }
            }
            that.isShowLoading = false;
        });
    }

    setVmData() {
        const that = this;
        if ((that.vmData.ha !== undefined) && (that.vmData.ha !== null)) {
            this.vmData.ha = _.first(that.vmData.ha.split('.'));
        } else {
            this.vmData.ha = '-';
        }
        if ((that.vmData.host !== undefined) && (that.vmData.host !== null)) {
            this.vmData.host = _.last(that.vmData.host.split(':'));
        } else {
            this.vmData.host = '-';
        }
        that.setVmPowerStateName();
    }

    setVmPowerStateName() {
        switch (this.vmData.powerState) {
            case 'running':
                this.vmData.powerStateName = 'running';
                break;
            case 'paused':
                this.vmData.powerStateName = 'paused';
                break;
            case 'shutdown':
                this.vmData.powerStateName = 'shutdown';
                break;
            case 'no state':
                this.vmData.powerStateName = 'no state';
                break;
            default:
                this.vmData.powerStateName = 'abnormal';
                break;
        }
    }
}
