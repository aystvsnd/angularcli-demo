/**
 * Created by root on 1/9/17.
 */
export * from './global-vm-detail.component';
