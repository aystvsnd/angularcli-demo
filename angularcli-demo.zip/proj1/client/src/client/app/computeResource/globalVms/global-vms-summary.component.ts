import { Component, OnInit, OnDestroy } from '@angular/core';
import { appConfig } from '../../app.config';
import { GlobalVmsService } from './global-vms.service';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { StorageService } from '../../storage.service';
import { AuthService } from '../../core/index';
import { ComputeResourceService } from '../compute-resource.service';

@Component({
  moduleId: module.id,
  templateUrl: 'global-vms-summary.component.html',
})

export class GlobalVmSummaryComponent implements OnInit, OnDestroy {
    isShowLoading = false;
    timerHandle : any;
    window: window = window;
    id: any;
    data: any;
    polldata : any;
    rebootVm : any;
    pauseVm : any;
    unpauseVm : any;
    vmOperMessage : any = {
        title: '',
        message: '',
        confirmText: '',
        cancelText: this.translate.instant('Cancel'),
        type: 'exclamation'
    };
    status : any;
    isShowLinks = false;
    links : any;
    infoMsgs: string[] = [this.translate.instant('computeRes.OperationSucceeded')];
    isShowInfo: boolean;
    selectedRows : any[] = [];
    isShowOperLoading = false;
    loadingOperTitle : any = this.translate.instant('computeRes.vmOpeting');
    operRefreshCount : any = 0;
    operTimerHandle : any = undefined;
    searchFields : any = 'name;dc;cloudEnv;host;ip;state;powerState';

    rowData : Array<any> = [];
    columnDefs: any[] = [
    {
      checkbox: true
    },
    {
      field: 'name',
      title: this.translate.instant('computeRes.vmName'),
      class: 'table-wrap',
      sortable: true,
      events: 'operateEvents',
      formatter: function (value, row, index) {
          return '<a href="javascript:void(0);" class="global_vm_detail">' + value + '</a>';
      }
    },
    {
      field: 'dc',
      title: this.translate.instant('computeRes.dcName'),
      class: 'table-wrap',
      sortable: true,
    },
    {
        field: 'cloudEnv',
        title: this.translate.instant('computeRes.homeEnv'),
        class: 'table-wrap',
        sortable: true,
    },
    {
      field: 'envType',
      title: this.translate.instant('computeRes.resPoolType'),
      class: 'table-wrap',
      sortable: true,
    },
    {
        field: 'host',
        title: this.translate.instant('computeRes.homeHost'),
        class: 'table-wrap',
        sortable: true,
        formatter: function (value, row, index) {
            if ((value === undefined) || (value === null)) {
                return '-';
            }
            return _.last(value.split(':'));
        }
    },
    {
        field: 'ip',
        sortable: true,
        title: this.translate.instant('computeRes.ip'),
        formatter: this.getVms,
        class: 'table-wrap'
    },
    {
        field: 'state',
        title: this.translate.instant('Status'),
        sortable: true,
        width: '165',
        formatter: (value, row, index) => {
            if (row.state) {
                if ((value.indexOf('ing') >= 0) && (value !== 'building') && (value !== 'migrating')) {
                    return '<img class="status-img" style="margin-right:6px;width:30px;height:13px;"' +
                        'src="assets/images/loading_grey.gif" />' + value;
                } else {
                    switch (value) {
                        case 'active':
                            return '<img class="status-img" style="margin-right: 6px;"' +
                                'src="assets/images/status/icon_status_green.png" />' + value;
                        case 'paused':
                            return '<img class="status-img" style="margin-right: 6px;"' +
                                'src="assets/images/status/icon_status_grey.png" />' + value;
                        case 'building':
                        case 'migrating':
                            return '<img class="status-img" style="margin-right: 6px;"' +
                                'src="assets/images/status/icon_status_blue.png" />' + value;
                        case 'error':
                            return '<img class="status-img" style="margin-right: 6px;"' +
                                'src="assets/images/status/icon_status_red.png" />' + value;
                        default:
                            return '<img class="status-img" style="margin-right: 6px;"' +
                                'src="assets/images/status/icon_status_grey.png" />' + value;
                    }
                }
            } else {
                return '<img class="status-img" src="assets/images/status/icon_status_grey.png" />';
            }
        }
    },
    {
        field: 'powerState',
        title: this.translate.instant('computeRes.powerState'),
        sortable: true,
        width: '140',
        formatter: function (value, row, index) {
            if (row.powerState) {
                if (value === 'running') {
                    return `<img class="status-img" style="margin-right: 6px;"
                            src="assets/images/status/icon_power_status_green.png" />` + value;
                } else if ((value === 'paused') || (value === 'shutdown') || (value === 'no state')) {
                    return `<img class="status-img" style="margin-right: 6px;"
                            src="assets/images/status/icon_power_status_grey.png" />` + value;
                } else {
                    return `<img class="status-img" style="margin-right: 6px;"
                     src="assets/images/status/icon_power_status_red.png" />` + value;
                }
            } else {
                return '<img class="status-img" src="assets/images/status/icon_power_status_grey.png" />';
            }
        }
    },
      {
        field: 'oper',
        title: this.translate.instant('Operation'),
        width: '140',
        cellStyle: (value, row, index, field) => {
          return {
            css: {'min-width': '123px'}
          };
        },
        events: 'operateEvents',
        formatter: (value, row, index) => {
          const pausedAction = '<div class="btn-group">\
                            <button class="btn btn-default reboot disabled" data-toggle="modal" \
                                 data-backdrop="static">\
                                ' + this.translate.instant('gengyun.rebootVm') + '</button>\
                            <button class="btn btn-default dropdown-toggle" id="dropdownMenu1" \
                                data-toggle="dropdown" ><span class="caret"></span>\
                            </button>\
                            <ul class="dropdown-menu dropdown-menu-top" role="menu" aria-labelledby="dropdownMenu1">\
                                <li role="presentation" class="disabled">\
                                    <a href="javascript:void(0);" class="pause" data-toggle="modal" \
                                     data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.pauseVm') + '</a>\
                                </li>\
                                <li role="presentation">\
                                    <a href="javascript:void(0);" class="unpause" data-toggle="modal" \
                                    data-target="#UnpauseVmModal" data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.unpauseVm') + '</a>\
                                </li>\
                             </ul>\
                        </div>';
          const suspendedAction = '<div class="btn-group">\
                            <button class="btn btn-default reboot disabled" data-toggle="modal" \
                                  data-backdrop="static">\
                                ' + this.translate.instant('gengyun.rebootVm') + '</button>\
                            <button class="btn btn-default dropdown-toggle" id="dropdownMenu1" \
                                data-toggle="dropdown" ><span class="caret"></span>\
                            </button>\
                            <ul class="dropdown-menu dropdown-menu-top" role="menu" aria-labelledby="dropdownMenu1">\
                                <li role="presentation"  class="disabled">\
                                    <a href="javascript:void(0);" class="pause" data-toggle="modal" \
                                     data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.pauseVm') + '</a>\
                                </li>\
                                <li role="presentation" class="disabled">\
                                    <a href="javascript:void(0);" class="unpause" data-toggle="modal" \
                                    data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.unpauseVm') + '</a>\
                                </li>\
                             </ul>\
                        </div>';
          const shutOffAction = '<div class="btn-group">\
                            <button class="btn btn-default reboot disabled" data-toggle="modal" \
                                  data-backdrop="static">\
                                ' + this.translate.instant('gengyun.rebootVm') + '</button>\
                            <button class="btn btn-default dropdown-toggle" id="dropdownMenu1" \
                                data-toggle="dropdown" ><span class="caret"></span>\
                            </button>\
                            <ul class="dropdown-menu dropdown-menu-top" role="menu" aria-labelledby="dropdownMenu1">\
                                <li role="presentation" class="disabled">\
                                    <a href="javascript:void(0);" class="pause" data-toggle="modal" \
                                     data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.pauseVm') + '</a>\
                                </li>\
                                <li role="presentation" class="disabled">\
                                    <a href="javascript:void(0);" class="unpause" data-toggle="modal" \
                                     data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.unpauseVm') + '</a>\
                                </li>\
                             </ul>\
                        </div>';
          const shelvedAction = '<div class="btn-group">\
                            <button class="btn btn-default reboot disabled" data-toggle="modal" \
                                  data-backdrop="static">\
                                ' + this.translate.instant('gengyun.rebootVm') + '</button>\
                            <button class="btn btn-default dropdown-toggle" id="dropdownMenu1" \
                                data-toggle="dropdown" ><span class="caret"></span>\
                            </button>\
                            <ul class="dropdown-menu dropdown-menu-top" role="menu" aria-labelledby="dropdownMenu1">\
                                <li role="presentation" class="disabled">\
                                    <a href="javascript:void(0);" class="pause" data-toggle="modal" \
                                      data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.pauseVm') + '</a>\
                                </li>\
                                <li role="presentation" class="disabled">\
                                    <a href="javascript:void(0);" class="unpause" data-toggle="modal" \
                                    data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.unpauseVm') + '</a>\
                                </li>\
                             </ul>\
                        </div>';
          const confirmAction = '<div class="btn-group">\
                            <button class="btn btn-default reboot disabled" data-toggle="modal" \
                                 data-backdrop="static">\
                                ' + this.translate.instant('gengyun.rebootVm') + '</button>\
                            <button class="btn btn-default dropdown-toggle" id="dropdownMenu1" \
                                data-toggle="dropdown" ><span class="caret"></span>\
                            </button>\
                            <ul class="dropdown-menu dropdown-menu-top" role="menu" aria-labelledby="dropdownMenu1">\
                                <li role="presentation"  class="disabled">\
                                    <a href="javascript:void(0);" class="pause" data-toggle="modal" \
                                      data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.pauseVm') + '</a>\
                                </li>\
                                <li role="presentation" class="disabled">\
                                    <a href="javascript:void(0);" class="unpause" data-toggle="modal" \
                                    data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.unpauseVm') + '</a>\
                                </li>\
                             </ul>\
                        </div>';
          const errorAction = '<div class="btn-group">\
                            <button class="btn btn-default reboot disabled" data-toggle="modal" \
                                  data-backdrop="static">\
                                ' + this.translate.instant('gengyun.rebootVm') + '</button>\
                            <button class="btn btn-default dropdown-toggle" id="dropdownMenu1" \
                                data-toggle="dropdown" ><span class="caret"></span>\
                            </button>\
                            <ul class="dropdown-menu dropdown-menu-top" role="menu" aria-labelledby="dropdownMenu1">\
                                <li role="presentation"  class="disabled">\
                                    <a href="javascript:void(0);" class="pause" data-toggle="modal" \
                                      data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.pauseVm') + '</a>\
                                </li>\
                                <li role="presentation" class="disabled">\
                                    <a href="javascript:void(0);" class="unpause" data-toggle="modal" \
                                    data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.unpauseVm') + '</a>\
                                </li>\
                             </ul>\
                        </div>';
          const absentAction = '<div class="btn-group">\
                            <button class="btn btn-default reboot disabled" data-toggle="modal" \
                                 data-backdrop="static">\
                                ' + this.translate.instant('gengyun.rebootVm') + '</button>\
                            <button class="btn btn-default dropdown-toggle" id="dropdownMenu1" \
                                data-toggle="dropdown" ><span class="caret"></span>\
                            </button>\
                            <ul class="dropdown-menu dropdown-menu-top" role="menu" aria-labelledby="dropdownMenu1">\
                                <li role="presentation" class="disabled">\
                                    <a href="javascript:void(0);" class="pause" data-toggle="modal" \
                                     data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.pauseVm') + '</a>\
                                </li>\
                                <li role="presentation" class="disabled">\
                                    <a href="javascript:void(0);" class="unpause" data-toggle="modal" \
                                    data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.unpauseVm') + '</a>\
                                </li>\
                             </ul>\
                        </div>';
          const uninstallAction = '<div class="btn-group">\
                            <button class="btn btn-default reboot disabled" data-toggle="modal" \
                                 data-backdrop="static">\
                                ' + this.translate.instant('gengyun.rebootVm') + '</button>\
                            <button class="btn btn-default dropdown-toggle" id="dropdownMenu1" \
                                data-toggle="dropdown" ><span class="caret"></span>\
                            </button>\
                            <ul class="dropdown-menu dropdown-menu-top" role="menu" aria-labelledby="dropdownMenu1">\
                                <li role="presentation" class="disabled">\
                                    <a href="javascript:void(0);" class="pause" data-toggle="modal" \
                                      data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.pauseVm') + '</a>\
                                </li>\
                                <li role="presentation" class="disabled">\
                                    <a href="javascript:void(0);" class="unpause" data-toggle="modal" \
                                    data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.unpauseVm') + '</a>\
                                </li>\
                             </ul>\
                        </div>';
          const activeAction = '<div class="btn-group">\
                            <button class="btn btn-default reboot" data-toggle="modal" \
                                 data-target="#RebootVmModal" data-backdrop="static">\
                                ' + this.translate.instant('gengyun.rebootVm') + '</button>\
                            <button class="btn btn-default dropdown-toggle" id="dropdownMenu1" \
                                data-toggle="dropdown" ><span class="caret"></span>\
                            </button>\
                            <ul class="dropdown-menu dropdown-menu-top" role="menu" aria-labelledby="dropdownMenu1">\
                                <li role="presentation">\
                                    <a href="javascript:void(0);" class="pause" data-toggle="modal" \
                                     data-target="#PauseVmModal" data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.pauseVm') + '</a>\
                                </li>\
                                <li role="presentation" class="disabled">\
                                    <a href="javascript:void(0);" class="unpause" data-toggle="modal" \
                                    data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.unpauseVm') + '</a>\
                                </li>\
                             </ul>\
                        </div>';

          if (row.state.indexOf('ing') === -1) {
            switch (row.state) {
              case 'paused':
                return pausedAction;
              case 'suspended':
                return suspendedAction;
              case 'shutoff':
                return shutOffAction;
              case 'verify_resize':
                return confirmAction;
              case  'shelved' :
              case 'shelved_offloaded':
                return shelvedAction;
              case 'uninstall':
                return uninstallAction;
              case 'active':
                return activeAction;
              case 'absent':
                return absentAction;
              default :
                return errorAction;
            }
          } else {
            return '<div class="btn-group">\
                            <button class="btn btn-default reboot disabled" data-toggle="modal" \
                                 data-backdrop="static">\
                                ' + this.translate.instant('gengyun.rebootVm') + '</button>\
                            <button class="btn btn-default dropdown-toggle" id="dropdownMenu1" \
                                data-toggle="dropdown" ><span class="caret"></span>\
                            </button>\
                            <ul class="dropdown-menu dropdown-menu-top" role="menu" aria-labelledby="dropdownMenu1">\
                                <li role="presentation" class="disabled">\
                                    <a href="javascript:void(0);" class="pause" data-toggle="modal" \
                                     data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.pauseVm') + '</a>\
                                </li>\
                                <li role="presentation" class="disabled">\
                                    <a href="javascript:void(0);" class="unpause" data-toggle="modal" \
                                     data-backdrop="static">\
                                    ' + this.translate.instant('gengyun.unpauseVm') + '</a>\
                                </li>\
                             </ul>\
                        </div>';
          }
        }
      }
    ];

    gridOptions: any = {
        pagination: true,
        escape: true,
        sidePagination: 'server',
        pageSize: 10,
        pageList: [10, 25, 50, 100],
        search: true,
        strictSearch: true,
        searchText: '',
        paginationDetailHAlign: 'left',
        paginationHAlign: 'left',
        clickToSelect: false,
        sortable: true,
        sortName: 'name',
        sortOrder: 'asc',
        showRefresh: true
    };

    constructor(private globalVmsService: GlobalVmsService, private route : ActivatedRoute,
                private translate: TranslateService, private storageService: StorageService,
                private authService: AuthService, private computeResourceService: ComputeResourceService, private router : Router) {
        const that = this;
        const dashboardUrl = this.computeResourceService.getDashboardUrl();

        that.links = [{name: this.translate.instant('computeRes.dashboard'), url: dashboardUrl},
            {name: this.translate.instant('computeRes.abnormalVm')}];

        that.timerHandle = undefined;
        if (this.storageService.getCurrentLang() === 'en') {
            $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
        } else {
            $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
        }
        that.window.operateEvents = {
            'click .reboot': function (e, value, row, index) {
                console.log(JSON.stringify(row));
                that.rebootVm = row;
                that.vmOperMessage.title = that.translate.instant('gengyun.rebootVm');
                that.vmOperMessage.message = that.translate.instant('computeRes.reboot.Message')
                  + ' ' + that.rebootVm.name + ' ' + that.translate.instant('computeRes.reboot.Message3');
                that.vmOperMessage.confirmText = that.translate.instant('gengyun.rebootVm');
                //that.actionOneVm(that.rebootVm, 'reboot', 'hard');
            },
            'click .pause': function (e, value, row, index) {
                console.log(JSON.stringify(row));
                that.pauseVm = row;
                that.vmOperMessage.title = that.translate.instant('gengyun.pauseVm');
                that.vmOperMessage.message = that.translate.instant('computeRes.Pause.Message')
                  + ' ' + that.pauseVm.name + ' ' + that.translate.instant('computeRes.Pause.Message3');
                that.vmOperMessage.confirmText = that.translate.instant('gengyun.pauseVm');
                //that.actionOneVm(that.pauseVm, 'pause');
            },
            'click .unpause': function (e, value, row, index) {
                console.log(JSON.stringify(row));
                that.unpauseVm = row;
                that.vmOperMessage.title = that.translate.instant('gengyun.unpauseVm');
                that.vmOperMessage.message = that.translate.instant('computeRes.Unpause.Message')
                  + ' ' + that.unpauseVm.name + ' ' + that.translate.instant('computeRes.Unpause.Message3');
                that.vmOperMessage.confirmText = that.translate.instant('gengyun.unpauseVm');
                //that.actionOneVm(that.unpauseVm, 'unpause');
            },
            'click .global_vm_detail': function (e, value, row, index) {
                that.goToGlobalVmDetail(row.userScopedVmId);
            }
        };
        if (!that.authService.containSomeRights(['Domain Virtual Machine#POST'])) {
            that.columnDefs = _.filter(that.columnDefs, function(x) {
                return x.field !== 'oper'; });
        }
    }


    ngOnInit() {
        const that = this;
        that.route.params.subscribe(params => {
            that.status = params['status'];
            if (that.status === 'abnormal') {
                that.isShowLinks = true;
            }
        });
        that.isShowLoading = true;
        setTimeout(function () {
          that.isShowLoading = false;
        }, 10000);
        that.initTable();
        that.startReloadInterval();
    }

    initTable() {
        const that = this;
        const $table = $('#table-global-vms');
        $table.bootstrapTable($.extend(this.gridOptions, {
            url: `${appConfig.vrmServiceUrl}vms?state=${that.status}&type=vm`,
            sidePagination: 'server',
            ajaxOptions: {},
            queryParams: function(params){
            return {
              search: params.search,
              pagesize : params.limit,
              currentpage: params.offset / params.limit + 1,
              sort: params.sort,
              order: params.order,
              fuzzy: that.searchFields
            };
            },
            dataField: 'vmInfo',
            //toolbar: '#toolbar1',
            columns: this.columnDefs
        }));

        $('.bootstrap-table .search input').attr('placeholder', that.translate.instant('WordForFilter'))
          .parent().append(`<span></span>`);

        that.setTableFooter();
    }

    setTableFooter() {
        const that = this;
        const $table = $('#table-global-vms');
        if (that.authService.containSomeRights(['Domain Virtual Machine#POST'])) {
            $table.parents('.fixed-table-container')
                .append(`<div class="fixed-table-footerButtons">
                          <input type="checkbox" class="checkAll">
                          <button id="reboot-global-vm-btn" data-toggle="modal" data-target="#RebootSelectVmModal"
                            data-backdrop="static" disabled>
                            ${that.translate.instant('gengyun.rebootVm')}</button>
                          <button id="pause-global-vm-btn" data-toggle="modal" data-target="#PauseSelectVmModal"
                            data-backdrop="static" disabled>
                            ${that.translate.instant('gengyun.pauseVm')}</button>
                          <button id="unpause-global-vm-btn" data-toggle="modal" data-target="#UnpauseSelectVmModal"
                            data-backdrop="static" disabled>
                            ${that.translate.instant('gengyun.unpauseVm')}</button>
                        </div>`);
        }

        $table.on('check.bs.table', function (row, $element) {
            if (_.contains(that.selectedRows, $element.userScopedVmId) !== true) {
                that.selectedRows.push($element.userScopedVmId);
            }
        });

        $table.on('uncheck.bs.table', function (row, $element) {
            that.selectedRows = _.without(that.selectedRows, $element.userScopedVmId);
        });

        $table.on('check-all.bs.table', function (rows, $element) {
            const tempArr = _.pluck($element, 'userScopedVmId');
            that.selectedRows = _.union(that.selectedRows, tempArr);
            //console.log(that.selectedRows.length);
        });

        $table.on('uncheck-all.bs.table', function (rows, $element) {
            const tempArr = _.pluck($element, 'userScopedVmId');
            that.selectedRows = _.difference(that.selectedRows, tempArr);
            //console.log(that.selectedRows.length);
        });
/*
        $table.on('check-all.bs.table uncheck-all.bs.table', function () {
            $('.fixed-table-footerButtons .checkAll').prop('checked', $table.bootstrapTable('getSelections').length > 0);
            console.log('4');
        });*/

        $table.on('check.bs.table uncheck.bs.table ' +
            'check-all.bs.table uncheck-all.bs.table', function () {
            that.setFooterOperButtons();
            that.setFooterCheckAllButton();
        });

        $('.bootstrap-table .fixed-table-footerButtons .checkAll').change(function () {
            if ($(this).prop('checked')) {
                $table.bootstrapTable('checkAll');
            } else {
                $table.bootstrapTable('uncheckAll');
            }
        });

        $table.on('load-success.bs.table', function (result) {
            if (that.selectedRows.length > 0) {
                $table.bootstrapTable('checkBy', {field: 'userScopedVmId', values: that.selectedRows});
            }
            that.setFooterCheckAllButton();
            that.setFooterOperButtons();
            that.isShowLoading = false;
        });

        $table.on('page-change.bs.table', function () {
            that.setFooterCheckAllButton();
            that.setFooterOperButtons();
        });

        $('#reboot-global-vm-btn').click(function() {
            that.rebootSelectVms();
        });
        $('.bootstrap-table .columns-right button[name="refresh"]')
          .addClass('btn-sm').css('marginLeft', '10px').click(function () {
          that.doPolling();
        });
        $('#pause-global-vm-btn').click(function() {
            that.pauseSelectVms();
        });
        $('#unpause-global-vm-btn').click(function() {
            that.unpauseSelectVms();
        });
    }

    reLoadData() {
        const that = this;
        that.refreshGlobalVmList();
        that.operRefreshCount--;
        if (that.operRefreshCount === 0) {
            that.stopOperRefreshInterval();
            that.startReloadInterval();
        } else {
            that.stopReloadInterval();
            that.startOperRefreshInterval();
        }
    }

    refreshGlobalVmList() {
        const $table = $('#table-global-vms');
        $table.bootstrapTable('refresh', {silent: true});
    }

    setFooterCheckAllButton() {
        const that = this;
        if (that.isCurrentPageAllSelected()) {
            $('.fixed-table-footerButtons .checkAll').prop('checked', true);
        } else {
            $('.fixed-table-footerButtons .checkAll').prop('checked', false);
        }
    }

    isCurrentPageAllSelected() {
        let curSelectNum : any = 0;
        const curPageData = $('#table-global-vms').bootstrapTable('getData', {useCurrentPage: true});
        curSelectNum = _.filter(curPageData, function (data) {
            return (data['0'] !== undefined) && (data['0'] === true);
        }).length;
        if ((curPageData.length !== 0) && (curSelectNum === curPageData.length)) {
            return true;
        } else {
            return false;
        }
    }

    setFooterOperButtons() {
        const that = this;
        if (that.isCurrentPageUnSelected()) {
            $('.fixed-table-footerButtons button').prop('disabled', true);
        } else {
            $('.fixed-table-footerButtons button').prop('disabled', false);
        }
    }

    isCurrentPageUnSelected() {
        const curPageData = $('#table-global-vms').bootstrapTable('getData', {useCurrentPage: true});
        const select = _.find(curPageData, function (data) {
            return (data['0'] !== undefined) && (data['0'] === true);
        });
        return _.isUndefined(select);
    }

    startReloadInterval() {
        const that = this;
        if (that.timerHandle === undefined) {
            that.timerHandle = setInterval(function(){
                that.refreshGlobalVmList();
            }, 10000);
        }
    }

    stopReloadInterval() {
        if (this.timerHandle !== undefined) {
            clearInterval(this.timerHandle);
            this.timerHandle = undefined;
        }
    }

    startOperRefreshInterval() {
        const that = this;
        if (that.operTimerHandle === undefined) {
            that.operTimerHandle = setInterval(function(){
                that.reLoadData();
            }, 1000);
        }
    }

    stopOperRefreshInterval() {
        if (this.operTimerHandle !== undefined) {
            clearInterval(this.operTimerHandle);
            this.operTimerHandle = undefined;
        }
    }

    ngOnDestroy() {
        this.stopReloadInterval();
        this.stopOperRefreshInterval();
    }

    rebootSelectVms() {
        const that = this;
        const selectedVms : any[] = $('#table-global-vms').bootstrapTable('getSelections');
        let unActiveVmNum : any = 0;
        _.each(selectedVms, function (vm) {
            if (vm.state !== 'active') {
                unActiveVmNum++;
            }
        });
        that.vmOperMessage.title = that.translate.instant('gengyun.rebootVm');
        that.vmOperMessage.confirmText = that.translate.instant('gengyun.rebootVm');
        if (unActiveVmNum !== 0) {
            that.vmOperMessage.message = `${unActiveVmNum} ` + that.translate.instant('VirMachine') +
                that.translate.instant('computeRes.StatusIs') + ' ' + that.translate.instant('gengyun.abnormal') +
                that.translate.instant('computeRes.reboot.Forbidden') + that.translate.instant('gengyun.confirmOperVm');
        } else {
            that.vmOperMessage.message = `${selectedVms.length} ` + that.translate.instant('VirMachine') + ' ' +
                that.translate.instant('gengyun.selectRebootMsg') + ',' +
                that.translate.instant('computeRes.reboot.Message2');
        }
    }

    pauseSelectVms() {
        const that = this;
        const selectedVms : any[] = $('#table-global-vms').bootstrapTable('getSelections');
        that.vmOperMessage.title = that.translate.instant('gengyun.pauseVm');
        that.vmOperMessage.confirmText = that.translate.instant('gengyun.pauseVm');
        that.vmOperMessage.message = `${selectedVms.length} ` + that.translate.instant('VirMachine') + ' ' +
            that.translate.instant('gengyun.selectPauseMsg') + ',' +
            that.translate.instant('computeRes.Pause.Message2');
    }

    unpauseSelectVms() {
        const that = this;
        const selectedVms : any[] = $('#table-global-vms').bootstrapTable('getSelections');
        that.vmOperMessage.title = that.translate.instant('gengyun.unpauseVm');
        that.vmOperMessage.confirmText = that.translate.instant('gengyun.unpauseVm');
        that.vmOperMessage.message = `${selectedVms.length} ` + that.translate.instant('VirMachine') + ' ' +
            that.translate.instant('gengyun.selectUnpauseMsg') + ',' +
            that.translate.instant('computeRes.Unpause.Message2');
    }

    actionVm(actionName: any, actionType: any= '') {
        const that = this;
        const $table = $('#table-global-vms');
        const selectedVms: any[] = $table.bootstrapTable('getSelections');
        const vmAndCloudIds = new Array();
        function vmAndCloudId(vmId, cloudEnvId) {
            this.vmId = vmId;
            this.cloudEnvId = cloudEnvId;
        }

        for (let i = 0; i < selectedVms.length; i++) {
            vmAndCloudIds.push(new vmAndCloudId(selectedVms[i].userScopedVmId, selectedVms[i].cloudEnvId));
        }

        that.data = {
            'vmAndCloudIds': vmAndCloudIds,
            'action': {
                'name': actionName,
                'actionType': actionType
            }
        };

        that.isShowOperLoading = true;
        that.globalVmsService.postAction(this.data).then((res: any) => {
            that.isShowOperLoading = false;
            that.isShowInfo = true;
            that.operRefreshCount = 10;
            setTimeout(function () {
                that.isShowInfo = false;
                that.reLoadData();
            }, 2000);
        },
        (error : any) => {
            that.isShowOperLoading = false;
        });
    }

    actionOneVm(vm : any, actionName : any, actionType : any= '') {
        const that = this;
        const vmAndCloudIds = new Array();
        function vmAndCloudId(vmId, cloudEnvId) {
          this.vmId = vmId;
          this.cloudEnvId = cloudEnvId;
        }
        vmAndCloudIds.push(new vmAndCloudId(vm.userScopedVmId, vm.cloudEnvId));

        that.data = {
          'vmAndCloudIds' : vmAndCloudIds,
          'action': {
            'name': actionName,
            'actionType': actionType
          }
        };

        that.isShowOperLoading = true;
        that.globalVmsService.postAction(that.data).then((res: any) => {
            that.isShowOperLoading = false;
            that.isShowInfo = true;
            that.operRefreshCount = 10;
            setTimeout(function () {
              that.isShowInfo = false;
              that.reLoadData();
            }, 2000);
        },
        (error : any) => {
            that.isShowOperLoading = false;
        });
    }

    goToGlobalVmDetail(id : any) {
        this.router.navigate([`/main/computeResource/globalvms/${this.status}/detail`, id]);
    }

    doPolling() {
      const that = this;
      that.polldata = {
        cloudEnvIds: [],
        action: 'full'
      };
      that.globalVmsService.postPolling(that.polldata).then((res: any) => {
        that.isShowLoading = false;
      });
    }

    getVms(value, row, index) {
      let tempEnvs = [];
      tempEnvs.push('<span>');
        for (let env of value) {
          if(tempEnvs.length === 1) {
            tempEnvs.push(env);
          } else {
            tempEnvs.push('<br/>' + env);
        }
      }
      tempEnvs.push('</span>');
      return tempEnvs.join('');
    }
}
