import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/index';
import { routing } from './global-vms.routes';

import { GlobalVmSummaryComponent } from './global-vms-summary.component';
import { GlobalVmDetailComponent } from './global-vm-detail/index';
import { GlobalVmsService } from './global-vms.service';

@NgModule({
  imports: [SharedModule, routing],
  declarations: [GlobalVmSummaryComponent, GlobalVmDetailComponent],
  providers: [GlobalVmsService]
})

export class GlobalVmModule { }
