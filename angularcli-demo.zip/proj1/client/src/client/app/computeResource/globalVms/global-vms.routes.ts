import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GlobalVmSummaryComponent } from './global-vms-summary.component';
import { GlobalVmDetailComponent } from './global-vm-detail/index';

const routes: Routes = [
  {
    path: 'globalvms',
    children: [
        {path: '', component: GlobalVmSummaryComponent},
        {path: ':status', component: GlobalVmSummaryComponent},
        {path: ':state/detail/:id', component: GlobalVmDetailComponent},
    ]
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
