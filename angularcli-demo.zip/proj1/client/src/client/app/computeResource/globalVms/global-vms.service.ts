/**
 * Created by root on 8/30/16.
 */
import { Injectable } from '@angular/core';
import { Response } from '@angular/http';
import { ApiResourceService as Http } from '../../apiResource.service';
import { appConfig } from '../../app.config';

@Injectable()
export class GlobalVmsService {

    constructor(public http: Http) {}

    getAllVms() {
        return this.http.get(`${appConfig.vrmServiceUrl}/vms`)
          .toPromise().then((res: Response) => {return res.json(); });
    }

    getOneVm(vmId : any) {
        return this.http.get(`${appConfig.vrmServiceUrl}/vms/${vmId}`)
            .toPromise().then((res: Response) => {return res.json().vmInfo; });
    }

    postAction(data: any) {
    return this.http.post(`${appConfig.vrmServiceUrl}vmOperate`, data)
      .toPromise();
    }

    postPolling(data: any) {
      return this.http.post(`${appConfig.vrmServiceUrl}vmManualPolling`, data)
        .toPromise();
    }
}
