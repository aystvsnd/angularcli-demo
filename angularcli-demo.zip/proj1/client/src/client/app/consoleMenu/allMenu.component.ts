import {Component, ViewEncapsulation, } from '@angular/core';
import {AuthService} from '../core/index';
import {StorageService} from '../storage.service';

@Component({
    moduleId: module.id,
    selector: 'all-menu-view',
    templateUrl: 'allMenu.html',
    encapsulation: ViewEncapsulation.Emulated,
})

export class AllMenuComponent {
    private resouceCenter: any[];
    private organizationCenter: any[];
    private monitorCenter: any[];
    private systemManage: any[];
    private physicalresource: any[];
    private serviceCenter: any[];
    private serviceMarket: any[];
    private orderManage: any[];
    private myresource: any[];
    private myorganizationCenter: any[];
    private domainServiceManagerResource: any[];
    private vManage: any[];
    private orderAudit: boolean;
    constructor(private authService: AuthService, private storageService: StorageService) {
	    this.resouceCenter = this.authService.getTopMenuRights('resouceCenter');
	    this.organizationCenter = this.authService.getTopMenuRights('organizationCenter');
	    this.monitorCenter = this.authService.getTopMenuRights('monitorCenter');
	    this.systemManage = this.authService.getTopMenuRights('systemManage');
	    this.physicalresource = this.authService.getTopMenuRights('physicalresource');
	    this.serviceCenter = this.authService.getTopMenuRights('serviceCenter');
        this.vManage = this.authService.getTopMenuRights('vManage');
	    this.serviceMarket = this.authService.getTopMenuRights('serviceMarket');
	    this.orderManage = this.authService.getTopMenuRights('orderManage');
	    this.myresource  = this.authService.getTopMenuRights('myresource');
        this.myorganizationCenter = this.authService.getTopMenuRights('myorganizationCenter');
        this.domainServiceManagerResource = this.authService.getTopMenuRights('domainServiceManagerResource');
        this.orderAudit = this.authService.getUserNameRights('NOCServiceAdmin');
    }
}
