import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/index';

import { SendMessageService } from '../sendMessage.service';

import { AllMenuComponent } from './allMenu.component';
import { ResourceCenterMenuComponent } from './resourceCenterMenu.component';
import { SystemManageMenuComponent } from './systemManageMenu.component';
import { MonitorCenterMenuComponent } from './monitorCenterMenu.component';
import { MyresourceMenuComponent } from './myresourceMenu.component';
import { DomainServiceManagerResourceMenuComponent } from './domainServiceManagerResourceMenu.component';
import { SelfServiceMenuComponent } from './selfServiceMenu.component';
import { MyorgCenterMenuComponent } from './myorganizationCenterMenu.component';
import { OrganizationCenterMenuComponent } from './organizationCenterMenu.component';
import { PhysicalResourceMenuComponent } from './physicalResourceMenu.component';
import { OrderManageMenuComponent } from './orderManageMenu.component';
import { ServiceMarketMenuComponent } from './serviceMarketMenu.component';
import { OrderAuditMenuComponent }from './orderAuditMenu.component';
import { VmanagerMenuComponent }from './vmanagermenu.component';
import { OperationMenuComponent } from './operationMenu.component';


@NgModule({
    imports: [SharedModule],
    declarations: [AllMenuComponent,
        ResourceCenterMenuComponent,
        SystemManageMenuComponent,
        MonitorCenterMenuComponent,
        MyresourceMenuComponent,
       DomainServiceManagerResourceMenuComponent,
        SelfServiceMenuComponent,
        OrganizationCenterMenuComponent,
        MyorgCenterMenuComponent,
        PhysicalResourceMenuComponent,
        OrderManageMenuComponent,
        ServiceMarketMenuComponent,
        OrderAuditMenuComponent,
        VmanagerMenuComponent,
        OperationMenuComponent
    ],
    providers: [SendMessageService],
    exports: [AllMenuComponent]
})

export class AllMenuModule {
}
