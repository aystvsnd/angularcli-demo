import { Component } from '@angular/core';
import { SendMessageService } from '../sendMessage.service';

@Component({
    moduleId: module.id,
    selector: 'domain-service-manager-resource-menu-view',
    templateUrl: 'domainServiceManagerResourceMenu.component.html',
    styleUrls: ['consoleMenu.less'],
})

export class DomainServiceManagerResourceMenuComponent {

    boolValue = false;
    resultOfDetermin: any= {};
    public DeterminOfPic: any = {
        'mynetwork': 'true',
    };

    mouseOverSetImg(inputStr: string) {
        for (const key in this.DeterminOfPic) {
            this.DeterminOfPic[key] = false;
        }
        for (const key in this.DeterminOfPic) {
            if (key === inputStr) {
                this.DeterminOfPic[key] = true;
            }
        }
        this.resultOfDetermin = this.DeterminOfPic;
    }
    mouseOutSetImg(inputStr: string) {
        for (const key in this.DeterminOfPic) {
            this.DeterminOfPic[key] = false;
        }
        this.resultOfDetermin = this.DeterminOfPic;
    }
    constructor(private sendMessageService: SendMessageService) {

    }
    myresouceCenterOnClick() {
        this.sendMessageService.domainServiceManagerResouceOnClick();
    }


}
