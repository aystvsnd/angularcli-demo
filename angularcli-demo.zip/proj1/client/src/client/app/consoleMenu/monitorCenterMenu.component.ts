import {OnInit, Component} from '@angular/core';
import {SendMessageService} from '../sendMessage.service';
import { AuthService } from '../core/index';
import { TranslateService } from '@ngx-translate/core';
import { Router } from '@angular/router';
@Component({
    moduleId: module.id,
    selector: 'monitor-center-menu-view',
    templateUrl: 'monitorCenterMenu.component.html',
    styleUrls: ['consoleMenu.less'],
})

export class MonitorCenterMenuComponent implements OnInit {
    boolValue = false;
    resultOfDetermin: any= {};
    menumonitor: any ;

    public DeterminOfPic: any = {
        'alarm': 'true',
        'performanceStatistics': 'true',
        'log': 'true',
        'dashdoard': 'true',
        'opsInsight': 'true',
        'sheet': 'true',
        'serviceMonitor': 'true',
        'HealthPromotion': 'true',
        'CapacityOptimization': 'true',
        'NetworkPortDiagnostics': 'true',
        'topology': 'true',
        'MonitorObject': 'true',
        'Strategy': 'true',
    };
  /*myHealthCapacity= [['Health#GET','Capacity#GET'],'||',
    ['Smart Performance Operate#GET','Smart Capacity Operate#GET']];*/

  myNetworkPortDiagnostics= ['Network Diagnosis#GET'];

  /*myTopology = ['Topology#GET'];*/
  myMonitorObject = ['Smart Object Management#View'];
  myPolicy = ['Smart Config#View'];

  ngOnInit() {
    this.menumonitor =  this.translate.instant('menu.monitor.MonitorCenter');
  }
    mouseOverSetImg(inputStr: string) {
        for (const key in this.DeterminOfPic) {
            this.DeterminOfPic[key] = false;
        }
        for (const key in this.DeterminOfPic) {
            if (key === inputStr) {
                this.DeterminOfPic[key] = true;
            }
        }
        this.resultOfDetermin = this.DeterminOfPic;
    }
    mouseOutSetImg(inputStr: string) {
        for (const key in this.DeterminOfPic) {
            this.DeterminOfPic[key] = false;
        }
        this.resultOfDetermin = this.DeterminOfPic;
    }
    constructor(private sendMessageService: SendMessageService, private translate: TranslateService
      , private authService: AuthService, private router: Router) {

    }

    dashBoardOnClick() {
      if (this.authService.containAllRights([['Smart Object Management#View'], '||', ['Smart Config#View'], '||',
          ['Smart Alarm Analysis#View']])) {
          this.router.navigate(['/main/insight/dashboard/all']);
      } else {
        this.router.navigate(['/main/monitor/dashboard']);
      }
      this.monitorCenterOnClick();
    }
    monitorCenterOnClick() {
        this.sendMessageService.monitorCenterOnClick();
    }
}
