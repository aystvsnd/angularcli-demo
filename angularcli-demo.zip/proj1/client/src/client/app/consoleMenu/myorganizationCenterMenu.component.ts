/**
 * Created by root on 9/8/16.
 */
import { Component, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
//import { NgClass } from '@angular/common';
import { SendMessageService } from '../sendMessage.service';
@Component({
  moduleId: module.id,
  selector: 'myorg-center-menu-view',
  templateUrl: 'myorganizationCenterMenu.component.html',
  styleUrls: ['consoleMenu.less'],
  encapsulation: ViewEncapsulation.Emulated,
})

export class MyorgCenterMenuComponent {
  boolValue = false;
  resultOfDetermin: any= {};
  public DeterminOfPic: any = {
    'myorg': 'true',
  };

  mouseOverSetImg(inputStr: string) {
    for (const key in this.DeterminOfPic) {
      this.DeterminOfPic[key] = false;
    }
    for (const key in this.DeterminOfPic) {
      if (key === inputStr) {
        this.DeterminOfPic[key] = true;
      }
    }
    this.resultOfDetermin = this.DeterminOfPic;
  }
  mouseOutSetImg(inputStr: string) {
    for (const key in this.DeterminOfPic) {
      this.DeterminOfPic[key] = false;
    }
    this.resultOfDetermin = this.DeterminOfPic;
  }

  constructor(private sendMessageService: SendMessageService, private router: Router) {

  }

  myorganizationCenterOnClick() {
    const that = this;
    this.router.navigate(['/main/org/interval']);
    setTimeout(function () {
      that.router.navigate(['/main/org']);
    }, 1);
    this.sendMessageService.myorganizationCenterOnClick();
    $('.sideBar').css('display', 'none');
    $('.main-content').css('margin-left', '0');
  }

}
