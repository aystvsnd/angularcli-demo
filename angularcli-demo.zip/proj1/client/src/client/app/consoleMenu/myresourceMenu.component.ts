import { Component } from '@angular/core';
import { SendMessageService } from '../sendMessage.service';

@Component({
    moduleId: module.id,
    selector: 'myresource-menu-view',
    templateUrl: 'myresourceMenu.component.html',
    styleUrls: ['consoleMenu.less'],
})

export class MyresourceMenuComponent {

    boolValue = false;
    resultOfDetermin: any = {};
    public DeterminOfPic: any = {
        'myvm': 'true',
        'mybaremetal': 'true',
        'mydisk': 'true',
        'myimg': 'true',
        'mynetwork': 'true',
        'myvirtualapp': 'true',
        'mytemplate': 'true',
        'myfirewall': 'true',
        'mylb': 'true',
        'myconsume': 'true'
    };
    myNetorkMenuRights = ['Virtual Data Center Network Topology#GET', '||',
         'Virtual Data Center Network#GET', '||', 'VDC Cloud Environment Network#View', '||',
         'VDC Cloud Environment Sub Network#View', '||', 'VDC Network QOS Policy#View', '||',
         'VDC Cloud Environment Router Network#View', '||', 'Switch Port Groups#GET'];
    mouseOverSetImg(inputStr: string) {
        for (const key in this.DeterminOfPic) {
            this.DeterminOfPic[key] = false;
        }
        for (const key in this.DeterminOfPic) {
            if (key === inputStr) {
                this.DeterminOfPic[key] = true;
            }
        }
        this.resultOfDetermin = this.DeterminOfPic;
    }

    mouseOutSetImg(inputStr: string) {
        for (const key in this.DeterminOfPic) {
            this.DeterminOfPic[key] = false;
        }
        this.resultOfDetermin = this.DeterminOfPic;
    }

    constructor(private sendMessageService: SendMessageService) {

    }

    myresouceCenterOnClick() {
        this.sendMessageService.myresouceOnClick();
    }


}
