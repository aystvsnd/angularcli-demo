import { Component } from '@angular/core';
import { SendMessageService } from '../sendMessage.service';
import { StorageService } from '../storage.service';

@Component({
    moduleId: module.id,
    selector: 'opration-menu-view',
    templateUrl: 'operationMenu.component.html',
    styleUrls: ['consoleMenu.less'],
})

export class OperationMenuComponent {
    boolValue = false;
    resultOfDetermin: any = {};

    public DeterminOfPic: any = {
        'order': 'true',
        'workorder': 'true',
        'process': 'true',
        'catalog': 'true',
        'price': 'true',
        'arrange': 'true',
        'vdcOrder': 'true'
    };

    mouseOverSetImg(inputStr: string) {
        for (const key in this.DeterminOfPic) {
            this.DeterminOfPic[key] = false;
        }
        for (const key in this.DeterminOfPic) {
            if (key === inputStr) {
                this.DeterminOfPic[key] = true;
            }
        }
        this.resultOfDetermin = this.DeterminOfPic;
    }

    mouseOutSetImg(inputStr: string) {
        for (const key in this.DeterminOfPic) {
            this.DeterminOfPic[key] = false;
        }
        this.resultOfDetermin = this.DeterminOfPic;
    }

    constructor(private sendMessageService: SendMessageService, private storageService: StorageService) {}

    operationOnClick(path: string) {
        this.sendMessageService.operationOnClick(path);
    }
}



