import { Component, ViewEncapsulation } from '@angular/core';
import { SendMessageService } from '../sendMessage.service';
@Component({
  moduleId: module.id,
  selector: 'order-manage-menu-view',
  templateUrl: 'orderManageMenu.component.html',
  styleUrls: ['consoleMenu.less'],
  encapsulation: ViewEncapsulation.Emulated,
})

export class OrderManageMenuComponent {
  boolValue = false;
  resultOfDetermin: any = {};
  public DeterminOfPic: any = {
    'workorder': 'true'
  };

  mouseOverSetImg(inputStr: string) {
    for (const key in this.DeterminOfPic) {
      this.DeterminOfPic[key] = false;
    }
    for (const key in this.DeterminOfPic) {
      if (key === inputStr) {
        this.DeterminOfPic[key] = true;
      }
    }
    this.resultOfDetermin = this.DeterminOfPic;
  }

  mouseOutSetImg(inputStr: string) {
    for (const key in this.DeterminOfPic) {
      this.DeterminOfPic[key] = false;
    }
    this.resultOfDetermin = this.DeterminOfPic;
  }

  constructor(private sendMessageService: SendMessageService) {
  }

  orderManageOnClick() {
    this.sendMessageService.orderManageOnClick();
  }
}
