import {Component} from '@angular/core';
import {SendMessageService} from '../sendMessage.service';

@Component({
    moduleId: module.id,
    selector: 'org-center-menu-view',
    templateUrl: 'organizationCenterMenu.component.html',
    styleUrls: ['consoleMenu.less'],
})

export class OrganizationCenterMenuComponent {
    boolValue = false;
    resultOfDetermin: any= {};
    public DeterminOfPic: any = {
        'org': 'true',
        'vdcs': 'true',
        'resReserves': 'true',
    };

    mouseOverSetImg(inputStr: string) {
        for (const key in this.DeterminOfPic) {
            this.DeterminOfPic[key] = false;
        }
        for (const key in this.DeterminOfPic) {
            if (key === inputStr) {
                this.DeterminOfPic[key] = true;
            }
        }
        this.resultOfDetermin = this.DeterminOfPic;
    }
    mouseOutSetImg(inputStr: string) {
        for (const key in this.DeterminOfPic) {
            this.DeterminOfPic[key] = false;
        }
        this.resultOfDetermin = this.DeterminOfPic;
    }
    constructor(private sendMessageService: SendMessageService) {

    }
    organizationCenterOnClick() {
        this.sendMessageService.organizationCenterOnClick();
    }
}
