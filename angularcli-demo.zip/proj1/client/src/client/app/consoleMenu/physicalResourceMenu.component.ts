import { Component } from '@angular/core';
import {SendMessageService} from '../sendMessage.service';

@Component({
    moduleId: module.id,
    selector: 'physical-resource-menu-view',
    templateUrl: 'physicalResourceMenu.component.html',
    styleUrls: ['consoleMenu.less'],
})

export class PhysicalResourceMenuComponent {
    boolValue = false;
    resultOfDetermin: any= {};
    public DeterminOfPic: any = {
        'server': 'true',
        'networkDevice': 'true',
        'storages': 'true',
        'asset': 'true',
        'pod': 'true',
        'rack': 'true',
    };
    mouseOverSetImg(inputStr: string) {
        for (const key in this.DeterminOfPic) {
            this.DeterminOfPic[key] = false;
        }
        for (const key in this.DeterminOfPic) {
            if (key === inputStr) {
                this.DeterminOfPic[key] = true;
            }
        }
        this.resultOfDetermin = this.DeterminOfPic;
    }
    mouseOutSetImg(inputStr: string) {
        for (const key in this.DeterminOfPic) {
            this.DeterminOfPic[key] = false;
        }
        this.resultOfDetermin = this.DeterminOfPic;
    }

    constructor(private sendMessageService: SendMessageService) {

    }

    physicalDeviceOnClick() {
        this.sendMessageService.physicalDeviceOnClick();
    }
}


