import { Component } from '@angular/core';
import { SendMessageService } from '../sendMessage.service';

@Component({
    moduleId: module.id,
    selector: 'resource-center-menu-view',
    templateUrl: 'resourceCenterMenu.component.html',
    styleUrls: ['consoleMenu.less'],
})

export class ResourceCenterMenuComponent {
    boolValue = false;
    resultOfDetermin: any= {};
    public DeterminOfPic: any = {
        'dateCenter': 'true',
        'computeResource': 'true',
        'netResource': 'true',
        'vmspec': 'true',
        'img': 'true',
        'flavor': 'true',
        'resGroup': 'true'
    };
    myNetorkMenuRights = ['Cloud Environment Network#GET', '||',
         'Cloud Environment Sub Network#GET', '||',
         'Cloud Environment Router Network#GET', '||',
         'SDNC#GET', '||',
          'SDNC Network Manage#GET', '||',
         'VNIS#GET', '||',
         'Subnet Pools#GET', '||',
         'Network QOS Policy#GET', '||',
         'Port Mapping#GET'];
    computeResourceMenuRights = ['Data Center#POST', '&&',
        ['Cloud Environment#GET', '||',
          'OS Aggregate#GET', '||',
          'Domain Host#GET', '||',
          'Domain Virtual Machine#GET', '||',
          'Physic Bare Metal#View', '||',
          'Bare Metal Server#View']];
    mouseOverSetImg(inputStr: string) {
        for (const key in this.DeterminOfPic) {
            this.DeterminOfPic[key] = false;
        }
        for (const key in this.DeterminOfPic) {
            if (key === inputStr) {
                this.DeterminOfPic[key] = true;
            }
        }
        this.resultOfDetermin = this.DeterminOfPic;
    }
    mouseOutSetImg(inputStr: string) {
        for (const key in this.DeterminOfPic) {
            this.DeterminOfPic[key] = false;
        }
        this.resultOfDetermin = this.DeterminOfPic;
    }
    constructor(private sendMessageService: SendMessageService) {

    }
    resouceCenterOnClick() {
        this.sendMessageService.resouceCenterOnClick();
    }
}



