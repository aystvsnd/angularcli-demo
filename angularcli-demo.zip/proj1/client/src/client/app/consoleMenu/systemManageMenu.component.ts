import { Component } from '@angular/core';
import { SendMessageService } from '../sendMessage.service';

@Component({
    moduleId: module.id,
    selector: 'system-manage-menu-view',
    templateUrl: 'systemManageMenu.component.html',
    styleUrls: ['consoleMenu.less'],
})

export class SystemManageMenuComponent {
    boolValue = false;
    resultOfDetermin: any= {};
    public DeterminOfPic: any = {
        'systemConfig': 'true',
        'opsInsightConfig': 'true',
        'userSafe': 'true',
        'backup': 'true',
        'about': 'true',
    };

    menuSysConfigRight: string[]= ['Performance Config#View', 'Operation Log Config#View',
    'Security Log Config#View', 'Backup Log Config#View', 'System Log Config#View',
    'North Report Config#GET', 'North Performance Config#View', 'Auto Backup Config#GET', 'QOS Alarm Strategy Config#GET',
    'Alarm Description#GET', 'Alarm Filter Rule#GET', 'Alarm Forward Rule#GET', 'Alarm Notify#GET',
      'Email Service Config#GET'];

    mouseOverSetImg(inputStr: string) {
        for (const key in this.DeterminOfPic) {
            this.DeterminOfPic[key] = false;
        }
        for (const key in this.DeterminOfPic) {
            if (key === inputStr) {
                this.DeterminOfPic[key] = true;
            }
        }
        this.resultOfDetermin = this.DeterminOfPic;
    }
    mouseOutSetImg(inputStr: string) {
        for (const key in this.DeterminOfPic) {
            this.DeterminOfPic[key] = false;
        }
        this.resultOfDetermin = this.DeterminOfPic;
    }
    constructor(private sendMessageService: SendMessageService) {

    }
    systemManageOnClick() {
        this.sendMessageService.systemManageOnClick();
    }
}

