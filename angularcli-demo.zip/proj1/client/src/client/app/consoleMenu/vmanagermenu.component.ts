import {Component, ViewEncapsulation} from '@angular/core';
import {SendMessageService} from '../sendMessage.service';
@Component({
  moduleId: module.id,
  selector: 'vmanager-menu-view',
  templateUrl: 'vmanagermenu.component.html',
  styleUrls: ['consoleMenu.less'],
  encapsulation: ViewEncapsulation.Emulated,
})

export class VmanagerMenuComponent {
  boolValue = false;
  resultOfDetermin: any= {};
  public DeterminOfPic: any = {
    'vManager': 'true'
  };
  mouseOverSetImg(inputStr: string) {
    for (const key in this.DeterminOfPic) {
      this.DeterminOfPic[key] = false;
    }
    for (const key in this.DeterminOfPic) {
      if (key === inputStr) {
        this.DeterminOfPic[key] = true;
      }
    }
    this.resultOfDetermin = this.DeterminOfPic;
  }
  mouseOutSetImg(inputStr: string) {
    for (const key in this.DeterminOfPic) {
      this.DeterminOfPic[key] = false;
    }
    this.resultOfDetermin = this.DeterminOfPic;
  }
  constructor(private sendMessageService: SendMessageService) {
  }
  vManagerOnClick() {
    this.sendMessageService.vmanagerOnClick();
  }
}

