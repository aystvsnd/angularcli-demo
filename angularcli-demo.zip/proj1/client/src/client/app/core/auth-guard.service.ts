import { Injectable }       from '@angular/core';
import {
  Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  CanActivateChild
}                           from '@angular/router';

import { AuthService } from './auth.service';

@Injectable()
export class AuthGuard implements CanActivateChild {
  constructor(private router: Router, private authService: AuthService) {}

  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    //if (!this.authService.getRouteRightsNode(['main','systemManage','about']))  return true;
    if (state.url === '/main/systemManage/about') {
      return true;
    }
    if (this.authRouteRights(route)) return true;

    const paths: string[] = this.getParentPaths(route.parent);
    let routeRights = this.authService.getRouteRightsChild(paths);
    routeRights = _.filter(routeRights, (routeRight) => {
      return route.routeConfig.path !== routeRight.path;
    });
    if (routeRights) {
      const routeUrl    = this.authService.getWeighRouteIn(routeRights);
      if (routeUrl.path) {
        paths.push(routeUrl.path);
        const nexturl = '/' + paths.join('/');
        this.router.navigate([nexturl]);
      }
    }
    return false;
  }
  private getParentPaths(parentRoute: ActivatedRouteSnapshot): string[] {
    const tmp1 = _.filter(_.pluck(parentRoute.pathFromRoot, 'url'), (url) => {
      return url.length > 0;
    });
    const tmp2 = _.flatten(tmp1);

    return  _.pluck(tmp2, 'path');
  }
  private authRouteRights(route: ActivatedRouteSnapshot): boolean {
    const paths: string[] = this.getParentPaths(route);
    const routeRight = this.authService.getRouteRightsNode(paths);
    if (! routeRight) {
      return true;
    }
    const someRights = this.authService.getchildRights(routeRight);
    if (someRights && someRights.length > 0) {
      return this.authService.containSomeRights(someRights);
    }else {
      return true;
    }
  }
}
