import { Injectable } from '@angular/core';
import { StorageService } from '../storage.service';
import { routeRights } from '../route-rights.config';
import { resouceTypeMap } from '../resource-type.map';
interface MenuRightInterface {
  [propName: string]: any[];
};
interface Routeweight {
  path: string;
  weight: number;
}

@Injectable()
export class AuthService {
  routeRights: any;
  private topMenuAuthRights: MenuRightInterface = {
    'resouceCenter': [
              [['Cloud Environment Network#GET', '||',
              'Cloud Environment Sub Network#GET', '||', 'Cloud Environment Router Network#GET'], '&&',
              'Data Center#POST'], '||', 'Data Center#POST', '||', 'Data Center#PUT', '||',
              'Data Center#DELETE', '||',
              'Cloud Environment#GET,POST', '||', 'OS Aggregate#GET', '||', 'Domain Host#GET', '||',
              'Domain Virtual Machine#GET,POST,DELETE', '||', 'SDNC#GET', '||', 'SDNC Network Manage#GET',
              '||', 'VNIS#GET', '||',
              'Data Center External Network#GET', '||',
              'Network QOS Policy#GET', '||', [['Domain Volume#GET', '||', 'Flavor#GET', '||', 'Resource Group#View'], '&&',
              'Data Center#POST'], '||',
              'Domain Image#GET', '||', 'Cloud Environment Image#GET', '||', 'Port Mapping#GET'],

    'organizationCenter': ['Organization#PUT', 'Virtual Data Center#PUT', 'Resource Reservation#View',
                          'Organization#DELETE', 'Virtual Data Center#DELETE',
                          'Organization#POST', 'Virtual Data Center#POST'],
    'monitorCenter': ['Current Alarm#GET', 'Current Alarm Confirm#GET', 'History Alarm#GET', 'Notification#GET',
                     'Indicator Query#View', 'Task Management#View', 'Kpi Management#View',
                     'Backup Log#View',
                     'Operation Log#View', 'Security Log#View', 'System Log#View', 'Form Report#View',
                     'Domain Exception#GET', 'Report#GET', 'Smart Object Management#View', 'Smart Config#View',
                      'Topology#GET', 'Smart Alarm Analysis#View'],
    'systemManage': ['Performance Config#View', 'Operation Log Config#GET',
                  'Security Log Config#View', 'Backup Log Config#View', 'System Log Config#View',
                  'North Report Config#GET', 'North Performance Config#View', 'Auto Backup Config#GET',
                  'QOS Alarm Strategy Config#View',
                  'Alarm Description#GET', 'Alarm Filter Rule#GET', 'Alarm Forward Rule#GET',
                  'User#View', 'Third Auth Server Config#GET', 'User Lock-Time Config#GET',
                  'Role#View', 'Backup Data Management#GET',
                  'OPS Plus Cloud Environment#GET', 'OPS Plus Cloud Environment Config#GET'],
    'physicalresource': ['Physical Server#View', 'Physical Network Device#View', 'Disk Array#View'],
    'serviceCenter': ['Security Center#GET'],
    'vManage': ['VNF Manager#GET'],
    'serviceMarket': ['Resource Service Catalog#GET', 'Virtual Data Center Service Catalog#GET'],
    'orderManage': ['Work Order#GET'],
    'myorganizationCenter': ['Organization#GET', 'Project#POST'],
    'domainServiceManagerResource': ['Organization#POST', '&&', ['Virtual Data Center Network Topology#GET',
              '||', 'Virtual Data Center Network#GET', '||', 'Cloud Environment Network#GET', '||',
              'Cloud Environment Sub Network#GET', '||', 'Cloud Environment Router Network#GET']],
    'myresource': [[['Virtual Data Center Network Topology#GET', '||',
              'Virtual Data Center Network#GET', '||', 'VDC Cloud Environment Network#View', '||',
              'VDC Cloud Environment Sub Network#View', '||', 'VDC Cloud Environment Router Network#View', '||',
              'Switch Port Groups#GET', '||', 'VDC Network QOS Policy#View'],
              '&&', 'Project#POST'], '||', ['My Virtual Machine#GET', '||',
              'My Volume#GET', '||', 'Virtual Data Center Image#GET', '||',
              'My Virtual Machine#GET', '||', 'My Template#GET', '||', 'My Firewall#GET', '||',
              'My Load Balance#GET', '||', 'Resource Bill#GET']]
  };
  constructor(private storageService: StorageService) {
    this.routeRights = routeRights;
  }
  containEveryRights(rights: string[]): boolean {
    if (rights.length === 0) return true;
    return _.every(rights, right => this.containRight(right));
  }

  containSomeRights(rights: string[]): boolean {
    if (rights.length === 0) return true;
    return _.some(rights, right => this.containRight(right));
  }
  containAllRights(rights: any): boolean {
    if (rights instanceof Array) {
      let pos: number;
      pos = rights.indexOf('&&');
      if (pos !== -1) {
        let left = rights.slice(0, pos);
        if (left.length === 1) {
          left = left[0];
        }
        let right = rights.slice(pos + 1);
        if (right.length === 1) {
          right = right[0];
        }
        return this.containAllRights(left) && this.containAllRights(right);
      }
      pos = rights.indexOf('||');
      if (pos !== -1) {
        let left = rights.slice(0, pos);
        if (left.length === 1) {
          left = left[0];
        }
        let right = rights.slice(pos + 1);
        if (right.length === 1) {
          right = right[0];
        }
        return this.containAllRights(left) || this.containAllRights(right);
      }
      return this.containEveryRights(rights);
    }else {
      return this.containRight(rights);
    }
  }

  getTopMenuRights(key: string): string[] {
    return this.topMenuAuthRights[key];
  }
  getWeighRoute(): string {
    const routeweight: Routeweight = this.getWeighRouteIn(this.routeRights);
    return routeweight.path;
  }
  getRouteRightsChild(paths: string[]): any {
    let child = this.routeRights;
    for (const path of paths) {
      child =  _.find(child, (routeRight: any) => {
        return (routeRight.path === path)  ;
      });
      if (!child) {
        return child;
      }
      child = child.children;
    }
    return child;
  }
  getRouteRightsNode(paths: string[]): any {
    let child = this.routeRights;
    for (const path of paths) {
      if (child.children) {
        child = child.children;
      }
      child =  _.find(child, (routeRight: any) => {
        return (routeRight.path === path)  ;
      });
      if (!child) {
        return child;
      }
    }
    return child;
  }
  getchildRights(routeRights_: any): string[] {
    let res: string [] = [];
    if (routeRights_.someRights) {
      res = res.concat(routeRights_.someRights);
    }
    if (routeRights_.children) {
      for (const child of routeRights_.children){
      res = res.concat(this.getchildRights(child));
    }
    }

    return res;
  }
  getWeighRouteIn(routeRights_: any): Routeweight {
    const routeweight: Routeweight = {path: '', weight: 0};
    let routeweighttmp: Routeweight;
    for (const child of routeRights_){
      if ( child.children ) {
        routeweighttmp = this.getWeighRouteIn(child.children);
        if ( routeweighttmp.weight > routeweight.weight ) {
          routeweight.path = child.path + '/' + routeweighttmp.path;
          routeweight.weight = routeweighttmp.weight;
        }
      } else {
        if ( child.someRights  ) {//for route-right.config.ts  someRights  detail
          if ( this.containSomeRights( child.someRights ) ) {
            if (child.weight > routeweight.weight) {
              routeweight.path = child.path;
              routeweight.weight = child.weight;
            }//endif
          }//endif
        }//endif
        if ( child.allRights ) {//for route-right.config.ts  allRights  detail
          if ( this.containAllRights( child.allRights )) {
            if (child.weight > routeweight.weight) {
              routeweight.path = child.path;
              routeweight.weight = child.weight;
            }//endif
          }
        }//endif
      }//end-else
    }
    return routeweight;
  }

  getUserNameRights(key: string): boolean {
    if (this.storageService.getUserName() === key) {
      return true;
    } else {
      return false;
    }
  }

  private containRight(right: string): boolean {
    let type = right.split('#')[0];
    let FlagNot  = false;
    if ( type.startsWith('!') ) {
      FlagNot = true;
      type = type.substr(1);
    }
    if ( resouceTypeMap.has(type) ) {
      type = resouceTypeMap.get(type);
    }
    const methods = right.split('#')[1].split(',');

    const storageService = this.storageService.getUserRights();
    if (storageService === undefined) {
      return true;
    }
    const userRight = _.findWhere(storageService, {resourceType: type});
    if (userRight === undefined) {
      if (FlagNot) {
        return true;
      }else {
        return false;
      }
    }
    const res = _.every(methods, function(method){
      return _.contains(userRight.operations, method);
    });
    if ( FlagNot ) {
        return !res;
      }else {
        return res;
      }
  };
}
