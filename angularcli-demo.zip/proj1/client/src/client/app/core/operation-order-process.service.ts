import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { OrgService } from '../orgManage/org.service';

@Injectable()
export class OrderProcessResolve implements Resolve<string[]> {
    constructor(private orgService: OrgService) {
    }

    resolve(route: ActivatedRouteSnapshot): Promise<any>|boolean {
        if (this.orgService.getChangeOrg()) {
            this.orgService.setChangeOrg(false);
        } else {
            this.orgService.setShowOrgChange(false);
        }

        return true;
    }
}
