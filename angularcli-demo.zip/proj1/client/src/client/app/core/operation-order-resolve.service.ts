/**
 * Created by 00186819 on 2017/4/10.
 */
import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { StorageService } from '../storage.service';
import { SendMessageService } from '../sendMessage.service';
import { OrgService } from '../orgManage/org.service';


@Injectable()
export class OrderResolve implements Resolve<string[]> {
    constructor(private orgService: OrgService,
                private storageService: StorageService,
                private sendMessageService: SendMessageService) {
    }

    resolve(route: ActivatedRouteSnapshot): Promise<string[]>|boolean {
        this.orgService.setShowOrgChange(true);

        if (this.orgService.getFirstLogin()) {
            this.orgService.setFirstLogin(false);
            this.sendMessageService.myresouceOnClick();
            return true;
        } else {
            if (this.orgService.getChangeOrg()) {
                this.orgService.setChangeOrg(false);
            } else {
                const currentOrg = this.storageService.getCurrentOrg();

                if (currentOrg) {
                    //刷新
                    this.orgService.setCurrentOrg(currentOrg);
                }
            }

            this.sendMessageService.operationOnClick();
            return true;
        }
    }
}
