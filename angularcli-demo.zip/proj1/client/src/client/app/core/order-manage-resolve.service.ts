import { Injectable }             from '@angular/core';
import {
    Resolve,
    ActivatedRouteSnapshot
} from '@angular/router';

import { SendMessageService } from '../sendMessage.service';
import { OrgService } from '../orgManage/org.service';
import { StorageService } from '../storage.service';


@Injectable()
export class OrderManageResolve implements Resolve<string[]> {
    constructor(private sendMessageService: SendMessageService,
                private storageService: StorageService,
                private orgService: OrgService) {
    }

    resolve(route: ActivatedRouteSnapshot): boolean {
        this.orgService.setShowOrgChange(true);
        if (this.orgService.getChangeOrg()) {
            this.orgService.setChangeOrg(false);
        } else {
            const currentOrg = this.storageService.getCurrentOrg();

            if (currentOrg) {
                //刷新
                this.orgService.setCurrentOrg(currentOrg);
            }
        }
        this.sendMessageService.orderManageOnClick();
        return true;
    }
}

