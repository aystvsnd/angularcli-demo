import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
@Injectable()
export class OsTypeService {
  getOsTypeList() {
    return [
      {
        name: 'Ubuntu',
        type: 'Linux',
        value: 0,
        options: [
          {
            name: `Ubuntu Linux (64 ${this.translate.instant('Bit')})`,
            value: 'Ubuntu Linux (64-bit)',
            map: 'ubuntu64Guest'
          },
          {
            name: `Ubuntu Linux (32 ${this.translate.instant('Bit')})`,
            value: 'Ubuntu Linux (32-bit)',
            map: 'ubuntuGuest'
          }
        ]
      },
      {
        name: 'CentOS',
        type: 'Linux',
        value: 1,
        options: [
          {
            name: `CentOS 4/5/6/7 (64 ${this.translate.instant('Bit')})`,
            value: 'CentOS 4/5/6/7 (64-bit)',
            map: 'centos64Guest'
          },
          {
            name: `CentOS 4/5/6 (32 ${this.translate.instant('Bit')})`,
            value: 'CentOS 4/5/6 (32-bit)',
            map: 'centosGuest'
          }
        ]
      },
      {
        name: 'Red Hat',
        type: 'Linux',
        value: 2,
        options: [
          {
            name: `Red Hat Enterprise Linux 7 (64 ${this.translate.instant('Bit')})`,
            value: 'Red Hat Enterprise Linux 7 (64-bit)',
            map: 'rhel7_64Guest'
          },
          {
            name: `Red Hat Enterprise Linux 6 (64 ${this.translate.instant('Bit')})`,
            value: 'Red Hat Enterprise Linux 6 (64-bit)',
            map: 'rhel6_64Guest'
          },
          {
            name: `Red Hat Enterprise Linux 6 (32 ${this.translate.instant('Bit')})`,
            value: 'Red Hat Enterprise Linux 6 (32-bit)',
            map: 'rhel6Guest'
          },
          {
            name: `Red Hat Enterprise Linux 5 (64 ${this.translate.instant('Bit')})`,
            value: 'Red Hat Enterprise Linux 5 (64-bit)',
            map: 'rhel5_64Guest'
          },
          {
            name: `Red Hat Enterprise Linux 5 (32 ${this.translate.instant('Bit')})`,
            value: 'Red Hat Enterprise Linux 5 (32-bit)',
            map: 'rhel5Guest'
          },
          {
            name: `Red Hat Enterprise Linux 4 (64 ${this.translate.instant('Bit')})`,
            value: 'Red Hat Enterprise Linux 4 (64-bit)',
            map: 'rhel4_64Guest'
          },
          {
            name: `Red Hat Enterprise Linux 4 (32 ${this.translate.instant('Bit')})`,
            value: 'Red Hat Enterprise Linux 4 (32-bit)',
            map: 'rhel4Guest'
          },
          {
            name: `Red Hat Enterprise Linux 3 (64 ${this.translate.instant('Bit')})`,
            value: 'Red Hat Enterprise Linux 3 (64-bit)',
            map: 'rhel3_64Guest'
          },
          {
            name: `Red Hat Enterprise Linux 3 (32 ${this.translate.instant('Bit')})`,
            value: 'Red Hat Enterprise Linux 3 (32-bit)',
            map: 'rhel3Guest'
          },
          {
            name: `Red Hat Enterprise Linux 2.1`,
            value: 'Red Hat Enterprise Linux 2.1',
            map: 'rhel2Guest'
          },
          {
            name: `Red Hat Fedora (64 ${this.translate.instant('Bit')})`,
            value: 'Red Hat Fedora (64-bit)',
            map: 'redhat64Guest'
          },
          {
            name: `Red Hat Fedora (32 ${this.translate.instant('Bit')})`,
            value: 'Red Hat Fedora (32-bit)',
            map: 'redhatGuest'
          }
        ]
      },
      {
        name: 'Microsoft Windows Server',
        type: 'Windows',
        value: 3,
        options: [
          {
            name: `Microsoft Windows Server2016(64 ${this.translate.instant('Bit')})`,
            value: 'Microsoft Windows Server2016(64-bit)',
            map: ''
          },
          {
            name: `Microsoft Windows Server2012 (64 ${this.translate.instant('Bit')})`,
            value: 'Microsoft Windows Server2012 (64-bit)',
            map: ''
          },
          {
            name: `Microsoft Windows Server2008 R2 (64 ${this.translate.instant('Bit')})`,
            value: 'Microsoft Windows Server2008 R2 (64-bit)',
            map: ''
          },
          {
            name: `Microsoft Windows Server2008 (64 ${this.translate.instant('Bit')})`,
            value: 'Microsoft Windows Server2008 (64-bit)',
            map: ''
          },
          {
            name: `Microsoft Windows Server2008 (32 ${this.translate.instant('Bit')})`,
            value: 'Microsoft Windows Server2008 (32-bit)',
            map: ''
          },
          {
            name: `Microsoft Windows Server2003 (64 ${this.translate.instant('Bit')})`,
            value: 'Microsoft Windows Server2003 (64-bit)',
            map: ''
          },
          {
            name: `Microsoft Windows Server2003 (32 ${this.translate.instant('Bit')})`,
            value: 'Microsoft Windows Server2003 (32-bit)',
            map: ''
          }
        ]
      },
      {
        name: 'Microsoft Windows',
        type: 'Windows',
        value: 4,
        options: [
          {
            name: `Microsoft Windows 10 (64 ${this.translate.instant('Bit')})`,
            value: 'Microsoft Windows 10 (64-bit)',
            map: 'windows10_64Guest'
          },
          {
            name: `Microsoft Windows 10 (32 ${this.translate.instant('Bit')})`,
            value: 'Microsoft Windows 10 (32-bit)',
            map: 'windows10Guest'
          },
          {
            name: `Microsoft Windows 8 (64 ${this.translate.instant('Bit')})`,
            value: 'Microsoft Windows 8 (64-bit)',
            map: 'windows8_64Guest'
          },
          {
            name: `Microsoft Windows 8 (32 ${this.translate.instant('Bit')})`,
            value: 'Microsoft Windows 8 (32-bit)',
            map: 'windows8Guest'
          },
          {
            name: `Microsoft Windows 7 (64 ${this.translate.instant('Bit')})`,
            value: 'Microsoft Windows 7 (64-bit)',
            map: 'windows7_64Guest'
          },
          {
            name: `Microsoft Windows 7 (32 ${this.translate.instant('Bit')})`,
            value: 'Microsoft Windows 7 (32-bit)',
            map: 'windows7Guest'
          },
          {
            name: `Microsoft Windows Vista (64 ${this.translate.instant('Bit')})`,
            value: 'Microsoft Windows Vista (64-bit)',
            map: 'winVista64Guest'
          },
          {
            name: `Microsoft Windows Vista (32 ${this.translate.instant('Bit')})`,
            value: 'Microsoft Windows Vista (32-bit)',
            map: 'winVistaGuest'
          },
          {
            name: `Microsoft Windows XP Professional (64 ${this.translate.instant('Bit')})`,
            value: 'Microsoft Windows XP Professional (64-bit)',
            map: 'winXPPro64Guest'
          },
          {
            name: `Microsoft Windows XP Professional (32 ${this.translate.instant('Bit')})`,
            value: 'Microsoft Windows XP Professional (32-bit)',
            map: 'winXPProGuest'
          },
          {
            name: 'Microsoft Windows 2000',
            value: 'Microsoft Windows 2000',
            map: 'win2000ProGuest'
          },
          {
            name: 'Microsoft Windows NT',
            value: 'Microsoft Windows NT',
            map: 'winNTGuest'
          },
          {
            name: 'Microsoft Windows 98',
            value: 'Microsoft Windows 98',
            map: 'win98Guest'
          },
          {
            name: 'Microsoft Windows 95',
            value: 'Microsoft Windows 95',
            map: 'win95Guest'
          },
          {
            name: 'Microsoft Windows 3.1',
            value: 'Microsoft Windows 3.1',
            map: 'win31Guest'
          },
          {
            name: 'Microsoft MS-DOS',
            value: 'Microsoft MS-DOS',
            map: 'dosGuest'
          }
        ]
      },
      {
        name: 'Debian',
        type: 'Linux',
        value: 5,
        options: [
          {
            name: `Debian GUN/Linux 8 (64 ${this.translate.instant('Bit')})`,
            value: 'Debian GUN/Linux 8 (64-bit)',
            map: 'debian8_64Guest'
          },
          {
            name: `Debian GUN/Linux 8 (32 ${this.translate.instant('Bit')})`,
            value: 'Debian GUN/Linux 8 (32-bit)',
            map: 'debian8Guest'
          },
          {
            name: `Debian GUN/Linux 7 (64 ${this.translate.instant('Bit')})`,
            value: 'Debian GUN/Linux 7 (64-bit)',
            map: 'debian7_64Guest'
          },
          {
            name: `Debian GUN/Linux 7 (32 ${this.translate.instant('Bit')})`,
            value: 'Debian GUN/Linux 7 (32-bit)',
            map: 'debian7Guest'
          },
          {
            name: `Debian GUN/Linux 6 (64 ${this.translate.instant('Bit')})`,
            value: 'Debian GUN/Linux 6 (64-bit)',
            map: 'debian6_64Guest'
          },
          {
            name: `Debian GUN/Linux 6 (32 ${this.translate.instant('Bit')})`,
            value: 'Debian GUN/Linux 6 (32-bit)',
            map: 'debian6Guest'
          },
          {
            name: `Debian GUN/Linux 5 (64 ${this.translate.instant('Bit')})`,
            value: 'Debian GUN/Linux 5 (64-bit)',
            map: 'debian5_64Guest'
          },
          {
            name: `Debian GUN/Linux 5 (32 ${this.translate.instant('Bit')})`,
            value: 'Debian GUN/Linux 5 (32-bit)',
            map: 'debian5Guest'
          },
          {
            name: `Debian GUN/Linux 4 (64 ${this.translate.instant('Bit')})`,
            value: 'Debian GUN/Linux 4 (64-bit)',
            map: 'debian4_64Guest'
          },
          {
            name: `Debian GUN/Linux 4 (32 ${this.translate.instant('Bit')})`,
            value: 'Debian GUN/Linux 4 (32-bit)',
            map: 'debian4Guest'
          }
        ]
      },
      {
        name: 'SUSE',
        type: 'Linux',
        value: 6,
        options: [
          {
            name: `SUSE Linux Enterprise 12 (64 ${this.translate.instant('Bit')})`,
            value: 'SUSE Linux Enterprise 12 (64-bit)',
            map: 'sles12_64Guest'
          },
          {
            name: `SUSE Linux Enterprise 11 (64 ${this.translate.instant('Bit')})`,
            value: 'SUSE Linux Enterprise 11 (64-bit)',
            map: 'sles11_64Guest'
          },
          {
            name: `SUSE Linux Enterprise 11 (32 ${this.translate.instant('Bit')})`,
            value: 'SUSE Linux Enterprise 11 (32-bit)',
            map: 'sles11Guest'
          },
          {
            name: `SUSE Linux Enterprise 10 (64 ${this.translate.instant('Bit')})`,
            value: 'SUSE Linux Enterprise 10 (64-bit)',
            map: 'sles10_64Guest'
          },
          {
            name: `SUSE Linux Enterprise 11 (32 ${this.translate.instant('Bit')})`,
            value: 'SUSE Linux Enterprise 11 (32-bit)',
            map: 'sles11Guest'
          },
          {
            name: `SUSE Linux Enterprise 8/9 (64 ${this.translate.instant('Bit')})`,
            value: 'SUSE Linux Enterprise 8/9 (64-bit)',
            map: 'sles64Guest'
          },
          {
            name: `SUSE Linux Enterprise 8/9 (32 ${this.translate.instant('Bit')})`,
            value: 'SUSE Linux Enterprise 8/9 (32-bit)',
            map: 'slesGuest'
          },
          {
            name: `SUSE openSUSE (64 ${this.translate.instant('Bit')})`,
            value: 'SUSE openSUSE (64-bit)',
            map: 'opensuse64Guest'
          },
          {
            name: `SUSE openSUSE (32 ${this.translate.instant('Bit')})`,
            value: 'SUSE openSUSE (32-bit)',
            map: 'opensuseGuest'
          }
        ]
      },
      {
        name: 'Axianux',
        type: 'Linux',
        value: 7,
        options: [
          {
            name: `Asianux 4 (64 ${this.translate.instant('Bit')})`,
            value: 'Asianux 4 (64-bit)',
            map: 'asianux4_64Guest'
          },
          {
            name: `Asianux 4 (32 ${this.translate.instant('Bit')})`,
            value: 'Asianux 4 (32-bit)',
            map: 'asianux4Guest'
          },
          {
            name: `Asianux 3 (64 ${this.translate.instant('Bit')})`,
            value: 'Asianux 3 (64-bit)',
            map: 'asianux3_64Guest'
          },
          {
            name: `Asianux 3 (32 ${this.translate.instant('Bit')})`,
            value: 'Asianux 3 (32-bit)',
            map: 'asianux3Guest'
          }
        ]
      },
      {
        name: 'Oracle',
        type: 'Linux',
        value: 8,
        options: [
          {
            name: `Oracle Linux 4/5/6/7 (64 ${this.translate.instant('Bit')})`,
            value: 'Oracle Linux 4/5/6/7 (64-bit)',
            map: 'oracleLinux64Guest'
          },
          {
            name: `Oracle Linux 4/5/6 (32 ${this.translate.instant('Bit')})`,
            value: 'Oracle Linux 4/5/6 (32-bit)',
            map: 'oracleLinuxGuest'
          }
        ]
      },
      {
        name: 'Other',
        type: 'Linux',
        value: 9,
        options: [
          {
            name: 'Other',
            value: 'Other',
            map: 'other'
          },
        ]
      }
    ];
  }
  constructor(public translate: TranslateService) {
  }
}
