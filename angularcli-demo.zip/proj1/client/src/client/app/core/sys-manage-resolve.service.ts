import { Injectable }             from '@angular/core';
import {
    Resolve,
    ActivatedRouteSnapshot
} from '@angular/router';

import { SendMessageService } from '../sendMessage.service';
import { OrgService } from '../orgManage/org.service';


@Injectable()
export class SysManageResolve implements Resolve<string[]> {
  constructor(private sendMessageService: SendMessageService, private orgService: OrgService) {
  }

  resolve(route: ActivatedRouteSnapshot): boolean {
    this.orgService.setShowOrgChange(false);
    this.sendMessageService.systemManageOnClick();
    return true;
  }
}

