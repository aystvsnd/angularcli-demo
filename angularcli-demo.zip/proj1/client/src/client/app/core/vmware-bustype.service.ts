import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
@Injectable()
export class VmwareBusService {
  getVmwareBusTypeList() {
    return [
      {
        osname: 'ubuntu64Guest',
        bustype: [
          {value: 'lsiLogic', text: `lsiLogic (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      },
      {
        osname: 'centos64Guest',
        bustype: [
          {value: 'lsiLogic', text: `lsiLogic (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      },
      {
        osname: 'rhel6_64Guest',
        bustype: [
          {value: 'paraVirtual', text: `paraVirtual (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'},
          {value: 'lsiLogic', text: 'lsiLogic'}
        ]
      },
      {
        osname: 'rhel5_64Guest',
        bustype: [
          {value: 'lsiLogic', text: `lsiLogic (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]

      },
      {
        osname: 'sles11_64Guest',
        bustype: [
          {value: 'lsiLogic', text: `lsiLogic (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      },
      {
        osname: 'sles10_64Guest',
        bustype: [
          {value: 'lsiLogic', text: `lsiLogic (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'}

        ]
      },
      {
        osname: 'debian6_64Guest',
        bustype: [
          {value: 'lsiLogic', text: `lsiLogic (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'}
        ]
      },
      {
        osname: 'debian5_64Guest',
        bustype: [
          {value: 'lsiLogic', text: `lsiLogic (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'}
        ]
      },
      {
        osname: 'oracleLinux64Guest',
        bustype: [
          {value: 'lsiLogic', text: `lsiLogic (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      },
      {
        osname: 'oracleLinuxGuest',
        bustype: [
          {value: 'lsiLogic', text: `lsiLogic (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      },
      {
        osname: 'windows_64Guest',
        bustype: [
          {value: 'lsiLogicsas', text: `lsiLogicsas (${this.translate.instant('recommend')})`},
          {value: 'lsiLogic', text: 'lsiLogic'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      },
      {
        osname: 'otherGuest',        //Windows Server 2012 R2 SERVERSTANDARD
        bustype: [
          {value: 'lsiLogicsas', text: `lsiLogicsas (${this.translate.instant('recommend')})`},
          {value: 'lsiLogic', text: 'lsiLogic'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      },
      {
        osname: 'windows7Server64Guest',  //Windows Server2008 R2(64-bit)
        bustype: [
          {value: 'lsiLogicsas', text: `lsiLogicsas (${this.translate.instant('recommend')})`},
          {value: 'lsiLogic', text: 'lsiLogic'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      },
      {
        osname: 'winNetEnterprise64Guest', //Windows Server 2003,Enterprise Edition(64-bit)
        bustype: [
          {value: 'lsiLogic', text: `lsiLogicsas (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      },
      {
        osname: 'winNetDatacenterGuest',  //Windows Server 2003,Datacenter Edition
        bustype: [
          {value: 'lsiLogic', text: `lsiLogicsas (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      },
      {
        osname: 'winNetEnterprise64Guest',  //Windows Server 2003,Enterprise Edition(64-bit)
        bustype: [
          {value: 'lsiLogic', text: `lsiLogicsas (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      },
      {
        osname: 'winNetEnterpriseGuest',  //Windows Server 2003,Enterprise Edition
        bustype: [
          {value: 'lsiLogic', text: `lsiLogicsas (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      },
      {
        osname: 'winNetStandard64Guest', //Windows Server 2003,Standard Edition(64-bit)
        bustype: [
          {value: 'lsiLogic', text: `lsiLogicsas (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      },
      {
        osname: 'winNetStandardGuest', //Windows Server 2003,Standard Edition
        bustype: [
          {value: 'lsiLogic', text: `lsiLogic (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      },
      {
        osname: 'winNetWebGuest', //Windows Server 2003,Web Edition
        bustype: [
          {value: 'lsiLogic', text: `lsiLogic (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      },
      {
        osname: 'winNetBusinessGuest', //Windows Small Business Server 2003
        bustype: [
          {value: 'lsiLogic', text: `lsiLogic (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      },
      {
        osname: 'windows8_64Guest',
        bustype: [
          {value: 'lsiLogicsas', text: `lsiLogicsas (${this.translate.instant('recommend')})`},
          {value: 'lsiLogic', text: 'lsiLogic'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      },
      {
        osname: 'windows7_64Guest',
        bustype: [
          {value: 'lsiLogicsas', text: `lsiLogicsas (${this.translate.instant('recommend')})`},
          {value: 'lsiLogic', text: 'lsiLogic'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      },
      {
        osname: 'winVista64Guest',
        bustype: [
          {value: 'lsiLogic', text: `lsiLogicsas (${this.translate.instant('recommend')})`},
          {value: 'lsiLogicsas', text: 'lsiLogicsas'},
          {value: 'paraVirtual', text: 'paraVirtual'}
        ]
      }
    ];
  }
  constructor(public translate: TranslateService) {
  }
}
