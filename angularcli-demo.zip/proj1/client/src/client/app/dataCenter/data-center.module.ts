import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/index';
import { DcClusterModule } from './dc-cluster/index';
import { DcAssetModule } from './dc-asset/index';
import { DcActionModule } from './dc-action/index';
import { DcDetailVirtualResourceModule } from './dc-detail-virtual-resource/index';
import { DcDetailPhysicalResourceModule } from './dc-detail-physical-resource/index';

import { DcSummaryComponent } from './dc-summary.component';
import { DcDetailComponent } from './dc-detail.component';

import { routing } from './data-center.routes';

import { DcService } from  './dc.service';
import { ResourceCenterResolve } from '../core/index';

@NgModule({
  imports: [SharedModule, routing, DcClusterModule, DcAssetModule, DcActionModule,
    DcDetailVirtualResourceModule, DcDetailPhysicalResourceModule],
  declarations: [DcSummaryComponent, DcDetailComponent],
  providers: [DcService, ResourceCenterResolve],
})

export class DataCenterModule { }
