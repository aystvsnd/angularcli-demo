import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DcSummaryComponent } from './dc-summary.component';
import { DcCreateComponent, DcBindComponent } from './dc-action/index';
import { DcDetailComponent } from './dc-detail.component';
import { DcClusterDetailComponent, DcClusterCreateComponent } from './dc-cluster/index';
import { DcPhysicalResourceViewComponent } from './dc-detail-physical-resource/index';
import { DcClusterPhysicalResourceViewComponent } from './dc-cluster/detail-physical-resource/index';
import { ResourceCenterResolve } from '../core/index';

const routes: Routes = [
  {
    path: '',
    resolve: {
      data: ResourceCenterResolve,
    },
    children: [
      {path: 'summary', component: DcSummaryComponent},
      {path: 'create', component: DcCreateComponent},
      {path: 'detail/:dcId', component: DcDetailComponent},
      {path: 'cluster/detail/:id', component: DcClusterDetailComponent},
      {path: 'cluster/create/:dcId', component: DcClusterCreateComponent},
      {path: 'details/physicalresource/:dcId', component: DcPhysicalResourceViewComponent},
      {path: 'cluster/details/physicalresource/:clusterId', component: DcClusterPhysicalResourceViewComponent},
      {path: 'cluster/edit/:dcId/:cloudenvId', component: DcClusterCreateComponent},
      {path: 'cluster/details/useroperate/:dcId/:operType', component: DcBindComponent}
    ]
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);

