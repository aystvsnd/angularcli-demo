/**
 * Created by root on 11/16/16.
 */
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DcService } from '../../dc.service';
import {TranslateService} from '@ngx-translate/core';
import { StorageService } from '../../../storage.service';
import { AuthService } from '../../../core/index';
import { ApiResourceService as Http } from '../../../apiResource.service';

@Component({
    moduleId: module.id,
    selector: 'dc-bind',
    templateUrl: 'dc-bind.component.html',
    styleUrls: ['dc-bind.component.css']
})

export class DcBindComponent implements OnInit {
    userList : any[] = [];
    bindUsers : any[] = [];
    unbindUsers : any[] = [];
    postData : any;
    operType : any;
    dcInfo: any;
    oper : any;
    infoMsgs: string[] = [];
    isShowLoading = false;
    isShowBindLoading = false;
    loadingBindTitle : any = this.translate.instant('gengyun.bindUserWait');
    errMsgs : string [] = [];
    isShowError = false;
    isShowInfo = true;
    isUserOper = true;
    isFirstLoad = true;
    selectedRows : any[] = [];
    userbindMessage : any = {
      title: this.translate.instant('gengyun.userBind'),
      message: '',
      confirmText: this.translate.instant('gengyun.bind'),
      cancelText: this.translate.instant('Cancel'),
      type: 'exclamation'
    };
    userUnBindMessage : any = {
      title: this.translate.instant('gengyun.userUnBind'),
      message: '',
      confirmText: this.translate.instant('gengyun.UnBind'),
      cancelText: this.translate.instant('Cancel'),
      type: 'exclamation'
    };
    links: any = [{name: this.translate.instant('DataCenter'), url: '/main/dc/summary'},
                {name: '', url: '/main/dc/detail/'},
                {name: this.translate.instant('gengyun.userBind')}];
    rowData : Array<any> = [];
    columnDefs: any[] = [
      {
        checkbox: true
      },
      {
        field: 'name',
        sortable: true,
        title: this.translate.instant('flavor.flavorName'),
        class: 'table-wrap'
      },
      {
        field: 'id',
        title: this.translate.instant('gengyun.ID')
      },
      {
        field: 'email',
        title: this.translate.instant('gengyun.email')
      },
      {
        field: 'status',
        title: this.translate.instant('Status')
      }
    ];
    gridOptions: any = {
      pagination: true,
      //sidePagination: 'server',
      pageSize: 5,
      pageList: [10, 25, 50, 100],
      search: true,
      strictSearch: false,
      searchText: '',
      paginationDetailHAlign: 'left',
      paginationHAlign: 'left',
      clickToSelect: true,
      sortable: true,
      sortName:'name',
      sortOrder:'asc'
    };
    constructor(private router: Router, private route : ActivatedRoute, public http : Http,
                private dcService: DcService, private storageService: StorageService,
                private translate: TranslateService, private authService: AuthService) {
        const that = this;
        if (that.storageService.getCurrentLang() === 'en') {
          $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
        } else {
          $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
        }
        this.postData = {
            'add': [],
            'delete': []
        };
    }

    ngOnInit() {
      const that = this;
      that.isFirstLoad = true;
      that.initTable();
      that.refreshBinds();
    }

    refreshBinds() {
      const that = this;
      const $table = $('#table-user-oper');
      if (that.isFirstLoad) {
        $table.bootstrapTable('showLoading');
      }
      that.route.params.subscribe(params => {
        that.operType = params['operType'];
        const dcId = params['dcId'];
        that.dcService.getDcByDcId(dcId).then((res: any) => {
          that.dcInfo = res;
          that.links[1].name = that.dcInfo.name;
          that.links[1].url = that.links[1].url + that.dcInfo.id;
          if (that.operType === 'bind') {
            that.isUserOper = true;
            that.oper = this.translate.instant('gengyun.bind');
          } else {
            that.isUserOper = false;
            that.links[2].name = this.translate.instant('gengyun.userUnBind');
            that.oper = this.translate.instant('gengyun.UnBind');
          }
          that.dcService.getAllAuthUsers().then((res : any) => {
            that.userList = res;
            that.dcService.getIksAcls().then((res2 : any) => {
              that.setRowData(res2);
              $('.fixed-table-footerButtons').remove();
              $table.bootstrapTable('load', that.rowData);
              if (that.rowData.length > 0) {
                that.setTableFooter();
              }
              if (that.selectedRows.length > 0) {
                $table.bootstrapTable('checkBy', {field: 'id', values: that.selectedRows});
              }
              if (that.isFirstLoad) {
                $table.bootstrapTable('hideLoading');
                that.isFirstLoad = false;
              }
            });
          });
        });
      });
    }

    setRowData(acls : any) {
      this.setBindUsers(acls);
      if (this.operType === 'bind') {
        this.rowData = this.unbindUsers;
      } else {
        this.rowData = this.bindUsers;
      }
    }

    setBindUsers(acls : any) {
      for (const acl of acls) {
        if (this.isAclBindTheDc(acl)) {
          for (const user of this.userList) {
            if (user.id === acl.userId) {
              this.bindUsers.push(user);
            }
          }
        }
      }
      this.unbindUsers = _.difference(this.userList, this.bindUsers);
    }

    isAclBindTheDc(acl : any) {
      for (const resource of acl.resources) {
        if ((resource.resourceType === 'dc') &&
          (resource.resourceId === this.dcInfo.id)) {
          return true;
        }
      }
      return false;
    }

    initTable() {
      const that = this;
      const $table = $('#table-user-oper');
      $table.bootstrapTable($.extend(that.gridOptions, {
        toolbar: '#toolbar-table-user-oper',
        data: that.rowData,
        columns: that.columnDefs
      }));
      $('.bootstrap-table .search input').attr('placeholder', this.translate.instant('WordForFilter'))
        .parent().append(`<span></span>`);
    }

    setTableFooter() {
      const that = this;
      $('#table-user-oper').parents('.fixed-table-container').append(`<div class="fixed-table-footerButtons">
        <button id="oper-btn" disabled>${this.oper}</button>
        <button id="cancel-btn">${this.translate.instant('Cancel')}</button>
           </div>`);

      $('#table-user-oper').on('check.bs.table uncheck.bs.table ' +
        'check-all.bs.table uncheck-all.bs.table', function () {
        $('#oper-btn').prop('disabled', !$('#table-user-oper').bootstrapTable('getSelections').length);
      });

      $('#oper-btn').click(function() {
        const selectNums = $('#table-user-oper').bootstrapTable('getSelections').length;
        that.userbindMessage.message = selectNums + that.translate.instant('gengyun.bindMessage');
        that.userUnBindMessage.message = selectNums + that.translate.instant('gengyun.UnBindMessage');
        that.operUser();
      });

      $('#cancel-btn').click(function() {
        that.cancel();
      });
    }

    operUser() {
        if (this.operType === 'bind') {
          $('#bindModal').modal({
            show: true
          });
        } else {
          $('#unBindModal').modal({
            show: true
          });
        }
    }

    gotoBindUserOper() {
      const that = this;
      that.postData.add = that.getUsersOper();
      that.postData.delete = [];
      console.log(JSON.stringify(that.postData));
      that.isShowBindLoading = true;
      that.dcService.modIksAcls(that.postData).then((res : any) => {
          this.infoMsgs[0] = this.translate.instant('gengyun.bindSuccess');
          this.isShowInfo = true;
          setTimeout(function () {
            that.isShowInfo = false;
            that.router.navigate(['/main/dc/detail', that.dcInfo.id]);
          }, 2000);
        },
        (error : any) => {
          this.errMsgs[0] = this.translate.instant('gengyun.bindFailed');
          that.isShowError = true;
          setTimeout(function () {
            that.isShowError = false;
          }, 2000);
        });
    }

    gotoUnbindUserOper() {
      const that = this;
      that.postData.add = [];
      that.postData.delete = that.getUsersOper();
      console.log(JSON.stringify(that.postData));
      that.isShowBindLoading = true;
      that.dcService.modIksAcls(that.postData).then((res : any) => {
          this.infoMsgs[0] = this.translate.instant('gengyun.UnBindSuccess');
          this.isShowInfo = true;
          that.isShowBindLoading = false;
          setTimeout(function () {
            that.isShowInfo = false;
            that.router.navigate(['/main/dc/detail', that.dcInfo.id]);
          }, 2000);
        },
        (error : any) => {
          this.errMsgs[0] = this.translate.instant('gengyun.UnBindFailed');
          that.isShowError = true;
          setTimeout(function () {
            that.isShowError = false;
          }, 2000);
        });
    }

    getUsersOper() {
      const that = this;
      const temp : any[] = [];
      const $table = $('#table-user-oper');
      const selectedBind : any[] = $table.bootstrapTable('getSelections');
      for (const user of selectedBind) {
        const userOper : any = {
          'userId': '',
          'resources': [
            {
              'resourceId': '',
              'resourceType': 'dc',
              'as': ['member']
            }
          ]
        };
        userOper.userId = user.id;
        userOper.resources[0].resourceId = that.dcInfo.id;
        temp.push(userOper);
      }
        return temp;
    }

    cancel() {
      this.router.navigate(['/main/dc/detail', this.dcInfo.id]);
    }
}
