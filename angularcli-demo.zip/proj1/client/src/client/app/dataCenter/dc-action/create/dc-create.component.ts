import { Component, OnInit } from '@angular/core';
//import { Response } from '@angular/http';
import { Router } from '@angular/router';
import {TranslateService} from '@ngx-translate/core';

import { ApiResourceService as Http } from '../../../apiResource.service';
import { DcService } from '../../dc.service';
import { SendMessageService } from '../../../sendMessage.service';

@Component({
    moduleId: module.id,
    templateUrl: 'dc-create.component.html',
    styleUrls: ['dc-create.component.css']
})

export class DcCreateComponent implements OnInit {
    links : any = [{name: this.translate.instant('dc.dc'), url: '/main/dc/summary'},
                    {name: this.translate.instant('dc.addDc')}];
    dc: any;
    isShowInfo = false;
    infoMsgs: string[] = [this.translate.instant('dc.infoMsg')];
    dcList : Array<any> = [];
    isShowLoading = false;
    loadingTitle : any = this.translate.instant('dc.addDcWait');
    errMsgs : string [] = [];
    isShowError = false;
    isValid = false;

    constructor(public http : Http,
                private router : Router,
                private dcService : DcService,
                private sendMessageService: SendMessageService,
                private translate: TranslateService) {
        this.dc = {
            'name': '',
            'location': '',
            'description': ''
        };
    }

    ngOnInit() {
      const that = this;
      that.dcService.getDcList().then((res: any) => {
        this.dcList = res;
      });
    }

    createDc() {
        const that = this;
        that.errMsgs = [];
        that.isShowLoading = !that.isShowLoading;
        that.isValid = true;
        that.dcService.addDc(that.dc).then(() => {
        that.isShowLoading = false;
        this.isShowInfo = !this.isShowInfo;
        const backToLink = '/main/dc/summary';
        that.sendMessageService.sendSucMsg(that.infoMsgs, backToLink);
        //setTimeout(function () {
        //  that.isShowInfo = false;
        //  let link = '/main/dc';
        //  that.router.navigate([link]);
        //}, 2000);
        },
        (error : any) => {
            that.errMsgs.push(error.message || error);
            that.isShowLoading = false;
            that.isShowError = false;
            that.isValid = false;
            /*setTimeout(function () {
                that.isShowError = false;
            }, 5000);*/
        });
        setTimeout(function () {
            that.isShowLoading = false;
            that.isValid = false;
        }, 60000);
    }

    cancel() {
      this.router.navigate(['/main/dc/summary']);
    }

    isAllInputvalid() {
      return ((this.dc.name !== '') && (this.dc.location !== ''));
    }

    isDcExist() {
      const that = this;
      for (const dcdata of that.dcList) {
        if (this.dc.name === dcdata.name) {
          return true;
        }
      }

      return false;
    }
}
