/**
 * Created by root on 6/15/17.
 */
import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/index';

import { DcCreateComponent } from './create/dc-create.component';
import { DcBindComponent } from './bind/dc-bind.component';

import { DcService } from  '../dc.service';

@NgModule({
  imports: [SharedModule],
  declarations: [ DcCreateComponent, DcBindComponent],
  providers: [DcService]
})

export class DcActionModule { }
