import { Injectable } from '@angular/core';
import { ApiResourceService as Http } from '../../apiResource.service';
import {Response} from '@angular/http';
import {appConfig} from '../../app.config';


@Injectable()
export class DcAssetService {

  constructor(public http: Http) {

  }
  getBladebyid(bladeId: any) {
    const that = this;
    return that.http.get(appConfig.physicalResourceUrl + 'servers/' + bladeId)
      .toPromise()
      .then((res: Response) => {return res.json(); });
  }

  getAsset() {
    return this.http.get(appConfig.physicalResourceUrl + 'assetManagementList')
      .toPromise()
      .then((res: Response) => {return res.json().assetDevices; })
      .catch(this.handleError);
  }

  postAsset(id: any, deviceModel: any, postData: any) {
    return this.http.post(appConfig.physicalResourceUrl + 'assetManagement/' + id + '/' + deviceModel, postData)
      .toPromise()
      .then((res: Response) => {
        return res; });
  }

  private handleError(error : any) {
    console.error('An error occurred', error);
    console.log(JSON.stringify(error));
    return error;
  }
}

