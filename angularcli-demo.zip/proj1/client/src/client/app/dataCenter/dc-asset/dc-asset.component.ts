import {Component, Input, OnChanges, OnInit} from '@angular/core';
import { ApiResourceService as Http } from '../../apiResource.service';
import { Response } from '@angular/http';
import {TranslateService} from '@ngx-translate/core';
import { Router } from '@angular/router';
import {DcAssetService} from './dc-asset-service';
import { AuthService } from '../../core/index';

@Component({
    moduleId: module.id,
    selector: 'dc-asset-basic-info',
    templateUrl: 'dc-asset.html',
    styleUrls: ['dc-asset.css'],
})

export class DcAssetComponent implements OnChanges, OnInit {
  @Input() basicInfo: any;
  @Input() countNum: any;
  @Input() deviceDetailEnterPath: string;

  isEdit= false;
  deviceAll: any;
  deviceInfo: any;
  options = [{
    label: this.translate.instant('hwm.is_yes'),
    value: 'yes'
  }, {
    label: this.translate.instant('hwm.no'),
    value: 'no'
  }];
  editAssetObj : any= {
    rent: 'no',
    tenant: '',
    rentStartTime: '',
    rentEndTime: ''
  };
  blade: any;
  dateErrTipsShow = false;
  routerDetailFlag = false;
  isRentInfoShow = false;
  rentAuthFlag : Array = [false, false, false];

  constructor( public  http: Http,
               private dcAssetService: DcAssetService,
               public  router: Router,
               private translate: TranslateService,
               private authService: AuthService) {

  }

  ngOnChanges() {
    this.countNum++;
    if (this.basicInfo.type === 'blade') {
      this.getBladeInfo();
    } else {
      this.getAssetInfo();
    }
  }

  ngOnInit() {
    this.checkEnterLink();
    this.getAuth();
  }

  checkEnterLink() {
    const that = this;
    if (that.deviceDetailEnterPath === 'dc') {
      window.localStorage.setItem('deviceDetailEnterPath', 'dcTopo');
    };

    if (that.deviceDetailEnterPath === 'cluster') {
      window.localStorage.setItem('deviceDetailEnterPath', 'clusterTopo');
    };
  }

  getAuth() {
    if (this.authService.containEveryRights(['Physical Server#Rent'])) {
      this.rentAuthFlag[0] = true;
    }
    if (this.authService.containEveryRights(['Physical Network Device#Rent'])) {
      this.rentAuthFlag[1] = true;
    }
    if (this.authService.containEveryRights(['Disk Array#Rent'])) {
      this.rentAuthFlag[2] = true;
    }
  }

  getAssetInfo() {
    const that = this;
    that.dcAssetService.getAsset().then((res: Response) => {
      that.getRentAuth(res);
      that.deviceAll = res;
      for (const item of that.deviceAll) {
        if (item.id === that.basicInfo.id) {
          that.deviceInfo = item;
          that.getDataCheckInit(that.deviceInfo);
          that.checkRouter();
          break;
        }
      }
    });
  }

  getBladeInfo() {
    const that = this;
    that.dcAssetService.getBladebyid(that.basicInfo.id).then((res: any) => {
      that.blade = res;
      const tmp : any = {
        name: that.blade.name,
        environment: that.blade.environment,
        location: that.blade.location,
        rent: that.blade.assetDetail.rent,
        tenant: that.blade.assetDetail.tenant,
        rentStartTime: that.blade.assetDetail.rentStartTime,
        rentEndTime: that.blade.assetDetail.rentEndTime
      };
      that.deviceInfo = tmp;
      that.getDataCheckInit(that.deviceInfo);
    });
  }

  getRentAuth(res: any) {
    const that = this;
    res.map(row => {
       row.rentAuth = false;
        if ( that.rentAuthFlag[0] === true) {
          if (row.deviceType === 'chassis' || row.deviceType === 'RackServer') {
            row.rentAuth = true;
          }
        }
        if (that.rentAuthFlag[1] === true) {
          if (row.deviceType === 'switch' || row.deviceType === 'router') {
            row.rentAuth = true;
          }
        }
        if (that.rentAuthFlag[2] === true) {
          if (row.deviceType === 'storage') {
            row.rentAuth = true;
          }
        }
    });
  }

  getDataCheckInit(deviceInfo: any) {
    const that = this;
    if (deviceInfo.rent === 'yes') {
      that.deviceInfo.rent = that.translate.instant('hwm.is_yes');
      that.isRentInfoShow = true;
    }else {
      that.deviceInfo.rent = that.translate.instant('hwm.no');
      that.isRentInfoShow = false;
    }
  }

  checkRouter() {
    if (this.basicInfo.type === 'router') {
      this.routerDetailFlag = true;
    }else {
      this.routerDetailFlag = false;
    }
  }

  edit() {
    const that = this;
    that.isEdit = !that.isEdit;
    that.getCurrentRentInfo();
  }

  onStartTimeHandle(event: any) {
    this.editAssetObj.rentStartTime = event.target.value;
  }

  onEndTimeHandle(event: any) {
    this.editAssetObj.rentEndTime = event.target.value;
  }

  setDateValid() {
    if (this.editAssetObj.rentStartTime !== '' && this.editAssetObj.rentEndTime !== '') {
      this.dateErrTipsShow = (this.editAssetObj.rentStartTime > this.editAssetObj.rentEndTime) ? true : false;
    }
  }

  checkGetRent() {
    const that = this;
    if (that.deviceInfo.rent === that.translate.instant('hwm.is_yes')) {
      that.deviceInfo.rent = 'yes';
    }else {
      that.deviceInfo.rent = 'no';
    }
  }

  getCurrentRentInfo() {
    const that = this;
    that.checkGetRent();
    that.editAssetObj.rent = that.deviceInfo.rent;
    that.editAssetObj.tenant = that.deviceInfo.tenant;
    that.editAssetObj.rentStartTime = that.deviceInfo.rentStartTime;
    that.editAssetObj.rentEndTime = that.deviceInfo.rentEndTime;
  }

  save() {
    const that = this;
    const id : any = that.basicInfo.id;
    let deviceModel: any = that.basicInfo.type;
    if (deviceModel === 'rackServer') {
        deviceModel = 'RackServer';
    }
    that.fixEditRent();
    that.dcAssetService.postAsset(id, deviceModel, that.editAssetObj).then((res: Response) => {
       that.getAssetInfo();
       that.setEditRentInit();
       that.isEdit = !that.isEdit;
      });

  }

  fixEditRent() {
    const that = this;
    if (that.editAssetObj.rent === 'no') {
      that.editAssetObj.tenant = '';
      that.editAssetObj.rentStartTime = '';
      that.editAssetObj.rentEndTime = '';
      that.dateErrTipsShow = false;
    }
  }

  setEditRentInit() {
    const that = this;
    if (that.editAssetObj.rent === 'yes') {
      that.editAssetObj.rent = 'no';
    }
  }

  cancle() {
    const that = this;
    that.getAssetInfo();
    that.setEditRentInit();
    that.isEdit = !that.isEdit;
    that.dateErrTipsShow = false;
  }

  gotoDetail() {
   const that = this;
   if (that.basicInfo.type === 'chassis') {
       this.router.navigate(['/main/physicalResource/server/frameServer/frameInner/detail', that.basicInfo.id]);
   }else if (that.basicInfo.type === 'rackServer') {
       this.router.navigate(['/main/physicalResource/server/frameServerSummary/detail', that.basicInfo.id]);
   } else if (that.basicInfo.type === 'storage') {
       this.router.navigate(['/main/physicalResource/storagesDevice/storages/detail/', that.basicInfo.id]);
   } else if (that.basicInfo.type === 'switch') {
       this.router.navigate(['/main/physicalResource/networkDevices/switches/detail/', that.basicInfo.id]);
   } else if (that.basicInfo.type === 'blade') {
       this.router.navigate(['/main/physicalResource/server/frameServer/bladeInner/detail', that.basicInfo.id]);
   } else {
       return;
   }

  }

}
