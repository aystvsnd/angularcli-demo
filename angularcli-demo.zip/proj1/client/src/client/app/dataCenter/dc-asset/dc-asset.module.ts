import { NgModule } from '@angular/core';
import { CommonModule, } from '@angular/common';
import { SharedModule } from '../../shared/index';
import { DcAssetComponent } from './dc-asset.component';
import { DcAssetService } from './dc-asset-service';


@NgModule({
    imports: [CommonModule, SharedModule],
    declarations: [DcAssetComponent],
    providers: [DcAssetService],
    exports: [DcAssetComponent]
})

export class DcAssetModule {}
