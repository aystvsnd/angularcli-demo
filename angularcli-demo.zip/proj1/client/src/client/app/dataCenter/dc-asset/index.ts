export * from './dc-asset.component';
export * from './dc-asset.module';
