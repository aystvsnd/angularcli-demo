
import {TranslateService} from '@ngx-translate/core';
import {Component, OnInit} from '@angular/core';
import {Response} from '@angular/http';
import {Router, ActivatedRoute} from '@angular/router';

import {DcService} from '../../../dc.service';

@Component({
    moduleId: module.id,
    templateUrl: 'dc-cluster-create.component.html',
    styleUrls: ['dc-cluster-create.component.css'],
})

export class DcClusterCreateComponent implements OnInit {
    dcId : any;
    dcInfo : any;

    options : any[] = [{'name': 'openstack + kvm', 'value': 'openstack'},
                        {'name': 'openstack + vcenter', 'value': 'vmware'}];
    cloudenvType : any;

    cluster: any;
    cloudenvList : Array<any> = [];

    serviceGradeOptions : any[] = [{
        'value': 'gold',
        'name': this.translate.instant('gengyun.gold')
    }, {
        'value': 'silver',
        'name': this.translate.instant('gengyun.silver')
    }, {
        'value': 'copper',
        'name': this.translate.instant('gengyun.bronze')
    }];
    selectedServiceGrade : any;
    areaStation : any;
    subStation : any;
    passwordType : any = 'password';

    isShowInfo = false;
    infoMsgs: string[] = [];
    isShowLoading = false;
    loadingTitle : any = this.translate.instant('dc.addDcWait');
    errMsgs : string [] = [];
    isShowError = false;
    isValid = false;

    focusInputFlags : any[] = [{'name': 'name', 'isFocus': false},
                              {'name': 'url', 'isFocus': false}];

    links : any = [{name: this.translate.instant('dc.dc'), url: '/main/dc/summary'},
                    {name: '', url: '/main/dc/detail/'},
                    {name: ''}];
    isEditState = false;
    editCloudenvId : any;
    editCloudenvData : any;
    isShowPage = false;

    constructor(private translate: TranslateService,
                private activatedRoute: ActivatedRoute,
                private router: Router,
                private dcService: DcService) {
        this.cluster = {
            name: '',
            description: '',
            envType: '',
            uri: '',
            userName: '',
            password: '',
            defaultTenant: 'admin',
            serviceGrade: '',
            metadata: {}
        };
    }

    ngOnInit() {
        const that = this;
        that.activatedRoute.params.subscribe(params => {
            that.dcId = params['dcId'];
            that.editCloudenvId = params['cloudenvId'];
            if (that.editCloudenvId) {
                that.dcService.getcloudEnvbyid(that.editCloudenvId).then((res : any) => {
                    that.editCloudenvData = res;
                    that.setEditCloudenvData(that.editCloudenvData);
                    that.links[1].name = res.dc.name;
                    that.links[1].url = that.links[1].url + res.dc.id;
                    that.links[2].name = that.translate.instant('gengyun.editcloudenv');
                    that.isShowPage = true;
                    that.isEditState = true;
                });
                that.dcService.getAllCloudenvs().then((res : any) => {
                    that.cloudenvList = res;
                    that.cloudenvList = that.cloudenvList.filter(function(cloudenv) {
                        return cloudenv.id !== that.editCloudenvId;
                    });
                });
            } else {
                that.dcService.getDcByDcId(that.dcId).then((res : any) => {
                    that.dcInfo = res;
                    that.links[1].name = that.dcInfo.name;
                    that.links[1].url = that.links[1].url + that.dcId;
                    that.links[2].name = that.translate.instant('gengyun.addcloudenv');
                    that.isShowPage = true;
                });
                that.dcService.getAllCloudenvs().then((res : any) => {
                    that.cloudenvList = res;
                });
            }
        });
    }

    setEditCloudenvData(cloudenv : any) {
        const that = this;
        that.cluster.name = cloudenv.name;
        that.cluster.description = cloudenv.description;
        that.cluster.envType = cloudenv.envType;
        that.cluster.uri = cloudenv.admin_uri;
        that.cluster.userName = cloudenv.userName;
        that.cluster.password = cloudenv.password;
        that.cluster.defaultTenant = cloudenv.defaultTenant;
        that.cluster.serviceGrade = cloudenv.serviceGrade;
        that.cluster.metadata.switch = cloudenv.metadata.switch;
        if (cloudenv.metadata) {
            that.areaStation = cloudenv.metadata.areaStation;
            that.subStation = cloudenv.metadata.subStation;
        }
        that.cloudenvType = that.cluster.envType;
        that.selectedServiceGrade = that.cluster.serviceGrade;
    }

    estimateUrlPattern(uri: any) {
        /* tslint:disable */
        const reg = new RegExp('^http(s?)://((25[0-5]|2[0-4]\\d|[01]?\\d\\d?)\\.){3}(25[0-5]|2[0-4]\\d|[01]?\\d\\d?):([1-5]?\\d{1,4}|6[1-5][1-5][1-3][1-5])$');
        /* tslint:enable */
        return ((uri === '') || reg.test(uri));
    }

    selectType() {
        this.cluster.envType = this.cloudenvType;
    }

    addCluster() {
        const that = this;
        that.infoMsgs = [this.translate.instant('gengyun.addEnvinfo')];
        that.setMetadata();
        const postData = {
            cloudEnv: this.cluster,
            dc: {
                id: this.dcId
            }
        };

        that.isShowLoading = !that.isShowLoading;
        that.isValid = true;
        that.dcService.addCloudenv(postData).then((res: Response) => {
            that.isShowLoading = false;
            this.isShowInfo = !this.isShowInfo;
            setTimeout(function () {
                that.isShowInfo = false;
                that.router.navigate(['/main/dc/detail', that.dcId]);
            }, 2000);
        },
        (error : any) => {
            that.errMsgs.push(error.message || error);
            that.isShowLoading = false;
            that.isShowError = false;
            that.isValid = false;
            /*setTimeout(function () {
                that.isShowError = false;
            }, 5000);*/
        });
        setTimeout(function () {
            that.isShowLoading = false;
            that.isValid = false;
        }, 60000);
    }

    setMetadata() {
        const that = this;
        if (that.areaStation !== undefined) {
            that.cluster.metadata.areaStation = that.areaStation;
        }

        if (that.subStation !== undefined) {
            that.cluster.metadata.subStation = that.subStation;
        }
    }

    cancel() {
          this.router.navigate(['/main/dc/detail', this.dcId]);
    }

    confirm() {
        const that = this;
        that.infoMsgs = [this.translate.instant('gengyun.editCloudenvSuccess')];
        that.setMetadata();
        const postData = {
            cloudEnv: this.cluster,
            dc: {
                id: this.dcId
            }
        };
        that.isShowLoading = !that.isShowLoading;
        that.isValid = true;
        that.dcService.modCloudenv(that.editCloudenvId, postData).then((res: Response) => {
                that.isShowLoading = false;
                this.isShowInfo = !this.isShowInfo;
                setTimeout(function () {
                    that.isShowInfo = false;
                    that.router.navigate(['/main/dc/detail', that.dcId]);
                }, 2000);
            },
            (error : any) => {
                that.errMsgs.push(error.message || error);
                that.isShowLoading = false;
                that.isShowError = false;
                that.isValid = false;
                /*setTimeout(function () {
                    that.isShowError = false;
                }, 5000);*/
            });
        setTimeout(function () {
            that.isShowLoading = false;
            that.isValid = false;
        }, 60000);

    }

    editCancel() {
        this.router.navigate(['/main/dc/detail', this.dcId]);
    }

    isNameExist(name: any) {
        const that = this;
        for (const cloudenv of that.cloudenvList) {
            if (cloudenv.envName === name) {
                return true;
            }
        }

        return false;
    }

    isNameillegal(name: any) {
        const reg = /^[\-\w]+$/;
        return (name !== '') && !reg.test(name);
    }

    isUrlExist(uri: any) {
      const that = this;
        for (const cloudenv of that.cloudenvList) {
            if (cloudenv.url === uri) {
                return true;
            }
        }

      return false;
    }

    isCloudenvExist(name: any, uri: any) {
        const that = this;
        return (that.isNameExist(name) || that.isUrlExist(uri));
    }

    selectGrade() {
        this.cluster.serviceGrade = this.selectedServiceGrade;
    }

    isSelectedOption() {
        return ((this.cloudenvType !== undefined) && (this.selectedServiceGrade !== undefined));
    }

    changePasswordType() {
        if (this.passwordType === 'password') {
            this.passwordType = 'text';
            $('#eye').attr('src', 'assets/images/eye1.png');
        } else {
            this.passwordType = 'password';
            $('#eye').attr('src', 'assets/images/eye.png');
        }
    };

    setFocusInputFlag(inputName : any, flag : any) {
        const that = this;
        for (const inputFlag of that.focusInputFlags) {
            if (inputFlag.name === inputName) {
                inputFlag.isFocus = flag;
                break;
            }
        }
    }

    isShowExplain(isTryInputFlag : boolean, specConfig : any) {
        return (isTryInputFlag && (specConfig === ''));
    }
}
