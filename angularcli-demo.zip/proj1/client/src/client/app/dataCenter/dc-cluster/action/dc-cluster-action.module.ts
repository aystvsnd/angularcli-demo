/**
 * Created by root on 6/14/17.
 */
import { NgModule } from '@angular/core';
import { SharedModule } from '../../../shared/index';
import { MultipleSelectModule } from '../../multiple-select/index';

import { EditSwitchComponent } from './editFunctionSwitch/dc-cluster-editswitch.component';
import { ClusterSetDeployPolicyComponent } from './setDeployPolicy/cluster-set-deploypolicy.component';
import { DcClusterCreateComponent } from './create/dc-cluster-create.component';

import { DcService } from '../../dc.service';
import { DcClusterActionService } from './dc-cluster-action.service';

@NgModule({
  imports: [SharedModule, MultipleSelectModule],
  declarations: [EditSwitchComponent, ClusterSetDeployPolicyComponent, DcClusterCreateComponent],
  providers: [DcService, DcClusterActionService],
  exports: [ EditSwitchComponent, ClusterSetDeployPolicyComponent]
})

export class DcClusterActionModule { }

