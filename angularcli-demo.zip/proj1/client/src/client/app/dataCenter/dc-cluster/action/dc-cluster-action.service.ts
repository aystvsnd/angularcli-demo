/**
 * Created by root on 6/14/17.
 */
import { Injectable } from '@angular/core';
//import { Response } from '@angular/http';
import { appConfig } from '../../../app.config';
import { ApiResourceService as Http } from '../../../apiResource.service';

@Injectable()
export class DcClusterActionService {

  constructor(public http: Http) {

  }

  setClusterDeployPolicy(id : any, data : any) {
    return this.http.put(`${appConfig.vrmServiceUrl}cloudenvs/${id}/haPolicy`, data)
      .toPromise();
  }

  private handleError(error : any) {
    console.error('An error occurred', error);
    console.log(JSON.stringify(error));
    return error;
  }
}
