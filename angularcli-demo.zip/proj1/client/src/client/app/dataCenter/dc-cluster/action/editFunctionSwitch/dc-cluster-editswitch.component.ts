import { Component, EventEmitter, Input , Output, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DcService } from '../../../dc.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  moduleId: module.id,
  selector: 'edit-switch',
  templateUrl: 'dc-cluster-editswitch.component.html',
  styleUrls: ['dc-cluster-editswitch.component.css']
})

export class EditSwitchComponent implements OnInit {
  @Input() id : string;
  @Input() editid : any;
  @Output() sendMessageDown = new EventEmitter();
  dcId : any;
  userList : any[] = [];
  oldSelectedUsers : any[] = [];
  postData : any;
  isShowLoading = false;
  errMsgs : string [] = [];
  isShowError = false;
  isValid = true;
  postEditData : any;
  phyNet : any;
  haGrant : any;
  storagePolicy : any;
  checked : any;
  checkedlist : any;
  cloudenvs : any;
  cluster: any;
  switchlist : any = {};
  zzswitchlist : any = {
  'phyNet' : false,
  'haGrant' : false,
  'storagePolicy' : false
    };
  constructor(private router: Router,
              private dcService: DcService,
              private translate: TranslateService) {
    this.cluster = {
      name: '',
      description: '',
      envType: '',
      uri: '',
      userName: '',
      password: '',
      defaultTenant: 'admin',
      serviceGrade: '',
      metadata: {}
    };
  }

  ngOnInit() {
    const that = this;
    that.dcService.getcloudEnvbyid(that.editid).then((res: any) => {
      that.cloudenvs = res;
      that.dcId = that.cloudenvs.dc.id;
      that.setEditCloudenvData(that.cloudenvs);
      if (res.metadata.switch) {
        that.switchlist = res.metadata.switch;
        that.checkedlist = _.pairs(that.switchlist);
      } else {
        that.switchlist = that.zzswitchlist;
        that.checkedlist = _.pairs(that.switchlist);
      }
    });
  }

  setEditCloudenvData(cloudenv : any) {
    const that = this;
    that.cluster.name = cloudenv.name;
    that.cluster.description = cloudenv.description;
    that.cluster.envType = cloudenv.envType;
    that.cluster.uri = cloudenv.admin_uri;
    that.cluster.userName = cloudenv.userName;
    that.cluster.password = cloudenv.password;
    that.cluster.defaultTenant = cloudenv.defaultTenant;
    that.cluster.serviceGrade = cloudenv.serviceGrade;
    that.cluster.metadata = cloudenv.metadata;
    if (cloudenv.metadata.switch) {
      that.phyNet = cloudenv.metadata.switch.phyNet;
      that.haGrant = cloudenv.metadata.switch.haGrant;
      that.storagePolicy = cloudenv.metadata.switch.storagePolicy;
    }else {
      that.phyNet = false;
      that.haGrant = false;
      that.storagePolicy = false;
    }
  }

  setCheck(name : any , checked : any) {
    if (name === 'phyNet') {
          this.switchlist.phyNet = checked;
      }
      if (name === 'haGrant') {
        this.switchlist.haGrant = checked;
      }
      if (name === 'storagePolicy') {
        this.switchlist.storagePolicy = checked;
      }
      console.log(this.switchlist);
  }


  cancel() {
      this.sendMessageDown.emit('cancel');
  }

  submit() {
      console.log(JSON.stringify(this.switchlist));
      const that = this;
      that.cluster.metadata.switch = that.switchlist;
      const postEditData = {
        cloudEnv: this.cluster,
        dc: {
          id: this.dcId
        }
      };
      that.errMsgs = [];
      that.isShowLoading = true;
      that.dcService.modCloudenv(that.editid, postEditData).then((res: Response) => {
          that.isShowLoading = false;
          this.sendMessageDown.emit('submit');
        },
        (error : any) => {
          that.errMsgs.push(error.message || error);
          that.isShowLoading = false;
          that.isShowError = false;
          this.sendMessageDown.emit('cancel');
        });
      setTimeout(function () {
        that.isShowLoading = false;
      }, 8000);
  }

  checkname(key : any) {
    switch (key) {
      case 'phyNet':
        return this.translate.instant('gengyun.phyNet');
      case 'haGrant':
        return this.translate.instant('gengyun.haGrant');
      case 'storagePolicy':
        return this.translate.instant('gengyun.storagePolicy');
      default:
        return key;
    }
  }

}
