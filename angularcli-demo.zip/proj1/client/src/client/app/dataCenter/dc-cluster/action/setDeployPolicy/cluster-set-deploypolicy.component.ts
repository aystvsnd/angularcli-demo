/**
 * Created by root on 6/14/17.
 */
import { Component, EventEmitter, Input , Output, OnInit } from '@angular/core';
import { DcService } from '../../../dc.service';
import { TranslateService } from '@ngx-translate/core';
import { DcClusterActionService } from '../dc-cluster-action.service';

@Component({
  moduleId: module.id,
  selector: 'cluster-set-deploypolicy',
  templateUrl: 'cluster-set-deploypolicy.component.html',
  styleUrls: ['cluster-set-deploypolicy.component.css']
})

export class ClusterSetDeployPolicyComponent implements OnInit {
  @Input() cloudenvId : any;
  @Output() setDeployPolicyMessage = new EventEmitter();
  putData : any;
  isShowLoading = false;
  isValid = false;
  computeHaOptions : any[] = [];
  selectedComputeAggregate : any;
  computeTypeOptions : any[] = [{'name': this.translate.instant('gengyun.setdeploypolicy.router'),
                                  'value': 'router', 'checked': false},
                                {'name': this.translate.instant('gengyun.setdeploypolicy.office'),
                                  'value': 'office', 'checked': false},
                                {'name': this.translate.instant('gengyun.setdeploypolicy.firewall'),
                                  'value': 'firewall', 'checked': false},
                                {'name': this.translate.instant('gengyun.setdeploypolicy.ros'),
                                  'value': 'ros', 'checked': false},
                                {'name': this.translate.instant('gengyun.setdeploypolicy.lb'),
                                  'value': 'loadbalance', 'checked': false},
                                {'name': this.translate.instant('gengyun.setdeploypolicy.instrudetect'),
                                  'value': 'intrusiondetection', 'checked': false}];
  selectComputeTypes : any[] = [];
  nfvHaOptions : any[] = [];
  selectedNfvAggregate : any;
  nfvTypeOptions : any[] = [{'name': this.translate.instant('gengyun.setdeploypolicy.router'),
                              'value': 'router', 'checked': false},
                            {'name': this.translate.instant('gengyun.setdeploypolicy.office'),
                              'value': 'office', 'checked': false},
                            {'name': this.translate.instant('gengyun.setdeploypolicy.firewall'),
                              'value': 'firewall', 'checked': false},
                            {'name': this.translate.instant('gengyun.setdeploypolicy.ros'),
                              'value': 'ros', 'checked': false},
                            {'name': this.translate.instant('gengyun.setdeploypolicy.lb'),
                              'value': 'loadbalance', 'checked': false},
                            {'name': this.translate.instant('gengyun.setdeploypolicy.instrudetect'),
                              'value': 'intrusiondetection', 'checked': false}];
  selectNfvTypes : any[] = [];

  tempComputeTypes : any[] = [];
  tempNfvTypes : any[] = [];
  isTypeConflict = false;

  constructor(private dcService : DcService,
              private dcClusterActionService : DcClusterActionService,
              private translate : TranslateService) {
    this.putData = {
      'computeHa': [
        {
          'name': '',
          'resourceType': []
        }
      ],
      'NFVHa': [
        {
          'name': '',
          'resourceType': []
        }
      ]
    };
  }

  ngOnInit() {
    const that = this;
    that.isShowLoading = true;
    that.dcService.getcloudEnvbyid(that.cloudenvId).then((res : any) => {
      that.initConfigOptions(res);
      that.isShowLoading = false;
    });

    setTimeout(() => {
      that.isShowLoading = false;
    }, 10000);
  }

  initConfigOptions(cloudenv : any) {
    const that = this;
    if (!that.isArrayIllegal(cloudenv.azs)) {
      for (const az of cloudenv.azs) {
        if (!that.isArrayIllegal(az.host_aggregates)) {
          az.host_aggregates.forEach(function(aggregate) {
            const tmpOption = {'name': '', 'value': ''};
            tmpOption.value = aggregate.name;
            tmpOption.name = _.first(aggregate.name.split('.'));
            that.computeHaOptions.push(tmpOption);
            that.nfvHaOptions.push(tmpOption);
          });
        }
      }
    }
    //console.log(JSON.stringify(that.computeHaOptions));
    //console.log(JSON.stringify(that.nfvHaOptions));
    that.initComputeHaPolicy(cloudenv.computeHa);
    that.initNfvHaPolicy(cloudenv.NFVHa);
  }

  initComputeHaPolicy(computeHa : any) {
    if (this.isArrayIllegal(computeHa)) {
      return;
    }

    const selectedComputeHa = _.find(this.computeHaOptions, function(option) {
      return option.value === computeHa[0].name;
    });
    if (!_.isUndefined(selectedComputeHa)) {
      this.selectedComputeAggregate = selectedComputeHa.value;
      this.setComputeTypeOption(computeHa[0].resourceType);
    }
  }

  setComputeTypeOption(resourceTypes : any) {
    if (this.isArrayIllegal(resourceTypes)) {
      return;
    }

    this.computeTypeOptions.forEach((option) => {
      if (_.contains(resourceTypes, option.value)) {
        option.checked = true;
      }
    });
    this.selectComputeTypes = resourceTypes;
  }

  initNfvHaPolicy(NfvHa : any) {
    if (this.isArrayIllegal(NfvHa)) {
      return;
    }

    const selectedNfvHa = _.find(this.nfvHaOptions, function(option) {
      return option.value === NfvHa[0].name;
    });
    if (!_.isUndefined(selectedNfvHa)) {
      this.selectedNfvAggregate = selectedNfvHa.value;
      this.setNfvTypeOption(NfvHa[0].resourceType);
    }
  }

  setNfvTypeOption(resourceTypes : any) {
    if (this.isArrayIllegal(resourceTypes)) {
      return;
    }

    this.nfvTypeOptions.forEach((option) => {
      if (_.contains(resourceTypes, option.value)) {
        option.checked = true;
      }
    });
    this.selectNfvTypes = resourceTypes;
  }

  isArrayIllegal(value : any) {
    return _.isUndefined(value) || _.isNull(value) || _.isEmpty(value);
  }

  submit() {
    const that = this;
    that.setPutData();
    that.isShowLoading = true;
    that.dcClusterActionService.setClusterDeployPolicy(that.cloudenvId, that.putData)
      .then((res : any) => {
         that.isShowLoading = false;
         that.setDeployPolicyMessage.emit('submit');
         },
         (error : any) => {
         that.isShowLoading = false;
         that.setDeployPolicyMessage.emit('cancel');
      });

     setTimeout(() => {
      that.isShowLoading = false;
     }, 8000);
  }

  cancel() {
    this.setDeployPolicyMessage.emit('cancel');
  }

  setPutData() {
    this.putData.computeHa[0].name = this.selectedComputeAggregate;
    this.putData.computeHa[0].resourceType = this.selectComputeTypes;
    this.putData.NFVHa[0].name = this.selectedNfvAggregate;
    this.putData.NFVHa[0].resourceType = this.selectNfvTypes;
  }

  selectHaOption() {
    this.isTypeConflict = this.isSelectTypeConflict();
  }

  handleComputeTypeSelect(selectOptions : any) {
    //console.log(JSON.stringify(selectOptions));
    this.selectComputeTypes = _.pluck(selectOptions, 'value');
    this.isTypeConflict = this.isSelectTypeConflict();
  }

  handleNfvTypeSelect(selectOptions : any) {
    //console.log(JSON.stringify(selectOptions));
    this.selectNfvTypes = _.pluck(selectOptions, 'value');
    this.isTypeConflict = this.isSelectTypeConflict();
  }

  isSelectTypeConflict() {
    if ((this.selectedComputeAggregate === undefined) ||
       (this.selectedNfvAggregate === undefined) ||
       (this.selectedComputeAggregate === this.selectedNfvAggregate)) {
      return false;
    } else {
      return !_.isEmpty(_.intersection(this.selectComputeTypes, this.selectNfvTypes));
    }
  }

  isDisableConfirm() {
    return (this.selectedComputeAggregate === undefined) ||
           (this.selectedNfvAggregate === undefined) ||
           (this.selectComputeTypes.length === 0) ||
           (this.selectNfvTypes.length === 0) || this.isTypeConflict;
  }

}
