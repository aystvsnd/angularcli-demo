
import {Component, OnInit, OnDestroy} from '@angular/core';
import {Router, ActivatedRoute } from '@angular/router';
import {DcService} from '../dc.service';
import {TranslateService} from '@ngx-translate/core';
import {StorageService} from '../../storage.service';
import { AuthService } from '../../core/index';


@Component({
    moduleId: module.id,
    templateUrl: 'dc-cluster-detail.component.html',
    styleUrls: ['./action/create/dc-cluster-create.component.css'],
})
export class DcClusterDetailComponent implements OnInit, OnDestroy {
    static backFirstTabNamee : any = '';
    static backSencondTabNamee : any = '';
    id: any;
    cloudenv : any;
    currentActiveBtn: any;
    isShowLoading = false;

    links : any = [{name: this.translate.instant('DataCenter'), url: '/main/dc/summary'},
                  {name: '', url: '/main/dc/detail/'}, {name: ''}];
    selectTabFirstz : any;
    selectTabz : any;
    selectTabph: any;
    viewAuthFlag: Array<any>  = [false, false, false];
    //viewAuthFlag: Array<any>  =[];
    public tabsFirstLevel : Array<any> = [
        {title: this.translate.instant('hwm.virtual_resources'), name: 'cloudenvdetailbasic', active: false},
        {title: this.translate.instant('hwm.physical_resource1'), name: 'cloudenvdetailPhysicalResource', active: false}];

    public tabs : Array<any> = [
        {title: this.translate.instant('BasicInfo'), name: 'cloudenvdetailbasic', active: false},
        {title: this.translate.instant('hwm.resource_use_rate'), name: 'cloudenvdetailResource', active: false},
        {title: this.translate.instant('gengyun.AZ'), name: 'cloudenvdetailAz', active: false},
        {title: this.translate.instant('hwm.host_aggrate'), name: 'cloudenvdetailHostAggrate', active: false},
        {title: this.translate.instant('Host'), name: 'cloudenvdetailHost', active: false},
        {title: this.translate.instant('gengyun.bareMetal.name'), name: 'cloudenvdetailBareMetal', active: false},
        {title: this.translate.instant('VirMachine'), name: 'cloudenvdetailVm', active: false},
        {title: this.translate.instant('gengyun.bareMetal.machine'), name: 'cloudenvdetailBareMetalServer', active: false}];

    public tabsPhysicalResource : Array<any> = [
      {title: this.translate.instant('hwm.overview'), name: 'cloudenvdetailPhysicalResource', active: true},
      {title: this.translate.instant('hwm.chassis1'), name: 'cloudenvdetailChassis', active: false},
      {title: this.translate.instant('hwm.board1'), name: 'cloudenvdetailBlade', active: false},
      {title: this.translate.instant('hwm.rack_server'), name: 'cloudenvdetailRackServer', active: false},
      {title: this.translate.instant('hwm.storage1'), name: 'cloudenvdetailStorage', active: false},
      {title: this.translate.instant('hwm.switch'), name: 'cloudenvdetailSwitch', active: false},
      {title: this.translate.instant('hwm.router'), name: 'cloudenvdetailRouter', active: false},
      {title: 'POD', name: 'cloudenvdetailPod', active: false},
      {title: this.translate.instant('hwm.rack1'), name: 'cloudenvdetailRack', active: false}
    ];

    constructor(private activatedRoute : ActivatedRoute,
                private dcService : DcService,
                private router: Router,
                private storageService: StorageService,
                private translate: TranslateService,
                private authService: AuthService) {
        this.activatedRoute.params.subscribe(params => {
            this.id = params['id'];
        });
    }

    ngOnInit() {
        const that = this;
        this.getTabsAuth();
        this.setTabsAuth();
        that.isShowLoading = true;
        that.dcService.getcloudEnvbyid(that.id).then((res: any) => {
            that.cloudenv = res;
            that.links[1].name = that.cloudenv.dc.name;
            that.links[1].url = that.links[1].url + that.cloudenv.dc.id;
            that.links[2].name = that.cloudenv.name;
            that.isShowLoading = false;

        });
        window.localStorage.setItem('deviceDetailEnterPath', '');

        that.tabsFirstLevel[0].active = true;
        that.tabs[0].active = true;

        that.currentActiveBtn = window.localStorage.getItem('currentTab');
        if (that.currentActiveBtn !== '') {
          if (that.checkBtnBelong(that.tabs)) {
            that.tabsFirstLevel[0].active = true;
            that.setActiveBtn(that.tabs);
          }

          if (that.checkBtnBelong(that.tabsPhysicalResource)) {
            that.tabsFirstLevel[1].active = true;
            that.setActiveBtn(that.tabsPhysicalResource);
            that.tabsFirstLevel[0].active = false;
          }
        } else {
          that.tabsFirstLevel[0].active = true;
          that.tabs[0].active = true;
        }

        setTimeout(function () {
            that.isShowLoading = false;
        }, 60000);
    }

    getTabsAuth() {
      if (this.authService.containEveryRights(['Physical Server#View'])) {
        this.viewAuthFlag[0] = true;
      }
      if (this.authService.containEveryRights(['Disk Array#View'])) {
        this.viewAuthFlag[1] = true;
      }
      if (this.authService.containEveryRights(['Physical Network Device#View'])) {
        this.viewAuthFlag[2] = true;
      }
    }

    setTabsAuth() {
      for (let i = 0; i < this.tabsPhysicalResource.length; i++) {
         if (i === 0 || i === 7 || i === 8) {
           this.tabsPhysicalResource[i].auth = true;
         } else if (i === 1 || i === 2 || i === 3) {
           this.tabsPhysicalResource[i].auth = this.viewAuthFlag[0];
         } else if (i === 4) {
          this.tabsPhysicalResource[i].auth = this.viewAuthFlag[1];
         } else {
           this.tabsPhysicalResource[i].auth = this.viewAuthFlag[2];
         }
      }
    }

      checkBtnBelong(btns: any) {
        for (const btn of btns) {
          if (btn.name === this.currentActiveBtn) {
            return true;
          }
        }
      }

      setActiveBtn(btns : any) {
          for (const btn of btns) {
             if (btn.name === this.currentActiveBtn) {
                 btn.active = true;
                 btns[0].active = false;
                  break;
             }
          }
      }

    ngOnDestroy() {
        DcClusterDetailComponent.backFirstTabNamee = '';
        DcClusterDetailComponent.backSencondTabNamee = '';
        for (const tab of this.tabs) {
            tab.active = false;
        }
        for (const tab of this.tabsFirstLevel) {
            tab.active = false;
        }
        for (const tab of this.tabsPhysicalResource) {
            tab.active = false;
        }
    }

    onSelectFirstLevelTab(tabzz : any) {
        this.selectTabFirstz = tabzz;
        for (const tab of this.tabsFirstLevel) {
            tab.active = false;
        }
        tabzz.active = true;
    }

    onSelect(tabzz : any) {
        this.selectTabz = tabzz;
        for (const tab of this.tabs) {
            tab.active = false;
        }
        tabzz.active = true;
       window.localStorage.setItem('currentTab', tabzz.name);
    }

    onSelectPhTab(tabzz : any) {
        this.selectTabph = tabzz;
        for (const tab of this.tabsPhysicalResource) {
            tab.active = false;
        }
        tabzz.active = true;
        window.localStorage.setItem('currentTab', tabzz.name);
    }

    gotoPhysicalTopoView(cloudenvId: any) {
      this.router.navigate(['/main/dc/cluster/details/physicalresource', cloudenvId]);
    }

}
