import {TranslateService} from '@ngx-translate/core';
import { Component, Input, OnInit, OnDestroy } from '@angular/core';
//import {Response} from '@angular/http';
import { Router } from '@angular/router';
//import { DomainService } from '../../domain/domain.service';
import { ApiResourceService as Http } from '../../apiResource.service';
import { DcService } from '../dc.service';
import { StorageService } from '../../storage.service';
import { AuthService } from '../../core/index';
import { appConfig } from '../../app.config';

import {PxConfirmationService} from '../../../assets/libs/paletxUI';

@Component({
    moduleId: module.id,
    selector: 'dc-cluster-summary',
    templateUrl: 'dc-cluster-summary.component.html'
})

export class DcClusterSummaryComponent implements OnInit, OnDestroy {
    //@ViewChild('modal') modal: ModalComponent;
     @Input('dcId') dcId: any;
     tryDelCloudenv : any;
    //clusters:Array<any>;
    timerHandle: any = undefined;
     delCloudenvMessage : any = {
      title: this.translate.instant('computeRes.delEnv'),
      message: '',
      confirmText: this.translate.instant('Delete'),
      cancelText: this.translate.instant('Cancel'),
      type: 'exclamation'
    };

    isShowInfo = false;
    infoMsgs: string[] = [this.translate.instant('computeRes.delEnvSucc')];
    isShowError = false;
    errMsgs: string[] = [''];
    isShowLoading = false;
    isShowDelLoading = false;
    delLoadingTitle : any = this.translate.instant('flavor.delFlavorWait');
    isShowEditSwitchInfo = false;
    infoEditSwitchMsgs : string[] = [this.translate.instant('gengyun.editSuccessMsgs')];
    errMsgs : string [] = [];
    isShowError = false;
    isFirstLoad = false;
    selectid : any = '';
    setPolicyId : any;
    window: window= window;
    rowData : Array<any> = [];
    columnDefs : any[] = [
        {
            field: 'name',
            title: this.translate.instant('computeRes.envName'),
            class: 'table-wrap',
            sortable: true,
            searchFormatter: false,
            events: 'operateEvents',
            formatter: function(value, row, index) {
                return '<a href="javascript:void(0);" class="cluster_detail">' + value + '</a>';
            }
        },
        {
            field: 'envType',
            sortable: true,
            title: this.translate.instant('computeRes.envType'),
            class: 'table-wrap',
            formatter: function(value, row, index) {
                if (row.envType && (row.envType !== null) && (row.envType !== '')) {
                    if (value === 'openstack') {
                        return 'openstack + kvm';
                    } else {
                        return 'openstack + vcenter';
                    }
                } else {
                    return '';
                }
            }
        },
        {
          field: 'description',
          sortable: true,
          title: this.translate.instant('gengyun.description')
        },
        {
            field: 'azNum',
            sortable: true,
            title: this.translate.instant('gengyun.AZ')
        },
        {
            field: 'haNum',
            sortable: true,
            title: this.translate.instant('gengyun.HostCluster')
        },
        {
            field: 'hostNum',
            sortable: true,
            title: this.translate.instant('Host')
        },
        {
            field: 'vmNum',
            sortable: true,
            title: this.translate.instant('VirMachine')
        },
        {
            field: 'admin_uri',
            title: 'URL',
            sortable: true,
            searchFormatter: false,
            events: 'operateEvents',
            formatter: function(value, row, index) {
                return '<a href="javascript:void(0);" class="admin_uri">' + value + '</a>';
            }
        },
        {
            field: 'userName',
            sortable: true,
            title: this.translate.instant('Username'),
            class: 'table-wrap'
        },
        /*{
            field: 'grade',
            sortable: true,
            title: this.translate.instant('gengyun.servicegrade'),
            formatter: (value, row, index)=> {
                let serviceGradeList : any = {
                    'gold': this.translate.instant('gengyun.gold'),
                    'silver': this.translate.instant('gengyun.silver'),
                    'copper': this.translate.instant('gengyun.bronze')
                };
                if(value !== '') {
                    return serviceGradeList[value];
                }

                return value;
            }
        },*/
        {
            field: 'status',
            sortable: true,
            title: this.translate.instant('Status'),
            width: '100',
            searchFormatter: false,
            formatter: function (value, row, index) {
                if (row.status) {
                    if (value === 'normal') {
                        return '<img class="status-img" style="margin-right: 6px;" ' +
                            'src="assets/images/status/icon_status_green.png" />' + value;
                    } else {
                        return '<img class="status-img" style="margin-right: 6px;" ' +
                            'src="assets/images/status/icon_status_red.png" />' + value;
                    }
                } else {
                    return '<img class="status-img" src="assets/images/status/icon_status_grey.png" />';
                }
            }
        },
        {
            field: 'oper',
            title: this.translate.instant('Operation'),
            width: '140',
            searchFormatter: false,
            events: 'operateEvents',
            cellStyle: (value, row, index, field) => {
              return {
                css: {'min-width': '123px'}
              };
            },
            formatter: (value, row, index) => {
                if (this.authService.containSomeRights(['Cloud Environment#PUT,DELETE'])) {
                    return '<div class="btn-group">\
                            <button class="btn btn-default delete">' + this.translate.instant('Delete') + '</button>\
                            <button class="btn btn-default dropdown-toggle" id="dropdownMenu" \
                                data-toggle="dropdown" ><span class="caret"></span>\
                            </button>\
                            <ul class="dropdown-menu dropdown-menu-top" role="menu" aria-labelledby="dropdownMenu">\
                                <li role="presentation">\
                                     <a href="javascript:void(0);" class="edit">\
                                     ' + this.translate.instant('Edit') + '</a>\
                                </li>\
                                <li role="presentation">\
                                     <a href="javascript:void(0);" class="editswitch" data-toggle="modal"\
                                      data-target="#editSwitchModal">\
                                     ' + this.translate.instant('gengyun.editswitch') + '</a>\
                                </li>\
                             </ul>\
                        </div>';
                }
                if (this.authService.containSomeRights(['Cloud Environment#PUT'])) {
                    return '<div class="btn-group">\
                            <button class="btn btn-default edit">' + this.translate.instant('Edit') + '</button>\
                            <ul class="dropdown-menu dropdown-menu-top" role="menu" aria-labelledby="dropdownMenu">\
                                <li role="presentation">\
                                     <a href="javascript:void(0);" class="editswitch" data-toggle="modal"\
                                      data-target="#editSwitchModal">\
                                     ' + this.translate.instant('gengyun.editswitch') + '</a>\
                                </li>\
                             </ul>\
                            </div>';
                }
                if (this.authService.containSomeRights(['Cloud Environment#DELETE'])) {
                    return '<div class="btn-group">\
                            <button class="btn btn-default delete">' + this.translate.instant('Delete') + '</button>\
                            </div>';
                }
            }
        }
    ];

    gridOptions : any = {
        pagination: true,
        escape: true,
        //sidePagination: 'server',
        //onlyInfoPagination:true,
        showPaginationswitch: true,
        pageSize: 10,
        pageList: [10, 25, 50, 100],
        search: true,
        strictSearch: false,
        searchText: '',
        paginationDetailHAlign: 'left',
        paginationHAlign: 'left',
        clickToSelect: false,
        sortable: true,
        sortOrder: 'asc',
        sortName: 'name'
    };

    constructor(private translate: TranslateService, public http : Http,
                private router : Router,
                private dcService : DcService, 	private storageService: StorageService,
                private authService: AuthService,
                private confirmationService: PxConfirmationService) {
        const that = this;
        if (this.storageService.getCurrentLang() === 'en') {
            $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
        } else {
            $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
        }
      this.window.operateEvents = {
        'click .admin_uri': function(e, value, row, index) {
          const i = row.admin_uri.indexOf(':');
          const providerprotocol: any = row.admin_uri.substring(0, i + 1);
          const ipstr: string = that.window.location.hostname;
          that.http.get(`${appConfig.vrmServiceUrl}users/${window.localStorage.directorid}/cloudenv/${row.id}`)
            .toPromise().then(function (res) {
              const msbPort = res.json().msbPort;
              const userNameEncrypt: any = window.btoa(res.json().aaa);
              const passwordEncrypt: any = window.btoa(res.json().bbb);
              const langEncrypt: any = window.btoa(that.storageService.getCurrentLang());
              if ('0' === msbPort) {
                const url = row.admin_uri + '/#/login?username=' + userNameEncrypt + '&pwd=' + passwordEncrypt + '&lang=' + langEncrypt;
                that.gotoOpenstack(url);
              } else {
                const httpurl = providerprotocol + '//' + ipstr + ':' + msbPort + '/#/login?username=' + userNameEncrypt + '&pwd=' +
                  passwordEncrypt + '&lang=' + langEncrypt;
                that.gotoOpenstack(httpurl);
              }
            });
        },
            'click .delete': function(e, value, row, index){
                that.tryDelCloudenv = row;
                that.delCloudenvMessage.message = that.translate.instant('gengyun.delEnv') + ': ' +
                    that.tryDelCloudenv.name + ' ' + that.translate.instant('gengyun.maybevmdisable') +
                    ',' + that.translate.instant('gengyun.confirmdeletecloud') + '?';
                that.confirmationService.confirm({
                    'type': 'danger',
                    'header': that.delCloudenvMessage.title,
                    'acceptLabel': that.delCloudenvMessage.confirmText,
                    'rejectLabel': that.delCloudenvMessage.cancelText,
                    'message': that.delCloudenvMessage.message,
                    'accept': () => {
                        that.sureDel();
                    }
                }; 
            },
            'click .cluster_detail': function(e, value, row, index){
                that.goToDetail(row.id);
            },
            'click .edit': function(e, value, row, index){
                that.goToClusterEdit(row.id);
            },
            'click .editswitch': function(e, value, row, index){
              console.log(JSON.stringify(row));
              that.selectid = row.id;
            }
            /*'click .setDeployPolicy': function(e, value, row, index){
              that.setPolicyId = row.id;
            }*/
        };
        if (!that.authService.containSomeRights(['Cloud Environment#DELETE'])) {
            that.columnDefs = _.filter(that.columnDefs, function(x) {
                return x.field !== 'oper'; });
        }
    }

    ngOnInit() {
        const that = this;
        that.isShowLoading = true;
        that.isFirstLoad = true;
        that.initTable();
        that.reLoadData();
        setTimeout(function () {
            that.isShowLoading = false;
        }, 20000);
    }

    initTable() {
        const that = this;
        const $table = $('#table-cluster-summary');
        $table.bootstrapTable($.extend(that.gridOptions, {
            toolbar: '#toolbar-table-az-summary',
            data: that.rowData,
            columns: that.columnDefs
        }));
        $('.bootstrap-table .search input').attr('placeholder', this.translate.instant('WordForFilter'))
            .parent().append(`<span></span>`);
    }

    gotoOpenstack(url: any) {
        window.open(url);
    }

    goToDetail(id: any) {
        this.router.navigate(['/main/dc/cluster/detail', id]);
    }

    goToCreateCluster() {
        this.router.navigate(['/main/dc/cluster/create', this.dcId]);
    }

    goToClusterEdit(id: any) {
        this.router.navigate(['/main/dc/cluster/edit', this.dcId, id]);
    }

    sureDel() {
        const that = this;
        that.infoMsgs = [this.translate.instant('computeRes.delEnvSucc')];
        that.errMsgs = [];
        that.isShowDelLoading = true;
        that.dcService.deleteCloudenv(that.tryDelCloudenv.id).then(() => {
            that.reLoadData();
            that.isShowDelLoading = false;
            that.isShowInfo = !that.isShowInfo;
            setTimeout(function () {
                that.isShowInfo = false;
            }, 2000);
        },
        (error : any) => {
            that.errMsgs.push(error.message || error);
            that.isShowDelLoading = false;
            that.isShowError = false;
        });
        setTimeout(function () {
            that.isShowDelLoading = false;
        }, 8000);
    }

    reLoadData() {
        const that = this;
        that.refreshClusterList();
        that.startReloadInterval();
    }

    refreshClusterList() {
        const that = this;
        const $table = $('#table-cluster-summary');
        if (that.isFirstLoad) {
            $table.bootstrapTable('showLoading');
        }
        that.dcService.getcloudEnvListbyDcId(that.dcId).then((res : any) => {
            that.rowData = res;
            $table.bootstrapTable('load', that.rowData);
            that.isShowLoading = false;
            if (that.isFirstLoad) {
                $table.bootstrapTable('hideLoading');
                that.isFirstLoad = false;
            }
        });
    }

    ngOnDestroy() {
        this.stopReloadInterval();
    }

    startReloadInterval() {
        const that = this;
        if (that.timerHandle === undefined) {
            that.timerHandle = setInterval(function(){
                that.refreshClusterList();
            }, 15000);
        }
    }

    stopReloadInterval() {
        clearTimeout(this.timerHandle);
        this.timerHandle = undefined;
    }

  clearEditid(type : any) {
      this.selectid = '';
      const that = this;
      if (type === 'submit') {
        that.reLoadData();
        that.isShowEditSwitchInfo = !that.isShowEditSwitchInfo;
        setTimeout(function () {
          that.isShowEditSwitchInfo = false;
        }, 2000);
      }
    console.log(type);
  }

  /*dealSetDeployPolicyMessage(type : any) {
    let that = this;
    that.infoMsgs = [this.translate.instant('gengyun.operSucc')];
    that.setPolicyId = undefined;
    if(type === 'submit') {
      that.reLoadData();
      that.isShowInfo = true;
      setTimeout(function () {
        that.isShowInfo = false;
      }, 2000);
    }
  }*/

/*
    constructor(private translate:TranslateService,public http:Http,
                private domainService:DomainService,
                private router:Router,
                private dcService:DcService) {

    }

    ngOnInit() {
        let that = this;
        this.domainService.getClusters(this.dcId)
            .subscribe((res:any)=> {
                that.clusters = res;
            });
    }

    delCluster(cluster:any) {
        this.tryDelCloudenv = cluster;
    }
*/

}
