import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/index';
import { ServerModule, NetworkDeviceModule, StoragesModule, PhysicalResourceModule, RackModule} from '../../physicalResource/index';

import { ResourceModule } from '../../resource/index';
import { DcClusterActionModule } from './action/index';
import { DcClusterDetailVirtualResourceModule } from './detail-virtual-resource/index';
import { DcClusterDetailPhysicalResourceModule } from './detail-physical-resource/index';

import { DcClusterSummaryComponent } from './dc-cluster-summary.component';
import { DcClusterDetailComponent } from './dc-cluster-detail.component';

import { DomainService } from '../../domain/domain.service';
import { DcService } from '../dc.service';
import { DcClusterService } from './dc-cluster.service';

@NgModule({
  imports: [SharedModule, ServerModule, StoragesModule, ResourceModule,
    NetworkDeviceModule, PhysicalResourceModule, RackModule, DcClusterActionModule,
    DcClusterDetailVirtualResourceModule, DcClusterDetailPhysicalResourceModule],
  declarations: [DcClusterSummaryComponent, DcClusterDetailComponent],
  providers: [DomainService, DcService, DcClusterService],
  exports: [ DcClusterSummaryComponent ]
})

export class DcClusterModule { }
