import { Injectable } from '@angular/core';
import { Response } from '@angular/http';
import { appConfig } from '../../app.config';
import { ApiResourceService as Http } from '../../apiResource.service';

@Injectable()
export class DcClusterService {

    constructor(public http: Http) {

    }

    getDcClusterOverviewResource(dcId: any, cloudEnvId: any) {
        const that = this;
        return that.http.get(appConfig.hwvServiceUrl + 'hardwareSummary?dcId=' + dcId + '&&cloudEnvId=' + cloudEnvId)
          .toPromise()
          .then((res: Response) => {return res.json(); });
    }

    getDcClusterTopo(dcId : any, envId: any) {
        return this.http.get(appConfig.hwvServiceUrl + 'dcs/' + dcId + '/' + envId + '/topo')
          .toPromise()
          .then((res: Response) => {return res.json(); })
          .catch(this.handleError);
    }

    getCloudenvNetworks(id : any) {
        return this.http.get(`${appConfig.vrmServiceUrl}cloudenvs/${id}/networks`)
                .toPromise()
                .then((res: Response) => {return res.json().networks; });
    }

    putCloudenvNetwork(id : any, data : any) {
        return this.http.put(`${appConfig.vrmServiceUrl}cloudenvs/${id}/networks`, data)
                .toPromise();
    }

    private handleError(error : any) {
        console.error('An error occurred', error);
        console.log(JSON.stringify(error));
        return error;
    }
}
