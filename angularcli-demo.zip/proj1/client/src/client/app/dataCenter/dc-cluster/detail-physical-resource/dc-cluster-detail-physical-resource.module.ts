/**
 * Created by root on 6/15/17.
 */
import { NgModule } from '@angular/core';
import { SharedModule } from '../../../shared/index';

import { DcAssetModule } from '../../dc-asset/index';

import { DcClusterPhysicalResourceBasicComponent } from './dc-cluster-physical-resource-basic.component';
import { DcClusterPhysicalResourceViewComponent } from './dc-cluster-physical-resource-view.component';

import { DcService } from '../../dc.service';
import { DcClusterService } from '../dc-cluster.service';

@NgModule({
  imports: [SharedModule, DcAssetModule],
  declarations: [DcClusterPhysicalResourceBasicComponent, DcClusterPhysicalResourceViewComponent],
  providers: [DcService, DcClusterService],
  exports: [ DcClusterPhysicalResourceBasicComponent]
})

export class DcClusterDetailPhysicalResourceModule { }
