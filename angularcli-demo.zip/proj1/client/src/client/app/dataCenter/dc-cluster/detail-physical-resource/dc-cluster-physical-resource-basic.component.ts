
import {TranslateService} from '@ngx-translate/core';

import { Component, OnInit, Input} from '@angular/core';
import { Response } from '@angular/http';
import { ApiResourceService as Http } from '../../../apiResource.service';
import { DcClusterService } from '../dc-cluster.service';

@Component({
    moduleId: module.id,
    selector: 'dc-cluster-physical-resource-basic',
    templateUrl: 'dc-cluster-physical-resource-basic.component.html',
    styleUrls: ['dc-cluster-physical-resource.component.css'],
})

export class DcClusterPhysicalResourceBasicComponent implements OnInit {
  @Input() cloudEnv : any;
  dcId: any;
  cloudEnvId: any;
  overviewInfo: any = {};
  options: any= [];
  boardNumber= 0;
  rackServerNumber= 0;
  storageNumber= 0;
  switchNumber= 0;
  routerNumber= 0;
  podNumber= 0;
  rackNumber= 0;
  chassisNumber= 0;
  usedCapacity : number;


  constructor(private translate: TranslateService, public http : Http, private dcClusterOverviewService: DcClusterService) {

  }

  ngOnInit() {
      const that = this;
      that.dcId = that.cloudEnv.dc.id;
      that.cloudEnvId = that.cloudEnv.id;
      that.dcClusterOverviewService.getDcClusterOverviewResource(that.dcId, that.cloudEnvId).then((res: Response) => {
        that.overviewInfo = res;
        that.boardNumber = that.overviewInfo.boards.totalNumber;
        that.rackServerNumber = that.overviewInfo.rackServers.totalNumber;
        that.storageNumber = that.overviewInfo.storages.totalNumber;
        that.switchNumber = that.overviewInfo.switches.totalNumber;
        that.routerNumber = that.overviewInfo.routers.totalNumber;
        that.podNumber = that.overviewInfo.pods.totalNumber;
        that.rackNumber = that.overviewInfo.racks.totalNumber;
        that.chassisNumber = that.overviewInfo.chassises.totalNumber;
        that.usedCapacity = that.overviewInfo.storages.totalCapacity - that.overviewInfo.storages.freeCapacity;
      });
  }
}
