import {Component, OnInit} from '@angular/core';
import {DcService} from '../../dc.service';
import {ApiResourceService as Http} from '../../../apiResource.service';
import {Router, ActivatedRoute} from '@angular/router';
import {Response} from '@angular/http';
import {DcClusterService} from '../dc-cluster.service';
import {TranslateService} from '@ngx-translate/core';

@Component({
  moduleId: module.id,
  selector: 'dc-cluster-physical-resource-view',
  templateUrl: 'dc-cluster-physical-resource-view.html',
  styleUrls: ['dc-cluster-physical-resource.component.css']
})

export class DcClusterPhysicalResourceViewComponent implements OnInit {
  static nodes: any;
  static renderTopo: any;
  clusterInfo: any;
  links: any = [{name: this.translate.instant('DataCenter'), url: '/main/dc/summary'},
    {name: '', url: '/main/dc/detail/'},
    {name: '', url: '/main/dc/cluster/detail/'},
    {name: this.translate.instant('hwm.physical_resource_topo')}];
  clusterTopological: any = {};
  topoInfo: any = {};
  dcId: any;
  podNumList: any = [];
  rackNumList: any = [];
  chassisNumList: any = [];
  openAllDisabledBool = true;
  closeByPodDisabledBool = false;
  closeByRackDisabledBool = false;
  isCloseAll = false;
  countNum = 1;
  basicInfo: any = {
    id: '',
    type: ''
  };
  currentPath = 'cluster';

  constructor(private activatedRoute: ActivatedRoute,
              private dcService: DcService,
              public http: Http, private router: Router,
              private dcClusterService: DcClusterService,
              private translate: TranslateService) {
  }

  ngOnInit() {
    const that = this;
    window.localStorage.setItem('currentTab', '');
    this.activatedRoute.params.subscribe(params => {
      const envId: any = params['clusterId'];
      that.dcService.getcloudEnvbyid(envId).then((res: any) => {
        that.clusterInfo = res;
        that.links[1].name = that.clusterInfo.dc.name;
        that.links[1].url = that.links[1].url + that.clusterInfo.dc.id;
        that.links[2].name = that.clusterInfo.name;
        that.links[2].url = that.links[2].url + that.clusterInfo.id;
        that.dcId = that.clusterInfo.dc.id;
      }).then((res: any) => {
        that.dcClusterService.getDcClusterTopo(that.dcId, envId).then((res: Response) => {
          that.topoInfo = res;
          that.getClusterTopoInfo(that.clusterTopological, that.topoInfo.cloudEnv);
          that.initChart();
        });
      });

    });
  }

  getClusterTopoInfo(clusterTopological: any, topoInfo: any) {
    const that = this;
    const clusterInfo = topoInfo;
    that.setBaseInfo(clusterTopological, clusterInfo.name, 'cluster', clusterInfo.self);
    clusterTopological.children = that.podGroupInfo(clusterInfo.pods);
  }

  setBaseInfo(clusterTopological: any, name: any, type: any, self: any) {
    clusterTopological.name = name;
    clusterTopological.type = type;
    clusterTopological.self = self;
  }


  setBaseInfoForBlade(clusterTopological: any, id: any, type: any, self: any) {
    clusterTopological.name = id.split('*')[2];
    clusterTopological.type = type;
    clusterTopological.self = self.id;
  }

  podGroupInfo(pods: any) {
    const podList = [];
    const that = this;
    for (const item of pods) {
      const onePodTopo: any = {};
      const rackTemp = that.getRackListInfo(item);
      that.setBaseInfo(onePodTopo, item.podName, 'pod', item.id);
      onePodTopo.children = rackTemp;
      podList.push(onePodTopo);
    }
    return podList;
  }

  getRackListInfo(pod: any) {
    const rackList = [];
    const that = this;
    for (const item of pod.racks) {
      const oneRackTopo: any = {};
      const storagesList = that.getStorageListInfo(item);
      const switchesList = that.getSwitchesListInfo(item);
      const chassisesList = that.getChassisesListInfo(item);
      const rackServerList = that.getRackServerListInfo(item);
      const routeList = that.getRouterListInfo(item);
      that.setBaseInfo(oneRackTopo, item.rackName, 'rack', item.self);
      oneRackTopo.children = _.flatten([storagesList, switchesList, chassisesList, rackServerList, routeList]);
      rackList.push(oneRackTopo);
    }
    return rackList;
  }

  getStorageListInfo(rack: any) {
    const storageInfo = [];
    for (const item of rack.storages) {
      const storageTemp = {};
      this.setBaseInfo(storageTemp, item.name, 'storage', item.self);
      storageInfo.push(storageTemp);
    }
    return storageInfo;
  }

  getSwitchesListInfo(rack: any) {
    const switchesInfo = [];
    for (const item of rack.switches) {
      const switchesTemp = {};
      this.setBaseInfo(switchesTemp, item.name, 'switch', item.self);
      switchesInfo.push(switchesTemp);
    }
    return switchesInfo;
  }

  getChassisesListInfo(rack: any) {
    const chassisesInfo = [];
    for (const item of rack.chassises) {
      const chassisTemp = {};
      this.setBaseInfo(chassisTemp, item.name, 'chassis', item.self);
      const bladesList = this.getBladeListInfo(item);
      chassisTemp.children = bladesList;
      chassisesInfo.push(chassisTemp);
    }
    return chassisesInfo;
  }

  getBladeListInfo(chassis: any) {
    const bladesInfo = [];
    for (const item of chassis.bladeInfo) {
      const bladesTemp = {};
      this.setBaseInfoForBlade(bladesTemp, item.id, 'blade', item);
      bladesInfo.push(bladesTemp);
    }
    return bladesInfo;
  }

  getRackServerListInfo(rack: any) {
    const rackServerInfo = [];
    for (const item of rack.rackServers) {
      const rackServerTemp = {};
      this.setBaseInfo(rackServerTemp, item.name, 'rackServer', item.self);
      rackServerInfo.push(rackServerTemp);
    }
    return rackServerInfo;
  }

  getRouterListInfo(rack: any) {
    const routerInfo = [];
    for (const item of rack.routers) {
      const routerTemp = {};
      this.setBaseInfo(routerTemp, item.name, 'router', item.self);
      routerInfo.push(routerTemp);
    }
    return routerInfo;
  }

  //drawer chart
  getTree() {
    const _chart = {};
    const _width: any = 1100;
    const _height: any = 640;
    let viewWidth: any;
    let viewHeight: any;
    let LabelMaxLenth: any;
    const _margins: any = {
      top: 30,
      left: 80,
      right: 10,
      bottom: 30
    };
    let _svg: any;
    let _nodes: any;
    let _i: any = 0;
    let _tree: any;
    let _diagonal: any;
    let _bodyG: any;
    let tooltip: any;
    const that = this;
    const nodeStyleMap: any = {
      'cluster': {
        'textX': 18,
        'textY': -5,
        'imageX': -15,
        'imageY': -10,
        'imageWidth': '32px',
        'imageHeight': '20px',
        'imageHref': 'assets/images/topo/cluster.png',
        'imageHrefPlus': 'assets/images/topo/cluster-plus.png',
        'imageHrefBlack': 'assets/images/topo/cluster-black.png',
        'stateRoute': 'cloudManage.hardware.pod',
        //'stateFunc': stateDirect
      },
      'pod': {
        'textX': 17,
        'textY': -5,
        'imageX': -14,
        'imageY': -10,
        'imageWidth': '32px',
        'imageHeight': '20px',
        'imageHref': 'assets/images/topo/pod.png',
        'imageHrefPlus': 'assets/images/topo/pod-plus.png',
        'imageHrefBlack': 'assets/images/topo/pod-black.png',
        'stateRoute': 'cloudManage.hardware.pod',
        //'stateFunc': gotoBasicInfo
      },
      'rack': {
        'textX': 10,
        'textY': -5,
        'imageX': -7,
        'imageY': -11,
        'imageWidth': '32px',
        'imageHeight': '20px',
        'imageHref': 'assets/images/topo/rack.png',
        'imageHrefPlus': 'assets/images/topo/rack-plus.png',
        'imageHrefBlack': 'assets/images/topo/rack-black.png',
        'stateRoute': 'cloudManage.hardware.rackAndChassis.summary',
        //'stateFunc': gotoBasicInfo
      },
      'externalSwitch': {
        'textX': 17,
        'textY': -2,
        'imageX': -20,
        'imageY': -20,
        'imageWidth': '20px',
        'imageHeight': '20px',
        'imageHref': 'assets/images/topo/switch.png',
        'imageHrefPlus': 'assets/images/topo/switch.png',
        'imageHrefBlack': 'assets/images/topo/switch.png',
        'stateRoute': 'cloudManage.hardware.switches.extdetail',
        'stateFunc': gotoBasicInfo
      },
      '8905externalSwitch': {
        'textX': 17,
        'textY': -2,
        'imageX': -20,
        'imageY': -20,
        'imageWidth': '20px',
        'imageHeight': '20px',
        'imageHref': 'assets/images/topo/switch.png',
        'imageHrefPlus': 'assets/images/topo/switch.png',
        'imageHrefBlack': 'assets/images/topo/switch.png',
        'stateRoute': 'cloudManage.hardware.switches.8905extdetail',
        'stateFunc': gotoBasicInfo
      },
      'switch': {
        'textX': 17,
        'textY': -2,
        'imageX': -10,
        'imageY': -10,
        'imageWidth': '20px',
        'imageHeight': '20px',
        'imageHref': 'assets/images/topo/switch.png',
        'imageHrefPlus': 'assets/images/topo/switch.png',
        'imageHrefBlack': 'assets/images/topo/switch.png',
        'stateRoute': 'cloudManage.hardware.switches.detail',
        'stateFunc': gotoBasicInfo
      },
      'chassis': {
        'textX': 17,
        'textY': -2,
        'imageX': -16,
        'imageY': -10,
        'imageWidth': '32px',
        'imageHeight': '20px',
        'imageHref': 'assets/images/topo/chassis.png',
        'imageHrefPlus': 'assets/images/topo/chassisPlus.png',
        'imageHrefBlack': 'assets/images/topo/chassis.png',
        'stateRoute': 'cloudManage.hardware.rackAndChassis.chassisDetail',
        'stateFunc': gotoBasicInfo
      },
      'storage': {
        'textX': 17,
        'textY': -2,
        'imageX': -10,
        'imageY': -10,
        'imageWidth': '20px',
        'imageHeight': '20px',
        'imageHref': 'assets/images/topo/storage.png',
        'imageHrefPlus': 'assets/images/topo/storage.png',
        'imageHrefBlack': 'assets/images/topo/storage.png',
        'stateRoute': 'cloudManage.hardware.storages.detail',
        'stateFunc': gotoBasicInfo
      },
      'blade': {
        'textX': 17,
        'textY': -2,
        'imageX': -13,
        'imageY': -10,
        'imageWidth': '20px',
        'imageHeight': '20px',
        'imageHref': 'assets/images/topo/blade.png',
        'imageHrefPlus': 'assets/images/topo/blade.png',
        'imageHrefBlack': 'assets/images/topo/blade.png',
        'stateRoute': 'cloudManage.hardware.boards.boardDetail',
        'stateFunc': gotoBasicInfo
      },
      'rackServer': {
        'textX': 17,
        'textY': -2,
        'imageX': -10,
        'imageY': -10,
        'imageWidth': '20px',
        'imageHeight': '20px',
        'imageHref': 'assets/images/topo/rackServer.png',
        'imageHrefPlus': 'assets/images/topo/rackServer.png',
        'imageHrefBlack': 'assets/images/topo/rackServer.png',
        'stateRoute': 'cloudManage.hardware.rackServers.detail',
        'stateFunc': gotoBasicInfo
      },
      'router': {
        'textX': 17,
        'textY': -2,
        'imageX': -10,
        'imageY': -10,
        'imageWidth': '20px',
        'imageHeight': '20px',
        'imageHref': 'assets/images/topo/router.png',
        'imageHrefPlus': 'assets/images/topo/router.png',
        'imageHrefBlack': 'assets/images/topo/router.png',
        'stateRoute': 'cloudManage.hardware.routers.detail',
        'stateFunc': gotoBasicInfo
      }
    };


    function gotoBasicInfo(item) {
      that.countNum++;
      if (item.type === 'blade') {
        that.basicInfo.id = item.self;
      } else {
        that.basicInfo.id = item.self.split('/').pop();
      }
      that.basicInfo.type = item.type;
    }

    _chart.render = function () {
      if (!_svg) {
        _svg = d3.select('#cloudTopoGraph').append('svg')
          .attr('height', _height)
          .attr('width', _width);

        tooltip = d3.select('#cloudTopoGraph')
          .append('div')
          .attr('class', 'tool-tip')
          .style('opacity', 0.0);
      }
      renderBody(_svg);
    };

    /* function zoom() {
     _bodyG.attr('transform', 'translate(' + d3.event.translate + ')scale(' + d3.event.scale + ')');
     }*/

    function renderBody(svg) {
      if (!_bodyG) {
        _bodyG = svg.append('g')
          .attr('class', 'body')
          .attr('transform', function () {
            return 'translate(' + _margins.left + ',' + _margins.top + ')';
          });

      }

      /*  d3.select('svg')
       .call(
       d3.behavior.zoom()
       .scaleExtent([0.1, 10])
       .on('zoom', zoom)
       );
       */

      viewHeight = _height - _margins.top - _margins.bottom;
      viewWidth = _width - _margins.left - _margins.right;

      _tree = d3.layout.tree();

      _diagonal = d3.svg.diagonal()
        .projection(function (d) {
          return [d.y, d.x];
        });

      _nodes.x0 = (_height - _margins.top - _margins.bottom) / 2;
      _nodes.y0 = 0;

      const levelWidth = [1];
      const childCount = function (level, n) {
        if (n.children && n.children.length > 0) {
          if (levelWidth.length <= level + 1) levelWidth.push(0);

          levelWidth[level + 1] += n.children.length;
          n.children.forEach(function (d) {
            childCount(level + 1, d);
          });
        }
      };

      childCount(0, that.clusterTopological);
      let newHeight = d3.max(levelWidth) * 48;
      if (newHeight < viewHeight) {
        newHeight = viewHeight;
      } else {
        newHeight = newHeight;
      }

      d3.select('svg')
        .attr('height', newHeight)
        .attr('width', viewWidth);

      _tree = _tree.size([newHeight - 50, viewWidth]);
      DcClusterPhysicalResourceViewComponent.renderTopo(_nodes);
    }

    DcClusterPhysicalResourceViewComponent.renderTopo = function (source) {
      DcClusterPhysicalResourceViewComponent.nodes = _tree.nodes(_nodes);
      renderNodes(DcClusterPhysicalResourceViewComponent.nodes, source);
      renderLinks(DcClusterPhysicalResourceViewComponent.nodes, source);
    };

    function getValByType(type) {
      return nodeStyleMap[type];
    }

    function gotoBasicInfoById(d) {
      nodeStyleMap[d.type].stateFunc(d);
    }

    function getLabelMaxLength() {
      if (viewWidth < 672.5 || viewWidth === 672.5) {
        LabelMaxLenth = 5;
      } else if (viewWidth > 672.5 && viewWidth < 792.5) {
        LabelMaxLenth = 12;
      } else if (viewWidth === 792.5) {
        LabelMaxLenth = 23;
      } else {
        LabelMaxLenth = 50;
      }
    }


    function renderNodes(nodes, source) {
      nodes.forEach(function (d) {
        d.y = d.depth * 180;
      });

      const node = _bodyG.selectAll('g.node')
        .data(nodes, function (d) {
          return d.id || (d.id = ++_i);
        });

      const nodeEnter = node.enter().append('svg:g')
        .attr('class', 'node')
        .attr('transform', function () {
          return 'translate(' + source.y0 + ',' + source.x0 + ')';
        })
        .on('click', function (d) {
          d3.event.stopPropagation();
          const type: [] = ['chassis', 'rackServer', 'switch', 'storage', 'router', 'blade'];
          if (type.includes(d.type)) {
            gotoBasicInfoById(d);
          }
        })
        .on('dblclick', function (d) {
          if (d.type === 'cluster') {
            that.toggleAll();
          } else {
            toggle(d);
          }
          DcClusterPhysicalResourceViewComponent.renderTopo(d);
          if (d.type === 'pod') {
            that.checkPodToggleAbled();
          }
          if (d.type === 'rack') {
            that.checkRackToggleAbled();
          }

          if (that.rackNumList[1] === 0 && that.podNumList[1] === 0 && that.isCloseAll === false) {
            that.openAllDisabledBool = true;
          }
          if (d.type === 'chassis') {
            that.checkChassisToggleAbled();
          }

        })
        .on('mouseenter', function (d) {
          if (d.children || d._children || d.depth === 3 || d.depth === 4) {
            d3.select(this).style('cursor', 'pointer');
          }
        });

      nodeEnter.append('rect')
        .attr('x', function (d) {
          return getValByType(d.type).rectX;
        })
        .attr('y', function (d) {
          return getValByType(d.type).rectY;
        })
        .attr('width', function (d) {
          return getValByType(d.type).rectWidth;
        })
        .attr('height', function (d) {
          return getValByType(d.type).rectHeight;
        })
        .style('fill', function (d) {
          if (d.status && (d.status === 'normal' || d.status === 'OK')) {
            return 'green';
          } else if (d.status) {
            return 'red';
          } else {
            return 'gray';
          }
        });

      nodeEnter.append('image')
        .attr('x', function (d) {
          return getValByType(d.type).imageX;
        })
        .attr('y', function (d) {
          return getValByType(d.type).imageY;
        })
        .attr('width', function (d) {
          return getValByType(d.type).imageWidth;
        })
        .attr('height', function (d) {
          return getValByType(d.type).imageHeight;
        })
        .attr('xlink:href', function (d) {
          return d._children || d.children ? getValByType(d.type).imageHref : getValByType(d.type).imageHrefBlack;
        });


      const nodeUpdate = node.transition()
        .attr('transform', function (d) {
          return 'translate(' + d.y + ',' + d.x + ')';
        });

      nodeUpdate.selectAll('image')
        .attr('xlink:href', function (d) {
          let nodeImage = '';

          function setImage(d) {
            if (d._children) {
              nodeImage = getValByType(d.type).imageHrefPlus;
            } else if (d.children) {
              nodeImage = getValByType(d.type).imageHref;
            } else {
              nodeImage = getValByType(d.type).imageHrefBlack;
            }
          };
          setImage(d);
          return nodeImage;
        });

      const nodeExit = node.exit().transition()
        .attr('transform', function () {
          return 'translate(' + source.y + ',' + source.x + ')';
        })
        .remove();

      renderLabels(nodeEnter, nodeUpdate, nodeExit);

      nodes.forEach(function (d) {
        d.x0 = d.x;
        d.y0 = d.y;
      });
    }

    function renderLabels(nodeEnter, nodeUpdate, nodeExit) {
      getLabelMaxLength();

      nodeEnter.append('svg:text')
        .attr('x', function (d) {
          return (d.depth === 3 || d.depth === 4) ? getValByType(d.type).textX : -getValByType(d.type).textX;
        })
        .attr('y', function (d) {
          return (d.depth === 3 || d.depth === 4) ? -getValByType(d.type).textY : -getValByType(d.type).textY;
        })
        .attr('text-anchor', function (d) {
          return (d.depth === 3 || d.depth === 4) ? 'start' : 'end';
        })
        .text(function (d) {
          return d.name;
        })
        .style('fill-opacity', 1e-6)
        .style('font-size', '10px')
        .on('mouseover', function (d) {
          if (d.name.length > LabelMaxLenth) {
            tooltip.html(d.name)
              .style('position', 'absolute')
              .style('height', 'auto')
              .style('width', '200px')
              .style('background-color', '#43abef')
              .style('color', '#fff')
              .style('border-radius', '5px')
              .style('z-index', '999')
              .style('padding', '5px')
              .style('left', (d3.event.pageX - 250) + 'px')
              .style('top', (d3.event.pageY - 110) + 'px')
              .style('opacity', 1.0);
          }
        })
        .on('mouseout', function () {
          tooltip.style('opacity', 0.0);
        });

      nodeUpdate.select('text')
        .style('fill-opacity', 1);

      nodeExit.select('text')
        .style('fill-opacity', 1e-6);
    }

    function renderLinks(nodes, source) {
      const link = _bodyG.selectAll('path.link')
        .data(_tree.links(nodes), function (d) {
          return d.target.id;
        });

      link.enter().insert('svg:path', 'g')
        .attr('class', 'link')
        .attr('d', function () {
          const o = {
            x: source.x0,
            y: source.y0
          };
          return _diagonal({
            source: o,
            target: o
          });
        })
        .style('fill', 'none')
        .style('stroke', '#bbb')
        .style('stroke-width', '1px');

      link.transition()
        .attr('d', _diagonal);

      link.exit().transition()
        .attr('d', function () {
          const o = {
            x: source.x,
            y: source.y
          };
          return _diagonal({
            source: o,
            target: o
          });
        })
        .remove();
    }

    function toggle(d) {
      if (d.children) {
        d._children = d.children;
        d.children = null;
      } else {
        d.children = d._children;
        d._children = null;
      }
    }

    _chart.nodes = function (n) {
      if (!arguments.length) {
        return _nodes;
      }
      _nodes = n;
      return _chart;
    };

    return _chart;
  }

  initChart() {
    const that = this;
    const chart: any = that.getTree();
    chart.nodes(that.clusterTopological).render();
    that.checkPodToggleAbled();
    that.checkRackToggleAbled();
    that.openAllDisabledBool = true;

  }

  openAll() {
    const that = this;
    that.openByCluster();
    that.openByPod();
    that.openByRack();
    that.openByChassis();
    that.openAllDisabledBool = !that.openAllDisabledBool;
    that.isCloseAll = false;
  }

  openByCluster() {
    for (const d of DcClusterPhysicalResourceViewComponent.nodes) {
      if (d.type === 'cluster') {
        if (d._children) {
          d.children = d._children;
          d._children = null;
        }
      }
      DcClusterPhysicalResourceViewComponent.renderTopo(d);
    }
  }

  toggleAll() {
    const that = this;
    for (const d of DcClusterPhysicalResourceViewComponent.nodes) {
      if (d.type === 'cluster') {
        if (d._children) {
          d.children = d._children;
          d._children = null;
          DcClusterPhysicalResourceViewComponent.renderTopo(d);
          that.openByPod();
          that.openByRack();
          that.openByChassis();
          that.checkRackToggleAbled();
          that.checkPodToggleAbled();
          that.openAllDisabledBool = true;
          that.isCloseAll = false;
          that.checkChassisToggleAbled();
        } else if (d.children) {
          d._children = d.children;
          d.children = null;
          DcClusterPhysicalResourceViewComponent.renderTopo(d);
          that.openAllDisabledBool = false;
          that.isCloseAll = true;
          that.closeByPodDisabledBool = true;
          that.closeByRackDisabledBool = true;
        } else {
          that.openAllDisabledBool = true;
        }
      }
    }
  }

  openByPod() {
    const that = this;
    that.countOpenPodNum();
    if (that.podNumList[1] > 0) {
      for (const d of DcClusterPhysicalResourceViewComponent.nodes) {
        if (d.type === 'pod') {
          if (d._children) {
            d.children = d._children;
            d._children = null;
          }
        }
        DcClusterPhysicalResourceViewComponent.renderTopo(d);
      }
    }
    that.checkPodToggleAbled();
  }

  closeByPod() {
    const that = this;
    that.countOpenPodNum();
    if (that.podNumList[0] > 0) {
      for (const d of DcClusterPhysicalResourceViewComponent.nodes) {
        if (d.type === 'pod') {
          if (d.children) {
            d._children = d.children;
            d.children = null;
          }
        }
        DcClusterPhysicalResourceViewComponent.renderTopo(d);
      }
    }
    that.checkPodToggleAbled();
  }

  countOpenPodNum() {
    const that = this;
    that.podNumList = [];
    let openNum = 0;
    let closeNum = 0;
    let withoutChildrenNum = 0;
    for (const d of DcClusterPhysicalResourceViewComponent.nodes) {
      if (d.type === 'pod') {
        if (d.children) {
          openNum += 1;
        } else if (d._children) {
          closeNum += 1;
        } else {
          withoutChildrenNum += 1;
        }
      }
    }
    const totalNum: number = openNum + closeNum + withoutChildrenNum;
    that.podNumList.push(openNum);
    that.podNumList.push(closeNum);
    that.podNumList.push(withoutChildrenNum);
    that.podNumList.push(totalNum);
  }

  checkPodToggleAbled() {
    const that = this;
    that.countOpenPodNum();
    if (that.podNumList[1] === 0 || that.podNumList[2] === that.podNumList[3]) {
      that.openAllDisabledBool = false;
      that.closeByRackDisabledBool = false;
    } else {
      that.openAllDisabledBool = false;
      that.closeByRackDisabledBool = true;
    }

    if (that.podNumList[0] === 0 || that.podNumList[2] === that.podNumList[3]) {
      that.closeByPodDisabledBool = true;
      that.closeByRackDisabledBool = true;
    } else {
      that.closeByPodDisabledBool = false;
      that.closeByRackDisabledBool = false;
    }

    that.checkRackToggleAbled();
  }

  //rack toggle

  openByRack() {
    const that = this;
    that.countOpenRackNum();
    if (that.rackNumList[1] > 0) {
      for (const d of DcClusterPhysicalResourceViewComponent.nodes) {
        if (d.type === 'rack') {
          if (d._children) {
            d.children = d._children;
            d._children = null;
          }
        }
        DcClusterPhysicalResourceViewComponent.renderTopo(d);
      }
    }
    that.checkRackToggleAbled();
  }

  closeByRack() {
    const that = this;
    that.countOpenRackNum();
    if (that.rackNumList[0] > 0) {
      for (const d of DcClusterPhysicalResourceViewComponent.nodes) {
        if (d.type === 'rack') {
          if (d.children) {
            d._children = d.children;
            d.children = null;
          }
        }
        DcClusterPhysicalResourceViewComponent.renderTopo(d);
      }
    }
    that.checkRackToggleAbled();
  }

  countOpenRackNum() {
    const that = this;
    that.rackNumList = [];
    let openNum = 0;
    let closeNum = 0;
    let withoutChildrenNum = 0;
    for (const d of DcClusterPhysicalResourceViewComponent.nodes) {
      if (d.type === 'rack') {
        if (d.children) {
          openNum += 1;
        } else if (d._children) {
          closeNum += 1;
        } else {
          withoutChildrenNum += 1;
        }
      }
    }
    const totalNum: number = openNum + closeNum + withoutChildrenNum;
    that.rackNumList.push(openNum);
    that.rackNumList.push(closeNum);
    that.rackNumList.push(withoutChildrenNum);
    that.rackNumList.push(totalNum);
  }

  checkRackToggleAbled() {
    const that = this;
    that.countOpenRackNum();
    if (that.rackNumList[1] === 0 || that.rackNumList[2] === that.rackNumList[3]) {
      that.openAllDisabledBool = false;
    } else {
      that.openAllDisabledBool = false;
    }

    if (that.rackNumList[0] === 0 || that.rackNumList[2] === that.rackNumList[3]) {
      that.closeByRackDisabledBool = true;
    } else {
      that.closeByRackDisabledBool = false;
    }

  }

  countOpenChassisNum() {
    const that = this;
    that.chassisNumList = [];
    let openNum = 0;
    let closeNum = 0;
    let withoutChildrenNum = 0;
    for (const d of DcClusterPhysicalResourceViewComponent.nodes) {
      if (d.type === 'chassis') {
        if (d.children) {
          openNum += 1;
        } else if (d._children) {
          closeNum += 1;
        } else {
          withoutChildrenNum += 1;
        }
      }
    }
    const totalNum: number = openNum + closeNum + withoutChildrenNum;
    that.chassisNumList.push(openNum);
    that.chassisNumList.push(closeNum);
    that.chassisNumList.push(withoutChildrenNum);
    that.chassisNumList.push(totalNum);
  }

  checkChassisToggleAbled() {
    const that = this;
    that.countOpenChassisNum();
    if (that.chassisNumList[1] === 0 || that.chassisNumList[2] === that.chassisNumList[3]) {
      that.openAllDisabledBool = true;
    } else {
      that.openAllDisabledBool = false;
    }
  }

  openByChassis() {
    const that = this;
    that.countOpenChassisNum();
    if (that.chassisNumList[1] > 0) {
      for (const d of DcClusterPhysicalResourceViewComponent.nodes) {
        if (d.type === 'chassis') {
          if (d._children) {
            d.children = d._children;
            d._children = null;
          }
        }
        DcClusterPhysicalResourceViewComponent.renderTopo(d);
      }
    }
  }

}
