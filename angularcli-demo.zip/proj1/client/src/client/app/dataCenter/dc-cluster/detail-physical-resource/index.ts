/**
 * Created by root on 6/15/17.
 */
export * from './dc-cluster-detail-physical-resource.module';
export * from './dc-cluster-physical-resource-view.component';
