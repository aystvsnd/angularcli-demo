

import {TranslateService} from '@ngx-translate/core';

import {Component, Input } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'dc-cluster-basic',
    templateUrl: 'dc-cluster-basic.component.html',
})

export class DcClusterBasicComponent {
    @Input() cluster : any;
    password : any = '******';
    editCluster : any;
    isEditState = false;
    serviceGradeList : any = {
        'gold': this.translate.instant('gengyun.gold'),
        'silver': this.translate.instant('gengyun.silver'),
        'copper': this.translate.instant('gengyun.bronze')
    };
    cloudenvTypeList = {
        'openstack': 'openstack + kvm',
        'vmware': 'openstack + vcenter'
    };

    constructor(private translate: TranslateService) {}

    edit() {
      this.editCluster = this.cluster;
      this.isEditState = true;
    }

    save() {
      this.isEditState = false;
    }

    cancel() {
      this.isEditState = false;
    }
}
