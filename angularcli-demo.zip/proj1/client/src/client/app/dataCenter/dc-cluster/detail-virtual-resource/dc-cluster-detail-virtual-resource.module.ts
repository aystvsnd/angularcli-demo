/**
 * Created by root on 6/15/17.
 */
import { NgModule } from '@angular/core';
import { SharedModule } from '../../../shared/index';

import { DcClusterBasicComponent } from './dc-cluster-basic.component';
import { DcClusterResourceUsageComponent } from './dc-cluster-resource-usage.component';

import { DcService } from '../../dc.service';
import { CloudEnvVmService } from '../../../resource/index';
import { HostService } from '../../../resource/index';
import { HostAggragatesService } from '../../../resource/hostAggragates/hostAggragates.service';

@NgModule({
  imports: [SharedModule],
  declarations: [DcClusterBasicComponent, DcClusterResourceUsageComponent],
  providers: [DcService, HostAggragatesService, CloudEnvVmService, HostService],
  exports: [ DcClusterBasicComponent, DcClusterResourceUsageComponent]
})

export class DcClusterDetailVirtualResourceModule { }
