import {TranslateService} from '@ngx-translate/core';
import {Component, Input, OnInit} from '@angular/core';
// import { ApiResourceService as Http } from '../../apiResource.service';
import {Pie, PieData} from '../../../shared/kylib/index';
import {HostService} from '../../../resource/host/host.service';
import {CloudEnvVmService} from '../../../resource/cloudEnvVm/cloudEnvVm.service';
import {DcService} from '../../dc.service';
import { AuthService } from '../../../core/index';

@Component({
    moduleId: module.id,
    selector: 'dc-cluster-resource-usage',
    templateUrl: 'dc-cluster-resource-usage.component.html',
    styleUrls: ['../action/create/dc-cluster-create.component.css']
})

export class DcClusterResourceUsageComponent implements OnInit {
    @Input() cloudenvData : any;
    usageOptions : Array<any> = [];
    cloudenv : any;
    isShowLoading = false;
    shareUsed : any;
    shareTotal : any;
    fcsanTip : any;
    ipsanTip : any;
    otherTip : any;
    detailTip: any = '';

    constructor(private translate: TranslateService,
                private hostService : HostService,
                private vmService : CloudEnvVmService,
                private dcService : DcService,
                private authService: AuthService) {
    }

    ngOnInit() {
        const that = this;
        that.isShowLoading = true;
        that.dcService.getcloudEnvbyid(that.cloudenvData.id).then((res : any) => {
            that.cloudenv = res;
            that.setUsageOptions();
            that.isShowLoading = false;
        });

        setTimeout(function () {
            that.isShowLoading = false;
        }, 10000);
    }
/*
    setResourceUsageData(Hypervisors : any) {
        let that = this;
        for(let Hypervisor of Hypervisors) {
            that.setVcpuUsageData(Hypervisor);
            that.setMemoryUsageData(Hypervisor);
            that.setStorageUsageData(Hypervisor);
        }
    }

    setVcpuUsageData(hypervisor : any) {
        let that = this;
        that.vcpuUsed += hypervisor.vcpu.used;
        that.vcpuTotal += hypervisor.vcpu.total;
    }

    setMemoryUsageData(hypervisor : any) {
        let that = this;
        that.memoryUsed += hypervisor.memory.used;
        that.memoryTotal += hypervisor.memory.total;
    }

    setStorageUsageData(hypervisor : any) {
        let that = this;
        that.storageUsed += hypervisor.storage.used;
        that.storageTotal += hypervisor.storage.total;
    }

    setHostUsageData(hosts :any) {
        let that = this;
        for(let host of hosts) {
            that.hostTotalNum++;
            if(host.status === 'normal') {
                that.hostNormalNum++;
            }
        }
    }

    setVmUsageData(vms :any) {
        let that = this;
        for(let vm of vms) {
            that.vmTotalNum++;
            if(vm.state === 'active') {
                that.vmNormalNum++;
            }
        }
    }
*/
    setUsageOptions() {
        const that = this;
        that.doUseageRateChart(that.cloudenv.vcpu.used, that.cloudenv.vcpu.total, that.translate.instant('dashboard.cpu'));
        that.doUseageRateChart(Math.round(that.cloudenv.memory.used / 1024), Math.round(that.cloudenv.memory.total / 1024),
          that.translate.instant('dashboard.ram'));
        that.doUseageRateChart(that.cloudenv.localStorage.used, that.cloudenv.localStorage.total,
            that.translate.instant('dashboard.localStorage'));
        that.shareUsed = that.cloudenv.iSCSIShareStorage.used
          + that.cloudenv.FCShareStorage.used + that.cloudenv.otherShareStorage.used;
        that.shareTotal = that.cloudenv.iSCSIShareStorage.total
        + that.cloudenv.FCShareStorage.total + that.cloudenv.otherShareStorage.total;
        that.doUseageRateChart(that.shareUsed, that.shareTotal, this.translate.instant('dashboard.shareStorage'));
        that.otherTip = this.translate.instant('dashboard.otherUse') + ':' + that.cloudenv.otherShareStorage.used + '\n'
          + this.translate.instant('dashboard.otherTotal') + ':' + that.cloudenv.otherShareStorage.total + '\n';
        that.ipsanTip = this.translate.instant('dashboard.fcsanUse') + ':' + that.cloudenv.FCShareStorage.used + '\n'
          + this.translate.instant('dashboard.fcsanTotal') + ':' + that.cloudenv.FCShareStorage.total + '\n';
        that.fcsanTip = this.translate.instant('dashboard.ipsanUse') + ':' + that.cloudenv.iSCSIShareStorage.used + '\n'
          + this.translate.instant('dashboard.ipsanTotal') + ':' + that.cloudenv.iSCSIShareStorage.total + '\n';
        if (that.cloudenv.FCShareStorage.total !== 0) {
          this.detailTip += that.ipsanTip;
        }
        if (that.cloudenv.iSCSIShareStorage.total !== 0) {
          this.detailTip += that.fcsanTip;
        }
        if (that.cloudenv.otherShareStorage.total !== 0) {
          this.detailTip += that.otherTip;
        }
        that.dohostOrVmRateChart(that.cloudenv.host.running, that.cloudenv.host.total,
            that.translate.instant('dashboard.hostz'));
        that.dohostOrVmRateChart(that.cloudenv.vm.running, that.cloudenv.vm.total,
            that.translate.instant('dashboard.vm'));

        if (that.authService.containSomeRights(['Physic Bare Metal#View'])) {
          if (that.cloudenv.bare_metal) {
            that.doUseageRateChart(that.cloudenv.bare_metal.used, that.cloudenv.bare_metal.total,
              that.translate.instant('gengyun.bareMetal.usag'));
          } else {
            that.doUseageRateChart(0, 0,
              that.translate.instant('gengyun.bareMetal.usag'));
          }
        }
    }

    doUseageRateChart(used: number, total: number, title: string) {
        const pieData = <Pie>{};
        pieData.data = [];
        pieData.data[0] = <PieData>{};
        let rate: number;
        if (0 === total) {
            rate = 0;
        }else {
            rate = Math.round(used * 100 / total);
        }
        pieData.data[0].name = `${used} used`;
        pieData.data[0].value = used;
        pieData.data[0].color = '';

        pieData.data[1] = <PieData>{};
        let unused : any;
        if (used > total) {
            unused = 0;
            rate = 100;
        } else {
            unused = total - used;
        }
        pieData.data[1].name = `${unused} unused`;
        pieData.data[1].value = unused;
        pieData.data[1].color = '';

        pieData.title = title;
        pieData.pieName = this.translate.instant('gengyun.used');
        pieData.pieSubName = `${rate}%`;
        this.usageOptions.push(pieData);
    }

    dohostOrVmRateChart(normalHost: number, total: number, title: string) {
        const pieData = <Pie>{};
        pieData.data = [];
        pieData.data[0] = <PieData>{};
        let rate: number;
        if (0 === total) {
            rate = 0;
        }else {
            rate = Math.round(normalHost * 100 / total);
        }
        pieData.data[0].name = `${normalHost} normal`;
        pieData.data[0].value = normalHost;
        pieData.data[0].color = '#5cb85c';

        pieData.data[1] = <PieData>{};
        const abnormal = total - normalHost;
        pieData.data[1].name = `${abnormal} abnormal`;
        pieData.data[1].value = abnormal;
        pieData.data[1].color = '#f66661';

        pieData.title = title;
        pieData.pieName = this.translate.instant('gengyun.normaluse');
        pieData.pieSubName = `${rate}%`;
        this.usageOptions.push(pieData);
    }

}
