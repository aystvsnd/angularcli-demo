
import {TranslateService} from '@ngx-translate/core';
import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiResourceService as Http } from '../../apiResource.service';
import { DcHardwareService } from './dc-hardware.service';
import {Response} from '@angular/http';

@Component({
  moduleId: module.id,
  selector: 'dc-basic-hardware',
  templateUrl: 'dc-basic-hardware.component.html',
  styleUrls: ['dc-basic-hardware.component.css'],
})

export class DcBasicHardwareComponent implements OnInit {
  @Input() dc : any;
  options: any= [];
  dcInfo: any;
  boardNumber= 0;
  rackServerNumber= 0;
  storageNumber= 0;
  switchNumber= 0;
  routerNumber= 0;
  podNumber= 0;
  rackNumber= 0;
  chassisNumber= 0;
  devices: Array<any>= [
    {name: this.translate.instant('hwm.chassis1'), number: 0, type: 'chassis'},
    {name: this.translate.instant('hwm.board1'), number: 0, type: 'board'},
    {name: this.translate.instant('hwm.rack_server'), number: 0, type: 'rackServer'},
    {name: this.translate.instant('hwm.storage1'), number: 0, type: 'storage'},
    {name: this.translate.instant('hwm.switch'), number: 0, type: 'switch'},
    {name: this.translate.instant('hwm.router'), number: 0, type: 'router'},
    {name: 'POD', number: 0, type: 'pod'},
    {name: this.translate.instant('hwm.rack1'), number: 0, type: 'rack'}
  ];
  isShowInfo = false;
  constructor(private translate: TranslateService,
              public http : Http, private router : Router,
              private dcHardwareService: DcHardwareService) {
    this.dc = {
      domain: {name: ''}
    };
  }

  ngOnInit() {
    const that = this;
    if (that.dc.cloudEnvs.length !== 0) {
      that.dcHardwareService.getDcHardwareResource(that.dc.id).then((res: Response) => {
        that.dcInfo = res;
        that.devices[0].number = that.dcInfo.chassises.totalNumber;
        that.devices[1].number = that.dcInfo.boards.totalNumber;
        that.devices[2].number = that.dcInfo.rackServers.totalNumber;
        that.devices[3].number = that.dcInfo.storages.totalNumber;
        that.devices[4].number = that.dcInfo.switches.totalNumber;
        that.devices[5].number = that.dcInfo.routers.totalNumber;
        that.devices[6].number = that.dcInfo.pods.totalNumber;
        that.devices[7].number = that.dcInfo.racks.totalNumber;
      });

    }
  }

  gotoList(item: any) {
    if (item.type === 'chassis') {
      window.localStorage.setItem('chassisBladeLinkTag', 'chassis');
      this.setItemToLocalstorage();
      this.router.navigate(['/main/physicalResource/server/frameServer/frameInner', {'dcId': this.dc.id, 'dcName': this.dc.name}]);
    }else if (item.type === 'board') {
      window.localStorage.setItem('chassisBladeLinkTag', 'blade');
      this.setItemToLocalstorage();
      this.router.navigate(['/main/physicalResource/server/frameServer/bladeInner', {'dcId': this.dc.id, 'dcName': this.dc.name}]);
    } else if (item.type === 'rackServer') {
      this.setItemToLocalstorage();
      this.router.navigate(['/main/physicalResource/server/frameServerSummary', {'dcId': this.dc.id, 'dcName': this.dc.name}]);
    } else if (item.type === 'storage') {
      this.setItemToLocalstorage();
      this.router.navigate(['/main/physicalResource/storagesDevice/storages', {'dcId': this.dc.id, 'dcName': this.dc.name}]);
    } else if (item.type === 'switch') {
      this.setItemToLocalstorage();
      this.router.navigate(['/main/physicalResource/networkDevices/switches', {'dcId': this.dc.id, 'dcName': this.dc.name}]);
    } else if (item.type === 'router') {
      this.setItemToLocalstorage();
      this.router.navigate(['/main/physicalResource/networkDevices/routers', {'dcId': this.dc.id, 'dcName': this.dc.name}]);
    } else if (item.type === 'pod') {
      this.setItemToLocalstorage();
      this.router.navigate(['/main/physicalResource/pods', {'dcId': this.dc.id, 'dcName': this.dc.name}]);
    } else if (item.type === 'rack') {
      this.setItemToLocalstorage();
      this.router.navigate(['/main/physicalResource/rack/list', {'dcId': this.dc.id, 'dcName': this.dc.name}]);
    } else {
      return;
    }
  }

  setItemToLocalstorage() {
     if (window.localStorage.getItem('dcCardLinkTag') === null) {
         window.localStorage.setItem('dcCardLinkTag', 'card');
     }
  }

}

