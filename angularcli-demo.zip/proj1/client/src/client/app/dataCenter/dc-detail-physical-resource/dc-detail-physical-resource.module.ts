/**
 * Created by root on 6/15/17.
 */
import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/index';

import { DcAssetModule } from '../dc-asset/index';

import { DcBasicHardwareComponent } from './dc-basic-hardware.component';
import { DcPhysicalResourceViewComponent } from './dc-physical-resource-view.component';

import { DcService } from  '../dc.service';
import { DcHardwareService } from './dc-hardware.service';

@NgModule({
  imports: [SharedModule, DcAssetModule],
  declarations: [DcBasicHardwareComponent, DcPhysicalResourceViewComponent],
  providers: [DcService, DcHardwareService],
  exports: [DcBasicHardwareComponent]
})

export class DcDetailPhysicalResourceModule { }
