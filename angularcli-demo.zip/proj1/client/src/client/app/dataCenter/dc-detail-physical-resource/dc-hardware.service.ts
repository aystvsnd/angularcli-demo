import { Injectable } from '@angular/core';
import { ApiResourceService as Http } from '../../apiResource.service';
import {Response} from '@angular/http';
import {appConfig} from '../../app.config';


@Injectable()
export class DcHardwareService {

  constructor(public http: Http) {

  }

  getDcHardwareResource(id) {
      const that = this;
      return that.http.get(appConfig.hwvServiceUrl + 'hardwareSummary?dcId=' + id)
        .toPromise()
        .then((res: Response) => {return res.json(); })
        .catch(this.handleError);
    }

  getDcTopo(dcId : any) {
      return this.http.get(appConfig.physicalResourceUrl + 'dcs/' + dcId + '/topo')
        .toPromise()
        .then((res: Response) => {return res.json(); })
        .catch(this.handleError);
  }

  getAsset() {
    return this.http.get(appConfig.physicalResourceUrl + 'assetManagementList')
      .toPromise()
      .then((res: Response) => {return res.json(); })
      .catch(this.handleError);
  }

  postAsset(id: any, deviceModel: any, postData: any) {
    return this.http.post(appConfig.physicalResourceUrl + 'assetManagement/' + id + '/' + deviceModel, postData)
      .toPromise()
      .then((res: Response) => {return res.json(); });
  }

  private handleError(error : any) {
    console.error('An error occurred', error);
    console.log(JSON.stringify(error));
    return error;
   }
  }

