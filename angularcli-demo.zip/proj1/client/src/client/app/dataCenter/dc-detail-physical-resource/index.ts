/**
 * Created by root on 6/15/17.
 */
export * from './dc-detail-physical-resource.module';
export * from './dc-physical-resource-view.component';
