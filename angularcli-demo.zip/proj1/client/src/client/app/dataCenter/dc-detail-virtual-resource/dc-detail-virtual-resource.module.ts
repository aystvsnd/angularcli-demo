/**
 * Created by root on 6/15/17.
 */
import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/index';

import { DcVirtualResourceComponent } from './dc-virtual-resource.component';

import { DcService } from  '../dc.service';

@NgModule({
  imports: [SharedModule],
  declarations: [DcVirtualResourceComponent],
  providers: [DcService],
  exports: [DcVirtualResourceComponent]
})

export class DcDetailVirtualResourceModule { }
