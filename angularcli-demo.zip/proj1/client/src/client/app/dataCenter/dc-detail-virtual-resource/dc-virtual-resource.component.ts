/**
 * Created by root on 6/15/17.
 */
import {TranslateService} from '@ngx-translate/core';
import { Component, Input, OnInit } from '@angular/core';
import { ApiResourceService as Http } from '../../apiResource.service';
import { DcService } from '../dc.service';
import { Pie, PieData } from '../../shared/kylib/ky-pie/ky-pie.types';
import { AuthService } from '../../core/index';

@Component({
  moduleId: module.id,
  selector: 'dc-virtual-resource',
  templateUrl: 'dc-virtual-resource.component.html',
  styleUrls: ['dc-virtual-resource.component.css'],
})

export class DcVirtualResourceComponent implements OnInit {
  @Input() dc: any;
  options: any = [];
  shareUsed : any;
  shareTotal : any;
  fcsanTip : any;
  ipsanTip : any;
  otherTip : any;
  detailTip: any = '';

  constructor(private translate: TranslateService,
              public http: Http,
              private dcService: DcService,
              private authService: AuthService) {
  }

  doUseageRateChart(used: number, total: number, title: string) {
    const pieData = <Pie>{};
    pieData.data = [];
    pieData.data[0] = <PieData>{};
    let rate: number;
    if (0 === total) {
      rate = 0;
    } else {
      rate = Math.round(used * 100 / total);
    }
    pieData.data[0].name = `${used} used`;
    pieData.data[0].value = used;
    pieData.data[0].color = '';

    pieData.data[1] = <PieData>{};
    let unused: any;
    if (used > total) {
      unused = 0;
      rate = 100;
    } else {
      unused = total - used;
    }
    pieData.data[1].name = `${unused} unused`;
    pieData.data[1].value = unused;
    pieData.data[1].color = '';

    pieData.title = title;
    pieData.pieName = this.translate.instant('gengyun.used');
    pieData.pieSubName = `${rate}%`;
    this.options.push(pieData);
  }

  dohostOrVmRateChart(normalHost: number, total: number, title: string) {
    const pieData = <Pie>{};
    pieData.data = [];
    pieData.data[0] = <PieData>{};
    let rate: number;
    if (0 === total) {
      rate = 0;
    } else {
      rate = Math.round(normalHost * 100 / total);
    }
    pieData.data[0].name = `${normalHost} normal`;
    pieData.data[0].value = normalHost;
    pieData.data[0].color = '';

    pieData.data[1] = <PieData>{};
    const abnormal = total - normalHost;
    pieData.data[1].name = `${abnormal} abnormal`;
    pieData.data[1].value = abnormal;
    pieData.data[1].color = '';

    pieData.title = title;
    pieData.pieName = this.translate.instant('gengyun.normaluse');
    pieData.pieSubName = `${rate}%`;
    this.options.push(pieData);
  }

  ngOnInit() {
    const that = this;
    that.doUseageRateChart(that.dc.vcpu.used, that.dc.vcpu.total, that.translate.instant('dashboard.cpu'));
    that.doUseageRateChart(Math.round(that.dc.memory.used / 1024), Math.round(that.dc.memory.total / 1024),
      that.translate.instant('dashboard.ram'));
    that.doUseageRateChart(that.dc.storage.used, that.dc.storage.total, this.translate.instant('dashboard.localStorage'));
    that.dohostOrVmRateChart(that.dc.host.running, that.dc.host.total, this.translate.instant('dashboard.hostz'));
    that.shareUsed = that.dc.iSCSIShareStorage.used
      + that.dc.FCShareStorage.used + that.dc.otherShareStorage.used;
    that.shareTotal = that.dc.iSCSIShareStorage.total
      + that.dc.FCShareStorage.total + that.dc.otherShareStorage.total;
    that.doUseageRateChart(that.shareUsed, that.shareTotal, this.translate.instant('dashboard.shareStorage'));
    that.otherTip = this.translate.instant('dashboard.otherUse') + ':' + that.dc.otherShareStorage.used + '\n'
      + this.translate.instant('dashboard.otherTotal') + ':' + that.dc.otherShareStorage.total + '\n';
    that.ipsanTip = this.translate.instant('dashboard.fcsanUse') + ':' + that.dc.FCShareStorage.used + '\n'
      + this.translate.instant('dashboard.fcsanTotal') + ':' + that.dc.FCShareStorage.total + '\n';
    that.fcsanTip = this.translate.instant('dashboard.ipsanUse') + ':' + that.dc.iSCSIShareStorage.used + '\n'
      + this.translate.instant('dashboard.ipsanTotal') + ':' + that.dc.iSCSIShareStorage.total + '\n';
    if (that.dc.FCShareStorage.total !== 0) {
      this.detailTip += that.ipsanTip;
    }
    if (that.dc.iSCSIShareStorage.total !== 0) {
      this.detailTip += that.fcsanTip;
    }
    if (that.dc.otherShareStorage.total !== 0) {
      this.detailTip += that.otherTip;
    }
    that.dohostOrVmRateChart(that.dc.vm.running, that.dc.vm.total, that.translate.instant('dashboard.vm'));
    if (that.authService.containSomeRights(['Physic Bare Metal#View'])) {
      if (that.dc.bareMetal) {
        that.doUseageRateChart(that.dc.bareMetal.used, that.dc.bareMetal.total,
          that.translate.instant('gengyun.bareMetal.usag'));
      } else {
        that.doUseageRateChart(0, 0,
          that.translate.instant('gengyun.bareMetal.usag'));
      }
    }
  }
}
