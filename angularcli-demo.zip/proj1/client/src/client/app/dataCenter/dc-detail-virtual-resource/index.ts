/**
 * Created by root on 6/15/17.
 */
export * from './dc-detail-virtual-resource.module';
