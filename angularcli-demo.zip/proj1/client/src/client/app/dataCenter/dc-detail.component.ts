
import {Component, OnInit, OnDestroy} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';
import { DcService } from './dc.service';
import {TranslateService} from '@ngx-translate/core';
import {StorageService} from '../storage.service';
import { AuthService } from '../core/index';

@Component({
    moduleId: module.id,
    selector: 'dc-detail',
    templateUrl: 'dc-detail.html',
    styleUrls: ['./dc-detail-physical-resource/dc-basic-hardware.component.css'],
})

export class DcDetailComponent implements OnInit , OnDestroy {
    static backTabNamee : any = '';
    dcInfo : any;
    selectTabz : any;
  //${that.translate.instant('DELETE')} this.translate.instant('CloudEnv')
  selectOperation: any;
    public tabs : Array<any> = [];
    links : any = [{name: this.translate.instant('DataCenter'), url: '/main/dc/summary'}, {name: ''}];

    delDcMessage : any = {
      title: this.translate.instant('gengyun.deletedatacenter'),
      message: '',
      confirmText: this.translate.instant('Delete'),
      cancelText: this.translate.instant('Cancel'),
      type: 'exclamation'
    };
    createUserMessage : any = {
        title: this.translate.instant('gengyun.userCreate.title'),
        message: this.translate.instant('gengyun.userCreate.message'),
        confirmText: this.translate.instant('flavor.confirmText'),
        cancelText: this.translate.instant('Cancel'),
        type: 'question'
    };

    isShowInfo = false;
    infoMsgs: string[] = [this.translate.instant('gengyun.delDcinfo')];
    errMsgs : string [] = [];
    isShowError = false;
    isShowLoading = false;
    isShowDelLoading = false;
    loadingTitle : any = this.translate.instant('gengyun.delWait');
    dcDescription : any = '';
    isDcBind = false;
    isShowDcBindInfo = false;
    infoDcBindMsgs : string[] = [this.translate.instant('gengyun.bindUserSucc')];
    isShowUserCreateInfo = false;
    infoUserCreateMsgs : string[] = [this.translate.instant('gengyun.operSucc')];
    isShowDcCloudenv = true;

    constructor(private activatedRoute: ActivatedRoute,
                private dcService : DcService,
                private router: Router,
                private storageService: StorageService,
                private translate: TranslateService, private authService: AuthService) {
        if (this.storageService.getCurrentLang() === 'en') {
            $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
        } else {
            $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
        }
    }

    ngOnInit() {
        const that = this;
        if (window.localStorage.getItem('deviceDetailEnterPath') ||
            window.localStorage.getItem('deviceDetailEnterPath' === '')) {
           window.localStorage.removeItem('deviceDetailEnterPath');
        }

        if (that.authService.containEveryRights(['Cloud Environment#GET', 'Domain Host#GET', 'OS Aggregate#GET',
                'Domain Virtual Machine#GET'])) {
            that.isShowDcCloudenv = true;
            that.tabs = [{title: this.translate.instant('CloudEnv'), name: 'dcDetailEnvResource', active: false},
                {title: this.translate.instant('hwm.virtual_resources'), name: 'dcDetailResource', active: false},
                {title: this.translate.instant('hwm.physical_resource1'), name: 'dcDetailHardware', active: false}];
        } else {
            that.isShowDcCloudenv = false;
            that.tabs = [{title: this.translate.instant('hwm.virtual_resources'), name: 'dcDetailResource', active: false},
                {title: this.translate.instant('hwm.physical_resource1'), name: 'dcDetailHardware', active: false}];
        }
        that.isShowLoading = true;
        this.activatedRoute.params.subscribe(params => {
            const dcId = params['dcId'];
            that.dcService.getDcByDcId(dcId).then((res: Response) => {
                that.dcInfo = res;
                that.dcDescription = that.dcInfo.description;
                that.links[1].name = that.dcInfo.name;
                if (DcDetailComponent.backTabNamee !== '') {
                    for (const tab of this.tabs) {
                        if (tab.name === DcDetailComponent.backTabNamee) {
                            tab.active = true;
                            break;
                        }
                    }
                } else {
                    that.tabs[0].active = true;
                }
                that.isShowLoading = false;
                if (window.localStorage.getItem('dcCardLinkTag')) {
                  that.setActiveTab();
                }
            });
      });
      window.localStorage.setItem('currentTab', '');

        setTimeout(function () {
            that.isShowLoading = false;
        }, 60000);
    }

    setActiveTab() {
        const item = window.localStorage.getItem('dcCardLinkTag');
        if (this.tabs.length === 3) {
            if (item === 'card') {
               this.tabs[2].active = true;
               this.tabs[1].active = false;
               this.tabs[0].active = false;
            } else {
               this.tabs[0].active = true;
               this.tabs[1].active = false;
               this.tabs[2].active = false;
            }
        }

        if (this.tabs.length === 2) {
            if (item === 'card') {
               this.tabs[1].active = true;
               this.tabs[0].active = false;
            } else {
               this.tabs[0].active = true;
               this.tabs[1].active = false;
            }
        }
    }

    ngOnDestroy() {
        DcDetailComponent.backTabNamee = '';
        for (const tab of this.tabs) {
            tab.active = false;
        }
    }

    onSelect(tabzz : any) {
        if (window.localStorage.getItem('dcCardLinkTag')) {
           window.localStorage.removeItem('dcCardLinkTag');
        }

        this.selectTabz = tabzz;
        for (const tab of this.tabs) {
            tab.active = false;
        }
        tabzz.active = true;
    }

    delDc() {
        this.delDcMessage.message = this.translate.instant('gengyun.deletedatacenter') + ': ' +
            this.dcInfo.name + ' ' + this.translate.instant('gengyun.maybeunusedvm') + ',' +
            this.translate.instant('gengyun.confirmdeletedatacenter') + '?';
    }

    sureDel() {
        const that = this;
        that.errMsgs = [];
        that.isShowDelLoading = true;
        that.dcService.deleteDc(that.dcInfo.id).then((res : any) => {
                that.isShowInfo = !that.isShowInfo;
                that.isShowDelLoading = false;
                setTimeout(function () {
                    that.isShowInfo = false;
                    that.router.navigate(['/main/dc/summary']);
                }, 2000);
            },
            (error : any) => {
                that.errMsgs.push(error.message || error);
                that.isShowDelLoading = false;
                /*that.isShowError = true;
                setTimeout(function () {
                    that.isShowError = false;
                }, 5000);*/
            });
        setTimeout(function () {
            that.isShowDelLoading = false;
        }, 8000);
    }

    gotoViewPhysicalResource(dcId: any) {
        this.router.navigate(['/main/dc/details/physicalresource', dcId]);
    }

    bindDc(operType : any) {
        this.router.navigate(['/main/dc/cluster/details/useroperate', this.dcInfo.id, operType]);
    }

    UnbindDc(operType: any) {
        this.router.navigate(['/main/dc/cluster/details/useroperate', this.dcInfo.id, operType]);
    }

    createUserForEnvsOfDc() {
        const that = this;
        that.errMsgs = [];
        that.isShowLoading = true;
        that.dcService.createUserForCloudenvs(that.dcInfo.id).then((res : any) => {
                that.isShowLoading = false;
                if (!res.error) {
                    that.isShowUserCreateInfo = true;
                    setTimeout(function () {
                        that.isShowUserCreateInfo = false;
                    }, 2000);
                }
            },
            (error : any) => {
                that.errMsgs.push(error.message || error);
                that.isShowLoading = false;
            });
        setTimeout(function () {
            that.isShowLoading = false;
        }, 30000);
    }
}
