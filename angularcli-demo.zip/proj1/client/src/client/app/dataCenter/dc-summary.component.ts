import { Component, ViewChild, OnInit } from '@angular/core';
import { Response } from '@angular/http';
import { DcService } from './dc.service';
import { Router } from '@angular/router';
import { ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { ApiResourceService as Http } from '../apiResource.service';
import {TranslateService} from '@ngx-translate/core';

@Component({
    moduleId: module.id,
    selector: 'dc-summary',
    templateUrl: 'dc-summary.component.html',
    styleUrls: ['dc-summary.component.css'],
})

export class DcSummaryComponent implements OnInit {
    @ViewChild('modal') modal: ModalComponent;
    dcs: Array<any>;
    isShowLoading = false;

    constructor(public http: Http,
                private dcService: DcService,
                private router: Router,
                private translate: TranslateService) {
        this.dcs = [];
    }

    ngOnInit() {
        this.removeInvaildItem();
        this.getDcList();
    }

    removeInvaildItem() {
        if (window.localStorage.getItem('dcCardLinkTag')) {
          window.localStorage.removeItem('dcCardLinkTag');
        }

        if (window.localStorage.getItem('chassisBladeLinkTag')) {
          window.localStorage.removeItem('chassisBladeLinkTag');
        }
    }

    goToDcCreate() {
        this.router.navigate(['/main/dc/create']);

    }
    goToDetail(id: any) {
        this.router.navigate(['/main/dc/detail', id]);
    }

    getDcList() {
        const that = this;
        that.isShowLoading = true;
        that.dcService.getDcList().then((res: Response) => {
            that.dcs = res;
            that.isShowLoading = false;
        });
        setTimeout(function () {
            that.isShowLoading = false;
        }, 10000);
    }
}
