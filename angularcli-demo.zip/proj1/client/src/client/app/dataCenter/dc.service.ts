import { Injectable } from '@angular/core';
import { Response } from '@angular/http';
import { appConfig } from '../app.config';
//import '../rxjs-operators';
//import 'rxjs/add/observable/zip';
import { ApiResourceService as Http } from '../apiResource.service';

@Injectable()
export class DcService {

    constructor(public http: Http) {

    }

    getcloudEnvbyid(cloudEnvId: any) {
        const that = this;
        return that.http.get(appConfig.vrmServiceUrl + 'cloudenvs/' + cloudEnvId)
                .toPromise()
                .then((res: Response) => {return res.json().cloudEnv; }).catch(this.handleError);
    }

    getcloudEnvListbyDcId(dcId: any) {
        const that = this;
        return that.http.get(appConfig.vrmServiceUrl + 'cloudenvs?dcId=' + dcId)
                .toPromise()
                .then((res: Response) => {return res.json().cloudEnvs; }).catch(this.handleError);
    }

    getDcList() {
        const that = this;
        return that.http.get(appConfig.vrmServiceUrl + 'dcs')  //   api/v1.0/vrm/dcs
                .toPromise()
                .then((res: Response) => {return res.json().dcs; }).catch(this.handleError);
    }

    getDcByDcId(id : any) {
        const that = this;
        return that.http.get(appConfig.vrmServiceUrl + 'dcs/' + id)
                .toPromise()
                .then((res: Response) => {return res.json().dcs; }).catch(this.handleError);
    }

    deleteDc(id : any) {
        return this.http.delete(`${appConfig.vrmServiceUrl}dcs/${id}`)
                .toPromise();
                //.catch(this.handleError);
    }

    addDc(addDcData : any) {
        return this.http.post(`${appConfig.vrmServiceUrl}dcs`, {'dc': addDcData})
                .toPromise()
                .then((res: Response) => res.json().dcs)
                .catch(this.handleError);
    }

    deleteCloudenv(id : any) {
        return this.http.delete(`${appConfig.vrmServiceUrl}cloudenvs/${id}`)
                .toPromise();
                //.catch(this.handleError);
    }

    /* tslint:disable */
    addCloudenv(addCloudenvData : any) {
        return this.http.post(appConfig.vrmServiceUrl + 'cloudenvs', addCloudenvData)
                .toPromise()
                .then((res:Response) => {})
                .catch(this.handleError);
    }
    /* tslint:enable */

    modCloudenv(id : any, CloudenvData : any) {
        return this.http.put(`${appConfig.vrmServiceUrl}cloudenvs/${id}`, CloudenvData)
            .toPromise()
            .catch(this.handleError);
    }

    getAllAuthUsers() {
        const that = this;
        return that.http.get(`${appConfig.userServiceUrl}?resource=Data Center&methods=GET&displaySelf=false`)
            .toPromise()
            .then((res: Response) => {return res.json().users; }).catch(this.handleError);
    }

    getIksAcls() {
        const that = this;
        return that.http.get(`${appConfig.iksUrl}acls`)
            .toPromise()
            .then((res: Response) => {return res.json().acls; }).catch(this.handleError);
    }

    modIksAcls(aclsData : any) {
        const that = this;
        return that.http.post(`${appConfig.iksUrl}acls`, aclsData)
            .toPromise()
            .then((res: Response) => {return res.json(); })
            .catch(this.handleError);
    }

    getHypervisorsByCloudenvid(cloudenvId: any) {
        const that = this;
        return that.http.get(`${appConfig.vrmServiceUrl}cloudenvs/${cloudenvId}/hypervisors`)
            .toPromise()
            .then((res: Response) => {return res.json().hypervisors; }).catch(this.handleError);
    }

    getAllCloudenvs() {
        return this.http.get(`${appConfig.vrmServiceUrl}domain/cloudenvs?state=all`)
            .toPromise()
            .then((res: Response) => {return res.json().domainEnvs; }).catch(this.handleError);
    }

    createUserForCloudenvs(dcId : any) {
        return this.http.post(`${appConfig.vrmServiceUrl}users/grant/${dcId}`, {})
            .toPromise()
            .catch(this.handleError);
    }

    private handleError(error : any) {
        console.error('An error occurred', error);
        console.log(JSON.stringify(error));
        return error;
    }
}
