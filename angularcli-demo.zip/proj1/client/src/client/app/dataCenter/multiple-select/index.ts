/**
 * Created by root on 6/19/17.
 */
export * from './multiple-select.module';
