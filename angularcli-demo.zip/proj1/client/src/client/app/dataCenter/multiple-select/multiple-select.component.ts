/**
 * Created by root on 6/16/17.
 */
import { Component, Input, Output, EventEmitter, OnInit, DoCheck } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  moduleId: module.id,
  selector: 'multiple-select',
  templateUrl: 'multiple-select.component.html',
  styleUrls: ['multiple-select.component.css']
})

export class MultipleSelectComponent implements OnInit, DoCheck {
  @Input() options : any[] = [];
  @Input() dropDownStyle = '';
  @Output() multiSelectedOptions = new EventEmitter<any[]>();
  backupOptions : any[] = [];
  displayInfo : string = this.translate.instant('Select');
  isAllSelected = false;
  selectedNum : any = 0;
  selectedOptions : any[] = [];
  isActiveButton = false;
  displayText1 : any = this.translate.instant('Select');
  displayText2 : any = this.translate.instant('dashboard.multiSelect.selected');
  displayText3 : any = this.translate.instant('dashboard.multiSelect.item');

  @Input() isShowSearch = false;
  searchText : any = '';

  @Input() isRequire = true;
  isFirstLoad = true;

  constructor(private translate: TranslateService) {
  }

  ngOnInit() {
    this.initOptions();
    if (this.isShowSearch) {
      this.backupOptions = this.cloneOptions(this.options);
    }
  }

  ngDoCheck() {
    this.initOptions();
    if (this.isShowSearch && this.isFirstLoad && !_.isEmpty(this.selectedOptions)) {
      console.log('ngDoCheck-clonebackupOptions');
      this.backupOptions = this.cloneOptions(this.options);
      this.isFirstLoad = false;
    }
  }

  initOptions() {
    this.options.forEach((option) => {
      if (option.checked) {
        if (!this.isOptionSelected(option)) {
          const tmp = {'name': '', 'value': ''};
          tmp.name = option.name;
          tmp.value = option.value;
          this.selectedOptions.push(tmp);
        }
      }
    });
    this.isAllSelected = this.isAllItemSelected();
    this.setDisplayInfo();
  }

  cloneOptions(options) {
    const target : any[] = [];
    options.forEach((option) => {
      const tmp = {'name': '', 'value': '', 'checked': false};
      tmp.name = option.name;
      tmp.value = option.value;
      tmp.checked = option.checked;
      target.push(tmp);
    });
    return target;
  }

  setDisplayInfo() {
    const that = this;
    that.selectedNum = that.selectedOptions.length;
    if (that.selectedNum !== 0) {
      that.displayInfo =  this.displayText2 + that.selectedNum + this.displayText3;
    } else {
      that.displayInfo = this.displayText1;
    }
  }

  isAllItemSelected() {
    if (!this.isShowSearch) {
      return this.selectedOptions.length === this.options.length;
    } else {
      return this.selectedOptions.length === this.backupOptions.length;
    }
  }

  selectAll() {
    const that = this;
    if (that.isAllSelected) {
      this.options.forEach((option) => {
        option.checked = true;
        if (!this.isOptionSelected(option)) {
          const tmp = {'name': '', 'value': ''};
          tmp.name = option.name;
          tmp.value = option.value;
          this.selectedOptions.push(tmp);
        }
      });
    } else {
      this.options.forEach((option) => {
        option.checked = false;
      });
      that.selectedOptions = [];
    }
    that.setDisplayInfo();
    that.multiSelectedOptions.emit(that.selectedOptions);
    if (this.isShowSearch) {
      that.setBackupOptions('selectAll', '');
    }
  }

  selectOne(option : any) {
    const that = this;
    if (option.checked) {
      if (!that.isOptionSelected(option)) {
        const tmp = {'name': '', 'value': ''};
        tmp.name = option.name;
        tmp.value = option.value;
        that.selectedOptions.push(tmp);
      }
    } else {
      that.selectedOptions = _.filter(that.selectedOptions, function (selectOption) {
        return selectOption.name !== option.name;
      });
    }

    that.isAllSelected = that.isAllItemSelected();
    that.setDisplayInfo();
    that.multiSelectedOptions.emit(that.selectedOptions);
    if (this.isShowSearch) {
      that.setBackupOptions('selectOne', option);
    }
  }

  setBackupOptions(type : any, option : any) {
    if (type === 'selectAll') {
      this.backupOptions.forEach((option) => {
        option.checked = this.isAllSelected;
      });
    } else if (type === 'selectOne'){
      this.backupOptions.forEach((backOption) => {
        if (backOption.name === option.name) {
          backOption.checked = option.checked;
          return;
        }
      });
    } else {
      return;
    }
  }

  isOptionSelected(option : any) {
    return _.find(this.selectedOptions, function (selectOpt) {
      return selectOpt.name === option.name;
    });
  }

  search() {
    if (this.isShowSearch) {
      this.options = this.cloneOptions(this.backupOptions);
    }

    if (this.searchText !== '') {
      this.options = this.options.filter((option) => {
        return (option.name.indexOf(this.searchText) !== -1);
      });
    }
  }

  moveOverButton() {
    this.isActiveButton = true;
  }

  moveOutButton() {
    this.isActiveButton = false;
  }

  getNameDisplay(name : any) {
    return name.length > 30 ? (name.substr(0, 20) + '...') : name;
  }

}
