/**
 * Created by root on 6/16/17.
 */
import { NgModule } from '@angular/core';

import {MultipleSelectComponent} from './multiple-select.component';
import {SharedModule} from '../../shared/shared.module';

@NgModule({
  imports: [SharedModule],
  declarations: [MultipleSelectComponent],
  exports: [MultipleSelectComponent]
})

export class MultipleSelectModule {}

