import { Injectable } from '@angular/core';
import { appConfig } from '../app.config';
import '../rxjs-operators';
import { Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/zip';
import { ApiResourceService as Http } from '../apiResource.service';

@Injectable()
export class DomainService {
    dcs: Array<any>;
    clusters: Array<any>;
    constructor(public http: Http) {
        this.dcs = [];
        this.clusters = [];
    }

    getCpuPer(dc: any) {
        return  dc.vcpu.total === 0 ? 0 : parseInt((dc.vcpu.used / dc.vcpu.total * 100).toString());
    }
    getDiskPer(dc: any) {

        return dc.storage.total === 0 ? 0 :  parseInt((dc.storage.used / dc.storage.total * 100).toString());
    }
    getMemoryPer(dc: any) {
        return dc.memory.total === 0 ? 0 : parseInt((dc.memory.used / dc.memory.total * 100).toString());
    }
    getHostPer(dc: any) {
        return dc.host.total === 0 ? 0 : parseInt((dc.host.running / dc.host.total * 100).toString());
    }
    // getDc(dcs:Array<any>) {
    //     let that = this;
    //     let promiseList:Array<any> = [];
    //     for(let dc of dcs) {
    //         promiseList.push(this.http.get(appConfig.vdcServiceUrl + 'dcs/' + dc.id).toPromise());
    //     }
    //     return Promise.all(promiseList).then((res:any)=> {
    //          for (let dc of res) {
    //             var temDc = dc.json().dcs;
    //             temDc.memory.total = parseInt((temDc.memory.total / 1024).toString());
    //             temDc.memory.used = parseInt((temDc.memory.used / 1024).toString());
    //             temDc.cpuPer= that.getCpuPer(temDc);
    //             temDc.diskPer= that.getDiskPer(temDc);
    //             temDc.hostPer= that.getHostPer(temDc);
    //             temDc.memoryPer=that.getMemoryPer(temDc);
    //             that.dcs.push(temDc);
    //         }
    //         return Promise.resolve(that.dcs);
    //     })
    //
    // }
    // getDcs() {
    //     return this.http.get(appConfig.vdcServiceUrl + 'dcs')
    //         .toPromise().then((res:Response)=>this.getDc(res.json().dcs));
    // }
    getDc(dcs: any) {
        return this.http.get(appConfig.vrmServiceUrl + 'dcs/' + dcs.id);
    }
    proDcDetail(detailObj: any) {
        const temDc = detailObj.json().dcs;
        temDc.memory.total = parseInt((temDc.memory.total / 1024).toString());
        temDc.memory.used = parseInt((temDc.memory.used / 1024).toString());
        temDc.cpuPer = this.getCpuPer(temDc);
        temDc.diskPer = this.getDiskPer(temDc);
        temDc.hostPer = this.getHostPer(temDc);
        temDc.memoryPer = this.getMemoryPer(temDc);
        return temDc;
    }

    getDcs() {
        const that = this;
        return this.http.get(appConfig.vrmServiceUrl + 'dcs').flatMap(res => {
            return Observable.from(res.json().dcs).flatMap(res => {
                return that.getDc(res);
            }).map(detailObj => {
                return that.proDcDetail(detailObj);
            }).toArray();
        });
    }

    getClusters(dcId: any) {
        // return this.http.get(appConfig.vdcServiceUrl + 'cloudenvs?dcId=' + dcId)
        //     .toPromise().then((res:Response)=>this.getCluster(res.json().cloudEnvs));
        const that = this;
        return this.http.get(appConfig.vrmServiceUrl + 'cloudenvs?dcId=' + dcId)
            .flatMap(res => {
                return Observable.from(res.json().cloudEnvs).flatMap(res => {
                    return Observable.zip(
                        that.http.get(appConfig.vrmServiceUrl + 'cloudenvs/' + res.id),
                        that.http.get(appConfig.vrmServiceUrl + 'cloudenvs/' + res.id + '/hosts'),
                        that.http.get(appConfig.vrmServiceUrl + 'cloudenvs/' + res.id + '/os-aggregates'),
                        that.http.get(appConfig.vrmServiceUrl + 'vms?cloudEnvId=' + res.id),
                        function(res1, res2, res3, res4) {
                            const cloudEnv = res1.json().cloudEnv;
                            cloudEnv.password = res.password;
                            cloudEnv.hosts = res2.json().hosts;
                            cloudEnv.aggregates = res3.json().aggregates;
                            cloudEnv.vms = res4.json().vmInfo;
                            return cloudEnv;
                        }
                    );
                }).map(
                     res => {return res; }
                ).toArray();
            });
    }




    getOneCluster(cloudEnvId: any) {
        return Observable.zip(
            this.http.get(appConfig.vrmServiceUrl + 'cloudenvs/' + cloudEnvId),
            this.http.get(appConfig.vrmServiceUrl + '/cloudenvs/' + cloudEnvId + '/hosts'),
            this.http.get(appConfig.vrmServiceUrl + '/cloudenvs/' + cloudEnvId + '/os-aggregates'),
            this.http.get(appConfig.vrmServiceUrl + 'cloudenvs/' + cloudEnvId + '/vms'),
            function(res1, res2, res3, res4) {
                const cloudEnv = res1.json().cloudEnv;
                cloudEnv.hosts = res2.json().hosts;
                cloudEnv.aggregates = res3.json().aggregates;
                cloudEnv.vms = res4.json().vmsGetInfo;
                return cloudEnv;
            }
        );
    }
}
