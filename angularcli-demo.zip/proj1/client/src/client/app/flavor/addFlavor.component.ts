
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FlavorService } from  './flavor.service';
import { ApiResourceService } from '../apiResource.service';
import {TranslateService} from '@ngx-translate/core';

@Component({
  moduleId: module.id,
  selector: 'add-flavor',
  templateUrl: 'addFlavor.component.html',
  styleUrls: ['flavor.component.css']
})

export class AddFlavorComponent implements OnInit {
    flavor: any;
    tmp : string;
    vcpuList: Array<any>= [];
    hugepagesizeList: Array<any>= [];
    flavorList : Array<any> = [];
    flavorExspeclist : Array<any> = [];
    isHugepagesize = false;
    isWatchdogflag = false;
    isNumaflag = false;
    isBootflag = false;
    isComputeTypeflag = false;
    isBaremetalflag = false;
    isCpuArchflag = false;
    numaNodeOptions : any[] = [{'value': '1'}, {'value': '2'}];
    bootOptions : any[] = [{'value': 'local'}];
    cpuArchOptions : any[] = [{'value': 'x86_64'}];
    computeTypeOptions : any[] = [{'value': 'ironic'}];
    selectedBootPolicy : any;
    selectedCpuArchPolicy : any;
    selectedComputeTypePolicy : any;
    selectedNumaNode : any;
    numaPolicyOptions : any[] = [{'value': 'shared'}, {'value': 'dedicated'}];
    selectedNumaPolicy : any;
    placeholder1 = this.translate.instant('flavor.addflavorExspecname');
    placeholder2 = this.translate.instant('flavor.addflavorExspecdescribe');
    links : any = [{name: this.translate.instant('flavor.vmFlavor'), url: '/main/flavor/summary'},
                    {name: this.translate.instant('flavor.createVmFlavor')}];
    isShowInfo = false;
    infoMsgs: string[] = [this.translate.instant('flavor.infoMsgs')];
    isShowLoading = false;
    loadingTitle : any = this.translate.instant('flavor.createFlavorWait');
    errMsgs : string [] = [];
    isShowError = false;
    showErrorMsg : any = '';
    isValid = false;

    exchageDisk : any = 0;
    tempDisk : any = 0;
    focusInputFlags : any[] = [{'name': 'name', 'isFocus': false},
                            {'name': 'ram', 'isFocus': false},
                            {'name': 'disk', 'isFocus': false},
                            {'name': 'vcpus', 'isFocus': false}];
    SelectNumaPolicyTitle : any = this.translate.instant('flavor.selectNumaPolicy');
    SelectNumaNodesTitle : any = this.translate.instant('flavor.selectNumaNodes');
    SelectBootTitle : any = this.translate.instant('flavor.selectBootPolicy');
    SelectCpuArchTitle : any = this.translate.instant('flavor.selectCpuArchPolicy');
    SelectComputeTypeTitle : any = this.translate.instant('flavor.selectComputeTypePolicy');
    inputDelayTimeTitle : any = this.translate.instant('flavor.inputWaitdog');

    constructor(public http: ApiResourceService,
                private router: Router,
                private flavorService: FlavorService,
                private translate: TranslateService) {
        this.flavor = {
          'flavor': {
            'spec': {
              'name': '',
              'ram': '',
              'vcpus': '',
              'disk': ''
            },
            'extra_spec': {
              'aggregate_instance_extra_specs:isSSD': false,
              'hw:mem_page_size': '',
              'hw:numa_nodes': '1',
              'hw:cpu_policy': '',
              'capabilities:boot_option': '',
              'cpu_arch': '',
              'hw:compute_type': '',
              'hw_watchdog_action': 'reset',
              'hw_watchdog_enabledelay': '600000'
            }
          }
        };

        this.tmp = '';
        this.hugepagesizeList = [{'value': '2048', 'isActive': false},
                                {'value': '1048576', 'isActive': false},
                                {'value': 'large', 'isActive': false},
                                {'value': 'small', 'isActive': false},
                                {'value': 'any', 'isActive': false}];
        this.vcpuList = [{'value': 1, 'isActive': false},
                         {'value': 2, 'isActive': false},
                         {'value': 4, 'isActive': false},
                         {'value': 8, 'isActive': false},
                         {'value': 16, 'isActive': false},
                         {'value': 32, 'isActive': false}];
    }


    ngOnInit() {
        this.flavorService.getFlavors().then((res : any) => {
            this.flavorList = res;
        });
    }

    isFlavorExist() {
        for (const flavor of this.flavorList) {
            if (flavor.spec.name === this.flavor.flavor.spec.name) {
                return true;
            }
        }

        return false;
    }


    gotoAddFlavor() {
        const that = this;
        that.errMsgs = [];
        // let headers = new Headers({'Content-Type': 'application/json'});
        if (!that.flavor.flavor.extra_spec['aggregate_instance_extra_specs:isSSD']) {
            delete that.flavor.flavor.extra_spec['aggregate_instance_extra_specs:isSSD'];
        } else {
            that.flavor.flavor.extra_spec['aggregate_instance_extra_specs:isSSD']
                = that.flavor.flavor.extra_spec['aggregate_instance_extra_specs:isSSD'].toString();
        }

        if (!that.isHugepagesize) {
            delete that.flavor.flavor.extra_spec['hw:mem_page_size'];
        }

        if (!that.isWatchdogflag) {
            delete that.flavor.flavor.extra_spec.hw_watchdog_action;
            delete that.flavor.flavor.extra_spec.hw_watchdog_enabledelay;
        }

        if (!that.isNumaflag) {
            delete that.flavor.flavor.extra_spec['hw:numa_nodes'];
            delete that.flavor.flavor.extra_spec['hw:cpu_policy'];
        } else {
            that.flavor.flavor.extra_spec['hw:numa_nodes'] = that.selectedNumaNode;
            that.flavor.flavor.extra_spec['hw:cpu_policy'] = that.selectedNumaPolicy;
        }

        if (!that.isBaremetalflag) {
          delete that.flavor.flavor.extra_spec['capabilities:boot_option'];
          delete that.flavor.flavor.extra_spec['cpu_arch'];
          delete that.flavor.flavor.extra_spec['hw:compute_type'];
        } else {
          that.flavor.flavor.extra_spec['capabilities:boot_option'] = that.selectedBootPolicy;
          that.flavor.flavor.extra_spec['cpu_arch'] = that.selectedCpuArchPolicy;
          that.flavor.flavor.extra_spec['hw:compute_type'] = that.selectedComputeTypePolicy;
        }


        for (const a of this.flavorExspeclist) {
          that.flavor.flavor.extra_spec[a.key] = a.value;
        }

        that.flavor.flavor.spec.ram = +that.flavor.flavor.spec.ram;
        that.flavor.flavor.spec.disk = +that.flavor.flavor.spec.disk;
        that.flavor.flavor.spec.vcpus = +that.flavor.flavor.spec.vcpus;
        that.isShowLoading = !that.isShowLoading;
        that.isValid = true;
        that.flavorService.addFlavor(that.flavor).then((res : any) => {
            that.isShowLoading = false;
            that.isShowInfo = !this.isShowInfo;
            setTimeout(function () {
                that.isShowInfo = false;
                that.cancel();
            }, 2000);
        },
        (error : any) => {
            that.errMsgs.push(error.message || error);
            that.isShowLoading = false;
            that.isShowError = false;
            that.isValid = false;
            /*setTimeout(function () {
                that.isShowError = false;
            }, 5000);*/
        });
        setTimeout(function () {
            that.isShowLoading = false;
            that.isValid = false;
        }, 60000);
    }

    cancel() {
        this.router.navigate(['/main/flavor/summary']);
    }

    // setVcpus(item:any) {
    //     _.map(this.vcpuList,function (vcpu:any) {
    //       vcpu.isActive = false;
    //     });
    //     this.flavor.flavor.spec.vcpus  = item.value;
    //     item.isActive = true;
    // }

    setHugepagesize(item: any) {
        _.map(this.hugepagesizeList, function (hugepagesize: any) {
            hugepagesize.isActive = false;
        });
        this.flavor.flavor.extra_spec['hw:mem_page_size'] = item.value;
        item.isActive = true;
    }

    selectHugepagesize() {
        _.map(this.hugepagesizeList, function (hugepagesize: any) {
            hugepagesize.isActive = false;
        });
        this.flavor.flavor.extra_spec['hw:mem_page_size'] = this.hugepagesizeList[0].value;
        this.hugepagesizeList[0].isActive = true;
    }

    setFocusInputFlag(inputName : any, flag : any) {
        const that = this;
        for (const inputFlag of that.focusInputFlags) {
            if (inputFlag.name === inputName) {
                inputFlag.isFocus = flag;
                break;
            }
        }
    }

    isShowExplain(isTryInputFlag : boolean, specConfig : any) {
        return (isTryInputFlag && (specConfig === ''));
    }

    isInputError(specConfig : any, min : any, max : any) {
        if (specConfig !== '') {
            return isNaN(specConfig) || (specConfig < min) || (specConfig > max) || this.isFloatNum(specConfig);
        }
        return false;
    }

    delflavorExspec(flavorExspeclist: Array<any>, flavorExspec: any) {
      const index = flavorExspeclist.indexOf(flavorExspec);
      if (index > -1) {
        flavorExspeclist.splice(index, 1);
      }
    }

    addflavorExspec(flavorExspeclist: Array<any>) {
      const tempIp = {
        'key' : '',
        'value': ''
      };
      flavorExspeclist.push(tempIp);
    }

    isExspechave() {
      const newkeylist = this.flavorExspeclist.map(function (v) {
        return v.key;
      });
      const newlist = [];
      for (const i of newkeylist) {
        if (newlist.indexOf(i) === -1) {
            newlist.push(i);
        }else {
          return true;
        }
      }
    }

    addflavorExspecvaild() {
      const initial = ['aggregate_instance_extra_specs:isSSD', 'hw:mem_page_size', 'hw:cpu_policy', 'hw:numa_nodes',
        'hw_watchdog_action', 'hw_watchdog_enabledelay', 'isSSD', 'hugepagesize', ''];
      for (const a of this.flavorExspeclist) {
        if (_.contains(initial, a.key)) {
          return true;
        }
      }
      return false;
    }

    isRamInputError() {
        const that = this;
        if (that.isInputError(that.flavor.flavor.spec.ram, 1, 2000000)) {
            that.showErrorMsg = that.translate.instant('flavor.inputRamError');
            return true;
        }
        if (!that.isRamAccordHugepage(that.flavor.flavor.spec.ram)) {
            return true;
        }
        return false;
    }

  isVcpusInputError() {
    const reg = /^\+?[1-9][0-9]*$/;
    const vcpusinput = !reg.test(this.flavor.flavor.spec.vcpus);
    if (this.flavor.flavor.spec.vcpus) {
      return vcpusinput;
    }
    return false;
  }

    isRamAccordHugepage(ramConfig : any) {
        const that = this;
        if (ramConfig === '') {
            return true;
        }
        const  configNum = +ramConfig;
        const selectedHugepage : any = that.getSelectedHugepage();
        if (that.isHugepagesize && selectedHugepage !== '') {
            if ((selectedHugepage === '2048') && !that.isRamMultiple(configNum, 2)) {
                that.showErrorMsg = that.translate.instant('flavor.hugepageSelect') + '2M' + ',' +
                    that.translate.instant('flavor.RamAcdHugepageError1') + '2' +
                    that.translate.instant('flavor.RamAcdHugepageError2');
                return false;
            } else if ((selectedHugepage === '1048576') && !that.isRamMultiple(configNum, 1024)) {
                that.showErrorMsg = that.translate.instant('flavor.hugepageSelect') + '1G' + ',' +
                    that.translate.instant('flavor.RamAcdHugepageError1') + '1024' +
                    that.translate.instant('flavor.RamAcdHugepageError2');
                return false;
            } else if ((selectedHugepage === 'large') && !that.isRamMultiple(configNum, 2) &&
                      !that.isRamMultiple(configNum, 1024)) {
                that.showErrorMsg = that.translate.instant('flavor.hugepageSelect') + 'large' + ',' +
                    that.translate.instant('flavor.RamAcdHugepageError1') + '2' +
                    that.translate.instant('flavor.or') + '1024' + that.translate.instant('flavor.RamAcdHugepageError2');
                return false;
            } else {
                return true;
            }
        }
        return true;
    }

    isRamMultiple(ramNum : any, pagesize : any) {
        return (ramNum % pagesize) === 0;
    }

    getSelectedHugepage() {
        const that = this;
        for (const hugepage of that.hugepagesizeList) {
            if (hugepage.isActive) {
                return hugepage.value;
            }
        }
        return '';
    }

    isbaremetalComputeTypePolicy() {
        if (this.isBaremetalflag) {
          if (this.selectedComputeTypePolicy) {
            return false;
          }
          return true;
      }
    }

    isDisableButton() {
        return this.isFlavorExist() || this.isRamInputError()
          || this.isValid || this.addflavorExspecvaild() || this.isExspechave()
          || this.isbaremetalComputeTypePolicy() || this.isVcpusInputError();
    }

    isFloatNum(num : any) {
        return num.toString().indexOf('.') !== -1;
    }

    isShowSSDTip() {
        return this.flavor.flavor.extra_spec['aggregate_instance_extra_specs:isSSD'];
    }

    isShowHugeTip() {
        return this.isHugepagesize;
    }
}
