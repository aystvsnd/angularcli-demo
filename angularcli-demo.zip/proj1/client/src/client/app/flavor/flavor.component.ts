
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import {TranslateService} from '@ngx-translate/core';
import { FlavorService } from './flavor.service';
import { StorageService } from '../storage.service';
import { AuthService } from '../core/index';
//import { TooltipModule } from 'ng2-bootstrap/ng2-bootstrap';
//import { TOOLTIP_DIRECTIVES } from 'ng2-bootstrap/ng2-bootstrap';

@Component({
  moduleId: module.id,
//  selector: 'flavor',
  //directives: [TOOLTIP_DIRECTIVES],
  templateUrl: 'flavor.component.html'
})

export class FlavorComponent implements OnInit, OnDestroy {
    tryDelFlavor : any;
    tryPubFlavor : any;
    //tryEditFlavor : any;
    timerHandle : any = undefined;
    delFlavorMessage : any = {
        title: this.translate.instant('flavor.delFlavor'),
        message: '',
        confirmText: this.translate.instant('Delete'),
        cancelText: this.translate.instant('Cancel'),
        type: 'exclamation'
    };
    pubFlavorMessage : any = {
        title: this.translate.instant('flavor.pubTitle'),
        message: '',
        confirmText: this.translate.instant('flavor.publish'),
        cancelText: this.translate.instant('Cancel'),
        type: 'question'
    };
    allpubFlavorMessage : any = {
      title: this.translate.instant('flavor.pubTitle'),
      message: this.translate.instant('flavor.allpublishMsg'),
      confirmText: this.translate.instant('flavor.publish'),
      cancelText: this.translate.instant('Cancel'),
      type: 'question'
    };
    isShowInfo = false;
    infoMsgs: string[] = [this.translate.instant('flavor.delFlavorSucc')];
    hugepagesizes : any = {
        'large': 'large',
        'small': 'small',
        'any' : 'any',
        '2048': '2M',
        '1048576': '1G'
    };
    isShowLoading = false;
    loadingTitle : any = this.translate.instant('flavor.delFlavorWait');
    isShowDelSelectLoading = false;
    selectedNum : any = 0;
    errMsgs : string [] = [];
    isShowError = false;
    selectedRows : any[] = [];
    isFirstLoad = false;
    isPageChange = false;
    searchText : any = '';
    window: window = window;
    rowData : Array<any> = [];
    columnDefs: any[] = [
        {
            checkbox: true
        },
        {
            field: 'name',
            sortable: true,
            title: this.translate.instant('flavor.flavorName'),
            class: 'table-wrap'
        },
        {
            field: 'cloudenv',
            sortable: true,
            title: this.translate.instant('flavor.flavorEnv'),
            formatter: this.getCloudenvs,
            class: 'table-wrap'
        },
        {
            field: 'vcpus',
            sortable: true,
            title: this.translate.instant('flavor.flavorVcpu')
        },
        {
            field: 'ram',
            sortable: true,
            title: this.translate.instant('flavor.flavorRam')
        },
        {
            field: 'disk',
            sortable: true,
            title: this.translate.instant('flavor.flavorDisk')
        },
        {
            field: 'tempdisk',
            sortable: true,
            title: this.translate.instant('flavor.flavorTmpdisk')
        },
        {
            field: 'exchagedisk',
            sortable: true,
            title: this.translate.instant('flavor.flavorExdisk')
        },
        {
            field: 'extraspec',
            title: this.translate.instant('flavor.flavorExspec')
        },
        {
            field: 'oper',
            title: this.translate.instant('Operation'),
            width: '140',
            searchFormatter: false,
            cellStyle: (value, row, index, field) => {
              return {
                css: {'min-width': '123px'}
              };
            },
            events: 'operateEvents',
            formatter: (value, row, index) => {
                if (this.authService.containSomeRights(['Flavor#DELETE,PUT'])) {
                    return '<div class="btn-group">\
                          <button class="btn btn-default delete" \
                            data-toggle="modal" data-target="#deleteFlavorModal">\
                            ' + this.translate.instant('flavor.delete') + '</button>\
                          <button class="btn btn-default dropdown-toggle" id="dropdownMenu1" \
                            data-toggle="dropdown" ><span class="caret"></span>\
                          </button>\
                          <ul class="dropdown-menu dropdown-menu-top" role="menu" aria-labelledby="dropdownMenu1">\
                            <li role="presentation">\
                              <a href="javascript:void(0);" class="publish" \
                                data-toggle="modal" data-target="#publishFlavorModal">' + this.translate.instant('flavor.publish') + '</a>\
                            </li>\
                           </ul>\
                        </div>';
                }
                if (this.authService.containSomeRights(['Flavor#DELETE'])) {
                    return '<div class="btn-group">\
                          <button class="btn btn-default delete" \
                            data-toggle="modal" data-target="#deleteFlavorModal">\
                            ' + this.translate.instant('flavor.delete') + '</button>\
                          <button class="btn btn-default dropdown-toggle" id="dropdownMenu1" \
                            data-toggle="dropdown" ><span class="caret"></span>\
                          </button>\
                          <ul class="dropdown-menu dropdown-menu-top" role="menu" aria-labelledby="dropdownMenu1">\
                            <li role="presentation">\
                              <a href="javascript:void(0);" class="delete" \
                                data-toggle="modal" data-target="#deleteFlavorModal">' + this.translate.instant('flavor.delete') + '</a>\
                            </li>\
                           </ul>\
                        </div>';
                }
                if (this.authService.containSomeRights(['Flavor#PUT'])) {
                    return '<div class="btn-group">\
                          <button class="btn btn-default publish" \
                            data-toggle="modal" data-target="#publishFlavorModal">\
                            ' + this.translate.instant('flavor.publish') + '</button>\
                          <button class="btn btn-default dropdown-toggle" id="dropdownMenu1" \
                            data-toggle="dropdown" ><span class="caret"></span>\
                          </button>\
                          <ul class="dropdown-menu dropdown-menu-top" role="menu" aria-labelledby="dropdownMenu1">\
                            <li role="presentation">\
                              <a href="javascript:void(0);" class="publish" \
                                data-toggle="modal" data-target="#publishFlavorModal">' + this.translate.instant('flavor.publish') + '</a>\
                            </li>\
                           </ul>\
                        </div>';
                }
            }
        }
    ];

    gridOptions : any = {
        pagination: true,
        //sidePagination: 'server',
        //onlyInfoPagination:true,
        showPaginationswitch: true,
        pageSize: 10,
        pageList: [10, 25, 50, 100],
        search: true,
        strictSearch: false,
        searchText: '',
        paginationDetailHAlign: 'left',
        paginationHAlign: 'left',
        clickToSelect: false,
        sortable: true,
        sortName: 'name',
        sortOrder: 'asc'
    };

    constructor(private flavorService : FlavorService, private router : Router,
                private translate: TranslateService, private storageService: StorageService,
                private authService: AuthService) {
        const that = this;
        if (that.storageService.getCurrentLang() === 'en') {
            $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
        } else {
            $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
        }
        that.window.operateEvents = {
            /*'click .edit': function(e, value, row, index){
                that.tryEditFlavor = row;
            },*/
            'click .delete': function(e, value, row, index){
                console.log(JSON.stringify(row));
                that.tryDelFlavor = row;
                that.delFlavorMessage.message = that.translate.instant('flavor.vmFlavor') + ': ' +
                        that.tryDelFlavor.name + ' ' + that.translate.instant('flavor.delFlavorMsg2') +
                        that.translate.instant('flavor.delFlavorMsg3') +
                        that.translate.instant('flavor.delFlavorMsg4');
            },
           'click .publish': function(e, value, row, index){
                console.log(JSON.stringify(row));
                that.tryPubFlavor = row;
                that.pubFlavorMessage.message = that.translate.instant('flavor.vmFlavor') + ': ' +
                  that.tryPubFlavor.name + ' ' + that.translate.instant('flavor.pubFlavorMsg1') +
                   that.translate.instant('flavor.pubFlavorMsg2');
          }
        };
        if (!that.authService.containSomeRights(['Flavor#DELETE', 'Flavor#PUT'])) {
            that.columnDefs = _.filter(that.columnDefs, function(x) {
                return x.field !== 'oper'; });
        }
    }

    ngOnInit() {
        const that = this;
        that.isFirstLoad = true;
        that.initTable();
        that.reLoadData();
    }

    setRowData(flavors : any) {
        const tempRowData : Array<any> = [];
        for (const flavor of flavors) {
            const temprow : any = {
                'name': '',
                'vcpus': 0,
                'ram': 0,
                'disk': 0,
                'tempdisk': 0,
                'exchagedisk': 0,
                'extraspec': {},
                'cloudenv': [],
                'id': ''
            };
            temprow.name = flavor.spec.name;
            temprow.vcpus = flavor.spec.vcpus;
            temprow.ram = flavor.spec.ram;
            temprow.disk = flavor.spec.disk;
            temprow.tempdisk = 0;
            temprow.exchagedisk = 0;
            temprow.extraspec = this.getextraspec(flavor.extra_spec);
            temprow.cloudenv = flavor.cloudEnvs;
            temprow.id = flavor.id;
            tempRowData.push(temprow);
        }

        return tempRowData;
    }

    getextraspec(extraspec : any) {
        const tempExtraspec : any[] = [];
        const hugepagesizes : any = {
            '2048': '2M',
            '1048576': '1G',
            'large': 'large',
            'small': 'small',
            'any' : 'any'
        };
        let keyView : any;
        let valueView : any;
        tempExtraspec.push('<span>');
        if ((extraspec !== undefined) && (extraspec !== null)) {
            for (const key in extraspec) {
                if (extraspec[key] !== null) {
                    if (key === 'aggregate_instance_extra_specs:isSSD') {
                        keyView = 'isSSD';
                        valueView = extraspec[key];
                    } else if (key === 'hw:compute_type') {
                      keyView = this.getKeyView(key);
                      valueView = extraspec[key];
                    } else if (key === 'hw:numa_nodes') {
                      keyView = this.getKeyView(key);
                      valueView = extraspec[key];
                    } else if (key === 'hw_watchdog_action') {
                      keyView = this.getKeyView(key);
                      valueView = extraspec[key];
                    } else if (key === 'capabilities:boot_option') {
                      keyView = this.getKeyView(key);
                      valueView = extraspec[key];
                    } else if (key === 'cpu_arch') {
                      keyView = this.getKeyView(key);
                      valueView = extraspec[key];
                    } else if (key === 'hw_watchdog_enabledelay') {
                      keyView = this.getKeyView(key);
                      valueView = extraspec[key];
                    } else if (key === 'hw:cpu_policy') {
                      keyView = this.getKeyView(key);
                      valueView = extraspec[key];
                    } else if (key === 'hw:mem_page_size') {
                        keyView = this.getKeyView(key);
                        valueView = (extraspec[key] !== '') ? hugepagesizes[extraspec[key]] : extraspec[key] ;
                    } else {
                        keyView = key;
                        valueView = extraspec[key];
                    }

                    if (tempExtraspec.length === 1) {
                        tempExtraspec.push(keyView + ': ' + valueView);
                    } else {
                        tempExtraspec.push('<br/>' + keyView + ': ' + valueView);
                    }
                }
            }
        }
        tempExtraspec.push('</span>');
        return tempExtraspec.join('');
    }

    getKeyView(key : any) {
      switch (key) {
        case 'hw:mem_page_size':
          return this.translate.instant('flavor.hugepagesize');
        case 'hw:numa_nodes':
          return 'NUMA';
        case 'hw_watchdog_action':
          return this.translate.instant('flavor.watchDog');
        case 'capabilities:boot_option':
          return this.translate.instant('flavor.boot');
        case 'cpu_arch':
          return this.translate.instant('flavor.cpuArch');
        case 'hw:compute_type':
          return this.translate.instant('flavor.computeType');
        case 'hw_watchdog_enabledelay':
          return this.translate.instant('flavor.watchdogEnabledelay');
        case 'hw:cpu_policy':
          return this.translate.instant('flavor.cpuPolicy');
        default:
          return key;
      }
    }

    getCloudenvs(value, row, index) {
        const tempEnvs = [];
        tempEnvs.push('<span>');
        value.forEach(env => {
            if (tempEnvs.length === 1) {
                tempEnvs.push(env);
            } else {
                tempEnvs.push('<br/>' + env);
            }
        });
        tempEnvs.push('</span>');

        return tempEnvs.join('');
    }

    initTable() {
        const that = this;
        const $table = $('#table-flavor-summary');
        $table.bootstrapTable($.extend(that.gridOptions, {
            toolbar: '#toolbar-table-flavor-summary',
            data: that.rowData,
            columns: that.columnDefs
        }));
        $('.bootstrap-table .search input').attr('placeholder', this.translate.instant('WordForFilter'))
            .parent().append(`<span></span>`);
    }

    setTableFooter() {
        const that = this;
        const $table = $('#table-flavor-summary');
        if (that.authService.containSomeRights(['Flavor#DELETE,PUT'])) {
            $table.parents('.fixed-table-container')
                .append(`<div class="fixed-table-footerButtons">
                      <input type="checkbox" class="checkAll">
                      <button id="delete-flavors-btn" data-toggle="modal" data-target="#deleteSelectFlavorModal" disabled>
                        ${that.translate.instant('flavor.delete')}
                      </button>
                      <button id="publish-flavors-btn" data-toggle="modal" data-target="#publishSelectFlavorModal" disabled>
                        ${that.translate.instant('flavor.publish')}
                      </button>
                    </div>`);
        } else if (that.authService.containSomeRights(['Flavor#DELETE'])) {
            $table.parents('.fixed-table-container')
                .append(`<div class="fixed-table-footerButtons">
                      <input type="checkbox" class="checkAll">
                      <button id="delete-flavors-btn" data-toggle="modal" data-target="#deleteSelectFlavorModal" disabled>
                        ${that.translate.instant('flavor.delete')}
                      </button>
                    </div>`);
        } else if (that.authService.containSomeRights(['Flavor#PUT'])) {
            $table.parents('.fixed-table-container')
                .append(`<div class="fixed-table-footerButtons">
                      <input type="checkbox" class="checkAll">
                      <button id="publish-flavors-btn" data-toggle="modal" data-target="#publishSelectFlavorModal" disabled>
                        ${that.translate.instant('flavor.publish')}
                      </button>
                    </div>`);
        } else {
            console.log('todo');
        }

        $table.on('check.bs.table', function (row, $element) {
            if (_.contains(that.selectedRows, $element.id) !== true) {
                that.selectedRows.push($element.id);
            }
        });
        $table.on('uncheck.bs.table', function (row, $element) {
            that.selectedRows = _.without(that.selectedRows, $element.id);
        });
        $table.on('check-all.bs.table uncheck-all.bs.table', function (rows, $element) {
            const selections = $table.bootstrapTable('getSelections');
            that.selectedRows = _.pluck(selections, 'id');
        });
        /*$table.on('check-all.bs.table uncheck-all.bs.table', function () {
            $('.fixed-table-footerButtons .checkAll').prop('checked', $table.bootstrapTable('getSelections').length > 0);
        });*/

        $table.on('check.bs.table uncheck.bs.table ' +
            'check-all.bs.table uncheck-all.bs.table', function () {
            $('.fixed-table-footerButtons button').prop('disabled', !$table.bootstrapTable('getSelections').length);
            that.setFooterCheckAllButton();
        });

        $('.bootstrap-table .fixed-table-footerButtons .checkAll').change(function () {
            if ($(this).prop('checked')) {
                $table.bootstrapTable('checkAll');
            } else {
                $table.bootstrapTable('uncheckAll');
            }
        });

        $table.on('page-change.bs.table', function () {
            that.setFooterCheckAllButton();
        });

        $table.on('search.bs.table', function () {
            that.searchText = $('.bootstrap-table .search input').val();
            if (that.searchText !== '') {
                that.stopReloadInterval();
            } else {
                that.startReloadInterval();
            }
        });

        $('#delete-flavors-btn').click(function() {
            that.selectedNum = $table.bootstrapTable('getSelections').length;
            that.delFlavorMessage.message = `${that.selectedNum} ` + that.translate.instant('flavor.delFlavorMsg1') +
                ',' + that.translate.instant('flavor.delFlavorMsg2') + that.translate.instant('flavor.delFlavorMsg3') +
                that.translate.instant('flavor.delFlavorMsg4');
        });

        $('#publish-flavors-btn').click(function() {
          that.selectedNum = $table.bootstrapTable('getSelections').length;
          that.pubFlavorMessage.message = `${that.selectedNum} ` + that.translate.instant('flavor.pubFlavorMsg3');
        });

        $('#allpublish').click(function() {
          that.selectedNum = $table.bootstrapTable('getSelections').length;
          that.pubFlavorMessage.message = `${that.selectedNum} ` + that.translate.instant('flavor.pubFlavorMsg3');
        });
    }

    addFlavor() {
        this.router.navigate(['/main/flavor/flavorCreate']);
    }

    sureDel() {
        const that = this;
        that.errMsgs = [];
        that.isShowLoading = true;
        that.flavorService.deleteFlavor(that.tryDelFlavor.id).then(() => {
            that.reLoadData();
            that.isShowLoading = false;
            that.isShowInfo = !that.isShowInfo;
            setTimeout(function () {
                that.isShowInfo = false;
            }, 2000);
        },
        (error : any) => {
            that.errMsgs.push(error.message || error);
            that.isShowLoading = false;
            that.isShowError = false;
            /*setTimeout(function () {
                that.isShowError = false;
            }, 5000);*/
        });
        setTimeout(function () {
            that.isShowLoading = false;
        }, 8000);
    }

    surePub() {
        const that = this;
        that.errMsgs = [];
        that.isShowLoading = true;
        that.flavorService.publishFlavor(that.tryPubFlavor.id).then(() => {
            that.reLoadData();
            that.isShowLoading = false;
            that.isShowInfo = !that.isShowInfo;
            setTimeout(function () {
              that.isShowInfo = false;
            }, 2000);
          },
          (error : any) => {
            that.errMsgs.push(error.message || error);
            that.isShowLoading = false;
            that.isShowError = false;
            /*setTimeout(function () {
              that.isShowError = false;
            }, 5000);*/
          });
        setTimeout(function () {
          that.isShowLoading = false;
        }, 8000);
    }

    allPub() {
      const that = this;
      const pubData : any = {
        'flavors': []
      };
      that.errMsgs = [];
      that.isShowLoading = true;
      that.flavorService.allpublish(pubData).then(() => {
          that.reLoadData();
          that.isShowLoading = false;
          that.isShowInfo = !that.isShowInfo;
          setTimeout(function () {
            that.isShowInfo = false;
          }, 2000);
        },
        (error : any) => {
          that.errMsgs.push(error.message || error);
          that.isShowLoading = false;
          that.isShowError = false;
          /*setTimeout(function () {
            that.isShowError = false;
          }, 5000);*/
        });
      setTimeout(function () {
        that.isShowLoading = false;
      }, 8000);
    }

    deleteSelected() {
        const that = this;
        const $table = $('#table-flavor-summary');
        const selectedFlavors : any[] = $table.bootstrapTable('getSelections');
        for (const flavor of selectedFlavors) {
            that.isShowDelSelectLoading = true;
            that.flavorService.deleteFlavor(flavor.id).then((res : any) => {
                that.reLoadData();
                that.selectedNum--;
                if (that.selectedNum === 0) {
                    that.isShowDelSelectLoading = false;
                }
                if (that.isShowInfo === false) {
                    that.isShowInfo = true;
                    setTimeout(function () {
                        that.isShowInfo = false;
                    }, 2000);
                }
            });
        }
        setTimeout(function () {
            that.isShowDelSelectLoading = false;
        }, 10000);
    }

    publishSelected() {
      const that = this;
      const $table = $('#table-flavor-summary');
      const selectedFlavors : any[] = $table.bootstrapTable('getSelections');
      const allid = _.map(selectedFlavors, function(flavor){
        return {'id': flavor.id};
      });
      const pubData : any = {
        'flavors': []
      };
      pubData.flavors = allid;
      that.errMsgs = [];
      that.isShowLoading = true;
      that.flavorService.allpublish(pubData).then(() => {
          that.reLoadData();
          that.isShowLoading = false;
          that.isShowInfo = !that.isShowInfo;
          setTimeout(function () {
            that.isShowInfo = false;
          }, 2000);
        },
        (error : any) => {
          that.errMsgs.push(error.message || error);
          that.isShowLoading = false;
          that.isShowError = true;
          setTimeout(function () {
            that.isShowError = false;
          }, 5000);
        });
      setTimeout(function () {
        that.isShowLoading = false;
      }, 8000);
    }

    reLoadData() {
        const that = this;
        that.refreshFlavorList();
        that.startReloadInterval();
    }

    refreshFlavorList() {
        const that = this;
        const $table = $('#table-flavor-summary');
        if (that.isFirstLoad) {
            $table.bootstrapTable('showLoading');
        }
        that.flavorService.getFlavors().then((res : any) => {
            that.rowData = that.setRowData(res);
            $table.bootstrapTable('load', that.rowData);
            $('.fixed-table-footerButtons').remove();
            if (that.rowData.length > 0) {
                that.setTableFooter();
            }
            if (that.selectedRows.length > 0) {
                $table.bootstrapTable('checkBy', {field: 'id', values: that.selectedRows});
            }
            if (that.isFirstLoad) {
                $table.bootstrapTable('hideLoading');
                that.isFirstLoad = false;
            }
        });
    }

    setFooterCheckAllButton() {
        const that = this;
        if (that.isCurrentPageAllSelected()) {
            $('.fixed-table-footerButtons .checkAll').prop('checked', true);
        } else {
            $('.fixed-table-footerButtons .checkAll').prop('checked', false);
        }
    }

    isCurrentPageAllSelected() {
        let curSelectNum : any = 0;
        const curPageData = $('#table-flavor-summary').bootstrapTable('getData', {useCurrentPage: true});
        curSelectNum = _.filter(curPageData, function (data) {
            return (data['0'] !== undefined) && (data['0'] === true);
        }).length;
        if ((curPageData.length !== 0) && (curSelectNum === curPageData.length)) {
            return true;
        } else {
            return false;
        }
    }

    ngOnDestroy() {
        this.stopReloadInterval();
    }

    startReloadInterval() {
        const that = this;
        if (that.timerHandle === undefined) {
            that.timerHandle = setInterval(function(){
                that.refreshFlavorList();
            }, 10000);
        }
    }

    stopReloadInterval() {
        clearTimeout(this.timerHandle);
        this.timerHandle = undefined;
    }
/*
  isSelectAll:boolean = false;
  check:Array<any>;
  itemList:Array<any>;
  selectItems:Array<any>;

  constructor(private flavorService:FlavorService, private router:Router) {

  }

  ngOnInit() {
    this.selectItems = [];
    this.getFlavors();
  }

  getFlavors() {
    this.flavorService.getFlavors().then((res:any) => {
      this.itemList = res;
      for(let item of this.itemList){
        item['checked'] = false;
      }
    });
  }
  selectAll(isSelectAll:any,items:any) {
    isSelectAll = !isSelectAll;
    if(isSelectAll) {
      for(let item of items){
        item['checked'] = true;
      }

      this.selectItems = items;

    } else {
      for(let item of items){
        item['checked'] = false;
      }
      this.selectItems = [];
    }
  }

  selectOne(selectItem:any) {
    selectItem.checked = !selectItem.checked;
    if(selectItem.checked) {
       this.selectItems.push(selectItem);
    } else {
      this.selectItems = _.without(this.selectItems,selectItem);
    }
  }

  deleteSelected() {
    let that=this;
    for(let item of this.selectItems) {
      that.flavorService.deleteFlavor(item['id'])
        .then(() => {
         that.getFlavors();
        });
    }
  }

  delFlavor(flavor : any) {
    this.tryDelFlavor = flavor;
  }*/
}

