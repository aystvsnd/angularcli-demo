import { NgModule } from '@angular/core';
import {SharedModule} from '../shared/shared.module';
import { routing } from './flavor.routes';
import { FlavorComponent } from './flavor.component';
import { AddFlavorComponent } from './addFlavor.component';

import { FlavorService } from  './flavor.service';

@NgModule({
  imports: [SharedModule, routing],
  declarations: [FlavorComponent, AddFlavorComponent],
  providers: [FlavorService],
})

export class FlavorModule { }
