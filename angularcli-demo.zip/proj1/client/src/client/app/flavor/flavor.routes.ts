
import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AddFlavorComponent} from './addFlavor.component';
import {FlavorComponent} from './flavor.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'summary',
        component: FlavorComponent
      },
      {
        path: 'flavorCreate',
        component: AddFlavorComponent
      }
    ]
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);

