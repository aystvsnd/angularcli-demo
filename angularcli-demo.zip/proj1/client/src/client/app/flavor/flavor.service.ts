import { Injectable } from '@angular/core';
import { Response} from '@angular/http';

import { appConfig } from '../app.config';

import {ApiResourceService as Http} from '../apiResource.service';

@Injectable()
export class FlavorService {
  constructor(public http: Http) {
  }

  getFlavors() {
    return  this.http.get(`${appConfig.vrmServiceUrl}flavors`)
      .toPromise()
      .then((res: Response) => {return res.json().flavors; })
      .catch(this.handleError);
  }

  addFlavor(data: any) {
    return this.http.post(`${appConfig.vrmServiceUrl}flavors`, data)
      .toPromise()
      .then((res: Response) => {return res.json(); })
      .catch(this.handleError);
  }

  deleteFlavor(id: any) {
    return this.http.delete(`${appConfig.vrmServiceUrl}flavors/${id}`)
      .toPromise()
      .catch(this.handleError);
  }

  publishFlavor(id: any) {
    return this.http.put(`${appConfig.vrmServiceUrl}flavors/${id}`)
      .toPromise()
      .catch(this.handleError);
  }

  allpublish(data: any) {
    return this.http.put(`${appConfig.vrmServiceUrl}flavors`, data)
      .toPromise()
      .catch(this.handleError);
  }
  private handleError(error : any) {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}
