export * from './flavor.component';
export * from './addFlavor.component';
export * from './flavor.module';

