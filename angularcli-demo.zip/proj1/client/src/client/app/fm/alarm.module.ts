import { NgModule } from '@angular/core';

import { AlarmService } from './alarm.service';
//import { AlarmExportComponent } from './alarm-export.component';
import { UserService } from '../system-manage/user-security/user-manage/user.service';
//import {TrendChartComponent} from './trend-chart.component';
import {PmService} from '../pm/pm.service';

import {CurrentAlarmModule} from './currentAlarm/current-alarm.module';
import {HistoryAlarmModule} from './historyAlarm/history-alarm.module';
import {NotificationModule} from './notification/notification.module';

@NgModule({
  imports: [CurrentAlarmModule, HistoryAlarmModule, NotificationModule],
  //declarations: [AlarmExportComponent, TrendChartComponent],
  providers: [AlarmService, UserService, PmService],
  //exports: [AlarmExportComponent, TrendChartComponent]
})

export class AlarmModule {
}
