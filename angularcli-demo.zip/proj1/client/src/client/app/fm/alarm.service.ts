/**
 * Created by root on 7/15/16.
 */
import {Injectable} from '@angular/core';
import {ApiResourceService as Http} from '../apiResource.service';
import {Response} from '@angular/http';
import {TranslateService} from '@ngx-translate/core';
import {StorageService} from '../storage.service';

@Injectable()
export class AlarmService {
  currentPage: any = 1;

  curAlarmPageInfo: any = {};
  hisAlarmPageInfo: any = {};
  lang: string;
  curHiddenFlag = false;
  hisHiddenFlag = false;

  constructor(public http: Http, private translate: TranslateService, private storageService: StorageService) {

    if (this.storageService.getCurrentLang() !== undefined) {
      this.lang = this.storageService.getCurrentLang();
    } else {
      this.lang = this.translate.getBrowserLang();
    }

  }

  msec2days(value: number) {
    const seconds: number = parseInt(value / 1000);
    const days: number = parseInt(seconds / (60 * 60 * 24));
    const hours: number = parseInt((seconds - (days * 60 * 60 * 24)) / (60 * 60));
    const minutes: number = parseInt((seconds - (days * 60 * 60 * 24) - (hours * 60 * 60)) / 60);
    const second: number = parseInt((seconds - (days * 60 * 60 * 24) - (hours * 60 * 60) - (minutes * 60)));

    if (days === 0) {
      if (hours === 0) {
        return minutes + this.translate.instant('fm.mins') + second + this.translate.instant('fm.seconds');
      }
      return hours + this.translate.instant('fm.hours') +
        minutes + this.translate.instant('fm.mins') +
        second + this.translate.instant('fm.seconds');
    }

    return days + this.translate.instant('fm.days') +
      hours + this.translate.instant('fm.hours') +
      minutes + this.translate.instant('fm.mins') +
      second + this.translate.instant('fm.seconds');

  }

  calcComfirmTime(startTime: Date, endTime: Date) {
    let start = new Date(startTime).getTime();
    let end = new Date(endTime).getTime();
    start = start;
    end = end;
    if (isNaN(start) || isNaN(end)) {
      return '-';
    } else {
      return this.msec2days(end - start);
    }

  }


  downloadAlarms(url: string) {
    return this.http.get(url).toPromise().then((res: Response) => {
      return res;
    });
  }


  postAlarmComfirmInfo(alarmConfirm: any) {
    return this.http.put('/api/v1.0/fm/alarmConfirms', alarmConfirm).toPromise().then((res: Response) => {
      return res;
    });
  }

  //for current alarm detail
  getCurrentAlarmsDetailById(id: any) {
    return this.http.get('/api/v1.0/fm/alarms/' + id).toPromise().then((res: Response) => {
      return res.json();
    });
  }

  getHistoryAlarmsDetailById(id: any) {
    return this.http.get('/api/v1.0/fm/history_alarms/' + id).toPromise().then((res: Response) => {
      return res.json();
    });
  }

  getCurrentAlarmsDetail(currentAlarmLinks: Array<any>) {

    const promiseList: Array<any> = [];
    const AlarmDetails: Array<any> = [];
    for (const link of currentAlarmLinks) {
      promiseList.push(this.http.get(link).toPromise());
    }
    return Promise.all(promiseList).then((res: any) => {
      for (const alarmDetail of res) {
        AlarmDetails.push(alarmDetail.json());
      }
      return Promise.resolve(AlarmDetails);
    });

  }

  serverTimeToLocalTime(inputIntTime: any) {
    if (inputIntTime === '') {
      return '';
    }
    let localTime = '';
    inputIntTime = new Date(inputIntTime).getTime();
    const offset: number = (new Date()).getTimezoneOffset();
    localTime = (new Date(inputIntTime - offset * 60000)).toISOString();
    localTime = localTime.substr(0, localTime.lastIndexOf('.'));
    localTime = localTime.replace('T', ' ');
    return localTime;
  }


  deleteAlarm(alarmId: any) {
    const url = '/api/v1.0/fm/alarms/';
    return this.http.delete(url + alarmId).toPromise().then((res: Response) => {
      return res;
    });
  }

  deleteCurrentAlarm(alarmId: any) {
    return this.http.delete(alarmId).toPromise().then((res: any) => {
      res = res;
    });
  }


  getAlarmsDetail(AlarmLinks: Array<any>) {

    const promiseList: Array<any> = [];
    const AlarmDetails: Array<any> = [];
    for (const link of AlarmLinks) {
      promiseList.push(this.http.get(link).toPromise());
    }
    return Promise.all(promiseList).then((res: any) => {
      for (const alarmDetail of res) {

        AlarmDetails.push(alarmDetail.json());
      }
      return Promise.resolve(AlarmDetails);
    });
  }

  getHistoryAlarmTimeType(historyAlarmType: any, historyAlarmPeriod: any) {


    let phalarmTimeType = '';

    if (historyAlarmPeriod !== 'ALL' && (historyAlarmType === this.translate.instant('fm.alarmTime'))) {
      phalarmTimeType = 'occurTime';
    }

    if (historyAlarmPeriod !== 'ALL' && (historyAlarmType === this.translate.instant('fm.recoverTime'))) {
      phalarmTimeType = 'restoreTime';
    }

    return phalarmTimeType;
  }

  getHistoryAlarmTime(historyAlarmPeriod: any, absoluteTimeStart: any, absoluteTimeEnd: any) {
    const time = {
      beginTime: '',
      endTime: ''
    };
    const periodTimeStamp: any = this.getPeriodTimeStamp(historyAlarmPeriod, absoluteTimeStart, absoluteTimeEnd);
    time.beginTime = periodTimeStamp.begin === 'ALL' ? '' : periodTimeStamp.begin;
    time.endTime = periodTimeStamp.end === 'ALL' ? '' : periodTimeStamp.end;
    return time;
  }

  getHistoryAlarmsUrlParamPart(historyAlarmType: any, historyAlarmPeriod: any, absoluteTimeStart: any, absoluteTimeEnd: any) {
    const that = this;
    const periodTimeStamp: any = that.getPeriodTimeStamp(historyAlarmPeriod, absoluteTimeStart, absoluteTimeEnd);


    const phbeginTime: string = periodTimeStamp.begin === 'ALL' ? '' : 'beginTime=' + periodTimeStamp.begin;
    const phendTime: string = periodTimeStamp.end === 'ALL' ? '' : '&endTime=' + periodTimeStamp.end;
    const phalarmTimeType: string = periodTimeStamp.begin === 'ALL' ? '' : '&alarmTimeType=' +
      this.getHistoryAlarmTimeType(historyAlarmType, historyAlarmPeriod);
    //let phalarmTimeType:string = periodTimeStamp.begin === 'ALL' ? '' : '&alarmTimeType=' + AlarmTypeTransfer[historyAlarmType];

    const url = phbeginTime + phendTime + phalarmTimeType;

    return url;
  }

  getAlarmConfirmMsg(alarmId: any) {
    return this.http.get('/api/v1.0/fm/alarmConfirm/' + alarmId).toPromise().then((res: Response) => {
      return res.json();
    });
  }


  // history alarm time
  getAlarmTimePeriods(period: any) {

    let TimeIterval: any;

    if (period === this.translate.instant('fm.oneHour')) {
      TimeIterval = 60 * 60;
    } else if (period === this.translate.instant('fm.oneDay')) {
      TimeIterval = 24 * 60 * 60;
    } else if (period === this.translate.instant('fm.oneWeek')) {
      TimeIterval = 7 * 24 * 60 * 60;
    } else if (period === this.translate.instant('fm.oneMonth')) {
      TimeIterval = 30 * 24 * 60 * 60;
    }

    return TimeIterval;

  }


  convertDateToUnixTimeStamp(date: any) {
    return Date.parse(new Date(date)) / 1000;
    //return Date.parse((new Date(date)).toDateString()) / 1000;
  }

  getCurrentTimeEnd() {

    const currentTimeEnd = new Date();
    currentTimeEnd.setHours(23);
    currentTimeEnd.setMinutes(59);
    currentTimeEnd.setSeconds(59);

    return currentTimeEnd;

  }

  getCurrentDayTimeStamp() {
    const timeStamp = {
      'begin': 0,
      'end': 0
    };
    const currentTimeEnd = this.getCurrentTimeEnd();

    const currentTimeBegin = new Date(currentTimeEnd.getFullYear(),
      currentTimeEnd.getMonth(), currentTimeEnd.getDate());

    timeStamp.begin = this.convertDateToUnixTimeStamp(currentTimeBegin);
    timeStamp.end = this.convertDateToUnixTimeStamp(currentTimeEnd);
    return timeStamp;
  }

  getTimeStampByInterval(interval: any) {
    const timeStamp = {
      'begin': 0,
      'end': 0
    };
    const currentTimeEnd = new Date();
    timeStamp.end = this.convertDateToUnixTimeStamp(currentTimeEnd);
    timeStamp.begin = this.convertDateToUnixTimeStamp(currentTimeEnd) - interval;
    return timeStamp;
  }

  getPeriodTimeStamp(historyAlarmPeriod: string, absoluteTimeStart: any, absoluteTimeEnd: any) {
    let timeStamp = {};
    if (historyAlarmPeriod === 'ALL') {
      timeStamp.begin = 'ALL';
      timeStamp.end = 'ALL';
    } else if (historyAlarmPeriod === this.translate.instant('fm.currentDay')) {
      timeStamp = this.getCurrentDayTimeStamp();
    } else if (historyAlarmPeriod === this.translate.instant('fm.customTime')) {
      timeStamp.begin = this.convertDateToUnixTimeStamp(absoluteTimeStart);
      timeStamp.end = this.convertDateToUnixTimeStamp(absoluteTimeEnd);
    } else { //interval
      let interval: any;
      interval = this.getAlarmTimePeriods(historyAlarmPeriod);
      timeStamp = this.getTimeStampByInterval(interval);
    }
    return timeStamp;
  }

  putChangedAlarmThreshold(url: string, changedData: any) {
    const that = this;
    return that.http.put(url, changedData).toPromise().then((res: any) => {
      res = res;
    });
  }

  deleteAlarmCfg(url: string) {
    return this.http.delete(url).toPromise().then((res: any) => {
      res = res;
    });
  }

  snmpConfig() {
    return this.http.get('/api/v1.0/fm/snmp/configs').toPromise().then((res: Response) => {
      return res.json();
    });
  }

  deleteTrap(url: string, row) {
    return this.http.delete(url).toPromise().then((res: Response) => {
      return res.ok;
    });
  }

  updateTrapCfg(row) {
    const url = '/api/v1.0/fm/snmp/configs';
    return this.http.post(url, row).toPromise().then((res: Response) => {
      return res;
    });
  }

  getHeartbeatInterval() {
    const url = '/api/v1.0/fm/snmp/configs/heartbeat_interval';
    return this.http.get(url).toPromise().then((res: Response) => {
      return res.json();
    });
  }

  putHeartbeatInterval(url: string, changedData: any) {
    return this.http.post(url, changedData).toPromise().then((res: Response) => {
      //return res.json();
      res = res;
    });
  }

  ObjectToUrl(obj: any) {
    let url = '';
    _.map(obj, function (num, key) {
      if (num !== undefined) {
        url += '&' + key + '=' + num;
      }
    });
    return url;
  }


  getAllConfirmOperators() {
    return this.http.get('/api/v1.0/fm/alarmConfirmOperators').toPromise().then((res: Response) => {
      return res.json();
    });
  }


  /*getRootCauseAlarm(id:any) {
   return this.http.get('/api/v1/RCA/RelatedAlarms/' + id).toPromise().then((res:Response)=> {
   return res.json().faultModel;
   });
   }*/

  getRootCauseAlarm(id: any) {
    return this.http.get('/api/v1/fia/alarmModels?alarmId=' + id).toPromise().then((res: Response) => {
      return res.json();
    });
  }

  getObjectImage(objectType: any) {
    let image = '';
    if (objectType.toLowerCase().indexOf('vm') !== -1) {

      image = 'assets/images/insight/svg/0_VM_line.svg';
    } else if (objectType.toLowerCase().indexOf('host') !== -1) {

      image = 'assets/images/insight/svg/0_host_line.svg';
    } else if (objectType.toLowerCase().indexOf('cloudenv') !== -1) {

      image = 'assets/images/insight/svg/0_cloud-env.svg';
    } else if (objectType.toLowerCase().indexOf('cloud') !== -1) {

      image = 'assets/images/insight/svg/0_cloud-env.svg';
    } else if (objectType.toLowerCase().indexOf('chassis') !== -1) {

      image = 'assets/images/insight/svg/0_chasis.svg';
    } else if (objectType.toLowerCase().indexOf('system') !== -1) {

      image = 'assets/images/insight/svg/alarm_system.svg';
    } else if (objectType.toLowerCase().indexOf('switch') !== -1) {

      image = 'assets/images/insight/svg/alarm_switch.svg';
    } else if (objectType.toLowerCase().indexOf('server') !== -1) {

      image = 'assets/images/insight/svg/alarm_server.svg';
    } else if (objectType.toLowerCase().indexOf('rack') !== -1) {

      image = 'assets/images/insight/svg/alarm_rack.svg';
    } else if (objectType.toLowerCase().indexOf('router') !== -1) {

      image = 'assets/images/insight/svg/alarm_router.svg';
    } else if (objectType.toLowerCase().indexOf('storage') !== -1) {

      image = 'assets/images/insight/svg/alarm_storage.svg';
    } else if (objectType.toLowerCase().indexOf('volume') !== -1) {

      image = 'assets/images/insight/svg/alarm_volume.svg';
    }
    return image;
  }

  alarmImgChioce(alarmLevel: any, alarmImact: any) {
    if (alarmLevel === 'critical' || alarmLevel === 'Critical') {
      return {
        'health': 'assets/images/insight/svg/monitorObject/4_health_min.svg',
        'risk': 'assets/images/insight/svg/monitorObject/4_risk_min.svg',
        'efficiency': 'assets/images/insight/svg/monitorObject/4_efficiency_min.svg'
      }[alarmImact];
    }
    if (alarmLevel === 'major' || alarmLevel === 'Major') {
      return {
        'health': 'assets/images/insight/svg/monitorObject/3_health_min.svg',
        'risk': 'assets/images/insight/svg/monitorObject/3_risk_min.svg',
        'efficiency': 'assets/images/insight/svg/monitorObject/3_efficiency_min.svg'
      }[alarmImact];
    }
    if (alarmLevel === 'minor' || alarmLevel === 'Minor') {
      return {
        'health': 'assets/images/insight/svg/monitorObject/2_health_min.svg',
        'risk': 'assets/images/insight/svg/monitorObject/2_risk_min.svg',
        'efficiency': 'assets/images/insight/svg/monitorObject/2_efficiency_min.svg'
      }[alarmImact];
    }
    if (alarmLevel === 'warning' || alarmLevel === 'Warning') {
      return {
        'health': 'assets/images/insight/svg/monitorObject/1_health_min.svg',
        'risk': 'assets/images/insight/svg/monitorObject/1_risk_min.svg',
        'efficiency': 'assets/images/insight/svg/monitorObject/1_efficiency_min.svg'
      }[alarmImact];
    }
  }

  getPopstate() {
    window.addEventListener('popstate', function (e) {
      e.stopPropagation();
      window.localStorage.setItem('historyState', e.state);
    });
  }

  setModalCenter(querySelector: any) {
    $(querySelector).css({
      'margin-top': function () {
        return (window.innerHeight - $(this).height()) / 2;
      }
    });
  }

  setDelModalCenter(querySelector: any) {
    $(querySelector).css({
      'margin-top': function () {
        const modalHeight = $(this).height() < 240 ? 240 : $(this).height();
        return (window.innerHeight - modalHeight) / 2;
      }
    });
  }

}
