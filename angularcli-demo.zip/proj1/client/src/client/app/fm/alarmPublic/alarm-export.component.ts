import {Component, Input, OnChanges,OnInit} from '@angular/core';
import { AlarmService } from '../alarm.service';
import {TranslateService} from '@ngx-translate/core';
import { appConfig } from '../../app.config';

@Component({
  moduleId: module.id,
  selector: 'alarm-export',
  template: `
<div [id]="id" class="modal fade"  tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content ky-modal-content export-modal-content">
      <div class="modal-header ky-modal-header">
      <button type="button" class="close ky-modal-close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title ky-modal-title" >{{title}}</h4>
      </div>
        <form role="form" #export="ngForm" novalidate>

        <div class="modal-body ky-modal-body" style="position: relative">

          <!--<div style="position: absolute;top:40px;left:139px">-->
            <!--<label>导出文件: </label>-->
            <!--<ky-radio-group [(ngModel)]="chosenOption" [ngModelOptions]="{standalone:true}">-->
            <!--<ky-radio-button *ngFor="let o of options" [value]="o.value" style="margin-bottom: 3px">-->
              <!--{{o.label}}-->
            <!--</ky-radio-button>-->
            <!--</ky-radio-group>-->
          <!--</div>-->
         <div class="form-group" style="margin-top: 25px">
            <label class="form-group-left">{{'fm.exportFile' | translate}}</label>
            <ky-radio-group [(ngModel)]="chosenOption" [ngModelOptions]="{standalone:true}">
            <ky-radio-button *ngFor="let o of options" [value]="o.value" style="margin-bottom: 3px">
              {{o.label}}
            </ky-radio-button>
            </ky-radio-group>
         </div>
         <div class="form-group" style="margin-top: 20px;margin-bottom: 25px;">
             <label class="form-group-left">{{'fm.exportFileName' | translate}}</label>
             <input type="text" class="number-input form-group-right" [(ngModel)]="filename" name="filename" required/>
             <span >.csv</span>
         </div>
         </div>

          <!--<div style="position: absolute;top:70px;left:120px">-->
            <!--<label style="display: inline;" class="errColorRed">*</label>-->
            <!--<label style="display: inline;">导出文件名: </label>-->
            <!--<input type="text" class="number-input" [(ngModel)]="filename" name="filename" required/>-->
            <!--<span >.csv</span>-->
          <!--</div>-->

        </form>
        <div class="modal-footer ky-modal-footer">
          <ky-button [disabled]="!export.form.valid" [type]="'normal'"
            (click)="confirmButtonDown()" data-dismiss="modal">{{'fm.export' | translate}}</ky-button>
          <ky-button [type]="'cancel'" data-dismiss="modal">{{'Cancel' | translate}}</ky-button>
        </div>

    </div>
  </div>
</div>`,
  styleUrls: ['../currentAlarm/current-alarm.component.css']
})

export class AlarmExportComponent implements OnChanges,OnInit {
  @Input() title = '';
  @Input() id: string;

  @Input() currentPage: any;
  @Input() allPage: any;
  @Input() frontUrl: string;
  @Input() exportDate: Date;

  options = [{
    label: this.translate.instant('fm.ALL'),
    value: 'ALL'
  }, {
    label: this.translate.instant('fm.curPage'),
    value: 'CurPage'
  }];
  curDate = new Date();
  filename: any = this.genFileNameWithDateAndTime(this.curDate);
  chosenOption = 'ALL';
  startPage = 1;
  endPage = 1;

  constructor(private alarmservice: AlarmService, private translate: TranslateService) {

  }


  genFileNameWithDateAndTime(CurrenTime: any) {
    const year = CurrenTime.getFullYear();
    const month = CurrenTime.getMonth() + 1;
    const day = CurrenTime.getDate();
    const hour = CurrenTime.getHours();
    const minute = CurrenTime.getMinutes();
    const second = CurrenTime.getSeconds();
    return year + '-' + month + '-' + day + '_' + hour + ':' + minute + ':' + second;
  }

  confirmButtonDown() {
    const startPage = this.chosenOption === 'ALL' ? 1 : this.currentPage;
    const endPage = this.chosenOption === 'ALL' ? this.allPage : this.currentPage;
    const filename = this.filename;
    const timeZoneOffset = (new Date()).getTimezoneOffset();
    const url = this.frontUrl + `&startPage=${startPage}&endPage=${endPage}&name=${filename}&timeZoneOffset=${timeZoneOffset}`;

    const that = this;
    this.alarmservice.downloadAlarms(url).then((res: any) => {
      const filePath = res._body.split('/').pop();
      that.downloadFile(this.filename + '.csv', filePath);
    });

  }

  ngOnChanges() {
    this.curDate = this.exportDate ? this.exportDate : new Date();
    this.filename = this.genFileNameWithDateAndTime(this.curDate);
  }


  ngOnInit() {
    this.alarmservice.setModalCenter('.export-modal-content');
  }

  downloadFile(fileName: any, filePath: any) {
      const aLink = document.createElement('a');
      // var blob = new Blob([content]);
      //                var evt = document.createEvent('HTMLEvents');
      aLink.download = fileName;
      aLink.href = `${appConfig.fmServiceUrl}files/${filePath}`; //URL.createObjectURL(blob);
      const evt = document.createEvent('MouseEvents');
      evt.initMouseEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
      aLink.dispatchEvent(evt);
    }

  //ngOnInit() {
  //}

}

export const ALARM_EXPORT_DIRECTIVES = [AlarmExportComponent];

