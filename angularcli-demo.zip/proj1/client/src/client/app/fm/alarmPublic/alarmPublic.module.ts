import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { SharedModule } from '../../shared/index';
import { KyLibModule } from '../../shared/kylib/index';

import { AlarmService } from '../alarm.service';
import {TrendChartComponent} from './trend-chart.component';
import { AlarmExportComponent } from './alarm-export.component';
import {PmService} from '../../pm/pm.service';

@NgModule({
  imports: [CommonModule, FormsModule, HttpModule, SharedModule, KyLibModule],
  declarations: [TrendChartComponent, AlarmExportComponent],
  providers: [AlarmService, PmService],
  exports: [AlarmExportComponent, TrendChartComponent]
})

export class AlarmPublicModule {
}

