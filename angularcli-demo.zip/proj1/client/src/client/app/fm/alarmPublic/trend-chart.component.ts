import {Component, Input, AfterViewInit} from '@angular/core';
import {PmService} from '../../pm/pm.service';
import {TranslateService} from '@ngx-translate/core';
import {Subject} from 'rxjs/Subject';

@Component({
  moduleId: module.id,
  selector: 'trend-chart',
  templateUrl: 'trend-chart.component.html',
})

export class TrendChartComponent implements AfterViewInit {
  @Input() trendChartObserver: Subject<any>;
  uri: string;
  counterName: string;

  timeRanges: Array = [
    {
      value: 'sixhours',
      display: this.translate.instant('pm.dynamicThreshold.last6hour'),
    }, {
      value: 'day',
      display: this.translate.instant('pm.dynamicThreshold.last1day'),
    }
    //}, {
    //  value: 'month',
    //  display: this.translate.instant('pm.dynamicThreshold.last1week'),
    //}
  ];
  timeRange: any = this.timeRanges[0];

  chartOption: any = {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'line',
        lineStyle: {
          color: '#1483cc',
          width: 1,
          type: 'solid'
        }
      },
      formatter: (params, ticket, callback) => {
        const name = this.pmService.serverTimeToLocalTime(new Date(params[0].name));
        let currentThr = (params[1].data.value !== '') ? params[1].data.value : params[2].data.value;
        currentThr = (currentThr === '') ? '-' : currentThr;
        if (params[1].data.value !== '') {
          return [
            `<div>${name}</div>`,
            `<div style="height: 20px;">
            <span style="display:inline-block;border-radius:10px;width:10px;height:10px;background-color:#feb731"></span>
            <span style="display:inline-block;margin-left:6px;">${params[1].seriesName + ':' + currentThr}</span>
          </div>`,
          ].join('');
        } else {
          return [
            `<div>${name}</div>`,
            `<div style="height: 20px;">
            <span style="display:inline-block;border-radius:10px;width:10px;height:10px;background-color:#00abff"></span>
            <span style="display:inline-block;margin-left:6px;">${params[1].seriesName + ':' + currentThr}</span>
          </div>`,
          ].join('');
        }
      }
    },
    dataZoom: {
      show: true,
      realtime: true,
      height: 18,
      y: 182,
      start: 0,
      end: 100
    },
    grid: {
      borderWidth: 1,
      borderColor: '#e6e6e6',
      x: 45,
      y: 5,
      x2: 15,
      y2: 50,
      width: $('#lineChart').width() - 15 - 45,
      height: 145
    },
    calculable: true,
    xAxis: [{
      type: 'category',
      axisLabel: {
        textStyle: {
          fontSize: 11,
          color: '#7c868d',
        },
        formatter: function (value) {
          if (value !== '') return value.split(' ')[1];
        }
      },
      axisLine: {
        lineStyle: {
          color: '#e6e6e6',
        }
      },
      axisTick: {
        show: false,
      },
      data: [],
    }],
    yAxis: [{
      splitNumber: 5,
      axisLine: {
        show: false,
      },
      axisTick: {
        show: false,
      },
      axisLabel: {
        textStyle: {
          fontSize: 11,
          color: '#7c868d',
        },
        formatter: (value) => {
          if (value >= Math.pow(10, 3)) {
            return this.pmService.toSI(value);
          } else {
            return value;
          }
        }
      },
    }],
    series: []
  };

  constructor(private pmService: PmService, private translate: TranslateService) {
  }

  ngAfterViewInit() {
    if (this.trendChartObserver) {
      this.trendChartObserver.subscribe((data) => {
        console.log(encodeURI(encodeURI(data.objectId)));
        if (data.loadChart) {
          this.uri = this.pmService.pmServiceUrl + 'performanceTrend/' + data.cloudEnvId + '/' + encodeURIComponent(encodeURIComponent(data.objectId)) + '/' + data.sn
            + '?timestamp=' + data.timeStamp;
          this.getChartData();
        }
      });
    }
  }

  selectTimeRange() {
    this.getChartData();
  }

  getChartData() {
    this.pmService.getTrendData(this.uri + '&timerange=' + this.timeRange.value).then((res) => {
      this.setChartOption(res);
      this.createCharts();
    });
  }

  setChartOption(data: any) {
    const currentName: string = this.pmService.lang === 'zh' ? data.counter.name_cn : data.counter.name_us;
    this.counterName = currentName + '(' + data.counter.unit + ')';
    data.records = data.records.reverse();
    const that = this;
    this.chartOption.xAxis[0].data = _.map(_.pluck(data.records, 'timeStamp'), function (i) {
      return that.pmService.serverTimeToLocalTimeAccurateToMin(new Date(i).getTime() + 60 * 1000, 5);
    });
    const tmp = [];
    tmp.push(this.getHighSeries(data.records), this.getOutSideSeries(data.records),
      this.getInsideSeries(data.records), this.getLowSeries(data.records));
    this.chartOption.series = tmp;
  }

  getOutSideSeries(records: any) {
    const seriesData = new Array(records.length);
    for (let i = 0; i < records.length; i++) {
      //if (seriesData[i]) continue;
      const now = records[i];
      const curGreaterThanHigh: boolean = Number(now.pd) > Number(now.high);
      const curLessThanLow: boolean = Number(now.pd) < Number(now.low);
      if (curGreaterThanHigh || curLessThanLow) {
        seriesData[i] = now.pd;
        if (i >= 1) {
          const pre = records[i - 1];
          if (pre.pd !== '') seriesData[i - 1] = pre.pd;
        }
        if ((i + 1) < records.length) {
          const next = records[i + 1];
          if (next.pd !== '') seriesData[i + 1] = next.pd;
          //if ((next.pd !== '') && (curGreaterThanHigh && (Number(next.pd) <= Number(next.high)) ||
          //  curLessThanLow && (Number(next.pd) >= Number(next.low)))) {
          //  seriesData[i + 1] = next.pd;
          //}
        }
      }
    }
    return {
      name: (this.counterName.split('('))[0],
      type: 'line',
      smooth: true,
      showSymbol: false,
      data: this.getLineData(seriesData, 'emptyCircle'),
      itemStyle: {
        normal: {
          lineStyle: {
            color: '#feb731',
            width: 2,
          },
        }
      }
    };
  }

  getInsideSeries(records: any) {
    const seriesData = new Array(records.length);
    for (let i = 0; i < records.length; i++) {
      if (seriesData[i]) continue;
      const now = records[i];
      if ((Number(now.pd) <= Number(now.high)) && (Number(now.pd) >= Number(now.low))) {
        seriesData[i] = now.pd;
      }
    }
    return {
      name: (this.counterName.split('('))[0],
      type: 'line',
      smooth: true,
      showSymbol: false,
      data: this.getLineData(seriesData, 'emptyCircle'),
      itemStyle: {
        normal: {
          lineStyle: {
            color: '#00abff',
            width: 2,
          },
        }
      }
    };
  }

  getHighSeries(records: any) {
    return {
      name: this.translate.instant('pm.dynamicThreshold.supperThreshold'),
      type: 'line',
      smooth: true,
      showSymbol: false,
      data: this.getLineData(_.pluck(records, 'high'), 'none'),
      itemStyle: {
        normal: {
          lineStyle: {
            color: 'rgba(0,171,255,0.2)',
            width: 1,
          },
          areaStyle: {
            color: 'rgba(0,171,255,0.2)',
            type: 'default',
          }
        }
      }
    };
  }

  getLowSeries(records: any) {
    return {
      name: this.translate.instant('pm.dynamicThreshold.lowerThreshold'),
      type: 'line',
      smooth: true,
      showSymbol: false,
      data: this.getLineData(_.pluck(records, 'low'), 'none'),
      itemStyle: {
        normal: {
          lineStyle: {
            color: 'rgba(0,171,255,0.2)',
            width: 1,
          },
          areaStyle: {
            color: 'white',
            type: 'default',
          }
        }
      }
    };
  }

  getLineData(data: any, symbol: string) {
    const tmp = [];
    _.each(data, function (item) {
      const one = {
        value: item === undefined ? '' : item,
        symbol: symbol
      };
      tmp.push(one);
    });
    return tmp;
  }

  createCharts() {
    const dom: any = document.getElementById('lineChart');
    const myChart: any = echarts.init(dom, 'macarons');
    myChart.setOption(this.chartOption);
  }

  close() {
    this.timeRange = this.timeRanges[0];
  }

  getDisplayCounterName() {
    return (this.counterName && this.counterName.length > 20) ? (this.counterName.substring(0, 25) + '...') : this.counterName;
  }
}
