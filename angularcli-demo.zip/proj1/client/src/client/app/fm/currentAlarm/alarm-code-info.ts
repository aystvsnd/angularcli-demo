export class AlarmCodeInfo {
  public static  alarmCodeInfoHash = {
    '3305115652'     :      {'AlarmName': 'control is not available',
      'AlarmReasonChinese': '1）控制节点重启或关机；',
      'AlarmReasonEnglish': '1） controller node is reboot or shutdown',
      'SuggestionChinese': '1. 检查主机是否运行，如果没有，则使其上电运行，观察告警是否恢复。 \
      是->结束处理 \
  否->转2 \
  2. 检查主机与控制节点的连接，使其连接正常，观察告警是否恢复。 \
是->结束处理 \
  否->转3 \
  3.请寻求更高一级的设备维护支持;。',
  'SuggestionEnglish': '1. check host run state; \
  2. Check Message broker run state',
  'SystemInpactChinese': '控制节点不可用',
  'SystemInpactEnglish': 'controller node is unavailable'},
'3305115653'     :      {'AlarmName': 'Unavailable Services on the Computing Node',
  'AlarmReasonChinese': '1）计算节点重启或关机； \
  2）计算节点与控制节点通信断；',
  'AlarmReasonEnglish': '1. The computing node is restarted or shut down. \
  2. Communication between the computing node and the control node is interrupted.',
  'SuggestionChinese': '1. 找到计算节点所在的物理机，观察物理机是否上电。\
  是->步骤3 \
  否->步骤2 \
  2. 使物理机上电运行，观察告警是否恢复。 \
是->结束处理\
  否->步骤3\
  3. 控制节点执行nova hypervisor-list以及nova hypervisor-show命令查到服务状态为down的计算节点的IP地址，再执行ping 计算节点IP命令来检查物理机与控制节点的网络连接，使其连接正常，观察告警是否恢复。\
是->结束处理\
  否->步骤4\
  4. 联系中兴通讯技术支持。',
  'SuggestionEnglish': '1. Find the physical machine where the computing node is \l\
  ocated and check whether the physical machine is powered on.\
  Yes -> Step 3.\
  No -> Step 2.\
  2. Power on the physical machine and check whether the alarm is cleared.\
    Yes -> End.\
    No -> Step 3.\
  3. Run the nova hypervisor-list and nova hypervisor-show commands on the control \
  node to find the IP address of the computing node whose service status is down, and \
  further run the ping IP address of the computing node command to check whether the network \
  connection between the physical machine and the control node is good. Verify that the connection\
   is good and check whether the alarm is cleared.\
    Yes -> End.\
    No -> Step 4.\
  4. Contact ZTE technical support.',
  'SystemInpactChinese': '系统不能管理该计算节点。',
    'SystemInpactEnglish': 'The system fails to manage this computing node.'},
'3305115654'     :      {'AlarmName': 'Virtual Machine in Unsynchronous Status',
  'AlarmReasonChinese': '1）虚拟机状态异常',
  'AlarmReasonEnglish': '1. The status of the virtual machine in libvirt is not same to ' +
  'the state in nova db. Primary to the state: execute \'virsh suspend\' ' +
  'in libvirt, but the latest action in nova is not \'pause\'.',
  'SuggestionChinese': '1. 控制节点执行命令nova show 虚拟机uuid，查找到虚拟机的OS-EXT-SRV-ATTR: instance_name。\
  2. 到该虚拟机所在的计算节点执行命令virsh resume 虚拟机名称 （即步骤1.中查到的OS-EXT-SRV-ATTR: instance_name），再执行命令virsh list -all查看虚拟机的状态是不是paused。\
是->步骤4\
  否->步骤3\
  3. 等待5分钟，观察告警是否消失。\
是->结束处理\
  否->步骤4\
  4. 联系中兴通讯技术支持。',
  'SuggestionEnglish': '1. Run the nova show uuid of the virtual machine command on the \
  control node and find the OS-EXT-SRV-ATTR: instance_name of the virtual machine.\
  2. Run the virsh resume the name of the virtual machine (that is, OS-EXT-SRV-ATTR: \
  instance_name obtained in step 1.) command on the computing node where the virtual machine \
  is located, and run the virsh list –all command to check whether the status of the virtual machine is paused.\
    Yes -> Step 4.\
  No -> Step 3.\
  3. Wait for five minutes, and check whether the alarm is cleared.\
    Yes -> End.\
    No -> Step 4.\
  4. Contact ZTE technical support.',
  'SystemInpactChinese': '虚拟机当前状态与用户期望状态不一致。',
    'SystemInpactEnglish': 'The current status of the virtual machine is different from expected.'},
'3305115655'     :      {'AlarmName': 'Unknown Virtual Machine Status',
  'AlarmReasonChinese': '1. 无法获取该主机上的虚拟机运行状态',
  'AlarmReasonEnglish': '1. The operation status of the virtual machines on a physical machine is not obtained.',
  'SuggestionChinese': '1. 登录该物理机节点，使用命令systemctl status libvirtd.service查看libvirtd服务状态，Active: active (running)表示服务状态正常，否则为不正常。\
  是->步骤4\
  否->步骤2\
  2. 重启libvirtd服务，并观察服务状态是否恢复正常。\
重启libvirtd服务的命令为：systemctl restart libvirtd.service。\
是->步骤3 \
  否->步骤4\
  3. 等待5分钟，观察告警是否消失。\
是->结束处理\
  否->步骤4\
  4. 联系中兴通讯技术支持。',
  'SuggestionEnglish': '1. Log in to the physical machine and use the systemctl status \
  libvirtd.service command to check the status of the libvirtd service: Active: active \
  (running) indicates a proper status, otherwise, it is abnormal.\
  Yes -> Step 4.\
  No -> Step 2.\
  2. Restart the libvirtd service and observe whether the service status is normal. \
  Restart the libvirtd service by using the systemctl restart libvirtd.service command.\
    Yes -> Step 3.\
  No -> Step 4.\
  3. Wait for five minutes, and check whether the alarm is cleared.\
    Yes -> End.\
    No -> Step 4.\
  4. Contact ZTE technical support.',
  'SystemInpactChinese': '系统不能管理该物理机上已经部署的虚拟机，也不能再在该物理机上部署新的虚拟机。',
    'SystemInpactEnglish': 'The system fails to manage the virtual machines that have been deployed ' +
    'on the physical machine and cannot deploy more virtual machines on the physical machine.'},
'3305115656'     :      {'AlarmName': 'High Storage Space Usage on the Image Server',
  'AlarmReasonChinese': '1）镜像服务器镜像存储目录所在文件系统空间使用较多',
  'AlarmReasonEnglish': '1. The space usage of the file system where the image storage directory is located ' +
  'exceeds the preset value, 90% by default.',
  'SuggestionChinese': '1. 根据告警附加信息中上报的门限值，检查用于存储镜像的磁盘空间使用率门限值是否合理，该门限值一般推荐配置为70%~90%之间。\
  是->步骤3\
  否->步骤2\
  2. 修改 /etc/glance/glance-api.conf 中的配置项stroage_usage_threshold，调整门限值，查看告警是否恢复。\
是->结束处理\
  否->步骤3\
  3. 检查是否存在不需要的镜像，并删除这些镜像，查看告警是否恢复。\
是->结束处理\
  否->步骤4\
  4. 根据磁阵厂商提供的操作指导，扩容存储镜像的磁盘存储空间，查看告警是否恢复。\
是->结束处理\
  否->步骤5\
  5. 联系中兴通讯技术支持。',
  'SuggestionEnglish': '1. Check whether the usage threshold preset for \
  the image storage disk space is proper based on the threshold reported in the \
  additional alarm information. This threshold is set to 70%–90%.\
  Yes -> Step 3.\
  No -> Step 2.\
  2. Change the stroage_usage_threshold configuration item in /etc/glance/glance-api.conf and check whether the alarm is cleared.\
    Yes -> End.\
    No -> Step 3.\
  3. Check whether any unnecessary images exist, delete these images if they exist, and check whether the alarm is cleared.\
    Yes -> End.\
    No -> Step 4.\
  4. Expand the space of the disk for storing images in accordance \
  with the operation guide provided by the disk array manufacturer and check whether the alarm is cleared.\
    Yes -> End.\
    No -> Step 5.\
  5. Contact ZTE technical support.',
  'SystemInpactChinese': '可能会导致镜像无法上传。',
    'SystemInpactEnglish': 'Images may fail to be uploaded.'},
'3305115657'     :      {'AlarmName': 'Memory Failure on the Physical Machine',
  'AlarmReasonChinese': '1）主机内存故障',
  'AlarmReasonEnglish': '1. The memory of the physical machine has hardware faults.',
  'SuggestionChinese': '1. 重新拔插内存条并上电，查看告警是否恢复。\
  是->结束处理\
  否->步骤2\
  2. 更换新的内存条，重新上电，查看告警是否恢复。\
是->结束处理\
  否->步骤3\
  3. 更换单板，重新上电，查看告警是否恢复。\
是->结束处理\
  否->步骤4\
  4. 联系中兴通讯技术支持。',
  'SuggestionEnglish': '1. Remove and install the memory card again and check whether the alarm is cleared.\
  Yes -> End.\
    No -> Step 2.\
  2. Replace the faulty memory card with another one, power on the physical machine again, and check whether the alarm is cleared.\
    Yes -> End.\
    No -> Step 3.\
  3. Replace the board, power on the physical machine again, and check whether the alarm is cleared.\
    Yes -> End.\
    No -> Step 4.\
  4. Contact ZTE technical support.',
  'SystemInpactChinese': '物理机内存设备故障，该节点无法正常运行。',
    'SystemInpactEnglish': 'The memory of the physical machine has hardware faults and the node cannot operate properly.'},
'3305115659'     :      {'AlarmName': 'The Ethernet Interface of the Physical Machine Is Down',
  'AlarmReasonChinese': '1）以太网口链接断开；\
  2）以太网口硬件故障；',
  'AlarmReasonEnglish': '1. The connection on the Ethernet interface is broken.\
  2. The Ethernet interface has hardware faults.\
  3. The interface of the switch that is connected to the Ethernet interface is faulty.',
    'SuggestionChinese': '如果是集成交换机模块的刀片服务器\
    1. 使用交换板的命令查看告警网口对应的交换板端口是否是为UP（交换板的命令参见相应型号的交换板使用说明），对应交换板端口与告警网口的速率是否一致。\
是->步骤3\
    否->步骤2\
    2. 根据交换板厂商提供的操作指导，重新配置或者重启交换板，观察告警是否恢复。\
是->结束处理\
    否->步骤3\
    3. 联系中兴通讯技术支持。\
如果是独立的机架式或塔式服务器\
    1. 根据网卡的link灯是否点亮，判断光纤/网线是否连接正常。\
是->步骤3\
    否->步骤2\
    2. 连接好光纤/网线，观察告警是否恢复。\
是->结束处理\
    否->步骤3\
    3. 更换告警以太网口的光模块或者电模块，观察告警是否恢复。\
是->结束处理\
    否->步骤4\
    4. 更换与告警以太网口相连的交换机上的端口的光模块或者电模块，观察告警是否恢复。\
是->结束处理\
    否->步骤5\
    5. 联系中兴通讯技术支持。',
    'SuggestionEnglish': 'For a blade server integrated with a switch module.\
    1. Use the commands of the switch (for these commands, refer to \
    the guidelines for how to use the switch board of the corresponding model) \
    board to check whether the interface of the switch board corresponding to \
    the alarm network interface is UP, and whether the interface of the \
    switch board has the same rate as the alarm network interface.\
      Yes -> Step 3.\
      No -> Step 2.\
      2. Re-configure or restart the switch board in accordance with \
      the operation guide provided by the switch board manufacturer and check whether the alarm is cleared.\
        Yes -> End.\
        No -> Step 3.\
        3. Contact ZTE technical support.\
          For an independent rack or tower server\
        1. Determine whether the optical fiber or network cable is \
        properly connected in accordance with the status of the link indicator for the NIC.\
          Yes -> Step 3.\
        No -> Step 2.\
        2. Connect the optical fiber or network cable and check whether the alarm is cleared.\
          Yes -> End.\
          No -> Step 3.\
        3. Replace the optical module or electrical module of the faulty Ethernet interface and check whether the alarm is cleared.\
          Yes -> End.\
          No -> Step 4.\
        4. Replace the optical module or electrical module of \
        the interface on the switch connected to the faulty \
        Ethernet interface and check whether the alarm is cleared.\
          Yes -> End.\
          No -> Step 5.\
          5. Contact ZTE technical support.',
          'SystemInpactChinese': '该网口不可用，如果没有配置网口备份，则虚拟机网络中断。',
            'SystemInpactEnglish': 'This network interface cannot be used. The network on the virtual machine is broken.'},
'3305115672'     :      {'AlarmName': 'Virtual Machine in kernel failure state',
  'AlarmReasonChinese': '虚拟机内核故障',
  'AlarmReasonEnglish': '1. The kernel of virtual machine report LIFECYCLE_STOPPED event.',
  'SuggestionChinese': '1. 部署带有看门狗的虚拟机，使能狗后，不喂狗，等待5分钟，观察是否有告警和恢复。\
  是->结束处理\
  否->步骤2\
  2. 联系中兴通讯技术支持。',
  'SuggestionEnglish': '1. Boot an instance with watchdog and enable watchdog, \
  but do not feed the watchdog. Wait for five minutes, \
  and check whether the alarm and recovery.\
  Yes -> End.\
    No -> Step 2.\
  2. Contact ZTE technical support.',
  'SystemInpactChinese': '虚机不可用',
    'SystemInpactEnglish': 'Virtual machine is unavailable'},
'3305115673'     :      {'AlarmName': 'Virtual Machine in fault state.',
  'AlarmReasonChinese': '1. 虚拟机因不明原因关闭。',
  'AlarmReasonEnglish': '1. The kernel of virtual machine report LIFECYCLE_STOPPED event.',
  'SuggestionChinese': '1. 在控制节点执行命令：nova reboot <虚拟机uuid>。等待5分钟，观察告警是否消失。\
  是->结束处理\
  否->步骤2\
  2. 联系中兴通讯技术支持。',
  'SuggestionEnglish': '1. Run the command on the controll node: nova boot \
  <uuid>. Wait for five minutes, and check whether the alarm is cleared.\
  Yes -> End.\
    No -> Step 2.\
  2. Contact ZTE technical support.',
  'SystemInpactChinese': '虚机不可用',
    'SystemInpactEnglish': 'Virtual machine is unavailable'},
'88144'     :      {'AlarmName': 'Power on failed due to S5',
  'AlarmReasonChinese': '硬件异常。',
  'AlarmReasonEnglish': 'Hardware is abnormal.',
  'SuggestionChinese': '重新拔出单板，然后重新插入单板，等待单板重新上电。',
  'SuggestionEnglish': '',
  'SystemInpactChinese': '单板不可用',
  'SystemInpactEnglish': 'board is unavailable'},
'88146'     :      {'AlarmName': 'Mcelog detected',
  'AlarmReasonChinese': '检测到MCELog',
  'AlarmReasonEnglish': 'MCELog is  detected.',
  'SuggestionChinese': '重新拔出单板，然后重新插入单板，等待单板重新上电。',
  'SuggestionEnglish': '',
  'SystemInpactChinese': '单板不可用',
  'SystemInpactEnglish': 'board is unavailable'},
'88154'     :      {'AlarmName': 'CPU status error',
  'AlarmReasonChinese': '1. 系统发生灾难性错误，将不能正常运行\
  2. 系统发生可自恢复错误\
  3. 系统发生需操作系统或固件修复的非致命错误\
  4. 系统发生致命错误，需要重启恢复',
  'AlarmReasonEnglish': 'CPU is abnormal, should  be reboot.',
    'SuggestionChinese': '1. 等待10~20分钟, 观察告警是否恢复。\
  Y->处理结束。\
N->2。\
2. 拔出并重新插入单板，等待单板重新上电，观察是否还会出现。\
Y->3。\
N->处理结束。\
3.更换单板，并寻求更高一级的设备维护支持。\
',
  'SuggestionEnglish': '',
    'SystemInpactChinese': 'CPU不可用',
    'SystemInpactEnglish': 'CPU is unavailable'},
'88165'     :      {'AlarmName': 'Board offline',
  'AlarmReasonChinese': '1. 单板没有插入。\
  2. 机框管理板(CMM)与单板之间的通信链路故障。',
  'AlarmReasonEnglish': '',
    'SuggestionChinese': '1. 检查单板是否在位：\
  Y->转2\
  N->转3\
  2. 拔出并重新插入单板，观察告警是否恢复：\
Y->结束\
  N->转4\
  3. 插入单板，观察告警是否恢复：\
Y->结束\
  N->请联系ZTE4. 更换单板。',
  'SuggestionEnglish': '',
    'SystemInpactChinese': '单板不可用',
    'SystemInpactEnglish': 'board can not be used'},
'3305111646'     :      {'AlarmName': 'RAM status error',
  'AlarmReasonChinese': '刀片内存故障',
  'AlarmReasonEnglish': 'RAM status error',
  'SuggestionChinese': '1更换RAM；\
  2记录告警信息，寻求更高一级的设备维护支持。',
  'SuggestionEnglish': '',
    'SystemInpactChinese': '内存不可用',
    'SystemInpactEnglish': 'RAM is unavailable'}


};


}
