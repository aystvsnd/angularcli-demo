import { Component, OnInit,AfterViewInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AlarmService } from '../alarm.service';
import {TranslateService} from '@ngx-translate/core';
import { Router } from '@angular/router';
import {Subject} from 'rxjs/Subject';
import '../../rxjs-operators';
import {StorageService} from '../../storage.service';
import {SendMessageService} from '../../sendMessage.service';

declare var d3: any;

@Component({
  moduleId: module.id,
  selector: 'current-alarm-detail',
  styleUrls: ['current-alarm-detail.component.css', 'alarm-detail-topo.less'],
  templateUrl: 'current-alarm-detail.component.html',
})


export class CurrentAlarmDetailComponent implements OnInit,AfterViewInit {
  currentAlarmId: any;
  currentAlarmDetail: any = {};
  links : any= [];
  faultModelId: any;
  itemDetailList: Array<any>;
  itemDetailRootList: Array<any>;
  itemDetailNonRootList: Array<any>;
  graph: any;
  topoData: any = {
    nodes: [],
    links: []
  };

  data= {};

  deviceInfo= {};
  forceData: any= {};
  selected: any    = {};
  highlighted: any = null;
  alarmRootType = 0;

  alarmEventTime = '';
  alarmAdditionalText = '';
  alarmCode = '';
  alarmObjectType= '';
  alarmsuggestion= '';
  alarmEventTypeList: any;
  alarmEventType = '';
  alarmObjectName = '';
  alarmSuggestionList: Array<any>;
  alarmConfirmMsg: any;
  alarmConfirmImg = 'images/icon_status_red.png';
  alarmConfirmState= '';
  alarmConfirmReason= '';
  alarmConfirmOperator= '';
  alarmConfirmTime= '';
  alarmRootTypeList: any;
  alarmReasonTypeList: any;
  alarmLevel = '';

  objectName: any;
  objectPath: any;
  objectId: any;
  titleFromhealtyTest: any= false;

  showTipAlarmInfo: any;

  rootCauseLinePosX = 0;
  topoChanged = false;
  MaxPosXGroup = 0;

  rootSuggestionList : any = [];
  nonRootSuggestionList :  any = [];
  relatedSuggestionList : any = [];

  causalModel : any = {};
  relatedModels : any = {};

  currentAlarmType : any;
  isRootModel : any = false;
  isRelatedModel : any = false;

  supportQos = false;
  trendChartSubject: Subject<any> = new Subject<any>();

   delDcMessage: any = {
        title: this.translate.instant('fm.DeleteAlarm'),
        message: this.translate.instant('fm.delConfirm'),
        confirmText: this.translate.instant('Confirm'),
        cancelText: this.translate.instant('Cancel'),
        type: 'exclamation',
        mode: 'tip',
        tip: this.translate.instant('fm.fm_delete_tip')
    };
    errMsgs: string [] = [];
    isShowError = false;
    successfulTip: string[] = [this.translate.instant('fm.operate_success')];
    failedTip: string[] = [this.translate.instant('fm.operate_failed')];
    returnUrl: any = '/main/alarm/currentalarm';
    reason = '';
    alarmType = '';
    modalLable: string = this.translate.instant('fm.confirmInfo');
    modalTitle = '';

  constructor(private alarmService: AlarmService, private router: Router,
              private activatedRoute: ActivatedRoute,
              private translate: TranslateService,
              private sendMessageService: SendMessageService,
              private storageService: StorageService) {
    this.itemDetailList = [];
    this.itemDetailRootList = [];
    this.itemDetailNonRootList = [];
    this.forceData = [];
    this.alarmEventTypeList = {1: 'communicationsAlarm', 2: 'processingAlarm',
      3: 'environmentAlarm', 4: 'qualityOfServiceAlarm', 5: 'equipmentAlarm'};

    this.alarmRootTypeList = {
      0: 'None', 1: 'No', 2: 'Yes'
    };
    this.alarmReasonTypeList = {
      0: 'Reported', 1: 'Confirmed', 2: 'Suspected'
    };

    this.showTipAlarmInfo  = {
      'name': '',
      'imgSrc': '',
      'rootType': '',
      'reasonType': '',
      'eventType': '',
      'alarmObject': '',
      'alarmObjectType': '',
      'alarmCode': '',
      'alarmEventTime': ''
    };

    this.activatedRoute.params.subscribe(params => {
      this.currentAlarmId = params['alarmId'];
      /*this.faultModelId = params['faultModelId'];
      this.alarmRootType = params['alarmRootType'];

      this.objectName = params.objectName;
      this.objectPath = params.objectPath;
      this.objectId = params.objectId;*/
      this.titleFromhealtyTest = params.titleFromhealty;
    });
  }



  getCurrentAlarmsDetail() {
    const alarmId = this.currentAlarmId;
    const that = this;
    this.alarmService.getCurrentAlarmsDetailById(alarmId).then((res: any) => {
      if (res.otherInfo === '' || res.otherInfo === null || res.otherInfo === undefined) {
        that.supportQos = false;
      } else {
        const otherInfo: any = JSON.parse(res.otherInfo);
        let counterSn = '';
        if (_.has(otherInfo, 'sn')) {
          counterSn = otherInfo.sn;
        }
        if (_.has(otherInfo, 'value')) {
          counterSn = otherInfo.value;
        }
        if (counterSn !== '') {
          that.supportQos = true;
          const qosData: any = {
            loadChart: true,
            sn: counterSn,
            cloudEnvId: _.has(JSON.parse(res.topo), 'cloudEnvId') ? (JSON.parse(res.topo)).cloudEnvId : '',
            objectId: res.objectId,
            timeStamp: res.alarmTime,
          };
          setTimeout(() => {
            that.trendChartSubject.next(qosData);
          }, 0);
        }
      }
      this.currentAlarmDetail = res;

      if (this.currentAlarmDetail.suggestion === '' || this.currentAlarmDetail.suggestion === 'none') {
        this.currentAlarmDetail.suggestion = 'The Process of this alarm is temporarily unknown, please ' +
          'contact the ZTE technical support';
      }
      this.currentAlarmDetail.alarmAdditionalText = this.currentAlarmDetail.additionalInfo.join(',\n');

      this.currentAlarmDetail.alarmObjectName = this.currentAlarmDetail.alarmObject;
      this.currentAlarmDetail.alarmObjectType = this.currentAlarmDetail.objectType;
      this.currentAlarmDetail.objectImg = this.alarmService.getObjectImage(this.currentAlarmDetail.objectType);

      this.currentAlarmDetail.alarmEventType = this.alarmTypeTrans(this.currentAlarmDetail.alarmType);

      this.alarmLevel = this.levelChoose(this.currentAlarmDetail.level, this.currentAlarmDetail.impact);
      this.currentAlarmDetail.alarmEventTime = this.alarmService.serverTimeToLocalTime(this.currentAlarmDetail.alarmTime);

      this.currentAlarmDetail.alarmImg = this.alarmService.alarmImgChioce(this.currentAlarmDetail.level, this.currentAlarmDetail.impact);
      this.currentAlarmDetail.alarmSuggestionList = this.splitSuggestion(this.currentAlarmDetail.suggestion);

      this.getRootCauseAlarmDetail(this.currentAlarmId);
      /*if('1' === this.alarmRootType || '2' === this.alarmRootType) {

        this.getRootCauseAlarmDetail(this.currentAlarmId);

      }*/
    });
  }

  levelChoose(level : any, impact : any) {

    if (impact === 'health') {
      return {'critical': this.translate.instant('fm.critical'),
              'major': this.translate.instant('fm.major'),
              'minor': this.translate.instant('fm.minor'),
               'warning': this.translate.instant('fm.warning')}[level];
    }
    if (impact === 'risk') {
      return {'critical': this.translate.instant('fm.critical'),
        'major': this.translate.instant('fm.major'),
        'minor': this.translate.instant('fm.minor'),
        'warning': this.translate.instant('fm.warning')}[level];
    }

    if (impact === 'efficiency') {
      return {'critical': this.translate.instant('fm.critical'),
        'major': this.translate.instant('fm.major'),
        'minor': this.translate.instant('fm.minor'),
        'warning': this.translate.instant('fm.warning')}[level];
    }
    return '';
  }

  ngOnInit() {
        this.getgetAlarmConfirmMsg();
        this.getCurrentAlarmsDetail();
    }

  ngAfterViewInit() {
       this.alarmService.setDelModalCenter('#DelConfirm .modal-content');
  }

  getgetAlarmConfirmMsg() {
      const alarmId = this.currentAlarmId;
      this.alarmService.getAlarmConfirmMsg(alarmId).then((res: any) => {
          this.alarmConfirmMsg = res;
          this.alarmConfirmState = this.languageTrans(this.alarmConfirmMsg.state, 'insight.health');
          this.alarmConfirmReason = this.alarmConfirmMsg.reason;
          this.alarmConfirmOperator = this.alarmConfirmMsg.operator;
          this.alarmConfirmTime = this.alarmService.serverTimeToLocalTime(this.alarmConfirmMsg.time);
          this.alarmConfirmImg = this.confirmImgChoice(this.alarmConfirmState);
      });
  }

  languageTrans(oriLanguage : any, headStr : any) {
    if (oriLanguage !== '') {
      let str = oriLanguage.toLowerCase();
      str = str.replace(/\b\w+\b/g, function (word) {
        return word.substring(0, 1).toUpperCase() + word.substring(1);
      });
      str = headStr + '.' + str;
      return this.translate.instant(str);
    } else {
      return oriLanguage;
    }
  }

  alarmTypeTrans(alarmEventType: any) {
    let transEventType = '';

    alarmEventType = alarmEventType + '';
    for (const key in this.alarmEventTypeList) {
      if (alarmEventType === key ) {
        transEventType = this.languageTrans(this.alarmEventTypeList[alarmEventType], 'insight.alarmTypes');
        return transEventType;
      } else if (alarmEventType === this.alarmEventTypeList[key]) {
        transEventType = this.languageTrans(alarmEventType, 'insight.alarmTypes');
        return transEventType;
      }
    }

    return transEventType;
  }


  alarmLevelImg(alarmLevel : any) {
    if (alarmLevel === 'critical' || alarmLevel === 'Critical') {
      return 'app/insight/images/Alert_Critical.png';
    }
    if (alarmLevel === 'major' || alarmLevel === 'Major') {
      return 'app/insight/images/Alert_Major.png';
    }
    if (alarmLevel === 'minor' || alarmLevel === 'Minor') {
      return 'app/insight/images/Alert_Minor.png';
    }
    if (alarmLevel === 'warning' || alarmLevel === 'Warning') {
      return 'app/insight/images/Alert_Warning.png';
    }
  }

  confirmImgChoice(confirmState : any) {
    if (confirmState === 'unconfirmed') {
      return 'images/icon_status_red.png';
    } else {
      return 'images/icon_status_green.png';
    }
  }

  getRootCauseAlarmDetail(alarmId : any) {

    const that = this;

    this.alarmService.getRootCauseAlarm(alarmId).then((res: any) => {

      if (JSON.stringify(res) === '{}') {
        return;
      }
      that.causalModel = res['causalModel'];
      that.relatedModels = res['relatedModels'];

      if (JSON.stringify(that.causalModel) !== '{}') {

        that.isRootModel = true;

        that.getRootType(that.causalModel);
        that.getAlarmSuggestion(that.causalModel);

        document.getElementById('TopoInfoWindow').style.display = 'block';

        that.graph = res;
        that.getTopoData(that.graph);
        that.initGraph('map');

      } else {

        that.isRootModel = false;
      }

      if (that.relatedModels.length !== 0) {

        that.isRelatedModel = true;
        that.getRelatedSuggestion(that.relatedModels);
      } else {

        that.isRelatedModel = false;
      }


    });

  }

  getAlarmSuggestion(causalModel : any) {

    if (this.currentAlarmType === 0) {

      this.alarmSuggestionList = this.currentAlarmDetail.alarmSuggestionList;
    } else if (this.currentAlarmType === 1) {

      this.nonRootSuggestionHandle(causalModel);
    } else if (this.currentAlarmType === 2) {

      this.rootSuggestionHandle(causalModel);
    }


  }

  getRootType(causalModel : any) {

    const that = this;

    for (const alarm of causalModel.alarms) {
      if (that.currentAlarmId === alarm.alarmId) {

        that.currentAlarmType = alarm.alarmRootTypeIdx;
      }
    }
  }

  rootSuggestionHandle(causalModel : any) {
    //只存在根因告警返回原始告警
    if (causalModel.alarms.length === 1) {

      this.isRootModel = false;
    } else {

      for (const alarm of causalModel.alarms) {

        if (this.currentAlarmId === alarm.alarmId) {

          this.rootSuggestionList = this.splitSuggestion(alarm.alarmSuggestion);
        }
      }
    }

  }


  nonRootSuggestionHandle(causalModel : any) {
    const suggestionList = [];
    //只存在非根因告警返回原始告警
    if (causalModel.alarms.length === 1) {

      this.isRootModel = false;
    } else {

      for (const alarm of causalModel.alarms) {

        if (alarm.alarmRootTypeIdx === 2) {

          const suggestion = {name: '', suggestionAll: [], objectName: '', objectTypeImg: '', cutObjectName: ''};

          suggestion.name = alarm.alarmCodeName;
          suggestion.objectName = alarm.alarmObjectName;
          suggestion.objectTypeImg = this.alarmService.getObjectImage(alarm.alarmObjectType);
          suggestion.suggestionAll = this.splitSuggestion(alarm.alarmSuggestion);
          suggestion.cutObjectName = this.cutStr(suggestion.objectName, 10);
          suggestionList.push(suggestion);
        }
      }
      this.nonRootSuggestionList = suggestionList;
    }
  }

  getRelatedSuggestion(relatedModels : any) {

    for (const relatedModel of relatedModels) {

      const relatedSuggestion = {objectName: '', objectImage: '', modelName: '', alarmSuggestions: [], relatedModelId: '',
        cloudId: '', objectId: '', objectType: '', cutObjName: ''};

      relatedSuggestion.objectName = relatedModel.relatedObjectName;
      relatedSuggestion.cutObjName = this.cutStr(relatedSuggestion.objectName, 10);
      relatedSuggestion.objectImage = this.alarmService.getObjectImage(relatedModel.relatedObjectType);

      relatedSuggestion.modelName = relatedModel.relatedModelName;
      relatedSuggestion.alarmSuggestions = this.splitSuggestion(relatedModel.relatedModelSuggestion);

      relatedSuggestion.relatedModelId = relatedModel.relatedModelId;
      relatedSuggestion.cloudId = relatedModel.relatedObjectCloudId;
      relatedSuggestion.objectId = relatedModel.relatedObjectId;
      relatedSuggestion.objectType = relatedModel.relatedObjectType;

      this.relatedSuggestionList.push(relatedSuggestion);
    }
  }

  /*nonRootSuggestionHandle(alarmDetail : any) {
    if(alarmDetail.alarmRootTypeIdx === 2
      && alarmDetail.alarmCodeName !== '' && alarmDetail.alarmSuggestion !== '') {

      var suggestion = {name  : '', suggestionList : []};
      suggestion.name = alarmDetail.alarmCodeName;
      suggestion.suggestionList = this.splitSuggestion(alarmDetail.alarmSuggestion);
      return suggestion;
    } else {
      return null;
    }
  }*/

  splitSuggestion(alarmSuggestion : any) {
    let str = [];
    if (  alarmSuggestion.trim() === ''
      || alarmSuggestion.toLowerCase().trim() === 'none'
      || alarmSuggestion === 'No action is required.') {
      alarmSuggestion = 'The Suggestion of this alarm is temporarily unknown,please' +
        ' contact the ZTE technical support for help';
      str.push(alarmSuggestion);
      return str;
    }
    if (alarmSuggestion.match(/\d+\./g) === null && alarmSuggestion.indexOf('\n') === -1) {
      str.push(alarmSuggestion);
      return str;
    }
    if (alarmSuggestion.match(/\d+\./g)) {
      str = alarmSuggestion.split(/\d+\./g);
      str.shift();
      return str;
    }
    str.push(alarmSuggestion);
    return str;
  }

  CalcNodeXYValue(groupIndex: any, width: any, height: any, xOffset: any, yOffset: any) {
    const SeriesNumInfo: any [] = new Array();
    const SeriesNumInfoIndex: any [] = new Array();
    let calcNum = 0;
    let MaxPosYNumber = 0;

    SeriesNumInfo.length = this.topoData.nodes.length + 2;
    SeriesNumInfoIndex.length = SeriesNumInfo.length;

    for (let i = 0; i < SeriesNumInfo.length; i++) {
      SeriesNumInfo[i] = 0;
    }

    /* first clac num */
    for (const item of this.topoData.nodes) {
      if (item.posXGroup === groupIndex) {
        if (item.posYNumber > 0) {
          SeriesNumInfo[item.posYNumber] += 1;
        }
        if (MaxPosYNumber < item.posYNumber) {
          MaxPosYNumber = item.posYNumber;
        }
        calcNum += 1;
      }
    }

    for (let i = 1; i <= MaxPosYNumber; i++) {
      SeriesNumInfo[i] = SeriesNumInfo[i] + SeriesNumInfo[i - 1];
      SeriesNumInfoIndex[i] = 0;
    }

    /* seconde clac xy value */
    for (const item of this.topoData.nodes) {
      if (item.posXGroup === groupIndex) {
        if (item.posYNumber > 0) {
          SeriesNumInfoIndex[item.posYNumber] += 1;

          item.x = xOffset + width  / 2;
          item.y = yOffset + height * (SeriesNumInfoIndex[item.posYNumber] + SeriesNumInfo[item.posYNumber - 1]) / (calcNum + 1);

        } else {
          console.log('error node info');
          console.log(this.topoData.nodes);
          item.x = 0;
          item.y = 0;
        }

        item.px = item.x;
        item.py = item.y;

      }
    }

  }


  GetPosXYInfoValue (itemThisNode: any, posInfo: any, pathNum: any) {

    for (const itemLink of this.topoData.links) {
      if (itemLink.target === itemThisNode.index) {
        const itemNodeSource = this.topoData.nodes[itemLink.source];
        if (itemNodeSource.posXGroup === 0 || itemNodeSource.posXGroup === 1) {
          if (posInfo.posXGroup === -1) {
            posInfo.posXGroup = pathNum + 2;
            posInfo.posYNumber = itemNodeSource.posYNumber;
          } else  if (posInfo.posXGroup < (pathNum + 2)) {
            posInfo.posXGroup = pathNum + 2;
            posInfo.posYNumber = itemNodeSource.posYNumber;
          }
        } else {
          this.GetPosXYInfoValue(itemNodeSource, posInfo, (pathNum + 1));
        }
      }
    }

  }

  calcGroupsNodesXYValue(width: any , height: any) {
    let sourceNum = 0;

    let rootYNum = 0;
    let nonRootYNum = 0; /* 根节点 */

    let pathNum = 0; /* 到根节点的路径数目 */

    let nodeCalcPosPreInfo = {
      posXGroup: -1,
      posYNumber: -1
    } ;

    if (this.topoChanged === false) {

      this.MaxPosXGroup = 0;

      /* 先查找根节点,设置 posXGroup */
      for (const item of this.topoData.nodes) {

        item.posXGroup = -1;
        item.posYNumber = -1;

        sourceNum =  _.filter(this.topoData.links, {target: item.index}).length;
        if (sourceNum === 0) {
          if (item.name === 'NonRootCause') {
            nonRootYNum ++;
            item.posXGroup = 1;
            item.posYNumber = nonRootYNum;
          } else {
            rootYNum ++;
            item.posXGroup = 0;
            item.posYNumber = rootYNum;
          }
        }
      }

      /* 遍历所有节点 */
      for (const item of this.topoData.nodes) {

        /* 递归调用直到父节点为根节点*/
        pathNum = 0;
        nodeCalcPosPreInfo = {
          posXGroup: -1,
          posYNumber: -1
        } ;

        if (item.posXGroup < 0) {
          this.GetPosXYInfoValue (item, nodeCalcPosPreInfo, pathNum);
          item.posXGroup = nodeCalcPosPreInfo.posXGroup;
          item.posYNumber = nodeCalcPosPreInfo.posYNumber;
          if (nodeCalcPosPreInfo.posXGroup > this.MaxPosXGroup) {
            this.MaxPosXGroup = nodeCalcPosPreInfo.posXGroup;
          }
        }

      }

    } else {
      rootYNum =  _.filter(this.topoData.nodes, {posXGroup: 0}).length;
      nonRootYNum =  _.filter(this.topoData.nodes, {posXGroup: 1}).length;
    }



    /* 按3种类型画图：根因、非根因但是根因节点（可能不会出现）、其他非根因 */
    if (rootYNum > 0) {
      this.rootCauseLinePosX =  width / 4;
      this.CalcNodeXYValue(0, width / 4, height * rootYNum / (rootYNum + nonRootYNum), 0, 0);
    }

    if (nonRootYNum > 0) {
      this.CalcNodeXYValue(1, width / 12, height * nonRootYNum / (rootYNum + nonRootYNum), width / 4, height * rootYNum / (rootYNum + nonRootYNum));
    }

    if (this.MaxPosXGroup > 1) {
      for (let groupIndex = 2; groupIndex <= this.MaxPosXGroup; groupIndex++) {
        this.CalcNodeXYValue(groupIndex, width * 2 / (3 * (this.MaxPosXGroup - 1)),
            height, width / 3 + (groupIndex - 2) * 2 * width / (3 * (this.MaxPosXGroup - 1)), 0);
      }
    }

    console.log('zxf look node info:');
    console.log(this.topoData.nodes);

  }

  initGraph(divId: any) {
    const that = this;

    const divIdName = '#' +  divId;

    const width = $(divIdName).width();
    const height = $(divIdName).height();



    that.hideTip();

    that.calcGroupsNodesXYValue(width, height);

    /*let zoom= d3.behavior.zoom()
      .scaleExtent([1, 10])
      .on('zoom', zoomed);*/

    d3.select(divIdName).selectAll('svg').remove();
    that.forceData.svg = d3.select(divIdName).append('svg')
      .attr('width', width)
      .attr('height', height);
      /*.call(zoom);*/


    const container = that.forceData.svg.append('g');

    /*function zoomed() {
      container.attr('transform', 'translate(' + d3.event.translate + ')scale(' + d3.event.scale + ')');
    }*/
    that.forceData.force = d3.layout.force()
      .nodes(that.topoData.nodes)
      .links(that.topoData.links)
      .charge(-150)
      .linkDistance(1)
      .size([width, height])
      .start();

    that.forceData.svg.append('defs').append('marker')
      .attr('id'          , 'arrow')
      .attr('markerUnits', 'strokeWidth')
      .attr('viewBox'     , '0 0 16 16')
      .attr('refX'        , 11)
      .attr('refY'        , 6)
      .attr('markerWidth' , 16)
      .attr('markerHeight', 16)
      .attr('fill', '#666666')
      .attr('orient'      , 'auto')
      .append('path')
      .attr('d', 'M2,2,L10,6 L2,10 L6,6 L2,2');


    const url1 = window.location.href;
    that.forceData.link = container.append('g').selectAll('.link')
      .data(that.topoData.links)
      .enter()
      .append('line')
      .attr('class', 'link')
      .attr('marker-end', 'url(' + url1 + '#arrow' + ')')
      .attr({
        'd': function(d) {return ('M ' + d.source.x + ' ' + d.source.y + ' L ' + d.target.x + ' ' + d.target.y); }})
      .style('stroke-width', 1);


    that.forceData.drag = that.forceData.force.drag()
      .origin(function(d) { return d; })
      .on('dragstart', function (d) {
        d3.event.sourceEvent.stopPropagation();
        d.fixed = true;
      });

    that.forceData.node = container.append('g').selectAll('.node')
      .data(that.topoData.nodes)
      .enter()
      .append('g')
      .attr('class', 'node')
      .call(that.forceData.drag)
      .on('mouseover', function(d) {
        if (!that.selected.obj) {
          if (that.forceData.node.mouseoutTimeout) {
            clearTimeout(that.forceData.node.mouseoutTimeout);
            that.forceData.node.mouseoutTimeout = null;
          }

          if (d3.event.buttons === 0) {

            if (!(d3.event.defaultPrevented)) {
              d3.event.stopPropagation();

              const point = {
                x: d3.event.pageX,
                y: d3.event.pageY
              };

              that.toShowTip(d, point);
            }

          } else {
            that.hideTip();
          }

          that.highlightObject(d);
        }
      })
      .on('mouseout', function() {
        if (!that.selected.obj) {
          if (that.forceData.node.mouseoutTimeout) {
            clearTimeout(that.forceData.node.mouseoutTimeout);
            that.forceData.node.mouseoutTimeout = null;
          }
          that.forceData.node.mouseoutTimeout = setTimeout(function() {
            that.highlightObject(null);
            that.hideTip();
          }, 100);

        }
      })
      .on('mousedown', function(obj) {
          that.hideTip();
      });


    that.forceData.node.append('image')
      .attr('width', 32)
      .attr('height', 32)
      .attr('x', -16)
      .attr('y', -16)
      .attr('xlink:href', function (d) {

        if (d.alarmid === that.currentAlarmId) {

          return 'app/insight/images/svg/current.svg';

        } else if (d.alarmReasonType === 0) {

          return 'app/insight/images/svg/reported.svg';

        } else {

          return 'app/insight/images/svg/deduce_true.svg';

        }


      });

    that.forceData.svg
    .on('click', function(obj) {
      that.hideTip();
    });


    $('#show-tips').on('click', '.closeTips', function() {
      that.hideTip();
    });

    if (divId === 'big-map') {

      that.forceData.node.append('text')
          .attr('dy', '5em')
          .attr('dx', '2em')
          .attr('class', 'nodetext')
          .style('text-anchor', 'middle')
          .style('font-size', '6px')
          .style('fill', '#999999')
          .text(function(d) {
            if (d.type === 'SERVER') {
              if (d.objectName === '') {
                return d.type + '(' + d.alarmObjectId + ')';
              }
            }
            return d.type + '(' + d.objectName + ')';
          });

      that.forceData.node.append('text')
          .attr('dy', '-3em')
          .attr('dx', '2em')
          .attr('class', 'nodetext')
          .style('text-anchor', 'middle')
          .style('font-size', '6px')
          .style('fill', '#666666')
          .text(function(d) {
            return that.cutStr(d.name, 30);
          });
    }


    that.forceData.force.on('tick', function() {

      that.forceData.link.attr('x1', function(d) {

        that.CalcLimitXValue(d.source, width, height);

        return d.source.x;
      })
        .attr('y1', function(d) {
            return d.source.y;
        })
        .attr('x2', function(d) {

            that.CalcLimitXValue(d.target, width, height);

            return d.target.x;
          })
        .attr('y2', function(d) {
            return d.target.y;
        });

      that.forceData.node.attr('transform', function(d){

        that.CalcLimitXValue(d, width, height);

        return 'translate(' + d.x + ',' + d.y + ')';

      });

    });

    const rootCauseTextStr = that.translate.instant('fm.alarmTopoInfo.rootCauseAlarm');
    const nonRootCauseTextStr = that.translate.instant('fm.alarmTopoInfo.nonRootCauseAlarm');

    if (that.rootCauseLinePosX > 0) {
      that.forceData.svg.append('line')
          .attr('x1', that.rootCauseLinePosX)
          .attr('y1', 0)
          .attr('x2', that.rootCauseLinePosX)
          .attr('y2', height)
          .attr('stroke', '#666666')
          .attr('stroke-width', '0.1');
      that.forceData.svg.append('text')
          .attr('dx', '20px')
          .attr('dy', '20px')
          .style('font-size', '10px')
          .style('fill', '#999999')
          .text(rootCauseTextStr);
    }

    const temp = (that.rootCauseLinePosX + 20) + 'px';

    that.forceData.svg.append('text')
        .attr('dx', temp)
        .attr('dy', '20px')
        .style('font-size', '10px')
        .style('fill', '#999999')
        .text(nonRootCauseTextStr);
  };

  CalcLimitXValue(obj: any, width: any, height: any) {

    if (obj.group ===  'RootCause' || obj.group === 'RootCauseCurrent') {

      if (obj.x > (this.rootCauseLinePosX - 16)) {
        obj.x = this.rootCauseLinePosX - 16;
      }

    } else {

      if (obj.x < (this.rootCauseLinePosX + 14)) {
        obj.x = this.rootCauseLinePosX + 14;
      }
    }

    if (obj.x < 15) {
      obj.x = 15;
    }

    if (obj.x > (width - 16)) {
      obj.x = (width - 16);
    }

    if (obj.y < 14) {
      obj.y = 14;
    }

    if (obj.y > (height - 17)) {
      obj.y = (height - 17);
    }

  }


  getTopoData(graph: any) {
    const that = this;

    that.topoData = {
      nodes: [],
      links: []
    };

    for (const item of graph.causalModel.alarms) {

      const nodesTemp: any = {};
      const relatedLinks = that.getRelatedLinks(item.alarmRef, graph.causalModel.links);
      that.setNodeInfo(nodesTemp, that.topoData.nodes.length, relatedLinks, item);
      that.topoData.nodes.push(nodesTemp);
    }

    for (const item of graph.causalModel.links) {
      const that = this;
      const linkTemp: any = {};
      const source = that.findNodeIndex(item.alarmRefSrc);
      const target = that.findNodeIndex(item.alarmRefTarg);
      if (target !== -1) {
        that.setLinkInfo(linkTemp, source, target);
        that.topoData.links.push(linkTemp);
      };
    }
  }

  getGroupInfo(item: any) {

      if (item.alarmRootTypeIdx === 2) {
        return 'RootCause';
      } else {
        return 'NonRootCause';
      }

  }

  setNodeInfo (nodes: any, index: any, relatedLinks: any, item: any) {

    const group = this.getGroupInfo(item);

    const alarmImact = item.alarmImpact.toLowerCase();

    nodes.index = index;
    nodes.group = group;
    nodes.relateLinks = relatedLinks;

    nodes.name = item.alarmCodeName;
    nodes.type = item.alarmObjectType;
    nodes.id = item.alarmRef;

    nodes.alarmObjectId = item.alarmObjectId;

    nodes.alarmReasonType = item.alarmReasonTypeIdx;
    nodes.alarmid = item.alarmId;
    nodes.code = item.alarmCode;

    if (alarmImact === 'health' || alarmImact === 'risk' || alarmImact === 'efficiency') {
      nodes.imgSrc = this.alarmService.alarmImgChioce(item.alarmLevel , alarmImact);
    } else {
      nodes.imgSrc = this.alarmLevelImg(item.alarmLevel);
    }


    nodes.level = this.languageTrans(item.alarmLevel, 'insight.health');
    nodes.objectName = item.alarmObjectName;
    nodes.eventTime = this.alarmService.serverTimeToLocalTime(item.alarmEventTime);
    nodes.rootTypeIdx = item.alarmRootTypeIdx;
    nodes.rootType = this.translate.instant('fm.' + this.alarmRootTypeList[item.alarmRootTypeIdx]);
    nodes.reasonType = this.translate.instant('fm.alarmSource.' + this.alarmReasonTypeList[item.alarmReasonTypeIdx]);

    /*if(nodes.alarmid !== this.currentAlarmId) {
      nodes.eventType = this.alarmTypeTrans(item.alarmEventType);
      nodes.objectName = this.currentAlarmDetail.alarmObjectName;
    } else {
      nodes.eventType = item.alarmEventType;
    }*/

    nodes.eventType = this.alarmTypeTrans(item.alarmEventType);


    nodes.fixed = true;

    nodes.posXGroup = -1;
    nodes.posYNumber = -1;
  }

  getRelatedLinks (alarmRef: any, relatedLinks: any) {
    const linksTemp = [];
    for (const item of relatedLinks){
      if (item.alarmRefSrc === alarmRef || item.alarmRefTarg === alarmRef) linksTemp.push(item);
    }
    return linksTemp;
  }

  setLinkInfo (links: any, source: any, target: any) {
    links.source = source;
    links.target = target;
  }

  findNodeIndex(id) {
    return  _.findIndex(this.topoData.nodes, {id: id});
  }

  findNodeGroupNumber(group: any) {
    return  _.filter(this.topoData.nodes, {group: group});
  }

  highlightObject(obj: any) {
    const that = this;
    if (obj) {
      if (obj !== that.highlighted) {
        that.forceData.node.classed('inactive', function(d) {
          return (obj !== d
          && that.getAlarmSourceLength(d, obj) === 0
          && that.getAlarmTargetLength(d, obj) === 0);
        });
        that.forceData.link.classed('inactive', function(d) {
          return (
          obj.index !== d.source.index && obj.index !== d.target.index);
        });
      }
      that.highlighted = obj;
    } else {
      if (that.highlighted) {
        that.forceData.node.classed('inactive', false);
        that.forceData.link.classed('inactive', false);
      }
      that.highlighted = null;
    }
  }


  getAlarmSourceLength(d: any, obj: any) {
    const sourceTemp: any = [];
    const relateLink = d.relateLinks;
    for (const item of relateLink){
      if (item.alarmIdTarg === obj.id)
        sourceTemp.push(item);
    }
    const sourcelength = sourceTemp.length;
    return sourcelength;
  }

  getAlarmTargetLength(d: any, obj: any) {
    const targetTemp = [];
    const relateLink = d.relateLinks;
    for (const item of relateLink){
      if (item.alarmIdSrc === obj.id)
        targetTemp.push(item);
    }
    const targetlength = targetTemp.length;
    return targetlength;
  }

  getBackToHealthImprove() {
    this.router.navigate(['main/insight/health/health-promote']);

  }

  getBackToHealthImproveObject() {
    const param = this.objectPath.split(';');
    const cloudId = param[1].split('=')[1];
    const resourceType = param[2].split('=')[1];
    this.router.navigate(['/main/insight/health/health-detail', this.objectId,
      {'cloudId': cloudId, 'resourceType': resourceType}]);
  }

  goBack() {
    window.history.back(-1);
  }

  goBackToAnalysis() {
    this.router.navigate(['/main/insight/alarm/smart-analysis']);
  }
  enlarge() {
    document.getElementById('AlarmDetailInfo').style.display = 'none';
    this.topoChanged = true;
    this.initGraph('big-map');
    document.getElementById('TopoInfoMaxWindow').style.display = 'block';
  }

  shrink() {
    document.getElementById('TopoInfoMaxWindow').style.display = 'none';
    this.topoChanged = true;
    this.initGraph('map');
    document.getElementById('AlarmDetailInfo').style.display = 'flex';
  }

  showTip() {
    const display = $('#show-tips').css('display');
    if (display === 'none') {
      $('#show-tips').css('display', 'block');
    }
  }

  hideTip() {
    const display = $('#show-tips').css('display');
    if (display === 'block') {
      $('#show-tips').css('display', 'none');
    }
  }

  toShowTip(obj: any, position: any) {
    this.hideTip();

    this.showTipAlarmInfo.name = obj.name;
    this.showTipAlarmInfo.rootType = obj.rootType;
    this.showTipAlarmInfo.reasonType = obj.reasonType;
    this.showTipAlarmInfo.eventType = obj.eventType;

    this.showTipAlarmInfo.alarmObject = obj.objectName;

    if (obj.type === 'SERVER') {
      if (obj.objectName === '') {
        this.showTipAlarmInfo.alarmObject = obj.alarmObjectId;
      }
    }

    this.showTipAlarmInfo.alarmObjectType = obj.type;
    this.showTipAlarmInfo.alarmCode = obj.code;
    this.showTipAlarmInfo.alarmEventTime = obj.eventTime;

    this.showTipAlarmInfo.imgSrc = obj.imgSrc;

    const tip = $('#show-tips');
    const width = tip.width();
    const height = tip.height();

    tip.css({'left': (position.x - width / 2) , 'top': (position.y - height - 25) });

    this.showTip();

  }

  /**
   * js截取字符串，中英文都能用
   * @param str：需要截取的字符串
   * @param len: 需要截取的长度
   */
  cutStr(str, len) {
    let str_length = 0;
    let str_len = 0;
    let   str_cut, a;
    str_cut = '';
    str_len = str.length;
    for (let i = 0; i < str_len; i++) {
      a = str.charAt(i);
      str_length++;
      if (escape(a).length > 4) {
        //中文字符的长度经编码之后大于4
        str_length++;
      }
      str_cut = str_cut.concat(a);
      if (str_length >= len) {
        str_cut = str_cut.concat('...');
        return str_cut;
      }
    }
    //如果给定字符串小于指定长度，则返回源字符串；
    if (str_length < len) {
      return str;
    }
  }


  getBackToAlarm() {
    this.router.navigate(['/main/alarm/currentalarm']);
  }
  getBackToCurAlarm() {
    this.alarmService.curAlarmPageInfo.from = 'curAlarmDetail';
    this.router.navigate(['/main/alarm/currentalarm']);
  }

  gotoAnalysisDetail(mdoelId : any) {
    this.router.navigate(['/main/insight/alarm/smart-analysis-detail',
      {modelId: mdoelId, 'pageSrc': 'currentAlarmDetail', pageSrcName: this.currentAlarmDetail.description,
        pageSrcAlarmId: this.currentAlarmId}]);
  }
  getObjectName(nameSrc : any) {
    const arr = nameSrc.split(',');
    const name = $.trim(arr[arr.length - 1].split('=')[1]);
    return name;
  }
  gotoObjectDetail() {
    const objectId = {envId: JSON.parse(this.currentAlarmDetail.topo).cloudEnvId,
      vmId: this.currentAlarmDetail.objectId};
    const objectToString = JSON.stringify(objectId);

    const objectname = this.getObjectName(this.currentAlarmDetail.alarmObject);

    this.router.navigate(['/main/insight/monitorObject/monitor-obj-detail',
      {name: objectname, type: this.currentAlarmDetail.objectType, objectId: objectToString}]);
  }

  gotoRelateObjectDetail(relateModel : any) {

    const objectId = {envId: relateModel.cloudId,
      vmId: relateModel.objectId};
    const objectToString = JSON.stringify(objectId);

    const objectname = relateModel.objectName;

    this.router.navigate(['/main/insight/monitorObject/monitor-obj-detail',
      {name: objectname, type: relateModel.objectType, objectId: objectToString}]);
  }
  /*jumpToObjectDetail() {
    var objectId = this.currentAlarmDetail.objectType === 'vm' ? this.currentAlarmDetail.topo.vid :
      this.currentAlarmDetail.topo.hid;
    this.router.navigate(['/main/insight/monitorObject/monitor-obj-detail', objectId]);
  }*/

    // delete && confirm alarm
    deleteAlarm() {
        const alarmId: any = this.currentAlarmDetail.self.split('/').pop();
        const that = this;
        this.alarmService.deleteAlarm(alarmId).then((res: Response) => {
                that.sendMessageService.sendSucMsg(that.successfulTip, that.returnUrl, undefined);
            },
            (error: any) => {
                that.errMsgs.push(error.message || error);
                that.isShowError = true;
                setTimeout(function () {
                    that.isShowError = false;
                }, 2000);
            });
    }

    cancleDelAlarm() {
        console.log('cancle del');
    }

    alarmConfirm() {
        this.reason = '';
        this.modalTitle = this.translate.instant('fm.confirmAlarm');
        this.modalLable = this.translate.instant('fm.confirmDiscription');
        this.alarmType = 'confirmed';
        this.alarmService.setModalCenter('#confirmModal .confirm-modal-content');

    }


    alarmUnConfirm() {
        this.reason = '';
        this.modalTitle = this.translate.instant('fm.unconfirm');
        this.modalLable = this.translate.instant('fm.unconfirmDiscription');
        this.alarmType = 'unconfirmed';
        this.alarmService.setModalCenter('#confirmModal .confirm-modal-content');
    }

    confirm() {
        const data: any = {
            alarmIds: [],
            confirmation: {
                state: this.alarmType,
                reason: this.reason,
                operator: this.storageService.getUserName(),
                time: new Date()
            }
        };
        const alarmId: any = this.currentAlarmDetail.self.split('/').pop();
        data.alarmIds.push(alarmId);
        const backUrl: any = '/main/alarm/currentalarm' + alarmId;
        const that = this;
        this.alarmService.postAlarmComfirmInfo(data).then((res: any) => {
            that.sendMessageService.sendSucMsg(that.successfulTip, backUrl, undefined);
            that.getgetAlarmConfirmMsg();
            that.getCurrentAlarmsDetail();

        });
        $('#confirmModal').modal('hide');
    }
}

