import {Component, AfterViewInit, OnInit, EventEmitter} from '@angular/core';
import {Router} from '@angular/router';
import {TranslateService} from '@ngx-translate/core';
//import { AlarmExportComponent } from './alarmExport.component';
import '../../rxjs-operators';
import {ApiResourceService as Http} from '../../apiResource.service';
import {AlarmService} from '../alarm.service';
import {StorageService} from '../../storage.service';

import {appConfig} from '../../app.config';
import {ActivatedRoute} from '@angular/router';
import {AuthService} from '../../core/index';
import {UserService} from '../../system-manage/user-security/user-manage/user.service';
import {Observable} from 'rxjs/Observable';


@Component({
  moduleId: module.id,
  selector: 'current-alarm',
  styleUrls: ['current-alarm.component.css'],
  templateUrl: 'current-alarm.component.html'
})

export class CurrentAlarmComponent implements AfterViewInit, OnInit {
  //@ViewChild('modal1') modal:ModalComponent;
  reason = '';
  alarmType = '';
  modalLable = this.translate.instant('fm.confirmInfo');
  modalTitle = '';
  that = this;
  exportData: any = {
    currentPageInfo: {}
  };
  curExportDate: Date;

  delDcMessage: any = {
    title: this.translate.instant('fm.DeleteAlarm'),
    message: this.translate.instant('fm.delConfirm'),
    confirmText: this.translate.instant('Confirm'),
    cancelText: this.translate.instant('Cancel'),
    type: 'exclamation',
    mode: 'tip',
    tip: this.translate.instant('fm.fm_delete_tip')
  };
  alarmId = '';
  currentAlarmLevel: any = '';

  showPrevPage = true;
  isShowLoading = true;
  loading: any = this.translate.instant('fm.loading');

  //alarmLevels:any[] = ['ALL','critical','major','minor','warning'];
  //alarmLevel:any='ALL';

  alarmLevels: any[] = [
    {name: this.translate.instant('fm.ALL'), value: 'ALL'},
    {name: this.translate.instant('fm.critical'), value: 'critical'},
    {name: this.translate.instant('fm.major'), value: 'major'},
    {name: this.translate.instant('fm.minor'), value: 'minor'},
    {name: this.translate.instant('fm.warning'), value: 'warning'},
  ];
  alarmLevel: any = 'ALL';

  alarmRootTypes: any[] = [
    {name: this.translate.instant('fm.ALL'), value: 'ALL'},
    {name: this.translate.instant('fm.Yes'), value: 2},
    {name: this.translate.instant('fm.No'), value: 1},
    {name: this.translate.instant('fm.NoDeduction'), value: 0},
  ];
  alarmRootType: any = 'ALL';

  objectTypes: any[] = [
    {name: this.translate.instant('fm.ALL'), value: 'ALL'},
    {name: 'cloudEnv', value: 'cloudEnv'}, {name: 'chassis', value: 'chassis'},
    {name: 'cloud', value: 'cloud'},
    {name: 'host', value: 'host'}, {name: 'rack', value: 'rack'},
    {name: 'router', value: 'router'}, {name: 'server', value: 'server'},
    {name: 'storage', value: 'storage'}, {name: 'switch', value: 'switch'},
    {name: 'vm', value: 'vm'}, {name: 'volume', value: 'volume'},
    {name: 'system', value: 'system'}
  ];
  objectType: any = 'ALL';

  alarmTypes: any[] = [
    {name: this.translate.instant('fm.ALL'), value: 'ALL'},
    {name: 'communicationsAlarm', value: 'communicationsAlarm'},
    {name: 'processingErrorAlarm', value: 'processingErrorAlarm'},
    {name: 'environmentalAlarm', value: 'environmentalAlarm'},
    {name: 'qualityOfServiceAlarm', value: 'qualityOfServiceAlarm'},
    {name: 'equipmentAlarm', value: 'equipmentAlarm'},
    {name: 'integrityViolation', value: 'integrityViolation'},
  ];
  alarmTyp: any = 'ALL';

  alarmConfirmStates: any[] = [
    {name: this.translate.instant('fm.ALL'), value: 'ALL'},
    {name: this.translate.instant('fm.Confirm'), value: 'confirmed'},
    {name: this.translate.instant('fm.NoConfirm'), value: 'unconfirmed'},
  ];
  alarmConfirmState: any = 'ALL';


  queryAlarmTimePeriods: any[] = [
    {name: this.translate.instant('fm.ALL'), value: 'ALL'},
    {name: this.translate.instant('fm.currentDay'), value: this.translate.instant('fm.currentDay')},
    {name: this.translate.instant('fm.oneHour'), value: this.translate.instant('fm.oneHour')},
    {name: this.translate.instant('fm.oneDay'), value: this.translate.instant('fm.oneDay')},
    {name: this.translate.instant('fm.oneWeek'), value: this.translate.instant('fm.oneWeek')},
    {name: this.translate.instant('fm.oneMonth'), value: this.translate.instant('fm.oneMonth')},
    {name: this.translate.instant('fm.customTime'), value: this.translate.instant('fm.customTime')}
  ];
  currentAlarmPeriod: any = 'ALL';
  impactSystems: any[] = [
    {name: this.translate.instant('fm.ALL'), value: 'ALL'},
    {name: 'Health', value: 'health'},
    {name: 'Risk', value: 'risk'},
    {name: 'Efficiency', value: 'efficiency'}
  ];

  impactSystem: any = 'ALL';
  tipToolCol: any = `position: relative;cursor: pointer;`;
  alertIconTip: any = `display: inline-block;
    width:20px;
    height:20px;
    background-image: url('assets/images/alert_icon_all.png');
    background-repeat: no-repeat;
    position:relative;top:3px;`;
  fontPosition: any = `position:relative;top:-4px;`;
  absoluteTimeFlag;
  absoluteTimeStart: Date = new Date();
  absoluteTimeEnd: Date = new Date();
  timeErr = false;
  dashboradflag = true;
  //Healthy Page
  objectId: any;
  objectName: any;
  objectPath: any;
  objectTypeOps: any;
  objectTopo: any;

  titleFromhealtyTest = false;
  lang = this.translate.currentLang;
  selectedRows: Array = [];
  objectsSelected: EventEmitter<any> = new EventEmitter();
  alarmHiddenFlag = false;
  //new
  tip_tag: any = `display:inline-block;
  opacity:0;
  -moz-opacity:0;
  filter:Alpha(opacity=0);
  position:absolute;
  left:50%;color:#000;white-space:nowrap;transform: translate(-50%,-50%);`;
  tip_area: any = `height:24px;
  padding:0 10px;background-color:#fff;
  border:1px solid #e6e6e6;`;
  tip_areaCopy: any = `height:24px;
  padding:0 10px;`;
  tip_arrow: any = `float:left;
  position:relative;
  left:50%;`;
  tip_angle: any = `position:relative;
  left:-50%;
  top: -11px;
  display:inline-block;
  width:0px;
  height:0px;
  border-left:4px solid transparent;
  border-right:4px solid transparent;
  border-top:4px solid #e6e6e6;`;
  tip_angleWhite: any = `position: relative;
    left: -4px;
    top: -20px;
    display: block;
    width: 0px;
    height: 0px;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 4px solid #fff;`;
  rowData: any[];
  window: window = window;
  objTypeIcon: any = `width:20px;height:20px;margin-right:5px;`;
  hotKeyToggle = false;
  unconfirmBtnLabel = '';
  columnDefs: any[] = [
    {
      checkbox: true
    },
    {
      field: 'id',
      title: this.translate.instant('fm.Sequence'),
      formatter: function (value, row, index) {
        return index + 1;
      }
    },
    {
      field: 'level',
      align: 'center',
      width: 100,
      title: this.translate.instant('fm.impact_level'),
      events: 'operateEvents',
      formatter: function (value, row, index) {
        const levelVaule = value.toLowerCase();
        if (levelVaule === 'critical' && row.impact === 'health') {
          return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span style="${that.alertIconTip}"></span>
                    <div style="${that.tip_tag}" class="tip-toggle">
                     <div style="${that.tip_area}">
                     ${that.translate.instant('fm.impact_health')}&nbsp:&nbsp${that.translate.instant('fm.critical')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                 <div>`;
        } else if (levelVaule === 'critical' && row.impact === 'risk') {
          return `<div style="${that.tipToolCol}" class="impactLevel">
                   <span style="${that.alertIconTip}background-position:0px -22px;"></span>
                    <div style="${that.tip_tag}" class="tip-toggle">
                     <div style="${that.tip_area}">
                     ${that.translate.instant('fm.impact_risk')}&nbsp:&nbsp${that.translate.instant('fm.critical')}</div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  <div>`;
        } else if (levelVaule === 'critical' && row.impact === 'efficiency') {
          return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:0px -42px;"></span>
                    <div style="${that.tip_tag}" class="tip-toggle">
                     <div style="${that.tip_area}">
                     ${that.translate.instant('fm.impact_efficiency')}&nbsp:&nbsp${that.translate.instant('fm.critical')}</div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
        } else if (levelVaule === 'critical' && (row.impact !== 'health' || row.impact !== 'risk' || row.impact !== 'efficiency')) {
          return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:0px -62px;"></span>
                   <div style="${that.tip_tag}" class="tip-toggle">
                     <div style="${that.tip_area}">
                     ${that.translate.instant('fm.level')}&nbsp:&nbsp${that.translate.instant('fm.critical')}</div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
        } else if (levelVaule === 'major' && row.impact === 'health') {
          return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:-20px 0px;"></span>
                  <div style="${that.tip_tag}" class="tip-toggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.impact_health')}&nbsp:&nbsp${that.translate.instant('fm.major')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  <div>`;
        } else if (levelVaule === 'major' && row.impact === 'risk') {
          return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:-20px -22px;"></span>
                  <div style="${that.tip_tag}" class="tip-toggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.impact_risk')}&nbsp:&nbsp${that.translate.instant('fm.major')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
        } else if (levelVaule === 'major' && row.impact === 'efficiency') {
          return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:-20px -42px;"></span>
                  <div style="${that.tip_tag}" class="tip-toggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.impact_efficiency')}&nbsp:&nbsp${that.translate.instant('fm.major')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
        } else if (levelVaule === 'major' && (row.impact !== 'health' || row.impact !== 'risk' || row.impact !== 'efficiency')) {
          return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:-20px -62px;"></span>
                   <div style="${that.tip_tag}" class="tip-toggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.level')}&nbsp:&nbsp${that.translate.instant('fm.major')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
        } else if (levelVaule === 'minor' && row.impact === 'health') {
          return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:-40px 0px;"></span>
                  <div style="${that.tip_tag}" class="tip-toggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.impact_health')}&nbsp:&nbsp${that.translate.instant('fm.minor')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  <div>`;
        } else if (levelVaule === 'minor' && row.impact === 'risk') {
          return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:-40px -22px;"></span>
                  <div style="${that.tip_tag}" class="tip-toggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.impact_risk')}&nbsp:&nbsp${that.translate.instant('fm.minor')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  <div>`;
        } else if (levelVaule === 'minor' && row.impact === 'efficiency') {
          return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span style="${that.alertIconTip}background-position:-40px -42px;" ></span>
                   <div style="${that.tip_tag}" class="tip-toggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.impact_efficiency')}&nbsp:&nbsp${that.translate.instant('fm.minor')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
        } else if (levelVaule === 'minor' && (row.impact !== 'health' || row.impact !== 'risk' || row.impact !== 'efficiency')) {
          return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:-40px -62px;"></span>
                   <div style="${that.tip_tag}" class="tip-toggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.level')}&nbsp:&nbsp${that.translate.instant('fm.minor')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
        } else if (levelVaule === 'warning' && row.impact === 'health') {
          return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:-60px 0px;'"></span>
                   <div style="${that.tip_tag}" class="tip-toggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.impact_health')}&nbsp:&nbsp${that.translate.instant('fm.warning')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  <div>`;
        } else if (levelVaule === 'warning' && row.impact === 'risk') {
          return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span style="${that.alertIconTip}background-position:-60px -22px;"></span>
                   <div style="${that.tip_tag}" class="tip-toggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.impact_risk')}&nbsp:&nbsp${that.translate.instant('fm.warning')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
        } else if (levelVaule === 'warning' && row.impact === 'efficiency') {
          return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span style="${that.alertIconTip}background-position:-60px -42px;"></span>
                   <div style="${that.tip_tag}" class="tip-toggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.impact_efficiency')}&nbsp:&nbsp${that.translate.instant('fm.warning')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
        } else if (levelVaule === 'warning' && (row.impact !== 'health' || row.impact !== 'risk' || row.impact !== 'efficiency')) {
          return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:-60px -62px;"></span>
                   <div style="${that.tip_tag}" class="tip-toggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.level')}&nbsp:&nbsp${that.translate.instant('fm.warning')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
        } else {
          return `<div class="impactLevel"><div style class="tip-toggle"></div>-</div>`;
        }
      }
    },
    {
      field: 'description',
      title: this.translate.instant('fm.description'),
      events: 'operateEvents',
      align: 'left',
      formatter: function (value, row, index) {
        return `<a href="javascript:void(0);" class="detail">${value}</a>`;
      }
    },
    {
      field: 'objectType',
      align: 'left',
      width: 100,
      title: this.translate.instant('fm.objectType'),
      formatter: function (value, row, index) {
        switch (value) {
          case 'cloudEnv':
            return `<img src="assets/images/alarmObj/alarm_cloudenv.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
          case 'chassis':
            return `<img src="assets/images/alarmObj/alarm_chassis.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
          case 'cloud':
            return `<img src="assets/images/alarmObj/alarm_cloudenv.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
          case 'host':
            return `<img src="assets/images/alarmObj/alarm_host.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
          case 'rack':
            return `<img src="assets/images/alarmObj/alarm_rack.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
          case 'router':
            return `<img src="assets/images/alarmObj/alarm_router.svg" style="${that.objTypeIcon}"  /><span>${value}</span>`;
          case 'server':
            return `<img src="assets/images/alarmObj/alarm_server.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
          case 'storage':
            return `<img src="assets/images/alarmObj/alarm_storage.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
          case 'switch':
            return `<img src="assets/images/alarmObj/alarm_switch.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
          case 'vm':
            return `<img src="assets/images/alarmObj/alarm_vm.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
          case 'volume':
            return `<img src="assets/images/alarmObj/alarm_volume.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
          case 'system':
            return `<img src="assets/images/alarmObj/alarm_system.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
          case 'default':
            console.log('no this objectType');
        }
      }
    },
    {
      field: 'alarmObject',
      title: this.translate.instant('fm.objectName'),
      width: 100,
      align: 'left',
      formatter: function (value, row, index) {
        const value1 = value.split(',').pop();
        const value2 = value.split(',').join('\r\n');
        return `<pre data-toggle="tooltip" data-placement="top" title="${value2}">${value1}</pre>`;
      }
    },
    {
      field: 'alarmType',
      align: 'left',
      title: this.translate.instant('fm.alarmType')
    }, {
      field: 'alarmTime',
      align: 'left',
      title: this.translate.instant('fm.alarmTime'),
      cellStyle: () => {
        return {
          css: {'min-width': '140px'}
        };
      },
      formatter: function (value, row, index) {
        const reg = new RegExp('(([0-9]{4})-([0][1-9]|[1][0-2])-([0-2][0-9]|[3][0-1])T([0-1][0-9]' +
          '|[2][0-3]):([0-5][0-9]):([0-5][0-9])Z)');
        if (reg.test(value)) {
          value = Date.parse(value);
          let localTime = '';
          const offset: number = (new Date()).getTimezoneOffset();
          localTime = (new Date(value - offset * 60000)).toISOString();
          localTime = localTime.substr(0, localTime.lastIndexOf('.'));
          localTime = localTime.replace('T', ' ');
          return localTime;
        } else {
          value = ' ';
        }
      }
    }, {
      field: 'confirmStatus',
      align: 'left',
      width: 110,
      title: this.translate.instant('fm.confirmStatus'),
      formatter: function (value, row, index) {
        if (value === 'confirmed') {
          return `<div>
                  <image src="assets/images/status/icon_status_green.png" />
                  <span>${that.translate.instant('fm.Confirm')}</span>
                  </div>`;
        } else {
          return `<div>
                   <image src="assets/images/status/icon_status_grey.png" />
                   <span>${that.translate.instant('fm.NoConfirm')}</span>
                   </div>`;
        }
      }
    },
    {
      title: this.translate.instant('fm.operation'),
      field: 'operate',
      events: 'operateEvents',
      width: 150,
      align: 'center',
      formatter: function (value, row, index) {

        if (that.authService.containEveryRights(['Current Alarm#DELETE', 'Current Alarm Confirm#PUT'])) {

          if (row.confirmStatus === 'unconfirmed') {
            return `<div class="btn-group ">
                         <button class="btn btn-default confirm ">${that.translate.instant('Confirm')}</button>
                         <button class="btn btn-default dropdown-toggle" data-toggle="dropdown"><span class="caret"></span>
                         </button>
                         <ul class="dropdown-menu dropdown-menu-top">
                            <li>
                            <a data-target="#DelConfirm" data-toggle="modal" class="clear">${that.translate.instant('Delete')}</a>
                                <!--<a data-target="#DelConfirm" data-toggle="modal">删除</a>-->

                            </li>
                         </ul>
                   </div>`;
          } else {
            if (that.lang !== 'zh') {
              return `<div class="btn-group ">
                         <button class="btn btn-default unconfirm" title="${that.translate.instant('fm.unconfirm')}">
                         ${that.unconfirmBtnLabel}</button>
                         <button class="btn btn-default dropdown-toggle " data-toggle="dropdown" ><span class="caret"></span>
                         </button>
                         <ul class="dropdown-menu dropdown-menu-top">
                            <li>
                                <a data-target="#DelConfirm" data-toggle="modal" class="clear">${that.translate.instant('Delete')}</a>
                            </li>
                         </ul>
                   </div>`;
            } else {
              return `<div class="btn-group ">
                         <button class="btn btn-default unconfirm">${that.unconfirmBtnLabel}</button>
                         <button class="btn btn-default dropdown-toggle " data-toggle="dropdown" ><span class="caret"></span>
                         </button>
                         <ul class="dropdown-menu dropdown-menu-top">
                            <li>
                                <a data-target="#DelConfirm" data-toggle="modal" class="clear">${that.translate.instant('Delete')}</a>
                            </li>
                         </ul>
                   </div>`;
            }
          }

        } else if (that.authService.containEveryRights(['Current Alarm#DELETE'])) {
          return `<div class="btn-group">
                <button data-target="#DelConfirm" data-toggle="modal" class="clear btn btn-default ">
                ${that.translate.instant('Delete')}</button>
                </div>`;

        } else {
          if (row.confirmStatus === 'unconfirmed') {
            return `<div class="btn-group ">
                         <button class="btn btn-default confirm ">${that.translate.instant('Confirm')}</button>
                   </div>`;
          } else {
            if (that.lang !== 'zh') {
              return `<div class="btn-group">
                         <button class="btn btn-default unconfirm " title="${that.translate.instant('fm.unconfirm')}">
                         ${that.unconfirmBtnLabel}</button>
                   </div>`;
            } else {
              return `<div class="btn-group">
                         <button class="btn btn-default unconfirm ">
                         ${that.unconfirmBtnLabel}</button>
                   </div>`;
            }
          }

        }

      }


    }
  ];


  gridOptions: any = {
    method: 'get',
    url: appConfig.fmServiceUrl + 'alarmsWithDetail',
    queryParams: params => this.queryParams(params, this),
    columns: this.columnDefs,
    sidePagination: 'server',
    pagination: true,//是否开启分页
    pageSize: 10,//单页数量
    pageNumber: 1,
    pageList: [10, 20],
    paginationDetailHAlign: 'left',//分页详情水平位置
    paginationHAlign: 'left',//分页条水平位置
    clickToSelect: false,//单击行选中
    sortable: true,//是否开启排序,
    sortOrder: 'asc',
    search: true,
    toolbar: '#toolbar1'
  };


  getPage() {
    if (this.alarmService.curAlarmPageInfo.from === 'curAlarmDetail'
      || window.localStorage.getItem('historyState') === 'curAlarmQueryConditionId') {
      if (this.alarmService.curAlarmPageInfo.urlInfo === undefined) {
        return 1;
      } else {
        return this.alarmService.curAlarmPageInfo.urlInfo.currentPage;
      }

    } else {
      return 1;
    }
  }


  queryParams(params: any, that: any) {

    let tmp = {
      level: undefined,
      alarmConfirmOperator: undefined,
      beginTime: undefined,
      endTime: undefined,
      objectType: undefined,
      objectId: undefined,
      alarmRootType: undefined,
      alarmType: undefined,
      alarmConfirmState: undefined,
      onlyHidden: that.alarmHiddenFlag,
      impact: undefined,
      objectTopo: undefined,
      onlyUnknown: undefined,

      pageSize: params.limit,
      currentPage: params.offset / params.limit + 1,
      fuzzy: params.search
    };

    if (that.alarmService.curAlarmPageInfo.from === 'curAlarmDetail'
      || window.localStorage.getItem('historyState') === 'curAlarmQueryConditionId') {
      window.localStorage.removeItem('historyState');
      if (that.alarmService.curAlarmPageInfo.urlInfo === undefined) {
        that.SetUrlParamByOption(that, tmp);
      } else {
        tmp = that.alarmService.curAlarmPageInfo.urlInfo;
        that.RestoreFromSubPage(that, tmp);
      }
    } else {
      that.SetUrlParamByOption(that, tmp);
    }

    that.SetExportData(that, tmp);

    that.isShowLoading = true;
    return tmp;
  }

  RestoreFromSubPage(that: any, urlInfo: any) {
    //urlInfo = that.alarmService.curAlarmPageInfo.urlInfo;

    //Restore From Page

    that.alarmLevel = (urlInfo.level === undefined) ? 'ALL' : urlInfo.level;

    that.alarmRootType = (urlInfo.alarmRootType === undefined) ? 'ALL' : urlInfo.alarmRootType;

    that.alarmConfirmOperator = (urlInfo.alarmConfirmOperator === undefined) ? 'ALL' : urlInfo.alarmConfirmOperator;

    that.currentAlarmPeriod = that.alarmService.curAlarmPageInfo.currentAlarmPeriod;
    that.absoluteTimeEnd = that.alarmService.curAlarmPageInfo.absoluteTimeEndForShow;
    that.absoluteTimeStart = that.alarmService.curAlarmPageInfo.absoluteTimeStartForShow;

    that.objectType = (urlInfo.objectType === undefined) ? 'ALL' : urlInfo.objectType;
    that.alarmTyp = (urlInfo.alarmType === undefined) ? 'ALL' : urlInfo.alarmType;
    that.alarmConfirmState = (urlInfo.alarmConfirmState === undefined) ? 'ALL' : urlInfo.alarmConfirmState;
    that.onlyHidden = urlInfo.alarmHiddenFlag;
    that.impactSystem = (urlInfo.impact === undefined) ? 'ALL' : urlInfo.impact;
    that.objectTopo = (urlInfo.objectTopo === undefined) ? undefined : urlInfo.objectTopo;
    that.hotKeyToggle = (urlInfo.onlyUnknown === undefined) ? undefined : urlInfo.onlyUnknown;

    if (urlInfo.fuzzy !== undefined) {
      $('.bootstrap-table .search input').val(urlInfo.fuzzy);
    }


    if (that.currentAlarmPeriod === this.translate.instant('fm.customTime')) {
      that.absoluteTimeFlag = true;
    } else {
      that.absoluteTimeFlag = false;
      that.timeErr = false;
    }

    that.alarmService.curAlarmPageInfo.from = '';

  }


  SetUrlParamByOption(that: any, tmp: any) {

    const timeStamp = that.alarmService.getHistoryAlarmTime(that.currentAlarmPeriod, that.absoluteTimeStart, that.absoluteTimeEnd);

    //tmp.level = (that.currentAlarmLevel !== undefined)? that.currentAlarmLevel:undefined;
    //from dashboard
    if (that.currentAlarmLevel !== undefined && that.dashboradflag) {
      that.alarmLevel = that.currentAlarmLevel;
      //flag is used for only once
      that.dashboradflag = false;
    }
    //form health test
    tmp.objectId = that.objectId !== undefined ? that.objectId : undefined;

    tmp.level = (that.alarmLevel !== 'ALL') ? that.alarmLevel : tmp.level;

    tmp.alarmRootType = (that.alarmRootType !== 'ALL') ? that.alarmRootType : undefined;

    tmp.alarmType = (that.alarmTyp !== 'ALL') ? that.alarmTyp : undefined;
    tmp.alarmConfirmState = (that.alarmConfirmState !== 'ALL') ? that.alarmConfirmState : undefined;
    tmp.alarmConfirmOperator = (that.alarmConfirmOperator !== 'ALL') ? that.alarmConfirmOperator : undefined;
    tmp.beginTime = (timeStamp.beginTime !== '') ? timeStamp.beginTime : undefined;
    tmp.endTime = (timeStamp.endTime !== '') ? timeStamp.endTime : undefined;
    tmp.objectType = (that.objectType !== 'ALL') ? that.objectType : undefined;
    tmp.onlyHidden = that.alarmHiddenFlag;
    tmp.impact = (that.impactSystem !== 'ALL') ? that.impactSystem : undefined;
    tmp.objectTopo = (that.objectTopo !== undefined) ? that.objectTopo : undefined;
    tmp.onlyUnknown = (that.hotKeyToggle !== false) ? that.hotKeyToggle : undefined;


    this.alarmService.curHiddenFlag = tmp.onlyHidden;

  }

  SetExportData(that: any, currentPageInfo: any) {

    that.exportData.currentPageInfo = currentPageInfo;
    that.exportData.frontUrl = `/api/v1.0/fm/alarms/file/csv?` + that.alarmService.ObjectToUrl(currentPageInfo);
    that.exportData.title = this.translate.instant('fm.exportcurrentalarm');
    that.exportData.allPage = 1;
  }

  RecordCurPageInfo(that: any) {
    that.alarmService.curAlarmPageInfo.urlInfo = that.exportData.currentPageInfo;

    //for show
    that.alarmService.curAlarmPageInfo.currentAlarmPeriod = that.currentAlarmPeriod;
    that.alarmService.curAlarmPageInfo.absoluteTimeEndForShow = that.absoluteTimeEnd;
    that.alarmService.curAlarmPageInfo.absoluteTimeStartForShow = that.absoluteTimeStart;
  }


  getCurrentAlarms() {
    $('#table-current').bootstrapTable('destroy');
    this.initTable();
    this.hideFootBtns();
    $('.bootstrap-table .table').css('margin-top', '10px');
  }


  prepareExportInfo() {
    this.curExportDate = new Date();
  }

  sureDel() {
    this.deleteCurAlarms();

  }

  constructor(private alarmService: AlarmService, private router: Router,
              private storageService: StorageService, private activatedRoute: ActivatedRoute,
              private translate: TranslateService, private authService: AuthService,
              private userService: UserService, private  http: Http) {
    const that = this;

    this.activatedRoute.params.subscribe(params => {
      //form cloudPage
      this.currentAlarmLevel = params['alarmLevel'];
      // from healty test
      if (params.objectType !== undefined) {
        that.objectTypeOps = params['objectType'];
        that.objectType = that.objectTypeOps;
      }
      if (params.objectTopo !== undefined) {
        that.objectTopo = params['objectTopo'];
      }
      if (params.objectId !== undefined) {
        this.objectId = params.objectId;
        this.titleFromhealtyTest = true;
      }
      this.objectName = params.objectName;
      this.objectPath = params.objPath;
    });

    if (that.alarmService.lang === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }

    this.window.operateEvents = {
      'click .detail': function (e, value, row, index) {
        //const id = row.self.split('/').pop();
        //const faultmodeid = row.faultmodeid;
        //const alarmRootType = row.alarmRootType;
        const alarmDetail = {
          'alarmId': row.self.split('/').pop(),
          'faultModelId': row.faultModelId,
          //'alarmRootType':row.alarmRootType,
          'titleFromhealty': that.titleFromhealtyTest,
          'objectName': that.objectName,
          'objectPath': that.objectPath,
          'objectId': that.objectId,
        };
        that.RecordCurPageInfo(that);

        if (that.titleFromhealtyTest === true) {
          that.router.navigate(['/main/insight/health/health-detail/alarm/detail', alarmDetail]);
        } else {
          that.router.navigate(['/main/alarm/currentalarm/detail', alarmDetail]);
          const state = 'curAlarmQueryConditionId';
          window.history.pushState(state, null, '/main/alarm/currentalarm');
        }


      },
      'click .confirm': function (e, value, row, index) {
        $('#table-current').bootstrapTable('check', index);
        that.alarmConfirm();
      },
      'click .unconfirm': function (e, value, row, index) {
        $('#table-current').bootstrapTable('check', index);
        that.alarmUnConfirm();
      },
      'click .clear': function (e, value, row, index) {
        $('#table-current').bootstrapTable('check', index);
      },
      'mouseover .impactLevel': function (e, value, row, index) {
        $('.tip-toggle').eq(index).css('opacity', '1.0');
      },
      'mouseout .impactLevel': function (e, value, row, index) {
        $('.tip-toggle').eq(index).css('opacity', '0');
      }
    };
  }

  initTable() {
    const that = this;
    that.gridOptions.pageNumber = that.getPage();
    let tempColumnDefs: any = _.clone(that.columnDefs);
    if ((!that.authService.containSomeRights(['Current Alarm#DELETE', 'Current Alarm Confirm#PUT'])) || this.alarmHiddenFlag) {
      tempColumnDefs = _.filter(tempColumnDefs, function (x) {
        return x.field !== 'operate';
      });
      tempColumnDefs.shift();

      if (this.alarmHiddenFlag) {
        tempColumnDefs = _.filter(tempColumnDefs, function (x) {
          return x.field !== 'confirmStatus';
        });
      }
    }


    if (that.titleFromhealtyTest === true) {
      tempColumnDefs = _.filter(tempColumnDefs, function (x) {
        return x.field !== 'objectType' && x.field !== 'alarmObject';
      });
    }

    this.gridOptions.columns = tempColumnDefs;

    $('#table-current').bootstrapTable($.extend(this.gridOptions, {
      ajaxOptions: {
        beforeSend: function (xhr) {
          const accessToken = window.localStorage.directoraccessToken;
          const username = window.localStorage.directorusername;
          xhr.setRequestHeader('access-token', accessToken);
          xhr.setRequestHeader('operateuser', username);
        }
      },
      //url: appConfig.fmServiceUrl + 'alarms',
      toolbar: '#toolbar1',
      dataField: 'alarms',
      responseHandler: function (res) {

        that.exportData.allPage = Math.ceil(res.total / this.pageSize);

        if (res.total === 0) {
          $('.fixed-table-footerButtons').css('display', 'none');
        } else {
          $('.fixed-table-footerButtons').css('display', 'block');
          $('#delete-curalarm-btn').prop('disabled', true);
          $('#confirm-curalarm-btn').prop('disabled', true);
          $('#unconfirm-curalarm-btn').prop('disabled', true);
          //$('#table-current').bootstrapTable('uncheckAll');
        }

        that.isShowLoading = false;

        return res;
      }
    }));

    $('.bootstrap-table .search input').attr('placeholder', that.translate.instant('fm.importKey'))
      .parent().append(`<span></span>`);

    if ($('#table-current').parents('.fixed-table-container')[0].children.length === 4) {
      $('#table-current').parents('.fixed-table-container').append(`<div class="fixed-table-footerButtons">
        <button id="delete-curalarm-btn"  data-target="#DelConfirm" data-toggle="modal" disabled>
        ${that.translate.instant('Delete')}
        </button>
        <button id="confirm-curalarm-btn" disabled>${that.translate.instant('Confirm')}</button>
        <button id="unconfirm-curalarm-btn" disabled>${that.translate.instant('fm.unconfirm')}</button>
      </div>`);
    }

    $('#table-current').on('check.bs.table uncheck.bs.table ' +
      'check-all.bs.table uncheck-all.bs.table', function () {
      $('#delete-curalarm-btn').prop('disabled', !$('#table-current').bootstrapTable('getSelections').length);
    });

    $('#table-current').on('check.bs.table uncheck.bs.table ' +
      'check-all.bs.table uncheck-all.bs.table', function () {
      $('#confirm-curalarm-btn').prop('disabled', !$('#table-current').bootstrapTable('getSelections').length);
    });

    $('#table-current').on('check.bs.table uncheck.bs.table ' +
      'check-all.bs.table uncheck-all.bs.table', function () {
      $('#unconfirm-curalarm-btn').prop('disabled', !$('#table-current').bootstrapTable('getSelections').length);
    });

    $('#table-current').on('check-all.bs.table uncheck-all.bs.table', function () {
      $('.fixed-table-footerButtons .checkAll').prop('checked', $('#table-current').bootstrapTable('getSelections').length > 0);
    });

    $('.bootstrap-table .fixed-table-footerButtons .checkAll').change(function () {
      if ($(this).prop('checked')) {
        $('#table-current').bootstrapTable('checkAll');
      } else {
        $('#table-current').bootstrapTable('uncheckAll');
      }
    });

    $('#confirm-curalarm-btn').click(function () {
      that.alarmConfirm();
    });

    $('#unconfirm-curalarm-btn').click(function () {
      that.alarmUnConfirm();
    });

    $('#alarm-export-btn').click(function () {
      that.prepareExportInfo();
    });

    $('#table-current').on('check.bs.table check-all.bs.table', function (e, row) {
      that.addObjects(row);
    });

    $('#table-current').on('uncheck.bs.table uncheck-all.bs.table', function (e, row) {
      that.deleteObjects(row);
    });

    $('#table-current').on('load-success.bs.table', function () {
      that.setCheckbox();
    });
    $('.bootstrap-table .fixed-table-footerButtons').css('margin-left', '20px');

  }


  //select row
  setCheckbox() {
    //if (this.latestNode.checkAll) { this.isSelectAll = true; }
    const that = this;
    const currentPageDatas: any[] = $('#table-current').bootstrapTable('getData');
    for (let i = 0; i < currentPageDatas.length; i++) {
      const index = _.findIndex(that.selectedRows, function (item) {
        return item.self === currentPageDatas[i].self;
      });
      if (index !== -1) {
        $('#table-current').bootstrapTable('check', i);
      }
    }
  }

  addObjects(row: any) {
    const that = this;
    if (_.isArray(row)) {
      _.each(row, function (item) {
        that.addObj(item);
      });
    } else {
      this.addObj(row);
    }

  }

  addObj(obj: any) {
    if (this.containRow(obj)) return;
    this.selectedRows.push(obj);
  }

  containRow(row: any) {
    const index = _.findIndex(this.selectedRows, function (item) {
      return item.self === row.self;
    });

    return index !== -1;
  }

  deleteObjects(row: any) {
    const that = this;
    if (_.isArray(row)) {
      _.each(row, function (item) {
        that.deleteObj(item);
      });
    } else {
      this.deleteObj(row);
    }
  }

  deleteObj(obj: any) {
    if (!this.containRow(obj)) return;
    const index = _.findIndex(this.selectedRows, function (item) {
      return item.self === obj.self;
    });
    this.selectedRows.splice(index, 1);
  }

// Time
  checkAbsoluteTimerErr() {
    this.timeErr = (this.absoluteTimeStart > this.absoluteTimeEnd) ? true : false;
  }

  absoluteTimeStartHandle(event: any) {
    this.absoluteTimeStart = event.target.value;
    this.checkAbsoluteTimerErr();

  }

  absoluteTimeEndHandle(event: any) {
    this.absoluteTimeEnd = event.target.value;
    this.checkAbsoluteTimerErr();
  }

  refreshQueryTimeType(data: any) {
    this.absoluteTimeFlag = data === this.translate.instant('fm.customTime');
    this.timeErr = false;
    this.InitAbsoluteTime();
  }

  InitAbsoluteTime() {
    const curDate = new Date();
    const beginDate = curDate;
    beginDate.setDate(curDate.getDate() - 1);
    this.absoluteTimeStart = this.serverTimeToLocalTime(beginDate);
    this.absoluteTimeEnd = this.serverTimeToLocalTime(new Date());
  }

  serverTimeToLocalTime(inputIntTime: any) {
    let localTime = '';
    const offset: number = (new Date()).getTimezoneOffset();
    localTime = (new Date(inputIntTime - offset * 60000)).toISOString();
    localTime = localTime.substr(0, localTime.lastIndexOf('.'));
    localTime = localTime.replace('T', ' ');
    return localTime;
  }


  ngOnInit() {
    const that = this;
    this.alarmHiddenFlag = this.alarmService.curHiddenFlag;
    $('[data-toggle="tooltip"]').tooltip();
    this.handdelBtnLabel();
    this.alarmService.getPopstate();
    setTimeout(function () {
      that.initTable();
      that.hideFootBtns();
    }, 500);
    setTimeout(function () {
      that.isShowLoading = false;
    }, 5000);
  }

  handdelBtnLabel() {
    this.unconfirmBtnLabel = this.translate.instant('fm.unconfirm');
    this.unconfirmBtnLabel = this.lang === 'zh' ? this.unconfirmBtnLabel : this.unconfirmBtnLabel.substring(0, 8) + '...';
  }

  hideFootBtns() {
    if ((!this.authService.containEveryRights(['Current Alarm#DELETE'])) || this.alarmHiddenFlag) {
      $('#delete-curalarm-btn').remove();
    }
    if ((!this.authService.containEveryRights(['Current Alarm Confirm#PUT'])) || this.alarmHiddenFlag) {
      $('#confirm-curalarm-btn').remove();
      $('#unconfirm-curalarm-btn').remove();
    }
  }


  hideAlarmToggle() {
    this.alarmHiddenFlag = !this.alarmHiddenFlag;
    $('#table-current').bootstrapTable('destroy');
    this.initTable();
    this.hideFootBtns();
  }

  viewFilterRules() {
    this.router.navigate(['main/systemManage/systemConfig/alarmConfig/alarmFilterConfig']);
  }


  //删除
  deleteCurAlarms() {
    const that = this;
    that.batchDeleteAlarms().subscribe(() => {
      that.selectedRows = [];
      $('#table-current').bootstrapTable('refresh');
    });
  }

  batchDeleteAlarms() {
    const that = this;
    const selectedCurAlarms: any[] = that.selectedRows;
    return Observable.from(selectedCurAlarms).flatMap(item => {
      return that.deleteOneAlarm(item);
    });
  }

  deleteOneAlarm(item: any) {
    const url = item['self'];
    return this.http.delete(url);
  }


  cancleDel() {
    $('#table-current').bootstrapTable('uncheckAll');
    this.selectedRows = [];
  }


  alarmConfirm() {
    this.reason = '';
    this.modalTitle = this.translate.instant('fm.confirmAlarm');
    this.modalLable = this.translate.instant('fm.confirmDiscription');
    this.alarmType = 'confirmed';
    this.alarmService.setModalCenter('.confirm-modal-content');

    $('#confirmModal').modal('show');
  }


  alarmUnConfirm() {
    this.reason = '';
    this.modalTitle = this.translate.instant('fm.unconfirm');
    this.modalLable = this.translate.instant('fm.unconfirmDiscription');
    this.alarmType = 'unconfirmed';
    this.alarmService.setModalCenter('.confirm-modal-content');
    $('#confirmModal').modal('show');
  }

  confirm() {
    const data: any = {
      alarmIds: [],
      confirmation: {
        state: this.alarmType,
        reason: this.reason,
        operator: this.storageService.getUserName(),
        time: new Date()
      }
    };

    const that = this;


    const selectedCurAlarms: any[] = that.selectedRows;

    for (const item of selectedCurAlarms) {
      const alarmId = item.self.split('/').pop();
      data.alarmIds.push(alarmId);
    }

    that.alarmService.postAlarmComfirmInfo(data)
      .then((res: any) => {
        $('#table-current').bootstrapTable('refresh');
        that.selectedRows = [];
      });


    //$('#table-current').bootstrapTable('uncheck',that.row);
    $('#table-current').bootstrapTable('uncheckAll');
    $('#confirmModal').modal('hide');
  }

  cancle() {
    const that = this;
    $('#table-current').bootstrapTable('uncheckAll');
    that.selectedRows = [];
    $('#confirmModal').modal('hide');
  }

  ngAfterViewInit() {
    $('[data-toggle="tooltip"]').tooltip();
    this.alarmService.setDelModalCenter('#DelConfirm .modal-content');
  }

  test() {
    this.router.navigate(['/main/alarm/currentalarm/summary', {
      'objectId': 1,
      'objectName': 'vDirector',
      'objPath': 'main/insight/health/health-promote'
    }]);

  }

  test1() {
    this.router.navigate(['/main/alarm/currentalarm/gather', '1145373007212']);
  }

  test2() {
    this.router.navigate(['/main/alarm/currentalarm/gather', {
      'objectType': 'host',
      'objectTopo': '{\"dcId\":\"795d777d-9206-4d7d-861b-8249bee7440c\",\"envId\":\"49fb1bb6-70fe-4b31-9c8c-d23e5a0fde07\",' +
      '\"azId\":\"对象描述OPS_2\",\"haId\":\"OPS_2\",\"hostId\":\"host-192-11-1-14\",\"vmId\":\"3f8f0add-9189-46b0-8b56-ff037cce7bc5\"}'
    }]);
  }

  unknownHotKeyToggle() {
    this.hotKeyToggle = !this.hotKeyToggle;
    this.hotKeyToggle ? console.log('Hotkey Opened') : console.log('Hotkey Closed');
    $('#table-current').bootstrapTable('destroy');
    this.initTable();
    this.hideFootBtns();
  }

  getBackToHealthImprove() {
    this.router.navigate(['main/insight/health/health-promote']);
  }

  getBackToHealthImproveObject() {
    const param = this.objectPath.split(';');
    const cloudId = param[1].split('=')[1];
    const resourceType = param[2].split('=')[1];
    this.router.navigate(['/main/insight/health/health-detail', this.objectId,
      {'cloudId': cloudId, 'resourceType': resourceType}]);
  }

  gotoAnalysis() {
    this.router.navigate(['/main/insight/alarm/smart-analysis']);
  }
}
