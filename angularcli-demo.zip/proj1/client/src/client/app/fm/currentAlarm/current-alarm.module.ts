import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { KyLibModule } from '../../shared/kylib/index';
import { TooltipModule } from 'ng2-bootstrap/ng2-bootstrap';
import { PipesModule } from '../../shared/pipes/pipe.module';


import { routing } from './current-alarm.routes';

import { CurrentAlarmComponent } from './current-alarm.component';
import { CurrentAlarmDetailComponent } from './current-alarm-detail.component';
import {SharedModule} from '../../shared/shared.module';
import {AlarmPublicModule} from '../alarmPublic/alarmPublic.module';

@NgModule({
  imports: [AlarmPublicModule, CommonModule, SharedModule, FormsModule, HttpModule, KyLibModule, routing, TooltipModule, PipesModule],
  declarations: [CurrentAlarmComponent, CurrentAlarmDetailComponent],
  providers: [],
})

export class CurrentAlarmModule { }
