import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CurrentAlarmComponent } from './current-alarm.component';
import { CurrentAlarmDetailComponent } from './current-alarm-detail.component';


const routes: Routes = [
  {
    path: 'currentalarm',
    children: [
      {path: '', component: CurrentAlarmComponent},
      {path: 'summary', component: CurrentAlarmComponent},
      {path: 'summary/:alarmLevel', component: CurrentAlarmComponent},
      {path: 'gather', component: CurrentAlarmComponent},
      {path: 'detail', component: CurrentAlarmDetailComponent},
    ]
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
