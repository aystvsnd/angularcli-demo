import {Component, OnInit, AfterViewInit} from '@angular/core';
import {Router} from '@angular/router';
import {AlarmService} from '../alarm.service';
import '../../rxjs-operators';
import {appConfig} from '../../app.config';
import {TranslateService} from '@ngx-translate/core';
import {Observable} from 'rxjs/Observable';
import {ApiResourceService as Http} from '../../apiResource.service';
import {AuthService} from '../../core/auth.service';


@Component({
  moduleId: module.id,
  selector: 'history-alarm',
  templateUrl: 'history-alarm.component.html',
  styleUrls: ['../currentAlarm/current-alarm.component.css']
})

export class HistoryAlarmComponent implements OnInit, AfterViewInit {
  isSelectAll: boolean;
  check: Array<any>;
  itemList: Array<any>;
  selectItems: Array<any>;

  alarmLevels: any[] = [
    {name: this.translate.instant('fm.ALL'), value: 'ALL'},
    {name: this.translate.instant('fm.critical'), value: 'critical'},
    {name: this.translate.instant('fm.major'), value: 'major'},
    {name: this.translate.instant('fm.minor'), value: 'minor'},
    {name: this.translate.instant('fm.warning'), value: 'warning'},
  ];
  alarmLevel: any = 'ALL';

  objectTypes: any[] = [
    {name: this.translate.instant('fm.ALL'), value: 'ALL'},
    {name: 'cloudEnv', value: 'cloudEnv'}, {name: 'chassis', value: 'chassis'},
    {name: 'cloud', value: 'cloud'},
    {name: 'host', value: 'host'}, {name: 'rack', value: 'rack'},
    {name: 'router', value: 'router'}, {name: 'server', value: 'server'},
    {name: 'storage', value: 'storage'}, {name: 'switch', value: 'switch'},
    {name: 'vm', value: 'vm'}, {name: 'volume', value: 'volume'},
    {name: 'system', value: 'system'}
  ];
  objectType: any = 'ALL';

  alarmTypes: any[] = [
    {name: this.translate.instant('fm.ALL'), value: 'ALL'},
    {name: 'communicationsAlarm', value: 'communicationsAlarm'},
    {name: 'processingErrorAlarm', value: 'processingErrorAlarm'},
    {name: 'environmentalAlarm', value: 'environmentalAlarm'},
    {name: 'qualityOfServiceAlarm', value: 'qualityOfServiceAlarm'},
    {name: 'equipmentAlarm', value: 'equipmentAlarm'},
    {name: 'integrityViolation', value: 'integrityViolation'},
  ];
  alarmType: any = 'ALL';


  queryAlarmTimePeriods: any[] = [
    {name: this.translate.instant('fm.ALL'), value: 'ALL'},
    {name: this.translate.instant('fm.currentDay'), value: this.translate.instant('fm.currentDay')},
    {name: this.translate.instant('fm.oneHour'), value: this.translate.instant('fm.oneHour')},
    {name: this.translate.instant('fm.oneDay'), value: this.translate.instant('fm.oneDay')},
    {name: this.translate.instant('fm.oneWeek'), value: this.translate.instant('fm.oneWeek')},
    {name: this.translate.instant('fm.oneMonth'), value: this.translate.instant('fm.oneMonth')},
    {name: this.translate.instant('fm.customTime'), value: this.translate.instant('fm.customTime')}
  ];
  queryAlarmTimeTypes: any[] = [
    this.translate.instant('fm.alarmTime'),
    this.translate.instant('fm.recoverTime')
  ];
  historyAlarmType: any = this.translate.instant('fm.alarmTime');
  _historyAlarmPeriod: any = 'ALL';
  absoluteTimeFlag: boolean;
  absoluteTimeStart: Date = new Date();
  absoluteTimeEnd: Date = new Date();
  timeErr = false;
  delDcMessage: any = {
    title: this.translate.instant('fm.DeleteAlarm'),
    message: this.translate.instant('fm.delConfirm'),
    confirmText: this.translate.instant('Confirm'),
    cancelText: this.translate.instant('Cancel'),
    type: 'exclamation'
  };

  exportData: any = {
    historyPageInfo: {}
  };
  hisExportDate: Date;
  alarmHiddenFlag = false;

  rowData: any[];
  window: window = window;

  isShowLoading = true;
  loading: any = this.translate.instant('fm.loading');
  selectedRows: Array = [];
  impactSystems: any[] = [
    {name: this.translate.instant('fm.ALL'), value: 'ALL'},
    {name: 'Health', value: 'health'},
    {name: 'Risk', value: 'risk'},
    {name: 'Efficiency', value: 'efficiency'}
  ];

  impactSystem: any = 'ALL';
  tipToolCol: any = `position: relative;cursor: pointer;`;
  alertIconTip: any = `display: inline-block;
    width:20px;
    height:20px;
    background-image: url('assets/images/alert_icon_all.png');
    background-repeat: no-repeat;
    position:relative;top:3px;`;
  fontPosition: any = `position:relative;top:-4px;`;

  tip_tag: any = `display:inline-block;
  opacity:0;
  -moz-opacity:0;
  filter:Alpha(opacity=0);
  position:absolute;
  left:50%;color:#000;white-space:nowrap;transform: translate(-50%,-50%);`;
  tip_area: any = `height:24px;
  padding:0 10px;
  border:1px solid #e6e6e6;`;
  tip_areaCopy: any = `height:24px;
  padding:0 10px;`;
  tip_arrow: any = `float:left;
  position:relative;
  left:50%;`;
  tip_angle: any = `position:relative;
  left:-50%;
  top: -11px;
  display:inline-block;
  width:0px;
  height:0px;
  border-left:4px solid transparent;
  border-right:4px solid transparent;
  border-top:4px solid #e6e6e6;`;
  tip_angleWhite: any = `position: relative;
    left: -4px;
    top: -20px;
    display: block;
    width: 0px;
    height: 0px;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 4px solid #fff;`;
  objTypeIcon: any = `width:20px;height:20px;margin-right:5px;`;
  hotKeyToggle = false;

  gridOptions: any = {
    method: 'get',
    queryParams: params => this.queryParams(params, this),
    //columns: this.columnDefs,
    columns: this.columnDefs1(this),
    sidePagination: 'server',
    pagination: true, //是否开启分页
    pageSize: 10, //单页数量
    pageNumber: 1,
    pageList: [10, 20],
    paginationDetailHAlign: 'left', //分页详情水平位置
    paginationHAlign: 'left', //分页条水平位置
    sortable: true, //是否开启排序,
    sortOrder: 'asc',
    search: true,
    //toolbar: '#toolbar1'
    //searchText:'输入关键字筛选'
  };


  getPage() {
    if (this.alarmService.hisAlarmPageInfo.from === 'hisAlarmDetail'
      || window.localStorage.getItem('historyState') === 'hisAlarmQueryConditionId') {
      return this.alarmService.hisAlarmPageInfo.urlInfo.currentPage;
    } else {
      return 1;
    }
  }

  columnDefs1(that: any) {

    const columnDefs: any[] = [
      {
        checkbox: true
      },
      {
        field: 'name',
        align: 'center',
        title: this.translate.instant('fm.Sequence'),
        formatter: function (value, row, index) {
          return index + 1;
        }
      },
      {
        field: 'level',
        align: 'center',
        width: 100,
        title: this.translate.instant('fm.impact_level'),
        events: 'operateEvents',
        formatter: function (value, row, index) {
          const levelVaule = value.toLowerCase();
          if (levelVaule === 'critical' && row.impact === 'health') {
            return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span style="${that.alertIconTip}"></span>
                    <div style="${that.tip_tag}" class="tipToggle">
                     <div style="${that.tip_area}">
                     ${that.translate.instant('fm.impact_health')}&nbsp:&nbsp${that.translate.instant('fm.critical')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                 <div>`;
          } else if (levelVaule === 'critical' && row.impact === 'risk') {
            return `<div style="${that.tipToolCol}" class="impactLevel">
                   <span style="${that.alertIconTip}background-position:0px -22px;"></span>
                    <div style="${that.tip_tag}" class="tipToggle">
                     <div style="${that.tip_area}">
                     ${that.translate.instant('fm.impact_risk')}&nbsp:&nbsp${that.translate.instant('fm.critical')}</div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  <div>`;
          } else if (levelVaule === 'critical' && row.impact === 'efficiency') {
            return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:0px -42px;"></span>
                    <div style="${that.tip_tag}" class="tipToggle">
                     <div style="${that.tip_area}">
                     ${that.translate.instant('fm.impact_efficiency')}&nbsp:&nbsp${that.translate.instant('fm.critical')}</div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
          } else if (levelVaule === 'critical' && (row.impact !== 'health' || row.impact !== 'risk' || row.impact !== 'efficiency')) {
            return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:0px -62px;"></span>
                   <div style="${that.tip_tag}" class="tipToggle">
                     <div style="${that.tip_area}">
                     ${that.translate.instant('fm.level')}&nbsp:&nbsp${that.translate.instant('fm.critical')}</div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
          } else if (levelVaule === 'major' && row.impact === 'health') {
            return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:-20px 0px;"></span>
                  <div style="${that.tip_tag}" class="tipToggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.impact_health')}&nbsp:&nbsp${that.translate.instant('fm.major')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  <div>`;
          } else if (levelVaule === 'major' && row.impact === 'risk') {
            return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:-20px -22px;"></span>
                  <div style="${that.tip_tag}" class="tipToggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.impact_risk')}&nbsp:&nbsp${that.translate.instant('fm.major')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
          } else if (levelVaule === 'major' && row.impact === 'efficiency') {
            return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:-20px -42px;"></span>
                  <div style="${that.tip_tag}" class="tipToggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.impact_efficiency')}&nbsp:&nbsp${that.translate.instant('fm.major')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
          } else if (levelVaule === 'major' && (row.impact !== 'health' || row.impact !== 'risk' || row.impact !== 'efficiency')) {
            return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:-20px -62px;"></span>
                   <div style="${that.tip_tag}" class="tipToggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.level')}&nbsp:&nbsp${that.translate.instant('fm.major')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
          } else if (levelVaule === 'minor' && row.impact === 'health') {
            return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:-40px 0px;"></span>
                  <div style="${that.tip_tag}" class="tipToggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.impact_health')}&nbsp:&nbsp${that.translate.instant('fm.minor')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  <div>`;
          } else if (levelVaule === 'minor' && row.impact === 'risk') {
            return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:-40px -22px;"></span>
                  <div style="${that.tip_tag}" class="tipToggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.impact_risk')}&nbsp:&nbsp${that.translate.instant('fm.minor')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  <div>`;
          } else if (levelVaule === 'minor' && row.impact === 'efficiency') {
            return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span style="${that.alertIconTip}background-position:-40px -42px;" ></span>
                   <div style="${that.tip_tag}" class="tipToggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.impact_efficiency')}&nbsp:&nbsp${that.translate.instant('fm.minor')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
          } else if (levelVaule === 'minor' && (row.impact !== 'health' || row.impact !== 'risk' || row.impact !== 'efficiency')) {
            return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:-40px -62px;"></span>
                   <div style="${that.tip_tag}" class="tipToggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.level')}&nbsp:&nbsp${that.translate.instant('fm.minor')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
          } else if (levelVaule === 'warning' && row.impact === 'health') {
            return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:-60px 0px;'"></span>
                   <div style="${that.tip_tag}" class="tipToggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.impact_health')}&nbsp:&nbsp${that.translate.instant('fm.warning')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  <div>`;
          } else if (levelVaule === 'warning' && row.impact === 'risk') {
            return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span style="${that.alertIconTip}background-position:-60px -22px;"></span>
                   <div style="${that.tip_tag}" class="tipToggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.impact_risk')}&nbsp:&nbsp${that.translate.instant('fm.warning')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
          } else if (levelVaule === 'warning' && row.impact === 'efficiency') {
            return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span style="${that.alertIconTip}background-position:-60px -42px;"></span>
                   <div style="${that.tip_tag}" class="tipToggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.impact_efficiency')}&nbsp:&nbsp${that.translate.instant('fm.warning')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
          } else if (levelVaule === 'warning' && (row.impact !== 'health' || row.impact !== 'risk' || row.impact !== 'efficiency')) {
            return `<div style="${that.tipToolCol}" class="impactLevel">
                  <span  style="${that.alertIconTip}background-position:-60px -62px;"></span>
                   <div style="${that.tip_tag}" class="tipToggle">
                     <div style="${that.tip_area}">
                    ${that.translate.instant('fm.level')}&nbsp:&nbsp${that.translate.instant('fm.warning')}
                     </div>
                      <div style="${that.tip_areaCopy}">
                       <div style="${that.tip_arrow}">
                         <span style="${that.tip_angle}"></span>
                         <span style="${that.tip_angleWhite}"></span>
                       </div>
                      </div>
                   </div>
                  </div>`;
          } else {
            return `<div class="impactLevel"><div style class="tipToggle"></div>-</div>`;
          }
        }
      },
      {
        field: 'description',
        align: 'left',
        title: this.translate.instant('fm.description'),
        events: 'operateEvents',
        formatter: function (value, row, index) {
          return `<a href="javascript:void(0);" class="detail">${value}</a>`;
        }
      },
      {
        field: 'objectType',
        align: 'left',
        cellStyle: () => {
          return {
            css: {'min-width': '140px'}
          };
        },
        title: this.translate.instant('fm.objectType'),
        formatter: function (value, row, index) {
          switch (value) {
            case 'cloudEnv':
              return `<img src="assets/images/alarmObj/alarm_cloudenv.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
            case 'chassis':
              return `<img src="assets/images/alarmObj/alarm_chassis.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
            case 'cloud':
              return `<img src="assets/images/alarmObj/alarm_cloudenv.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
            case 'host':
              return `<img src="assets/images/alarmObj/alarm_host.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
            case 'rack':
              return `<img src="assets/images/alarmObj/alarm_rack.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
            case 'router':
              return `<img src="assets/images/alarmObj/alarm_router.svg" style="${that.objTypeIcon}"  /><span>${value}</span>`;
            case 'server':
              return `<img src="assets/images/alarmObj/alarm_server.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
            case 'storage':
              return `<img src="assets/images/alarmObj/alarm_storage.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
            case 'switch':
              return `<img src="assets/images/alarmObj/alarm_switch.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
            case 'vm':
              return `<img src="assets/images/alarmObj/alarm_vm.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
            case 'volume':
              return `<img src="assets/images/alarmObj/alarm_volume.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
            case 'system':
              return `<img src="assets/images/alarmObj/alarm_system.svg" style="${that.objTypeIcon}" /><span>${value}</span>`;
            case 'default':
              console.log('no this objectType');
          }
        }
      },
      {
        field: 'alarmObject',
        title: this.translate.instant('fm.objectName'),
        formatter: function (value, row, index) {
          const value1 = value.split(',').pop();
          const value2 = value.split(',').join('\r\n');
          return `<pre data-toggle="tooltip" data-placement="top" title="${value2}">${value1}</pre>`;
        }
      },
      {
        field: 'alarmType',
        align: 'left',
        title: this.translate.instant('fm.alarmType'),
      },
      {
        field: 'alarmTime',
        align: 'left',
        title: this.translate.instant('fm.alarmTime'),
        cellStyle: () => {
          return {
            css: {'min-width': '140px'}
          };
        },
        formatter: function (value, row, index) {
          value = Date.parse(value);
          let localTime = '';
          const offset: number = (new Date()).getTimezoneOffset();
          localTime = (new Date(value - offset * 60000)).toISOString();
          localTime = localTime.substr(0, localTime.lastIndexOf('.'));
          localTime = localTime.replace('T', ' ');
          return localTime;
        }
      },
      {
        field: 'restoreTime',
        align: 'left',
        title: this.translate.instant('fm.recoverTime'),
        cellStyle: () => {
          return {
            css: {'min-width': '140px'}
          };
        },
        formatter: function (value, row, index) {
          value = Date.parse(value);
          let localTime = '';
          const offset: number = (new Date()).getTimezoneOffset();
          localTime = (new Date(value - offset * 60000)).toISOString();
          localTime = localTime.substr(0, localTime.lastIndexOf('.'));
          localTime = localTime.replace('T', ' ');
          return localTime;
        }
      },
      {
        field: 'confirmStatus',
        align: 'left',
        title: this.translate.instant('fm.restoreTime'),
        cellStyle: () => {
          return {
            css: {'min-width': '120px'}
          };
        },
        formatter: function (value, row, index) {
          return that.alarmService.calcComfirmTime(row.alarmTime, row.restoreTime);
        }
      },
      {
        title: this.translate.instant('fm.operation'),
        field: 'operate',
        events: 'operateEvents',
        cellStyle: () => {
          return {
            css: {'min-width': '150px'}
          };
        },
        align: 'center',
        cellStyle: () => {
          return {
            css: {'min-width': '150px'}
          };
        },
        formatter: function (value, row, index) {
          return `<button data-target="#DelAlarm" data-toggle="modal" class="clear btn btn-default ">
                ${that.translate.instant('Delete')}</button>`;
        }

      }

      //{
      //  field: 'additionalInfo',
      //  title: this.translate.instant('fm.additionalInfo'),
      //  formatter: function (value, row, index) {
      //    let value1 = value[0].substr(0,20)+'...';
      //    let value2 = value[0].split(',').join('\n');
      //    return `<pre data-toggle="tooltip" data-placement="top" title="${value2}">${value1}</pre>`;
      //  }
      //}
    ];

    return columnDefs;
  }


  queryParams(params: any, that: any) {


    let tmp = {
      level: undefined,
      alarmTimeType: that.alarmService.getHistoryAlarmTimeType(that.historyAlarmType, that._historyAlarmPeriod),
      beginTime: undefined,
      endTime: undefined,
      objectType: undefined,
      alarmType: undefined,
      onlyHidden: that.alarmHiddenFlag,
      impact: undefined,
      onlyUnknown: undefined,

      pageSize: params.limit,
      currentPage: params.offset / params.limit + 1,
      fuzzy: params.search,
    };

    // back from hisalarm detail page
    if (that.alarmService.hisAlarmPageInfo.from === 'hisAlarmDetail' ||
      window.localStorage.getItem('historyState') === 'hisAlarmQueryConditionId') {
      window.localStorage.removeItem('historyState');
      tmp = that.alarmService.hisAlarmPageInfo.urlInfo;
      that.RestoreFromSubPage(tmp, that);
    } else {
      that.SetUrlParamByOption(that, tmp);
    }

    that.SetExportData(tmp, that);

    that.isShowLoading = true;

    return tmp;
  }

  RestoreFromSubPage(urlInfo: any, that: any) {
    //for show
    $('.bootstrap-table .search input').val(that.alarmService.hisAlarmPageInfo.urlInfo.fuzzy);

    that.alarmLevel = (urlInfo.level === undefined) ? 'ALL' : urlInfo.level;
    that.historyAlarmType = that.alarmService.hisAlarmPageInfo.historyAlarmType;
    that.historyAlarmPeriod = that.alarmService.hisAlarmPageInfo.historyAlarmPeriod;
    that.absoluteTimeStart = that.alarmService.hisAlarmPageInfo.absoluteTimeStartForShow;
    that.absoluteTimeEnd = that.alarmService.hisAlarmPageInfo.absoluteTimeEndForShow;
    that.objectType = (urlInfo.objectType === undefined) ? 'ALL' : urlInfo.objectType;
    that.alarmType = (urlInfo.alarmType === undefined) ? 'ALL' : urlInfo.alarmType;
    that.alarmHiddenFlag = urlInfo.onlyHidden;
    that.impactSystem = (urlInfo.impact === undefined) ? 'ALL' : urlInfo.impact;
    that.hotKeyToggle = (urlInfo.onlyUnknown === undefined) ? undefined : urlInfo.onlyUnknown;
    that.alarmService.hisAlarmPageInfo.from = '';

    if (that._historyAlarmPeriod === this.translate.instant('fm.customTime')) {
      that.absoluteTimeFlag = true;
    } else {
      that.absoluteTimeFlag = false;
      that.timeErr = false;
    }
  }


  SetUrlParamByOption(that: any, tmp: any) {

    const timeStamp = that.alarmService.getHistoryAlarmTime(that._historyAlarmPeriod, that.absoluteTimeStart, that.absoluteTimeEnd);
    tmp.level = (that.alarmLevel !== 'ALL') ? that.alarmLevel : undefined;
    tmp.beginTime = (timeStamp.beginTime !== '') ? timeStamp.beginTime : undefined;
    tmp.endTime = (timeStamp.endTime !== '') ? timeStamp.endTime : undefined;
    tmp.objectType = (that.objectType !== 'ALL') ? that.objectType : undefined;
    tmp.alarmType = (that.alarmType !== 'ALL') ? that.alarmType : undefined;
    tmp.onlyHidden = that.alarmHiddenFlag;
    tmp.impact = (that.impactSystem !== 'ALL') ? that.impactSystem : undefined;
    tmp.onlyUnknown = (that.hotKeyToggle !== false) ? that.hotKeyToggle : undefined;
    this.alarmService.hisHiddenFlag = tmp.onlyHidden;
  }

  SetExportData(historyPageInfo: any, that: any) {

    that.exportData.historyPageInfo = historyPageInfo;
    that.exportData.frontUrl = `/api/v1.0/fm/history_alarms/file/csv?` + that.alarmService.ObjectToUrl(historyPageInfo);
    that.exportData.title = this.translate.instant('fm.exportHistoryAlarm');
    that.exportData.allPage = 1;
  }

  RecordCurPageInfo(that: any) {

    that.alarmService.hisAlarmPageInfo.urlInfo = that.exportData.historyPageInfo;

    //for show
    that.alarmService.hisAlarmPageInfo.historyAlarmType = that.historyAlarmType;
    that.alarmService.hisAlarmPageInfo.historyAlarmPeriod = that.historyAlarmPeriod;
    that.alarmService.hisAlarmPageInfo.absoluteTimeEndForShow = that.absoluteTimeEnd;
    that.alarmService.hisAlarmPageInfo.absoluteTimeStartForShow = that.absoluteTimeStart;

  }


  prepareExportInfo() {
    this.hisExportDate = new Date();
  }

  initTable() {
    const that = this;
    that.gridOptions.pageNumber = that.getPage();
    let tempColumns = _.clone(that.columnDefs1(that));
    if ((!that.authService.containSomeRights(['History Alarm#DELETE'])) || that.alarmHiddenFlag) {
      tempColumns = _.filter(tempColumns, function (x) {
        return x.field !== 'operate';
      });
      tempColumns.shift();
    }
    that.gridOptions.columns = tempColumns;

    $('#table-history').bootstrapTable($.extend(this.gridOptions, {
      ajaxOptions: {
        beforeSend: function (xhr) {
          const accessToken = window.localStorage.directoraccessToken;
          const username = window.localStorage.directorusername;
          xhr.setRequestHeader('access-token', accessToken);
          xhr.setRequestHeader('operateuser', username);
        }
      },
      url: appConfig.fmServiceUrl + 'historyAlarmsWithDetail',
      dataField: 'alarms',
      responseHandler: function (res) {

        that.exportData.allPage = Math.ceil(res.total / this.pageSize);

        if (res.total === 0) {
          $('.fixed-table-footerButtons').css('display', 'none');
        } else {
          $('.fixed-table-footerButtons').css('display', 'block');
          $('#delete-hisalarm-btn').prop('disabled', true);
        }
        that.isShowLoading = false;

        return res;
      }
    }));

    $('.bootstrap-table .search input').attr('placeholder', that.translate.instant('fm.importKey'))
      .parent().append(`<span></span>`);
    /*  <input type="checkbox" class="checkAll">*/

    if ($('#table-history').parents('.fixed-table-container')[0].children.length === 4) {
      $('#table-history').parents('.fixed-table-container').append(`<div class="fixed-table-footerButtons">
        <button id="alarm-export-btn" style="margin-right:10px;" data-backdrop="static" data-target="#alarmExport" data-toggle="modal">
        ${that.translate.instant('fm.export')}</button></div>`);
      $('#table-history').parents('.fixed-table-container').append(`<div class="fixed-table-footerButtons">
        <button id="delete-hisalarm-btn"  data-target="#DelAlarm" data-toggle="modal" disabled>
        ${that.translate.instant('Delete')}
        </button>
     </div>`);
    }

    $('#table-history').on('check.bs.table uncheck.bs.table ' +
      'check-all.bs.table uncheck-all.bs.table', function () {
      $('#delete-hisalarm-btn').prop('disabled', !$('#table-history').bootstrapTable('getSelections').length);
    });


    $('#alarm-export-btn').click(function () {
      that.prepareExportInfo();
    });

    $('#table-history').on('check.bs.table check-all.bs.table', function (e, row) {
      that.addObjects(row);
    });

    $('#table-history').on('uncheck.bs.table uncheck-all.bs.table', function (e, row) {
      that.deleteObjects(row);
    });

    $('#table-history').on('load-success.bs.table', function () {
      that.setCheckbox();
    });
    $('#table-history').parents('.fixed-table-body').css('overflow-x', 'auto');
    $('#table-history').parents('.fixed-table-body').css('overflow-y', 'hidden');
  }

  //select row
  setCheckbox() {
    //if (this.latestNode.checkAll) { this.isSelectAll = true; }
    const that = this;
    const currentPageDatas: any[] = $('#table-history').bootstrapTable('getData');
    for (let i = 0; i < currentPageDatas.length; i++) {
      const index = _.findIndex(that.selectedRows, function (item) {
        return item.self === currentPageDatas[i].self;
      });
      if (index !== -1) {
        $('#table-history').bootstrapTable('check', i);
      }
    }
  }

  addObjects(row: any) {
    const that = this;
    if (_.isArray(row)) {
      _.each(row, function (item) {
        that.addObj(item);
      });
    } else {
      this.addObj(row);
    }

  }

  addObj(obj: any) {
    if (this.containRow(obj)) return;
    this.selectedRows.push(obj);
  }

  containRow(row: any) {
    const index = _.findIndex(this.selectedRows, function (item) {
      return item.self === row.self;
    });

    return index !== -1;
  }

  deleteObjects(row: any) {
    const that = this;
    if (_.isArray(row)) {
      _.each(row, function (item) {
        that.deleteObj(item);
      });
    } else {
      this.deleteObj(row);
    }
  }

  deleteObj(obj: any) {
    if (!this.containRow(obj)) return;
    const index = _.findIndex(this.selectedRows, function (item) {
      return item.self === obj.self;
    });
    this.selectedRows.splice(index, 1);
  }

  sureDel() {
    this.deleteCurAlarms();

  }

  //删除
  deleteCurAlarms() {
    const that = this;
    that.batchDeleteAlarms().subscribe(() => {
      that.selectedRows = [];
      $('#table-history').bootstrapTable('refresh');
    });
  }

  batchDeleteAlarms() {
    const that = this;
    const selectedCurAlarms: any[] = that.selectedRows;
    return Observable.from(selectedCurAlarms).flatMap(item => {
      return that.deleteOneAlarm(item);
    });
  }

  deleteOneAlarm(item: any) {
    const url = item['self'];
    return this.http.delete(url);
  }


  cancleDel() {
    $('#table-history').bootstrapTable('uncheckAll');
    this.selectedRows = [];
  }


  checkAbsoluteTimerErr() {
    this.timeErr = (this.absoluteTimeStart > this.absoluteTimeEnd) ? true : false;
  }

  absoluteTimeStartHandle(event: any) {
    this.absoluteTimeStart = event.target.value;
    this.checkAbsoluteTimerErr();

  }

  absoluteTimeEndHandle(event: any) {
    this.absoluteTimeEnd = event.target.value;
    this.checkAbsoluteTimerErr();
  }

  serverTimeToLocalTime(inputIntTime: any) {
    let localTime = '';
    const offset: number = (new Date()).getTimezoneOffset();
    localTime = (new Date(inputIntTime - offset * 60000)).toISOString();
    localTime = localTime.substr(0, localTime.lastIndexOf('.'));
    localTime = localTime.replace('T', ' ');
    return localTime;
  }


  set historyAlarmPeriod(historyAlarmPeriod: string) {
    this._historyAlarmPeriod = historyAlarmPeriod;
    if (historyAlarmPeriod === this.translate.instant('fm.customTime')) {
      this.absoluteTimeFlag = true;
    } else {
      this.absoluteTimeFlag = false;
      this.timeErr = false;
      this.InitAbsoluteTime();
    }
  }

  get historyAlarmPeriod() {
    return this._historyAlarmPeriod;
  }


  constructor(private alarmService: AlarmService, private router: Router,
              private translate: TranslateService, private  http: Http,
              private authService: AuthService) {
    const that = this;

    if (that.alarmService.lang === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }

    this.window.operateEvents = {
      'click .detail': function (e, value, row, index) {
        const id = row.self.split('/').pop();
        that.RecordCurPageInfo(that);
        that.router.navigate(['/main/alarm/historyalarm/detail', id]);
        const state = 'hisAlarmQueryConditionId';
        window.history.pushState(state, null, '/main/alarm/historyalarm');
      },
      'click .clear': function (e, value, row, index) {
        $('#table-history').bootstrapTable('check', index);
      },
      'mouseover .impactLevel': function (e, value, row, index) {
        $('.tipToggle').eq(index).css('opacity', '1.0');
      },
      'mouseout .impactLevel': function (e, value, row, index) {
        $('.tipToggle').eq(index).css('opacity', '0');
      }
    };
  }


  calcComfirmTime(startTime: Date, endTime: Date) {
    return this.alarmService.calcComfirmTime(startTime, endTime);
  }

  getHistoryAlarms() {
    //$('#table-history').bootstrapTable('refreshOptions',{pageNumber:1,pageSize:10});

    $('#table-history').bootstrapTable('destroy');
    this.initTable();
    this.hideFootBtns();
    $('.bootstrap-table .table').css('margin-top', '10px');
  }

  goToHistoryAlarmDetail(selectItem: any) {
    const id = selectItem.self.split('/').pop();
    this.router.navigate(['/main/alarm/historyalarm/detail', id]);
  }


  InitAbsoluteTime() {
    const curDate = new Date();
    const beginDate = curDate;
    beginDate.setDate(curDate.getDate() - 1);
    this.absoluteTimeStart = this.serverTimeToLocalTime(beginDate);
    this.absoluteTimeEnd = this.serverTimeToLocalTime(new Date());
  }


  ngOnInit() {
    let that = this;
    this.alarmHiddenFlag = this.alarmService.hisHiddenFlag;
    this.InitAbsoluteTime();
    this.alarmService.getPopstate();
    setTimeout(function () {
      that.initTable();
      that.hideFootBtns();
    }, 500);
    setTimeout(function () {
      that.isShowLoading = false;
    }, 5000);
  }

  ngAfterViewInit() {
    this.alarmService.setDelModalCenter('#DelAlarm .modal-content');
  }


  hideFootBtns() {
    if ((!this.authService.containEveryRights(['History Alarm#DELETE'])) || this.alarmHiddenFlag) {
      $('#delete-hisalarm-btn').remove();
    }
  }


  hideAlarmToggle() {
    this.alarmHiddenFlag = !this.alarmHiddenFlag;
    $('#table-history').bootstrapTable('destroy');
    this.initTable();
    this.hideFootBtns();
  }

  viewFilterRules() {
    this.router.navigate(['main/systemManage/systemConfig/alarmConfig/alarmFilterConfig']);
  }

  unknownHotKeyToggle() {
    this.hotKeyToggle = !this.hotKeyToggle;
    this.hotKeyToggle ? console.log('Hotkey Opened') : console.log('Hotkey Closed');
    $('#table-history').bootstrapTable('destroy');
    this.initTable();
    this.hideFootBtns();
  }

}
