import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { KyLibModule } from '../../shared/kylib/index';
import { TooltipModule } from 'ng2-bootstrap/ng2-bootstrap';
import { PipesModule } from '../../shared/pipes/pipe.module';

import {AlarmPublicModule} from '../alarmPublic/alarmPublic.module';
import { routing } from './history-alarm.routes';


import { AlarmService } from '../alarm.service';


import { HistoryAlarmComponent } from './history-alarm.component';
import { HistoryAlarmDetailComponent } from './history-alarmDetail.component';
import {SharedModule} from '../../shared/shared.module';

@NgModule({
  imports: [AlarmPublicModule, SharedModule, CommonModule, FormsModule,
    HttpModule, KyLibModule, routing, TooltipModule, PipesModule],
  declarations: [HistoryAlarmComponent, HistoryAlarmDetailComponent],
  providers: [AlarmService],
})

export class HistoryAlarmModule { }
