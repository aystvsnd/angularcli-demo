
import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HistoryAlarmComponent } from './history-alarm.component';
import { HistoryAlarmDetailComponent } from './history-alarmDetail.component';


const routes: Routes = [
  {
    path: 'historyalarm',
    children: [
      {path: '', component: HistoryAlarmComponent},
      {path: 'summary', component: HistoryAlarmComponent},
      {path: 'detail/:alarmId', component: HistoryAlarmDetailComponent},
    ]
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
