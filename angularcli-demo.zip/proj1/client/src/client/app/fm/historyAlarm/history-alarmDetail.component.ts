import {Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { AlarmService } from '../alarm.service';
import { Router } from '@angular/router';
import {Subject} from 'rxjs/Subject';
import '../../rxjs-operators';

@Component({
  moduleId: module.id,
  selector: 'history-alarm-detail',
  templateUrl: 'history-alarmDetail.component.html',
  styleUrls: ['history-alarmDetail.component.css'],
})

export class HistoryAlarmDetailComponent implements OnInit {
  historyAlarmId: any;
  historyAlarmDetail: any = {};
  supportQos = false;
  trendChartSubject: Subject<any> = new Subject<any>();

  constructor(private alarmService: AlarmService, private router: Router, private activatedRoute: ActivatedRoute) {
    this.activatedRoute.params.subscribe(params => {
      this.historyAlarmId = params['alarmId'];
    });
  }

  getBackToAlarm() {
    this.router.navigate(['/main/alarm/currentalarm']);
  }

  getBackToHisAlarm() {
    this.alarmService.hisAlarmPageInfo.from = 'hisAlarmDetail';
    this.router.navigate(['/main/alarm/historyalarm']);
  }

  ngOnInit() {
    this.getHistoryAlarmsDetail();
  }

  getHistoryAlarmsDetail() {
    const that = this;
    this.alarmService.getHistoryAlarmsDetailById(this.historyAlarmId).then((res: any) => {
      if (res.otherInfo === '' || res.otherInfo === null) {
        that.supportQos = false;
      } else {
        const otherInfo: any = JSON.parse(res.otherInfo);
        let counterSn = '';
        if (_.has(otherInfo, 'sn')) {
          counterSn = otherInfo.sn;
        }
        if (_.has(otherInfo, 'value')) {
          counterSn = otherInfo.value;
        }
        if (counterSn !== '') {
          that.supportQos = true;
          const qosData: any = {
            loadChart: true,
            sn: counterSn,
            cloudEnvId: _.has(JSON.parse(res.topo), 'cloudEnvId') ? (JSON.parse(res.topo)).cloudEnvId : '',
            objectId: res.objectId,
            timeStamp: res.alarmTime,
          };
          setTimeout(() => {
            that.trendChartSubject.next(qosData);
          }, 0);
        }
      }
      that.historyAlarmDetail = res;
      that.historyAlarmDetail.additionalInfo = that.historyAlarmDetail.additionalInfo.join(',\n');
      that.historyAlarmDetail.alarmImg = that.alarmService.alarmImgChioce(res.level, res.impact);
      that.historyAlarmDetail.objectImg = that.alarmService.getObjectImage(this.historyAlarmDetail.objectType);
    });
  }

  calcComfirmTime(startTime: Date, endTime: Date) {
    return this.alarmService.calcComfirmTime(startTime, endTime);
  }
}
