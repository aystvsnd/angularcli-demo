import { Component, OnInit } from '@angular/core';
// import { Headers,Http, Response } from '@angular/http';
import { ActivatedRoute } from '@angular/router';
import { NotificationService } from './notification.service';
import { Router } from '@angular/router';
//import {DcBasicComponent} from './dc-basic.component';
//import {ClusterSummaryComponent} from './cluster-summary.component';

@Component({
  moduleId: module.id,
  selector: 'notification-detail',
  template: `
      <div style="margin: 14px 0">
      <a (click)="getBackToAlarm()">{{'fm.alarm' | translate}}</a>
      <span style="padding: 0 6px;" >&gt;</span>
      <a (click)="getBackToNotification()">{{'fm.notificationMonitor' | translate}}</a>
      <span style="padding: 0 6px;" >&gt;</span>
      <span>{{'fm.currentNotification' | translate}}</span>
      </div>
      <fieldset>
      <div class="special-div">
        <div class="border-div">
          <div class="left-div">{{'fm.notificationDescription' | translate}}</div>
          <div class="right-div">{{notificationDetail.description}}</div>
        </div>
        <div class="border-div">
          <div class="left-div">{{'fm.notificationLevel' | translate}}</div>
          <div class="right-div">{{notificationDetail.level}}</div>
        </div>
        <div class="border-div">
          <div class="left-div">{{'fm.notificationCode' | translate}}</div>
          <div class="right-div">{{notificationDetail.notificationCode}}</div>
        </div>
        <div class="border-div">
          <div class="left-div">{{'fm.notificationType' | translate}}</div>
          <div class="right-div">{{notificationDetail.notificationType}}</div>
        </div>
        <div class="border-div">
          <div class="left-div">{{'fm.objectType' | translate}}</div>
          <div class="right-div">{{notificationDetail.objectType}}</div>
        </div>
        <div class="border-div">
          <div class="left-div">{{'fm.objectDescription' | translate}}</div>
          <div class="right-div">{{notificationDetail.notificationObject}}</div>
        </div>
        <div class="border-div">
          <div class="left-div">{{'fm.notificationTime' | translate}}</div>
          <div class="right-div">{{notificationDetail.notificationTime| localISOTime}}</div>
        </div>
        <div class="border-div">
           <div class="left-div">{{'fm.location' | translate}}</div>
           <div class="right-div">{{notificationDetail.location }}</div>
          <!--<div class="right-div">{{currentAlarmDetail.location | displayLocation}}</div>-->
        </div>
        <div class="border-div bottom-div">
          <div class="left-div">{{'fm.additionalInfo' | translate}}</div>
         <div class="right-div"><pre style="border:0px;background-color:white;">{{notificationDetail.additionalInfo}}</pre></div>
      </div>

      </div>
      </fieldset>
    `,
  //directives:[DcBasicComponent,ClusterSummaryComponent]
})

export class NotificationDetailComponent implements OnInit {
  notificationId: any;
  notificationDetail: any= {};
  constructor(private notificationService: NotificationService, private router: Router, private activatedRoute: ActivatedRoute) {
    this.activatedRoute.params.subscribe(params => {
      this.notificationId = params['notificationId'];
    });
  }

  getBackToAlarm() {
    this.router.navigate(['/main/alarm/currentalarm']);
  }
  getBackToNotification() {
    this.notificationService.isFromDetail = true;
    //this.notificationService.hisPageInfo.from = 'notificationIdDetail';
    this.router.navigate(['/main/alarm/notification']);
  }

  getNotificationDetail() {
    const notificationId = this.notificationId;
    //let that = this;
    //that.alarmService.getCurrentAlarmsDetailById(alarmId).then((res:any)=>{
    //  that.currentAlarmDetail = res;

    this.notificationService.getNotificationDetailById(notificationId).then((res: any) => {
      this.notificationDetail = res;
      this.notificationDetail.additionalInfo = this.notificationDetail.additionalInfo.join(',\n');
    });

  }

  ngOnInit() {
    //this.currentAlarmDetail = {};
    this.getNotificationDetail();
  }

}
