//import {Http, Response} from '@angular/http';
import {Component, ViewChild, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {NotificationService} from './notification.service';

import '../../rxjs-operators';


import {ModalComponent} from 'ng2-bs3-modal/ng2-bs3-modal';
import {StorageService} from '../../storage.service';
import {TranslateService} from '@ngx-translate/core';
import {AlarmService} from '../alarm.service';


@Component({
  moduleId: module.id,
  templateUrl: 'notification.component.html',
  styleUrls: ['../currentAlarm/current-alarm.component.css']
})

export class NotificationComponent implements OnInit {
  @ViewChild('modal1') modal: ModalComponent;
  itemList: Array<any>;
  reason = '';
  modalTitle = '';
  requestParams: any;
  timeErr: any;
  alarmHiddenFlag = false;

  exportData: any = {
    title: this.translate.instant('fm.exportNotification'),
    frontUrl: '1',
    currentPage: 1,
    allPage: 1
  };

  objectTypes: any[] = [
    {name: this.translate.instant('fm.ALL'), value: 'ALL'},
    {name: 'cloudEnv', value: 'cloudEnv'}, {name: 'chassis', value: 'chassis'},
    {name: 'cloud', value: 'cloud'},
    {name: 'host', value: 'host'}, {name: 'rack', value: 'rack'},
    {name: 'router', value: 'router'}, {name: 'server', value: 'server'},
    {name: 'storage', value: 'storage'}, {name: 'switch', value: 'switch'},
    {name: 'vm', value: 'vm'}, {name: 'volume', value: 'volume'},
    {name: 'hostnetwork', value: 'hostnetwork'}, {name: 'vmnetwork', value: 'vmnetwork'},
    {name: 'system', value: 'system'},
  ];
  objectType: any = 'ALL';


  notificationTypes: any[] = [
    {name: this.translate.instant('fm.ALL'), value: 'ALL'},
    {name: 'communicationsAlarm', value: 'communicationsAlarm'},
    {name: 'processingErrorAlarm', value: 'processingErrorAlarm'},
    {name: 'environmentalAlarm', value: 'environmentalAlarm'},
    {name: 'qualityOfServiceAlarm', value: 'qualityOfServiceAlarm'},
    {name: 'equipmentAlarm', value: 'equipmentAlarm'},
    {name: 'integrityViolation', value: 'integrityViolation'},
  ];
  notificationType: any = 'ALL';

  queryAlarmTimePeriods: any[] = [
    {name: this.translate.instant('fm.ALL'), value: 'ALL'},
    {name: this.translate.instant('fm.currentDay'), value: this.translate.instant('fm.currentDay')},
    {name: this.translate.instant('fm.oneHour'), value: this.translate.instant('fm.oneHour')},
    {name: this.translate.instant('fm.oneDay'), value: this.translate.instant('fm.oneDay')},
    {name: this.translate.instant('fm.oneWeek'), value: this.translate.instant('fm.oneWeek')},
    {name: this.translate.instant('fm.oneMonth'), value: this.translate.instant('fm.oneMonth')},
    {name: this.translate.instant('fm.customTime'), value: this.translate.instant('fm.customTime')}
  ];
  queryTimePeriod: any = 'ALL';
  absoluteTimeFlag: boolean;
  absoluteTimeStart: Date = new Date();
  absoluteTimeEnd: Date = new Date();
  timeErr = false;

  isShowLoading = true;
  loading: any = this.translate.instant('fm.loading');

  links: any = [{name: this.translate.instant('fm.alarm'), url: '/main/alarm/currentalarm/summary'},
    {name: this.translate.instant('fm.notificationMonitor')}];
  rowData: any[];
  window: window = window;
  hotKeyToggle = false;

  columnDefs: any[] = [
    {
      field: 'name',
      title: this.translate.instant('fm.Sequence'),
      align: 'left',
      formatter: function (value, row, index) {
        return index + 1;
      }
    },
    {
      field: 'description',
      title: this.translate.instant('fm.notificationDescription'),
      align: 'left',
      events: 'operateEvents',
      formatter: function (value, row, index) {
        return `<a href="javascript:;" class="detail">${value}</a>`;
      }
    },
    {
      field: 'level',
      title: this.translate.instant('fm.notificationLevel'),
      align: 'left',
      sortable: true
    },
    {
      field: 'notificationType',
      title: this.translate.instant('fm.notificationType'),
      align: 'left',
    },
    {
      field: 'objectType',
      title: this.translate.instant('fm.objectType'),
      align: 'left',
    },
    {
      field: 'notificationObject',
      title: this.translate.instant('fm.objectDescription'),
      align: 'left',
      formatter: function (value, row, index) {
        const value1 = value.substr(0, 20) + '...';
        const value2 = value.split(',').join('\r\n');
        return `<pre data-toggle="tooltip" data-placement="top" title="${value2}">${value1}</pre>`;
      }
    },
    {
      field: 'notificationTime',
      title: this.translate.instant('fm.notificationTime'),
      align: 'left',
      formatter: function (value, row, index) {
        value = Date.parse(value);
        let localTime = '';
        const offset: number = (new Date()).getTimezoneOffset();
        localTime = (new Date(value - offset * 60000)).toISOString();
        localTime = localTime.substr(0, localTime.lastIndexOf('.'));
        localTime = localTime.replace('T', ' ');
        return localTime;
      }
    }, {
      field: 'additionalInfo',
      title: this.translate.instant('fm.additionalInfo'),
      align: 'left',
      //formatter: function (value, row, index) {
      //  value = _.flatten(value);
      //  var value1 = value[0].split(',').join(',\n');
      //  return `<pre>${value1}</pre>`;
      //}
      formatter: function (value, row, index) {
        const value1 = value[0].substr(0, 20) + '...';
        const value2 = value[0].split(',').join('\n');
        return `<pre data-toggle="tooltip" data-placement="top" title="${value2}">${value1}</pre>`;
      }
    }
  ];
  gridOptions: any = {
    method: 'get',
    url: '/api/v1.0/fm/notificationsWithDetail',
    queryParams: params => this.queryParams(params, this),
    columns: this.columnDefs,
    sidePagination: 'server',
    pagination: true,//是否开启分页
    pageSize: 10,//单页数量
    pageNumber: 1,//this.ntService
    pageList: [10, 20],
    paginationDetailHAlign: 'left', //分页详情水平位置
    paginationHAlign: 'left', //分页条水平位置
    //clickToSelect: false,//单击行选中
    sortable: true, //是否开
    search: true,
    // search:false,
  };

  getPage() {
    if (this.getQueryConditionState()) {
      return this.ntService.pageInfo.currentPage;
    } else {
      return 1;
    }
  }

  getQueryConditionState() {
    return this.ntService.isFromDetail === true || window.localStorage.getItem('historyState') === 'notificationQueryConditionId';
  }

  queryParams(params: any, that: any) {
    const timeStamp = that.alarmService.getHistoryAlarmTime(that.queryTimePeriod, that.absoluteTimeStart, that.absoluteTimeEnd);
    let tmp: any;
    if (that.getQueryConditionState()) {
      tmp = that.ntService.pageInfo;
    } else {
      tmp = {
        pageSize: params.limit,
        beginTime: (timeStamp.beginTime !== '') ? timeStamp.beginTime : undefined,
        endTime: (timeStamp.endTime !== '') ? timeStamp.endTime : undefined,
        currentPage: params.offset / params.limit + 1,
        objectType: that.objectType === 'ALL' ? undefined : that.objectType,
        notificationType: that.notificationType === 'ALL' ? undefined : that.notificationType,
        onlyHidden: that.alarmHiddenFlag,
        onlyUnknown: that.hotKeyToggle === false ? undefined : that.hotKeyToggle,
        fuzzy: that.getQueryConditionState() ? that.ntService.pageInfo.fuzzy : params.search
      };
    }

    if (that.getQueryConditionState()) {
      window.localStorage.removeItem('historyState');
      $('.bootstrap-table .search input').val(that.ntService.pageInfo.fuzzy);
      that.ntService.isFromDetail = false;
    }
    that.ntService.queryTimePeriod = that.queryTimePeriod;
    that.ntService.absoluteTimeFlag = that.absoluteTimeFlag;
    that.ntService.absoluteTimeStart = that.absoluteTimeStart;
    that.ntService.absoluteTimeEnd = that.absoluteTimeEnd;
    that.ntService.pageInfo = tmp;
    that.exportData.currentPage = tmp.currentPage;
    that.exportData.pageSize = tmp.pageSize;
    //exportData.fuzzyword = (tmp.fuzzy === undefined)? '':tmp.fuzzy;
    that.exportData.frontUrl = `/api/v1.0/fm/notifications/file/csv?` + that.alarmService.ObjectToUrl(tmp);

    that.isShowLoading = true;


    return tmp;
  }

  constructor(private ntService: NotificationService, private router: Router,
              private storageService: StorageService, private translate: TranslateService,
              private alarmService: AlarmService) {
    const that = this;

    if (that.alarmService.lang === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }

    this.window.operateEvents = {
      'click .detail': function (e, value, row, index) {
        //that.RecordCurPageInfo(that);
        const id = row.self.split('/').pop();
        that.router.navigate(['/main/alarm/notification/detail', id]);
        const state = 'notificationQueryConditionId';
        window.history.pushState(state, null, '/main/alarm/notification');
      }
    };
  }


  initTable() {
    const that = this;
    this.gridOptions.pageNumber = this.getPage();
    $('#table-notification').bootstrapTable($.extend(this.gridOptions, {
      ajaxOptions: {
        beforeSend: function (xhr) {
          const accessToken = window.localStorage.directoraccessToken;
          const username = window.localStorage.directorusername;
          xhr.setRequestHeader('access-token', accessToken);
          xhr.setRequestHeader('operateuser', username);
        }
      },
      toolbar: '#toolbar1',
      dataField: 'notifications',
      responseHandler: function (res) {
        that.exportData.allPage = Math.ceil(res.total / this.pageSize);

        if (res.total === 0) {
          $('.fixed-table-footerButtons').remove();
        }

        that.isShowLoading = false;

        return res;
      }
    }));

    $('.bootstrap-table .search input').attr('placeholder', that.translate.instant('fm.importKey'))
      .parent().append(`<span></span>`);

    if ($('#table-notification').parents('.fixed-table-container')[0].children.length === 4) {
      $('#table-notification').parents('.fixed-table-container').append(`<div class="fixed-table-footerButtons">
        <button id="alarm-export-btn " data-target="#alarmExport" data-toggle="modal">${that.translate.instant('fm.export')}</button>
    </div>`);
    }
  }


  ngOnInit() {
    const that = this;
    this.alarmService.getPopstate();
    setTimeout(function () {
      that.initPageInfo();
      that.initTable();
    }, 500);
    setTimeout(function () {
      that.isShowLoading = false;
    }, 5000);

  }

  initPageInfo() {
    const that = this;
    if (that.getQueryConditionState()) {
      that.objectType = that.ntService.pageInfo.objectType || 'ALL';
      that.notificationType = that.ntService.pageInfo.notificationType || 'ALL';
      that.queryTimePeriod = that.ntService.queryTimePeriod || 'ALL';
      that.absoluteTimeFlag = that.ntService.absoluteTimeFlag || false;
      that.absoluteTimeStart = that.ntService.absoluteTimeStart || (new Date());
      that.absoluteTimeEnd = that.ntService.absoluteTimeEnd || (new Date());
      that.alarmHiddenFlag = that.ntService.pageInfo.onlyHidden;
      that.hotKeyToggle = that.ntService.pageInfo.onlyUnknown;
    }
  }

  hideAlarmToggle() {
    this.alarmHiddenFlag = !this.alarmHiddenFlag;
    $('#table-notification').bootstrapTable('destroy');
    this.initTable();
  }

  viewFilterRules() {
    this.router.navigate(['main/systemManage/systemConfig/alarmConfig/alarmFilterConfig']);
  }

  checkAbsoluteTimerErr() {
    this.timeErr = (this.absoluteTimeStart > this.absoluteTimeEnd) ? true : false;
  }

  absoluteTimeStartHandle(event: any) {
    this.absoluteTimeStart = event.target.value;
    this.checkAbsoluteTimerErr();

  }

  absoluteTimeEndHandle(event: any) {
    this.absoluteTimeEnd = event.target.value;
    this.checkAbsoluteTimerErr();
  }

  refreshQueryTimeType(data: any) {
    this.absoluteTimeFlag = data === this.translate.instant('fm.customTime');
    this.timeErr = false;
    this.InitAbsoluteTime();
  }

  InitAbsoluteTime() {
    const curDate = new Date();
    const beginDate = curDate;
    beginDate.setDate(curDate.getDate() - 1);
    this.absoluteTimeStart = this.serverTimeToLocalTime(beginDate);
    this.absoluteTimeEnd = this.serverTimeToLocalTime(new Date());
  }

  serverTimeToLocalTime(inputIntTime: any) {

    let localTime = '';
    const offset: number = (new Date()).getTimezoneOffset();

    localTime = (new Date(inputIntTime - offset * 60000)).toISOString();
    localTime = localTime.substr(0, localTime.lastIndexOf('.'));
    localTime = localTime.replace('T', ' ');
    return localTime;
  }

  getNotificationAlarms() {
    $('#table-notification').bootstrapTable('destroy');
    this.initTable();
    $('.bootstrap-table .table').css('margin-top', '10px');
  }

  unknownHotKeyToggle() {
    this.hotKeyToggle = !this.hotKeyToggle;
    this.hotKeyToggle ? console.log('Hotkey Opened') : console.log('Hotkey Closed');
    this.getNotificationAlarms();
  }

}
