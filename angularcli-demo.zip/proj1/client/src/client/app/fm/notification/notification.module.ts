import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { KyLibModule } from '../../shared/kylib/index';
import { TooltipModule } from 'ng2-bootstrap/ng2-bootstrap';
import { PipesModule } from '../../shared/pipes/pipe.module';

import {AlarmPublicModule} from '../alarmPublic/alarmPublic.module';
import { Ng2Bs3ModalModule } from 'ng2-bs3-modal/ng2-bs3-modal';
import { routing } from './notification.routes';

//import { AlarmService } from '../alarm.service';
import {StorageService} from '../../storage.service';
import {NotificationService} from './notification.service';


import { NotificationComponent } from './notification.component';
import { NotificationDetailComponent } from './notification-detail.component';
import {SharedModule} from '../../shared/shared.module';

@NgModule({
  imports: [AlarmPublicModule, SharedModule, CommonModule, FormsModule, HttpModule,
            KyLibModule, routing, TooltipModule, PipesModule, Ng2Bs3ModalModule],
  declarations: [NotificationComponent, NotificationDetailComponent],
  providers: [StorageService, NotificationService],
})

export class NotificationModule { }
