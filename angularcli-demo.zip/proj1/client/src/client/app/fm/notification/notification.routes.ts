import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NotificationComponent } from './notification.component';
import { NotificationDetailComponent } from './notification-detail.component';

const routes: Routes = [
  {
    path: 'notification',
    children: [
      {path: '', component: NotificationComponent},
      {path: 'detail/:notificationId', component: NotificationDetailComponent},
    ]
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
