/**
 * Created by root on 7/15/16.
 */
import {Injectable} from '@angular/core';
//import {Headers,Http, Response} from '@angular/http';
//import {MockCfg} from '../mock';
//import '../rxjs-operators';
//import * as _ from 'underscore';
import {ApiResourceService as Http} from '../../apiResource.service';
import {Response} from '@angular/http';

@Injectable()
export class NotificationService {
  isFromDetail = false;
  //objectType:any = 'ALL';
  //alarmType:any = 'ALL';
  queryTimePeriod: any;
  absoluteTimeFlag: boolean;
  absoluteTimeStart: any;
  absoluteTimeEnd: any;
  //currentPage:any=1;
  pageInfo: any = {
    pageSize: '',
    currentPage: '',
    objectType: this.objectType,
    alarmType: this.alarmType,
    fuzzy: '',
    onlyHidden: '',
    onlyUnknown: false
  };

  constructor(public http: Http) {

  }

  //for current alarm detail
  getNotificationDetailById(id: any) {
    return this.http.get('/api/v1.0/fm/notifications/' + id).toPromise().then((res: Response) => {
      return res.json();
    });
  }

  getNotificationLinksDetail(notificationLinks: Array<any>) {

    const promiseList: Array<any> = [];
    const NotificationDetails: Array<any> = [];
    for (const link of notificationLinks) {
      promiseList.push(this.http.get(link).toPromise());
    }
    return Promise.all(promiseList).then((res: any) => {
      for (const notificationDetail of res) {

        NotificationDetails.push(notificationDetail.json());
      }
      return Promise.resolve(NotificationDetails);
    });

  }


}
