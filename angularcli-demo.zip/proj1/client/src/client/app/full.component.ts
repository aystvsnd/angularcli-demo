import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StorageService } from './storage.service';
import { FullComponetToSiderbarService } from './fullComponetToSiderbar.service';
import { OrgService } from './orgManage/org.service';
import { Organization } from './orgManage/organization';
import { AjaxSetupService } from './ajaxSetup.service';
import { TranslateService } from '@ngx-translate/core';
import { ApiResourceService as Http } from './apiResource.service';
import { UserService } from './system-manage/index';
@Component({
  moduleId: module.id,
  templateUrl: 'full.component.html',
  styleUrls: ['full.component.less'],
  encapsulation: ViewEncapsulation.None
})

export class FullComponent implements OnInit {
  showBtn = false;
  showSideBar: boolean;
  showOrgChange: boolean;
  orgName: string;
  username: string;
  showImage = false;
  changeDropdownSize = false;
  language: any;
  myoptions: any[] = [];

  constructor(private router: Router, private storageService: StorageService,
              private ajaxSetupService: AjaxSetupService, private translate: TranslateService,
              private fullComponetToSiderbarService: FullComponetToSiderbarService,
              private orgService: OrgService, private http: Http,
              private userService: UserService) {
    this.ajaxSetupService._ajaxSetup();
    this.showSideBar = true;
    fullComponetToSiderbarService.SiderbarToMenuMsg$.subscribe(
        (msg: string) => {
          if (msg === 'true') {
            this.showBtn = true;
          }
          if (msg === 'false') {
            this.showBtn = false;
          }
        }
    );
    this.orgService.currentOrgName$.subscribe(
        (name: string) => {
          this.orgName = name;
        }
    );
    this.orgService.showOrgChange$.subscribe(
        (res: any) => {
          this.showOrgChange = res;
        }
    );
  }
  ngOnInit() {
    //for the browser header tip show
    if (window.localStorage.directorBrowserHeaderTipShow === 'true') {
      let currentLang = navigator.language;
      if (!currentLang) {//if IE
        currentLang = navigator.browserLanguage;
      }
      const langBool = ((currentLang === 'zh-CN') || (currentLang === 'zh-cn'));
      $('div#menu').css('margin-top', '40px');
      let winWidth = 0;
      if (window.innerWidth) {
        winWidth = window.innerWidth;
      }else if ((document.body) && (document.body.clientWidth)) {
        winWidth = document.body.clientWidth;
      }
      $('#innerBrowserTipMessageCh').css('width', winWidth);
      this.browserVersion();
      if (langBool) {
        $('#innerBrowserTipMessageCh').css('width', winWidth);
        $('#innerBrowserTipMessageCh').css('display', 'block');
      } else {
        $('#innerBrowserTipMessageEn').css('width', winWidth);
        $('#innerBrowserTipMessageEn').css('display', 'block');
      }
    }
    if (window.localStorage.directorBrowserHeaderTipShow === 'false') {
      $('div#menu').css('margin-top', '0px');
    }

    this.showOrgChange = this.orgService.firstLoginToShowOrgChange;
    this.username = this.storageService.getUserName();
    this.language = this.storageService.getCurrentLang();

    $('.sideBar').css('display', 'inline');
    $('.main-content').css('margin-left', '200px');

    //$('.main-content').css('margin-left', '0px');
    $('.tecs-breadcrumb').css('left', '40px');
    if (this.storageService.getSiderbarShowMenu() === 'true') {
      this.fullComponetToSiderbarService.FullComponentSendMessageToSiderbar(this.storageService.getSiderbarMsg());
    }

    document.onclick = function () {
      $('.org-quick-choose-tree').hide();
    };
  }

  setLang(lang: string) {
    this.storageService.setCurrentLang(lang);
    window.location.reload();
  }

  setSidebar() {
    if (this.storageService.getSiderbarMsg() === 'myorganizationCenterViewBool' &&
        this.storageService.getSiderbarShowMenu() === 'true') {
      $('.sideBar').css('display', 'none');
      $('.mainContent').css('margin-left', 0);
    }
  }
  goToLogin() {
    this.router.navigate(['login']);
  }

  showTree(event: any) {
    const e = window.event || event;
    if (e.stopPropagation) {
      e.stopPropagation();
    } else {
      e.cancelBubble = true;
    }
    $('.org-quick-choose-tree').show();
  }

  onShowOrg(org: Organization) {
    org.extendType = org.type;

    if (org.type === 'ORG') {
      org.type = 'ORG';
    } else {
      org.type = 'PROJECT';
    }

    const url = this.router.url;
    this.orgService.setCurrentOrg(org);
    this.orgService.setCurrentOrgName(org.name);
    this.storageService.setCurrentOrg(JSON.stringify(org));

    if (!this.orgService.getFirstLogin()) {
      this.orgService.setChangeOrg(true);
      this.router.navigate(['/interval']);

      if (org.type !== 'ORG') {
        setTimeout(() => {
          this.router.navigate([url]);
        }, 0);
      } else {
        setTimeout(() => {
          this.router.navigate(['main/myResource/overview']);
        }, 0);
      }
    }
    this.orgService.setFirstLogin(false);
  }

  showSidebarByBtn() {
    $('.sideBar').css('display', 'inline');
    $('.main-content').css('margin-left', '200px');
    this.showBtn = false;

  }

  setStyleAndImg(input: any) {
    input.style.cursor = 'pointer';
    input.src = 'assets/images/btn_menu_show_hover.png';
  }

  setCursor(input: any) {
    input.style.cursor = 'default';
  }
  /* tslint:disable */
  browserVersion(){
    var engine = {
      ie: 0,
      gecko: 0,
      webkit: 0,
      khtml: 0,
      opera: 0,
      ver: null
    };
    var browser = {
      ie: 0,
      firefox: 0,
      safari: 0,
      konq: 0,
      opera: 0,
      chrome: 0,
      ver: null
    };
    var system = {
      win: false,
      mac: false,
      x11: false,
      iphone: false,
      ipod: false,
      ipad: false,
      ios: false,
      android: false,
      nokiaN: false,
      winMobile: false,
      wii: false,
      ps: false
    };
    var ua = navigator.userAgent;
    var currentLang=navigator.language;
    if(!currentLang){//if IE
      currentLang = navigator.browserLanguage;
    }
    //opera(opera),webkit(chrome,safari),khtml(konq),gecko(firefox),ie(ie)
    if(window.opera) {
      engine.ver = browser.ver = window.opera.version();
      engine.opera = browser.opera = parseFloat(engine.ver);
    } else if(/AppleWebKit\/(\S+)/.test(ua)) {
      engine.ver = RegExp.$1;
      engine.webkit = parseFloat(engine.ver);
      //Chrome safari
      if(/Chrome\/(\S+)/.test(ua)) {
        browser.ver = RegExp.$1;
        browser.chrome = parseFloat(browser.ver);
      } else if(/Version\/(\S+)/.test(ua)) {
        browser.ver = RegExp.$1;
        browser.safari = parseFloat(browser.ver);
      } else {
        //safari webkit safari
        var safariVersion = 1;
        if(engine.webkit < 100) {
          safariVersion = 1;
        } else if(engine.webkit < 312) {
          safariVersion = 1.2;
        } else if(engine.webkit < 412) {
          safariVersion = 1.3;
        } else {
          safariVersion = 2;
        }
        browser.safari = browser.ver = safariVersion;
      }
    }
    else if(/KHTML\/(\S+)/.test(ua) || /Konqueror\/([^;]+)/.test(ua)) {
      engine.ver = browser.ver = RegExp.$1;
      engine.khtml = browser.khtml = parseFloat(engine.ver);
    }//notice  there must be a blank before the word Gecko
    else if(/rv:([^\)]+)\) Gecko\/\d{8}/.test(ua)) {
      engine.ver = RegExp.$1;
      engine.gecko = parseFloat(engine.ver);
      if(/Firefox\/(\S+)/.test(ua)) {
        browser.ver = RegExp.$1;
        browser.firefox = parseFloat(browser.ver);
      }
    } else if(/MSIE([^;]+)/.test(ua)||/Windows NT([^;]+)/.test(ua)) {
      engine.ver = browser.ver = RegExp.$1;
      engine.ie = browser.ie = parseFloat(engine.ver);
    }
    var p = navigator.platform;
    system.win = p.indexOf("Win") == 0;
    system.mac = p.indexOf("Mac") == 0;
    system.x11 = (p == "x11") || (p.indexOf("Linux") == 0);
    //Windows
    if(system.win) {
      if(/Win(?:dows )?([^do]{2})\s?(\d+\.\d+)?/.test(ua)) {
        if(RegExp.$1 == "NT") {
          switch(RegExp.$2) {
            case "5.0":
              system.win = "2000";
              break;
            case "5.1":
              system.win = "XP";
              break;
            case "6.0":
              system.win = "Vista";
            case "6.1":
              system.win = '7';
              break;
            default:
              system.win = "NT";
              break;
          }
        } else if(RegExp.$1 == "9x") {
          system.win = "ME";
        } else {
          system.win = RegExp.$1;
        }
      }
    }
    //
    system.iphone = ua.indexOf("iPhone") > -1;
    system.ipod = ua.indexOf("iPod") > -1;
    system.ipad = ua.indexOf("iPad") > -1;
    system.nokiaN = ua.indexOf("NokiaN") > -1;
    //windows mobile
    if(system.win == "CE") {
      system.winMobile = system.win;
    } else if(system.win == "Ph") {
      if(/Windows Phone OS (\d+.\d+)/.test(ua)) {
        system.win = "Phone";
        system.winMobile = parseFloat(RegExp.$1);
      }
    }
    //IOS
    if(system.mac && ua.indexOf("Mobile") > -1) {
      if(/CPU (?:iPhone )?OS (\d+_\d+)/.test(ua)) {
        system.ios = parseFloat(RegExp.$1.repeat("_", "."));
      } else {
        system.ios = 2;
      }
    }
    //Android
    if(/Android (\d+\.\d+)/.test(ua)) {
      system.android = parseFloat(RegExp.$1);
    }
    //游戏系统
    system.wii = ua.indexOf("Wii") > -1;
    system.ps = /playstation/i.test(ua);
    var finallyResult = {
      engine: engine,
      browser: browser,
      system: system
    };
    if(finallyResult.browser.firefox > 0) {
      let winWidth=0;
      if (window.innerWidth) {
        winWidth = window.innerWidth;
      }else if ((document.body) && (document.body.clientWidth)) {
        winWidth = document.body.clientWidth;
      }
      var currentLang=navigator.language;
      if(!currentLang){//if IE
        currentLang = navigator.browserLanguage;
      }
      var langBool = ((currentLang==='zh-CN')||(currentLang==='zh-cn'));
      if(!langBool) {
        $('#innerBrowserTipMessageCh').css('width', winWidth + 150);
        $('#innerBrowserTipMessageDivEn').css('margin-left', '-680px');
      }
    }
  }
  /* tslint:enable */
}
