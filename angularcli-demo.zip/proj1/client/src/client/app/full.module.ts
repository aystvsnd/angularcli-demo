import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { SharedModule } from './shared/index';
import { KyLibModule} from './shared/kylib/index';
import { SidebarModule } from './siderbar/index';
import { AllMenuModule } from './consoleMenu/index';

import { FullComponent } from './full.component';
import { IntervalComponent } from './interval.component';
import { AjaxSetupService } from './ajaxSetup.service';
import { OrgHeaderComponent } from './orgManage/org-header/org-header.component';

import { UserService } from './system-manage/index';
@NgModule({
  imports: [CommonModule, FormsModule, KyLibModule, SidebarModule, SharedModule, AllMenuModule],
  declarations: [FullComponent, OrgHeaderComponent, IntervalComponent],
  providers: [AjaxSetupService, UserService]
})

export class FullModule { }
