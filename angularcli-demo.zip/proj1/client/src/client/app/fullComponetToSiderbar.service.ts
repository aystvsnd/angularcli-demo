/*
*this service is use for the full.component.ts send message to the siderbar.directive.ts
* in order to control the show view of the siderbar
* */
import { Injectable } from '@angular/core';
import { Subject }    from 'rxjs/Subject';
@Injectable()
export class FullComponetToSiderbarService {
    /* tslint:disable */
    menuToSiderbar = new Subject<string>();

    public MenuToSiderbarMsg$= this.menuToSiderbar.asObservable();

    FullComponentSendMessageToSiderbar(msg: string) {
        this.menuToSiderbar.next(msg);
    }

    siderbarToMenu = new Subject<string>();

    public SiderbarToMenuMsg$ = this.siderbarToMenu.asObservable();

    SiderbarToFullComponentSendMessage(msg: string) {
        this.siderbarToMenu.next(msg);
    }

    /* tslint:enable*/
}
