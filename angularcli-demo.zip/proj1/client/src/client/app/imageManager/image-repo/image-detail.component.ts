
import {TranslateService} from '@ngx-translate/core';

import { Router, ActivatedRoute , Params} from '@angular/router';
import {Component, OnInit, OnDestroy, ViewChild} from '@angular/core';
import { ImageRepoService } from './image-repo.service';
import { ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';
import { ApiResourceService as Http } from '../../apiResource.service';
import { Response } from '@angular/http';

@Component({
  moduleId: module.id,
  templateUrl: 'image-detail.component.html',
  // styles: [`
  //       .show-down-icon {
  //           -webkit-transform: rotate(90deg);
  //           -moz-transform:rotate(90deg);
  //           transform:rotate(90deg);
  //       }
  //   `]
})

export class ImageDetailComponent implements OnInit, OnDestroy {
  @ViewChild('publishmodal') publishModal: ModalComponent;
  @ViewChild('depublishmodal') depublishModal: ModalComponent;
  links: any = [ {name: this.translate.instant('image.ImageResource'), url: 'main/image/imageSummary'},
    {name: this.translate.instant('image.ImageStorage'), url: '../..', relative: true},
    {name: this.translate.instant('image.ImageDetail')}
  ];
  unPublishImage = {};
  hasSelected: boolean;
  showDC: boolean;
  detail: any = '';
  timer: any;
  isSetPw = '';
  setpw = '';
  dcs: any;

  id: any;
  delMessage : any = {
    title: this.translate.instant('image.DelImage'),
    message: '',
    confirmText: this.translate.instant('CONFIRM'),
    cancelText: this.translate.instant('Cancel'),
    type: 'exclamation'
  };
  tryDelNet: any = {};
  window: window= window;
  rowData: any[];
  columnDefs: any[] = [
    {
      field: 'cloudenv_name',
      title: this.translate.instant('CloudEnv'),
      sortable: true
    },
    {
      field: 'cloudenv_type',
      title: this.translate.instant('image.EnvType'),
      sortable: true
    },
    // {
    //   field: 'vmware_adaptertype',
    //   title: 'vmware_adaptertype'
    // },
    // {
    //   field: 'vmware_disktype',
    //   title: 'vmware_disktype'
    // },
    //{
    //  field: 'progress_rate',
    //  title: this.translate.instant('image.Progress'),
    //  width: 100,
    //  formatter: function (value, row, index) {
    //    if (row.image_status === 'queued') {
    //      return `<div class="progress" style="margin-bottom:0">
    //                <div class="progress-bar progress-bar-success" role="progressbar"
    //                     aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"
    //                     style="width:${value}%">
    //                    <span class="sr-only" style="position:inherit">${value}%</span>
    //                </div>
    //            </div>`;
    //    } else {
    //      return '--';
    //    }
    //  }
    //},
    //{
    //  field: 'transferRate',
    //  title: this.translate.instant('image.ReleaseMir') + '(KB/s)',
    //  formatter: function (value, row, index) {
    //    if (row.image_status === 'queued') {
    //      return value;
    //    } else {
    //      return '--';
    //    }
    //  }
    //},
    {
      field: 'image_status',
      title: this.translate.instant('Status'),
      sortable: true
    },
    {
      field: 'oper',
      title: this.translate.instant('Operation'),
      width: '140px',
      events: 'operateEvents',
      formatter: (value, row, index) => {
        const str = '<div class="btn-group table-operate-float">\
                     <button class="btn btn-default cancelPublish table-operate-btn" data-toggle="modal" \
                             data-target="#cancelPublishModal">'
          + this.translate.instant('image.CancelPublish') +
          '</button></div>';
        return str;
      }
    }
    // {
    //   title: this.translate.instant('Operation'),
    //   width: 160,
    //   field: 'operate',
    //   events: 'operateEvents',
    //   formatter: function (value, row, index) {
    //     return ['<div class="btn-group table-operate-float">\
    //     <button class="btn btn-default authority table-operate-btn">请选择</button>\
    //     <button class="btn btn-default dropdown-toggle table-operate-btn" id="dropdownMenu" \
    //                      data-toggle="dropdown" ><span class="caret"></span>\
    //                   </button>\
    //     <ul class="dropdown-menu dropdown-menu-top table-operate-ulfont" role="menu" aria-labelledby="dropdownMenu1">\
    //                   <li role="presentation">\
    //                    <a href="javascript:void(0);" class="delete" data-toggle="modal" data-target="#deleteModal">删除</a>\
    //                   </li>\
    //                   <li role="presentation">\
    //                    <a href="javascript:void(0);" class="publish">发布</a>\
    //                   </li>\
    //     </ul>\
    //     </div>'
    //     ].join('');
    //   }
    // }
  ];

  gridOptions: any = {
    pagination: true,
    pageSize: 10,
    pageList: [10, 25, 50, 100],
    search: true,
    strictSearch: false,
    searchText: '',
    paginationDetailHAlign: 'left',
    paginationHAlign: 'left',
    clickToSelect: false,
    sortable: true
  };

  constructor(private translate: TranslateService, private imageRepoService: ImageRepoService,
  private router: Router, private route: ActivatedRoute, private http: Http) {
    const that = this;
    $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    // this.window.operateEvents = {
    //   'click .publish': function (e, value, row ,index) {
    //     that.publishManager(row);
    //   },
    //   'click .delete': function (e, value, row ,index) {
    //     that.tryDelNet = row;
    //     that.delMessage.message = '删除镜像: ' + that.tryDelNet.name +
    //       ', 确认要执行吗？';
    //   },
    // };
    this.window.operateEvents = {
      'click .cancelPublish': function(e, value, row, index){
        that.unPublish(row);
      }
    };
  }

  ngOnInit() {
    this.route.params.forEach((params: Params) => {
      this.id = params['id'];
    });
    this.initTable();
    this.getImage();
  }

  ngOnDestroy() {
    clearInterval(this.timer);
  }

  unPublish(image: any) {
    this.unPublishImage = image;
  }

  getImage() {
    const that = this;
    this.imageRepoService.getImage(this.id).then((response: any) => {
      if (response.os_type === undefined) {
        response.os_type = '';
      }
      that.detail = response;
      that.setpw = that.detail.set_image_password.toLowerCase();
      that.isSetPw = that.detail.set_image_password.toLowerCase();
      that.rowData = response.cloudenv_images;
      $('#detailTable').bootstrapTable('load', that.rowData);
    });
  }

  // publishManager(item:any) {
  //   this.router.navigate(['publish',item.id], {relativeTo: this.route});
  // }

  deleteSelected(item: any) {
    this.imageRepoService.deleteImage(item.id).then((response: any) => {this.getImage(); });
  }


  deleteNet() {
    const selectedItems: any[] = $('#detailTable').bootstrapTable('getSelections');

    for (const item of selectedItems) {
      this.deleteSelected(item);
    }
  }
  sureDel() {
    this.deleteSelected(this.tryDelNet);
  }

  showPublishPage(image: any) {
    this.hasSelected = false;
    this.showDC = true;
    // this.publishImage = image;
    // this.tryDel = false;
    // this.publishImg = true;
    const that = this;
    // this.publishing = false;
    // this.cancelPublish = false;
    // this.allClusters = [];
    this.imageRepoService.getDcs().then((res: Response) => {
      that.dcs = res;
      _.map(that.dcs, function (dc) {
        const cloudEnvs = [];
        dc.checked = false;
        dc.showCloudEnv = false;
        _.map(dc.cloudEnvs, function (cloud) {
          if ((_.filter(that.rowData, function (ele) {
              return ele.cloudenv_id === cloud.id;
            })).length === 0) {
            cloud.checked = false;
            cloudEnvs.push(cloud);
          }
        });
        dc.cloudEnvs = cloudEnvs;
      });
      that.dcs = _.filter(that.dcs, function (dc) {
        return dc.cloudEnvs !== undefined && dc.cloudEnvs.length !== 0;
      });
    });

    this.publishModal.open();
  }

  showDepublishPage(image: any) {
    this.hasSelected = false;
    this.showDC = true;
    const that = this;
    this.imageRepoService.getDcs().then((res: Response) => {
      that.dcs = res;
      _.map(that.dcs, function (dc) {
        const cloudEnvs = [];
        dc.checked = false;
        dc.showCloudEnv = false;
        _.map(dc.cloudEnvs, function (cloud) {
          if ((_.filter(that.rowData, function (ele) {
              return ele.cloudenv_id === cloud.id;
            })).length === 1) {
            cloud.checked = false;
            cloudEnvs.push(cloud);
          }
        });
        dc.cloudEnvs = cloudEnvs;
      });
      that.dcs = _.filter(that.dcs, function (dc) {
        return dc.cloudEnvs !== undefined && dc.cloudEnvs.length !== 0;
      });
    });

    this.depublishModal.open();
  }

  clickDC(dc: any) {
    dc.checked = !dc.checked;
    _.map(dc.cloudEnvs, function (cloudEnv) {
      cloudEnv.checked = dc.checked;
    });
    this.checkSelected();
  }

  clickCloudEnv(dc: any, cloudEnv: any) {
    cloudEnv.checked = !cloudEnv.checked;
    if (_.filter(dc.cloudEnvs, function (cloudEnv) {
        return cloudEnv.checked === true;
      }).length === dc.cloudEnvs.length) {
      dc.checked = true;
    } else {
      dc.checked = false;
    }
    this.checkSelected();
  }

  checkSelected() {
    const that = this;
    const selected = [];
    this.hasSelected = function () {
      _.map(that.dcs, function (dc) {
        _.map(dc.cloudEnvs, function (cloudEnv) {
          if (cloudEnv.checked) {
            selected.push({id: cloudEnv.id, name: cloudEnv.name});
          }
        });
      });
      return selected.length !== 0;
    }();
  }

  publish(type: any) {
    const that = this;
    this.imageRepoService.getCloudenvs().then((res: Response) => {
      const selected = [];
      _.map(this.dcs, function (dc) {
        _.map(dc.cloudEnvs, function (cloudEnv) {
          if (cloudEnv.checked) {
            const getted = _.filter(res, function (env) {
              return env.id === cloudEnv.id;
            });
            selected.push({cloudenvs_id: cloudEnv.id,
              cloudenvs_name: cloudEnv.name,
              cloudenvs_type: getted.length === 0 ? '' : getted[0].envType});
          }
        });
      });

      const data = {
        op_type: type,
        cloudenvs: selected
      };
      this.imageRepoService.publish(this.id, data).then(() => {
        console.log('');
      });
      if (type === 'publish') {
        that.publishModal.dismiss();
      } else {
        that.depublishModal.dismiss();
      }
    });
  }

  initTable() {
    $('#detailTable').bootstrapTable($.extend(this.gridOptions, {
      toolbar: '#toolbar1',
      data: this.rowData,
      columns: this.columnDefs
    }));

    $('.bootstrap-table .search input').attr('placeholder', this.translate.instant('WordForFilter'))
      .parent().append(`<span></span>`);
  }

  sureUnPublish() {
    const selected = [{
      cloudenvs_id: this.unPublishImage.cloudenv_id,
      cloudenvs_name: this.unPublishImage.cloudenv_name,
      cloudenvs_type: this.unPublishImage.cloudenv_type
    }];

    const data = {
      op_type: 'unpublish',
      cloudenvs: selected
    };
    this.imageRepoService.publish(this.id, data).then(() => {
      this.getImage();
    });
  }
}
