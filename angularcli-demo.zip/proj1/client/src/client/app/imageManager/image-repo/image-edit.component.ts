/**
 * Created by yuying on 4/11/17.
 */
import {TranslateService} from '@ngx-translate/core';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute , Params } from '@angular/router';
import { Response } from '@angular/http';

import { ImageRepoService } from './image-repo.service';

@Component({
  moduleId: module.id,
  templateUrl: 'image-edit.component.html'
})

export class ImageEditComponent implements OnInit {
  isShowLoading = false;
  isShowAllLoading = false;
  os_type_after = '';
  showPW = false;
  verOptions1: any = [];
  os_version = '';
  imageFileId = '';
  imageDetail: any = [];
  os_type_obj = '';
  image: any= {
    disk_format: '',
    container_format: '',
    os_type: '',
    os_type_convert: '',
    os_version: '',
    vmware_adaptertype: '',
    vmware_disktype: '',
    min_disk: 0,
    min_ram: 0,
    public: true,
    windows_auto_login: false,
    service_market_use: false,
    ironic_use: false,
    product_key: ''
  };

  /* breadcrumb */
  links: any = [ {name: this.translate.instant('image.ImageResource'), url: 'main/image/imageSummary'},
    {name: this.translate.instant('image.ImageStorage'), url: '../..', relative: true},
    {name: this.translate.instant('image.ImageFileEdit')}
  ];

  /* OS Type and OS version */
  osTypeOption: any = [
    {value: 'Linux', name: 'Ubuntu', 'verOptions': [
      {value: 'Ubuntu Linux(64-bit)', name: 'Ubuntu Linux(64-bit)', 'convertName': 'ubuntu64Guest', 'busName': 'lsiLogic'},
      {value: 'Ubuntu Linux(32-bit)', name: 'Ubuntu Linux(32-bit)', 'convertName': 'ubuntuGuest', 'busName': 'lsiLogic'}
    ]},
    {value: 'Linux', name: 'CentOS', 'verOptions': [
      {value: 'CentOS 4/5/6/6.5/7(64-bit)', name: 'CentOS 4/5/6/6.5/7(64-bit)', 'convertName': 'centos64Guest',
        'busName': 'lsiLogic'},
      {value: 'CentOS 4/5/6/6.5(32-bit)', name: 'CentOS 4/5/6/6.5(32-bit)', 'convertName': 'centosGuest',
        'busName': 'lsiLogic'}
    ]},
    {value: 'Linux', name: 'Red Hat', 'verOptions': [
      {value: 'Red Hat Enterprise Linux 7(64-bit)', name: 'Red Hat Enterprise Linux 7(64-bit)',
        'convertName': 'rhel7_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 6(64-bit)', name: 'Red Hat Enterprise Linux 6(64-bit)',
        'convertName': 'rhel6_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 6(32-bit)', name: 'Red Hat Enterprise Linux 6(32-bit)',
        'convertName': 'rhel6Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 5(64-bit)', name: 'Red Hat Enterprise Linux 5(64-bit)',
        'convertName': 'rhel5_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 5(32-bit)', name: 'Red Hat Enterprise Linux 5(32-bit)',
        'convertName': 'rhel5Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 4(64-bit)', name: 'Red Hat Enterprise Linux 4(64-bit)',
        'convertName': 'rhel4_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 4(32-bit)', name: 'Red Hat Enterprise Linux 4(32-bit)',
        'convertName': 'rhel4Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 3(64-bit)', name: 'Red Hat Enterprise Linux 3(64-bit)',
        'convertName': 'rhel3_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 3(32-bit)', name: 'Red Hat Enterprise Linux 3(32-bit)',
        'convertName': 'rhel3Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 2.1', name: 'Red Hat Enterprise Linux 2.1',
        'convertName': 'rhel2Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Fedora(64-bit)', name: 'Red Hat Fedora(64-bit)', 'convertName': 'redhat64Guest',
        'busName': 'lsiLogic'},
      {value: 'Red Hat Fedora(32-bit)', name: 'Red Hat Fedora(32-bit)', 'convertName': 'redhatGuest',
        'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 7 Server (64-bit)', name: 'Red Hat Enterprise Linux 7 Server (64-bit)',
        'convertName': 'rhel7_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 7 Client (64-bit)', name: 'Red Hat Enterprise Linux 7 Client (64-bit)',
        'convertName': 'rhel7_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 7 Workstation (64-bit)', name: 'Red Hat Enterprise Linux 7 Workstation (64-bit)',
        'convertName': 'rhel7_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 6.5 Server (64-bit)', name: 'Red Hat Enterprise Linux 6.5 Server (64-bit)',
        'convertName': 'rhel6_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 6.5 Client (64-bit)', name: 'Red Hat Enterprise Linux 6.5 Client (64-bit)',
        'convertName': 'rhel6_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 6.5 Workstation (64-bit)', name: 'Red Hat Enterprise Linux 6.5 Workstation (64-bit)',
        'convertName': 'rhel6_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 6.5 Server (32-bit)', name: 'Red Hat Enterprise Linux 6.5 Server (32-bit)',
        'convertName': 'rhel6Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 6.5 Client (32-bit)', name: 'Red Hat Enterprise Linux 6.5 Client (32-bit)',
        'convertName': 'rhel6Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 6.5 Workstation (32-bit)', name: 'Red Hat Enterprise Linux 6.5 Workstation (32-bit)',
        'convertName': 'rhel6Guest', 'busName': 'lsiLogic'},
    ]},
    {value: 'Windows', name: 'Microsoft Windows Server', 'verOptions': [
      {value: 'Windows Server2008 R2(64-bit)',
        name: 'Windows Server2008 R2(64-bit)', 'convertName': 'windows7Server64Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 2000 Advanced Server',
        name: 'Windows 2000 Advanced Server', 'convertName': 'win2000AdvServGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 2000 Server',
        name: 'Windows 2000 Server', 'convertName': 'win2000ServGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Server 2003,Datacenter Edition(64-bit)(experimental)',
        name: 'Windows Server 2003,Datacenter Edition(64-bit)(experimental)',
        'convertName': 'winNetDatacenter64Guest', 'busName': 'lsiLogic'},
      {value: 'Windows Server 2003,Datacenter Edition',
        name: 'Windows Server 2003,Datacenter Edition', 'convertName': 'winNetDatacenterGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Server 2003,Enterprise Edition(64-bit)',
        name: 'Windows Server 2003,Enterprise Edition(64-bit)', 'convertName': 'winNetEnterprise64Guest',
        'busName': 'lsiLogic'},
      {value: 'Windows Server 2003,Enterprise Edition',
        name: 'Windows Server 2003,Enterprise Edition', 'convertName': 'winNetEnterpriseGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Server 2003,Standard Edition(64-bit)',
        name: 'Windows Server 2003,Standard Edition(64-bit)', 'convertName': 'winNetStandard64Guest',
        'busName': 'lsiLogic'},
      {value: 'Windows Server 2003,Standard Edition',
        name: 'Windows Server 2003,Standard Edition', 'convertName': 'winNetStandardGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Server 2003,Web Edition',
        name: 'Windows Server 2003,Web Edition', 'convertName': 'winNetWebGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Small Business Server 2003', name: 'Windows Small Business Server 2003',
        'convertName': 'winNetBusinessGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Server 2012 R2 SERVERSTANDARDCORE', name: 'Windows Server 2012 R2 SERVERSTANDARDCORE',
        'convertName': 'otherGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Server 2012 R2 SERVERSTANDARD', name: 'Windows Server 2012 R2 SERVERSTANDARD',
        'convertName': 'otherGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Server 2012 R2 SERVERDATACENTERCORE', name: 'Windows Server 2012 R2 SERVERDATACENTERCORE',
        'convertName': 'otherGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Server 2012 R2 SERVERDATACENTER', name: 'Windows Server 2012 R2 SERVERDATACENTER',
        'convertName': 'otherGuest', 'busName': 'lsiLogicsas'},
    ]},
    {value: 'Windows', name: 'Microsoft Windows', 'verOptions': [
      {value: 'Windows 10(64-bit)', name: 'Windows 10(64-bit)', 'convertName': 'windows10_64Guest',
        'busName': 'lsiLogicsas'},
      {value: 'Windows 10(32-bit)', name: 'Windows 10(32-bit)', 'convertName': 'windows10Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 8(64-bit)', name: 'Windows 8(64-bit)', 'convertName': 'windows8_64Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 8(32-bit)', name: 'Windows 8(32-bit)', 'convertName': 'windows8Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 7(64-bit)', name: 'Windows 7(64-bit)', 'convertName': 'windows7_64Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 7(32-bit)', name: 'Windows 7(32-bit)', 'convertName': 'windows7Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Vista(64-bit)', name: 'Windows Vista(64-bit)', 'convertName': 'winVista64Guest',
        'busName': 'lsiLogic'},
      {value: 'Windows Vista(32-bit)', name: 'Windows Vista(32-bit)', 'convertName': 'winVistaGuest',
        'busName': 'lsiLogicsas'},
      {value: 'Windows Longhorn (64 bit) (experimental)', name: 'Windows Longhorn (64 bit) (experimental)',
        'convertName': 'winLonghorn64Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Longhorn (experimental)', name: 'Windows Longhorn (experimental)',
        'convertName': 'winLonghornGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows XP Professional(64-bit)', name: 'Windows XP Professional(64-bit)',
        'convertName': 'winXPPro64Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows XP Professional(32-bit)', name: 'Windows XP Professional(32-bit)',
        'convertName': 'winXPProGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows XP Home Edition', name: 'Windows XP Home Edition',
        'convertName': 'winXPHomeGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 2000 Professional', name: 'Windows 2000 Professional', 'convertName': 'win2000ProGuest',
        'busName': 'lsiLogicsas'},
      {value: 'Windows Millennium Edition', name: 'Windows Millennium Edition',
        'convertName': 'winMeGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows NT', name: 'Windows NT', 'convertName': 'winNTGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 98', name: 'Windows 98', 'convertName': 'win98Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 95', name: 'Windows 95', 'convertName': 'win95Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 3.1', name: 'Windows 3.1', 'convertName': 'win31Guest', 'busName': 'lsiLogicsas'},
      {value: 'MS-DOS', name: 'MS-DOS', 'convertName': 'dosGuest', 'busName': 'lsiLogicsas'}
    ]},
    {value: 'Linux', name: 'Debian', 'verOptions': [
      {value: 'Debian GUN/Linux 8(64-bit)', name: 'Debian GUN/Linux 8(64-bit)', 'convertName': 'debian8_64Guest',
        'busName': 'lsiLogic'},
      {value: 'Debian GUN/Linux 8(32-bit)', name: 'Debian GUN/Linux 8(32-bit)', 'convertName': 'debian8Guest',
        'busName': 'lsiLogic'},
      {value: 'Debian GUN/Linux 7(64-bit)', name: 'Debian GUN/Linux 7(64-bit)', 'convertName': 'debian7_64Guest',
        'busName': 'lsiLogic'},
      {value: 'Debian GUN/Linux 7(32-bit)', name: 'Debian GUN/Linux 7(32-bit)', 'convertName': 'debian7Guest',
        'busName': 'lsiLogic'},
      {value: 'Debian GUN/Linux 6(64-bit)', name: 'Debian GUN/Linux 6(64-bit)', 'convertName': 'debian6_64Guest',
        'busName': 'lsiLogic'},
      {value: 'Debian GUN/Linux 6(32-bit)', name: 'Debian GUN/Linux 6(32-bit)', 'convertName': 'debian6Guest',
        'busName': 'lsiLogic'},
      {value: 'Debian GUN/Linux 5(64-bit)', name: 'Debian GUN/Linux 5(64-bit)', 'convertName': 'debian5_64Guest',
        'busName': 'lsiLogic'},
      {value: 'Debian GUN/Linux 5(32-bit)', name: 'Debian GUN/Linux 5(32-bit)', 'convertName': 'debian5Guest',
        'busName': 'lsiLogic'},
      {value: 'Debian GUN/Linux 4(64-bit)', name: 'Debian GUN/Linux 4(64-bit)', 'convertName': 'debian4_64Guest',
        'busName': 'lsiLogic'},
      {value: 'Debian GUN/Linux 4(32-bit)', name: 'Debian GUN/Linux 4(32-bit)', 'convertName': 'debian4Guest',
        'busName': 'lsiLogic'}
    ]},
    {value: 'Linux', name: 'SUSE', 'verOptions': [
      {value: 'SUSE Linux Enterprise 12(64-bit)', name: 'SUSE Linux Enterprise 12(64-bit)',
        'convertName': 'sles12_64Guest', 'busName': 'lsiLogic'},
      {value: 'SUSE Linux Enterprise 11(64-bit)', name: 'SUSE Linux Enterprise 11(64-bit)',
        'convertName': 'sles11_64Guest', 'busName': 'lsiLogic'},
      {value: 'SUSE Linux Enterprise 11(32-bit)', name: 'SUSE Linux Enterprise 11(32-bit)',
        'convertName': 'sles11Guest', 'busName': 'lsiLogic'},
      {value: 'SUSE Linux Enterprise 10(64-bit)', name: 'SUSE Linux Enterprise 10(64-bit)',
        'convertName': 'sles10_64Guest', 'busName': 'lsiLogic'},
      {value: 'SUSE Linux Enterprise 10(32-bit)', name: 'SUSE Linux Enterprise 10(32-bit)',
        'convertName': 'sles10Guest', 'busName': 'lsiLogic'},
      {value: 'SUSE Linux Enterprise 8/9(64-bit)', name: 'SUSE Linux Enterprise 8/9(64-bit)',
        'convertName': 'sles64Guest', 'busName': 'lsiLogic'},
      {value: 'SUSE Linux Enterprise 8/9(32-bit)', name: 'SUSE Linux Enterprise 8/9(32-bit)',
        'convertName': 'slesGuest', 'busName': 'lsiLogic'},
      {value: 'SUSE openSUSE(64-bit)', name: 'SUSE openSUSE(64-bit)',
        'convertName': 'opensuse64Guest', 'busName': 'lsiLogic'},
      {value: 'SUSE openSUSE(32-bit)', name: 'SUSE openSUSE(32-bit)', 'convertName': 'opensuseGuest', 'busName': 'lsiLogic'}
    ]},
    {value: 'Linux', name: 'Asianux', 'verOptions': [
      {value: 'Asianux 4(64-bit)', name: 'Asianux 4(64-bit)', 'convertName': 'asianux4_64Guest', 'busName': 'lsiLogic'},
      {value: 'Asianux 4(32-bit)', name: 'Asianux 4(32-bit)', 'convertName': 'asianux4Guest', 'busName': 'lsiLogic'},
      {value: 'Asianux 3(64-bit)', name: 'Asianux 3(64-bit)', 'convertName': 'asianux3_64Guest', 'busName': 'lsiLogic'},
      {value: 'Asianux 3(32-bit)', name: 'Asianux 3(32-bit)', 'convertName': 'asianux3Guest', 'busName': 'lsiLogic'}
    ]},
    {value: 'Linux', name: 'Oracle', 'verOptions': [
      {value: 'Oracle Linux 4/5/6/7(64-bit)', name: 'Oracle Linux 4/5/6/7(64-bit)', 'convertName': 'oracleLinux64Guest',
        'busName': 'lsiLogic'},
      {value: 'Oracle Linux 4/5/6(32-bit)', name: 'Oracle Linux 4/5/6(32-bit)', 'convertName': 'oracleLinuxGuest',
        'busName': 'lsiLogic'}
    ]},
    {value: this.translate.instant('image.Other'), name: this.translate.instant('image.Other')}
  ];

  /* image format */
  imageFormatOption: any = [
    {value: 'aki', name: 'AKI - Amazon Kernel Image'},
    {value: 'ami', name: 'AMI - Amazon Machine Image'},
    {value: 'ari', name: 'ARI - Amazon Ramdisk Image'},
    {value: 'iso', name: 'ISO - Optical Disk Image'},
    {value: 'qcow2', name: 'QCOW2 - QEMU Emulator'},
    {value: 'raw', name: 'Raw'},
    {value: 'vdi', name: 'VDI'},
    {value: 'vhd', name: 'VHD'},
    {value: 'vmdk', name: 'VMDK'},
    {value: 'qed', name: 'QED'}
  ];

  /* vmware adapter type */
  vmware_adaptertype = [
    {value: null, 'name': this.translate.instant('image.Nothing')},
    {value: 'lsiLogic', name: 'lsiLogic'},
    {value: 'busLogic', name: 'busLogic'},
    {value: 'ide', name: 'ide'},
    {value: 'lsiLogicsas', name: 'lsiLogicsas'},
    {value: 'paraVirtual', name: 'paraVirtual'},
  ];

  /* vmware diskt type */
  vmware_disktype = [
    {value: null, 'name': this.translate.instant('image.Nothing')},
    {value: 'preallocated', name: 'preallocated'},
    {value: 'sparse', name: 'sparse'},
    {value: 'streamOptimized', name: 'streamOptimized'},
    {value: 'thin', name: 'thin'},
  ];

  /* container format */
  containerFormatOption = [
    {value: 'ami', name: 'ami'},
    {value: 'ari', name: 'ari'},
    {value: 'aki', name: 'aki'},
    {value: 'bare', name: 'bare'},
    {value: 'ovf', name: 'ovf'},
    {value: 'ova', name: 'ova'},
    {value: 'docker', name: 'docker'}];

  constructor(private translate: TranslateService, private route: ActivatedRoute,
              private imageRepoService: ImageRepoService) {

  }

  ngOnInit() {
    this.route.params.forEach((params: Params) => {
      this.imageFileId = params['id'];
    });
    /* get image file infomation */
    this.getImage();
  }

  getImage() {
    const that = this;
    this.isShowAllLoading = true;
    this.imageRepoService.getImage(this.imageFileId).then((response: any) => {
      that.image = response;
      if (response.os_type === undefined) {
        response.os_type = '';
      } else {
        if (response.os_type.indexOf(':') !== -1) {
          const os_type_unit = response.os_type.split(':');
          that.image.os_type = os_type_unit[0];
          that.image.os_type_convert = os_type_unit[1];
          /* filter os_type and os_version */
          const osTypeOption_select = _.filter(that.osTypeOption, function (osType_option) {
            return osType_option.value.toLowerCase() === that.image.os_type;
          });
          _.map(osTypeOption_select, function (osType_final) {
            _.map(osType_final.verOptions, function (os) {
              if (os.convertName === that.image.os_type_convert) {
                that.os_type_obj = osType_final.name;
                that.image.os_version = os.name;
                that.verOptions1 = osType_final.verOptions;
              }
            });
          });
        } else {
          that.image.os_type = response.os_type;
        }
      }
      that.image.ironic_use = response.ironic_use === 'true' ? true : false;
      that.image.service_market_use = response.service_market_use === 'true' ? true : false;
      that.image.set_image_password = response.set_image_password === 'True' ? true : false;
      that.image.product_key = response.product_key;
      that.image.protocol = response.protocol.toLowerCase();
      if (response.windows_auto_logon !== null) {
        that.showPW = true;
        that.image.windows_auto_login = response.windows_auto_logon === 'True' ? true : false;
      }
      that.isShowAllLoading = false;
    }, function() {
      that.isShowAllLoading = false;
    });
  }

  /* deal image OS type */
  chooseSys(sys: any) {
    this.image.os_type = '';
    this.os_type_after = '';
    this.image.vmware_adaptertype = '';
    const os_type = _.filter(this.osTypeOption, function(ostype) {
      return ostype.name === sys;
    });
    if (os_type[0].value.indexOf('Windows') !== -1) {
      this.image.os_type += 'windows';
      this.showPW = true;
    }

    if (os_type[0].value.indexOf('Linux') !== -1) {
      this.image.os_type += 'linux';
      this.showPW = false;
    }
    if (os_type[0].name.indexOf(this.translate.instant('image.Other')) !== -1) {
      this.image.os_type += '';
      this.showPW = false;
    }
    this.verOptions1 = os_type[0].verOptions;
  }

  /* deal image OS version */
  modifyType(ver: any) {
    this.os_type_after = '';
    const that = this;
    this.os_version = ver;
    this.image.vmware_adaptertype = '';
    _.map(that.osTypeOption, function (os_type) {
      _.map(os_type.verOptions, function (os_version) {
        if (os_version.name === ver) {
          that.os_type_after = os_version.convertName;
        }
      });
    });
    _.forEach(this.osTypeOption, function(osType) {
      _.forEach(osType.verOptions, function(os_type) {
        if (that.os_version === os_type.name) {
          that.image.vmware_adaptertype = os_type.busName;
        }
      });
    });
  }

  /* save image file edit result*/
  SaveFile() {
    const that = this;
    that.isShowLoading = true;
    /* join image OS type and version */
    if (this.image.os_type !== 'windows') {
      this.image.product_key = '';
    }

    if (!!this.image.os_type) {
      if (!!this.os_type_after) {
        this.image.os_type = this.image.os_type + ':' + this.os_type_after;
      }
    }
    /* the data which will post to server */
    const postData = {
      disk_format: that.image.disk_format,
      container_format: that.image.container_format,
      os_type: that.image.os_type,
      os_version: that.os_version,
      vmware_adaptertype: that.image.vmware_adaptertype,
      vmware_disktype: that.image.vmware_disktype,
      min_disk: that.image.min_disk,
      min_ram: that.image.min_ram,
      public: that.image.public,
      windows_auto_logon: '',
      service_market_use: that.image.service_market_use.toString(),
      ironic_use: that.image.ironic_use.toString(),
      product_key: that.image.product_key
    };

    if (that.showPW) {
      if (that.image.windows_auto_login) {
        postData.windows_auto_logon = 'True';
      } else {
        postData.windows_auto_logon = 'False';
      }
    }

    this.imageRepoService.editImageFile(that.imageFileId, postData)
      .then((res: Response) => {
        that.isShowLoading = false;
        window.history.back(-1);
      }, function() {
        that.isShowLoading = false;
      });
  }

  cancel() {
    window.history.back(-1);
  }
}
