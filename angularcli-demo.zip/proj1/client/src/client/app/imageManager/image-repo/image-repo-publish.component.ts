import { TranslateService } from '@ngx-translate/core';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute , Params } from '@angular/router';
import { StorageService } from '../../storage.service';

import { ImageRepoService } from './image-repo.service';

@Component({
  moduleId: module.id,
  templateUrl: 'image-repo-publish.component.html',
})

export class ImageRepoPublishComponent implements OnInit {
  placeholder: string = this.translate.instant('image.SelectImage');
  id = '';
  images: any = [];
  cloudenvs: any = [];
  clouds: any = [];
  dcs: any = [];
  selectedItem: any = [];
  imageName = '';
  usedCloudEnvs: any[];
  isShowLoading = false;
  buttonShowLoading = false;
  isShowInfo = false;
  infoMsgs: string[] = [this.translate.instant('image.ReleaseWait')];
  usedDcAndCloud= '';
  usedDcAndCloudArray: any = [];
  links: any = [
    {name: this.translate.instant('image.ImageStorage'), url: '../..', relative: true},
    {name: this.translate.instant('image.ReleaseMir')}
  ];

  constructor(private translate: TranslateService, private imageRepoService: ImageRepoService,
              private router: Router, private route: ActivatedRoute, private storageService: StorageService) {
    if (this.storageService.getCurrentLang() === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }
  }

  ngOnInit() {
    this.isShowLoading = true;
    this.route.params.forEach((params: Params) => {
      this.id = params['id'];
    });
    this.getImages();
    setTimeout(function() {
      this.isShowLoading = false;
    }, 20000);
  }

  goToStorage() {
    this.router.navigate(['/main/image/imageRepo']);
  }

  getImages() {
    const that = this;
    this.imageRepoService.getImageFiles().then((response: any) => {
      this.images = _.filter(response, function(res) {
        if (res.id === that.id) {
          that.imageName = res.name;
          return;
        }
      });
      this.imageRepoService.getImageFile(this.id).then((resp: any) => {
        if (resp.os_type === undefined) {
          resp.os_type = '';
        }
        that.usedCloudEnvs = resp.cloudenv_images;
        that.imageRepoService.getDcs().then((res: any) => {
          that.dcs = res;
          _.map(that.dcs, function(dc) {
            if (dc.cloudEnvs !== undefined && dc.cloudEnvs.length !== 0) {
              _.map(dc.cloudEnvs, function(dc_cloud) {
                _.map(that.usedCloudEnvs, function(cloud) {
                  if (cloud.image_status === 'active' && cloud.cloudenv_id === dc_cloud.id) {
                    if (!that.usedDcAndCloud) {
                      that.usedDcAndCloud = dc.name + '/' + cloud.cloudenv_name;
                    } else {
                      that.usedDcAndCloud = that.usedDcAndCloud + ',' + dc.name + '/' + cloud.cloudenv_name;
                    }
                  }
                });
                that.imageRepoService.getCloudenvs().then((cloudRes: any) => {
                  that.clouds = cloudRes;
                  _.map(that.clouds, function(cloud) {
                    if (cloud.status !== 'abnormal' && cloud.id === dc_cloud.id) {
                      if (that.usedCloudEnvs.length === 0) {
                        that.cloudenvs.push({
                          'value': dc.name + '/' + dc_cloud.name,
                          'checked': false,
                          'macroValue': {
                            'dc_id': dc.id,
                            'dc_name': dc.name,
                            'cloudenvs_id': dc_cloud.id,
                            'cloudenvs_name': dc_cloud.name,
                            'cloudenvs_type': dc_cloud.envType,
                            'dc_checked': false,
                            'cloud_checked': false
                          }
                        });
                      } else {
                        let hasEqual = false;
                        for (const usedCloudEnv of that.usedCloudEnvs) {
                          if (usedCloudEnv.cloudenv_id === dc_cloud.id) {
                            hasEqual = true;
                            return;
                          }
                        }
                        if (!hasEqual) {
                          that.cloudenvs.push({
                            'value': dc.name + '/' + dc_cloud.name,
                            'checked': false,
                            'macroValue': {
                              'dc_id': dc.id,
                              'dc_name': dc.name,
                              'cloudenvs_id': dc_cloud.id,
                              'cloudenvs_name': dc_cloud.name,
                              'cloudenvs_type': dc_cloud.envType,
                              'dc_checked': false,
                              'cloud_checked': false
                            }
                          });
                        }
                      }
                    }
                  });
                  that.isShowLoading = false;
                }, function() {
                  that.isShowLoading = false;
                });
              });
            }
          });
          that.usedDcAndCloudArray = that.usedDcAndCloud.split(',');
          if (res.size === 0) {
            that.isShowLoading = false;
          }
        }, function() {
          that.isShowLoading = false;
        });
      }, function() {
        that.isShowLoading = false;
      });
    }, function() {
      that.isShowLoading = false;
    });
  }

  selectedMeterItems(data: any) {
    this.selectedItem = data;
  }

  imagePublish(type: any) {
    this.buttonShowLoading = true;
    const that = this;
    const selected = [];
    _.map(that.selectedItem, function (item) {
      const getted = _.filter(that.clouds, function (env) {
        return env.id === item.cloudenvs_id;
      });
      selected.push({cloudenvs_id: item.cloudenvs_id,
        cloudenvs_name: item.cloudenvs_name,
        cloudenvs_type: getted.length === 0 ? '' : getted[0].envType});
    });

    const data = {
      op_type: type,
      cloudenvs: selected
    };
    this.imageRepoService.publish(this.id, data).then(() => {
      this.buttonShowLoading = false;
      this.isShowInfo = true;
      setTimeout(function () {
        that.isShowInfo = false;
        that.router.navigate(['main/image/imageSummary']);
      }, 2000);
    }, function() {
      this.buttonShowLoading = false;
    });
  }

  cancel() {
    this.router.navigate(['main/image/imageRepo']);
  }
}
