
import {TranslateService} from '@ngx-translate/core';
import { FileUploader } from 'ng2-file-upload/ng2-file-upload';
import { Router, ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';
import { ApiResourceService as Http } from '../../apiResource.service';
import { Component, IterableDiffers, OnInit, OnDestroy, DoCheck } from '@angular/core';
import { ImageRepoService } from './image-repo.service';
import { StorageService } from '../../storage.service';

@Component({
  moduleId: module.id,
  templateUrl: 'image-repo.component.html'
})

export class ImageRepoComponent implements OnInit, OnDestroy, DoCheck {
  links: any = [];
  isDropdownOpen = false;
  image: Object;
  uploader: any = {queue: []};
  differ: any;
  isSameImage = false;
  timer: any;
  curImagesize: any;
  timerSize: any;
  totalSize: any;
  usedSize: any;
  totalSizeStr: string;
  isFirstLoad = true;
  usedSizeStr: string;
  perCentSize: any;
  getImageRecovery = true;
  getSpaceRecovery = true;
  alarmTip = false;
  bothDelete = false;
  onlyFileileDelete = false;
  chosenOption: any = 'deleteAll';
  isShowLoading = false;
  infoMsgs: string[] = [this.translate.instant('gengyun.deltesuccess')];
  isShowInfo = false;
  noPubMessage : any = {
    title: this.translate.instant('image.PubTip'),
    message: this.translate.instant('image.PubTipContent'),
    confirmText: this.translate.instant('CONFIRM'),
    cancelText: this.translate.instant('Cancel'),
    type: 'exclamation'
  };
  noEditMessage : any = {
    title: this.translate.instant('image.EditTip'),
    message: this.translate.instant('image.EditTipContent'),
    confirmText: this.translate.instant('CONFIRM'),
    cancelText: this.translate.instant('Cancel'),
    type: 'exclamation'
  };
  tryDelNet: any = {};
  window: window= window;
  rowData: any[];
  columnDefs: any[] = [
    {
      field: 'name',
      title: this.translate.instant('Name'),
      events: 'operateEvents',
      formatter: function (value, row, index) {
        return `<a  href="javascript:void(0);" class="detail">${value}</a>`;
      },
      sortable: true
    },
    {
      field: 'size',
      title: this.translate.instant('image.FileSize'),
      formatter: function (value, row, index) {
        if (parseInt(row.size / 1024) < 1024) {
          return (row.size / 1024).toFixed(1) + 'KB';
        } else if (parseInt((row.size / 1024) / 1024) < 1024) {
          return ((row.size / 1024) / 1024).toFixed(1) + 'MB';
        } else if (parseInt(((row.size / 1024) / 1024) / 1024) < 1024) {
          return (((row.size / 1024) / 1024) / 1024).toFixed(1) + 'GB';
        } else {
          return ((((row.size / 1024) / 1024) / 1024) / 1024).toFixed(1) + 'TB';
        }
      },
      sortable: true
    },
    {
      field: 'disk_format',
      title: this.translate.instant('image.DiskType'),
      sortable: true
    },
    //{
    //  field: 'container_format',
    //  title: this.translate.instant('image.ContainerFormat'),
    //  sortable: true
    //},
    // {
    //   field: 'os_type',
    //   title: this.translate.instant('image.OperSysType')
    // },
    // {
    //   field: 'public',
    //   title: this.translate.instant('image.IsPubVisible')
    // },
    // {
    //   field: 'protect',
    //   title: this.translate.instant('image.IsProtect')
    // },
    // {
    //   field: 'os_version',
    //   title: this.translate.instant('image.OperSysVer')
    // },
    {
      field: 'createAt',
      title: this.translate.instant('image.CreateTime'),
      sortable: true
    },
    //{
    //  field: 'updatedAt',
    //  title: this.translate.instant('image.UpdateTime')
    //},
    {
      field: 'upload_progress_rate',
      title: this.translate.instant('image.UpProgress'),
      width: 100,
      formatter: function (value, row, index) {
        if (row.status === 'uploading' && row.upload_progress_rate !== '') {
          return `<div class="progress" style="margin-bottom:0">
            <div class="progress-bar progress-bar-success" role =""progressbar"
                 aria-valuemin="0%" aria-valuemax="99%" style="width:${row.upload_progress_rate}%">
            <span class="sr-only" style="position:inherit">${row.upload_progress_rate}%</span>
            </div>
            </div>`;
        } else {
          return `<span>--</span>`;
        }
        //else if (row.status === 'uploaded') {
        //  return `<div class="progress" style="margin-bottom:0">
        //    <div class="progress-bar progress-bar-success" role =""progressbar"
        //         aria-valuemin="100%" aria-valuemax="100%" style="width:100%">
        //    <span class="sr-only" style="position:inherit">100%</span>
        //    </div>
        //    </div>`;
        //}
      }
    },
    {
      field: 'upload_transfer_rate',
      title: this.translate.instant('image.UploadRate'),
      width: 90,
      formatter: function (value, row, index) {
        if (row.status === 'uploading' && row.upload_transfer_rate !== '') {
          return row.upload_transfer_rate;
        } else {
          return '--';
        }
      }
    },
    {
      field: 'status',
      title: this.translate.instant('Status'),
      formatter: this.statusFormatter,
      sortable: true
    },
    {
      title: this.translate.instant('Operation'),
      width: 160,
      cellStyle: (value, row, index, field) => {
        return {
          css: {'min-width': '123px'}
        };
      },
      field: 'operate',
      events: 'operateEvents',
      //formatter: (value, row, index) => {
      //  return ['<div class="btn-group table-operate-float">'+
      //  '<button class="btn btn-default delete table-operate-btn" data-toggle="modal" data-target="#deleteModal">'
      //  +that.translate.instant('Delete')+'</button>'+
      //
      //  '<button class="btn btn-default dropdown-toggle table-operate-btn" id="dropdownMenu" data-toggle="dropdown" >'
      //
      //  +'<span class="caret"></span></button>'+
      //  '<ul class="dropdown-menu dropdown-menu-top table-operate-ulfont" role="menu" aria-labelledby="dropdownMenu1">'+
      //                '<li role="presentation">'+
      //                 '<a href="javascript:void(0);" class="delete" data-toggle="modal" data-target="#deleteModal">'
      //  +that.translate.instant('Delete')+'</a> </li> </ul> </div>'
      //  ].join('');
      //}
      formatter: (value, row, index) => {
        if (this.storageService.getUserOperRights('Domain Image File', 'DELETE')) {
          if (row.status !== 'unloaded') {
            const strPartOne = '<div class="btn-group">'
              + '<button class="btn btn-default publish" data-toggle="modal">'
              + this.translate.instant('image.ReleaseMir') + '</button>'
              + '<button class="btn btn-default dropdown-toggle" id="dropdownMenu" data-toggle="dropdown">'
              + '<span class="caret"></span></button>' +
              '<ul class="dropdown-menu dropdown-menu-top" role="menu" aria-labelledby="dropdownMenu1">'
              + '<li role="presentation">' +
              '<a href="javascript:void(0);" class="delete" data-toggle="modal">'
              + this.translate.instant('Delete') + '</a></li><li role="presentation">' +
              '<a href="javascript:void(0);" class="edit" data-toggle="modal">'
              + this.translate.instant('Edit') + '</a></li></ul></div>';
            return strPartOne;
          } else {
            const strPartOne = '<div class="btn-group">'
              + '<button class="btn btn-default uploadImage" data-toggle="modal">'
              + this.translate.instant('image.UploadImages') + '</button>'
              + '<button class="btn btn-default dropdown-toggle" id="dropdownMenu" data-toggle="dropdown">'
              + '<span class="caret"></span></button>' +
              '<ul class="dropdown-menu dropdown-menu-top" role="menu" aria-labelledby="dropdownMenu1">'
              + '<li role="presentation">' +
              '<a href="javascript:void(0);" class="delete" data-toggle="modal">'
              + this.translate.instant('Delete') + '</a></li><li role="presentation">' +
              '<a href="javascript:void(0);" class="edit" data-toggle="modal">'
              + this.translate.instant('Edit') + '</a></li></ul></div>';
            return strPartOne;
          }
        }else {
          return '<div class="btn-group table-operate-float">' +
            '<button class="btn btn-default table-operate-btn publish" data-toggle="modal">'
            + this.translate.instant('image.ReleaseMir') + '</button></div>';
        }
      }
    }
  ];

  gridOptions: any = {
    pagination: true,
    pageSize: 10,
    pageList: [10, 25, 50, 100],
    search: true,
    strictSearch: false,
    searchText: '',
    paginationDetailHAlign: 'left',
    paginationHAlign: 'left',
    clickToSelect: false,
    sortable: true,
    sortName: 'createAt',
    sortOrder: 'desc'
  };

  constructor(private translate: TranslateService, private imageRepoService: ImageRepoService,
  private router: Router, private route: ActivatedRoute, private storageService: StorageService,
              differs: IterableDiffers, private http: Http) {
    const that = this;
    this.image = {
      name: '',
      origin: 'local',
    };
    this.differ = differs.find([]).create(null);
    this.accessToken = this.storageService.getAccessToken();
    this.headers = {
      name: 'Access-Token',
      value: this.accessToken
    };
    this.fileName = {
      name: 'fileName',
      value: ''
    };
    this.repoId = {
      name: 'repoId',
      value: ''
    };
    this.checksum = {
      name: 'checksum',
      value: ''
    };
    this.fileSize = {
      name: 'fileSize',
      value: ''
    };
    this.filter = {};
    this.uploader = new FileUploader({url: '/api/imagesvc/v1.0/files/upload',
      headers: [this.headers, this.fileName, this.repoId, this.checksum, this.fileSize]
    });

    if (that.storageService.getCurrentLang() === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }
    this.window.operateEvents = {
      'click .detail': function (e, value, row , index) {
        that.detail(row);
      },
      'click .delete': function (e, value, row , index) {
        that.tryDelNet = row;
        that.deleteModelShow(row);
      },
      'click .publish': function (e, value, row , index) {
        that.toPublish(row);
      },
      'click .uploadImage': function (e, value, row , index) {
        that.tryDelNet = row;
        that.toUpload(row);
      },
    'click .edit': function (e, value, row , index) {
      that.toEdit(row);
    }
    };
  }

  ngOnInit() {
    const that = this;
    this.initTable();
    this.getDiskSize();
    this.getImages();
    that.links = [{name: that.translate.instant('image.ImageResource'),
      url: 'main/image/imageSummary'},
      {name: that.translate.instant('image.ImageStorage')}];
    this.timer = setInterval(function () {
      if (that.getImageRecovery) {
        that.getImages();
      }
    }, 2000);
    this.timerSize = setInterval(function () {
      if (that.getSpaceRecovery) {
        that.getDiskSize();
      }
    }, 30000);
  }

  cancelNopubModal() {
    $('#nopubModal').modal('hide');
  }

  cancelNoEditModal() {
    $('#noEditModal').modal('hide');
  }

  cancelUpload() {
    $('#uploadModal').modal('hide');
  }

  uploadFile() {
    this.isShowLoading = true;
    this.isShowLoading = true;
    $('#uploadModal').modal('hide');
  }

  cancel() {
    const that = this;
    $('#imageDeleteModal').modal('hide');
    setTimeout(function() {
      that.chosenOption = 'deleteAll';
    }, 1000);
  }

  statusFormatter(value, row, index) {
    if (value.toLowerCase() === 'active' || value.toLowerCase() === 'uploaded' || value.toLowerCase() === 'unloaded') {
      return '<img class="status-img" src="assets/images/status/icon_status_green.png" />' + value;
    } else if (value.toLowerCase() === 'error' || value.toLowerCase() === 'upload failed'
      || value.toLowerCase() === 'publish failed') {
      return '<img class="status-img" src="assets/images/status/icon_status_red.png" />' + value;
    } else if (value.toLowerCase() === 'uploading') {
      return '<img src="assets/images/loading_grey_s2.gif" />' + value;
    }else if (value.indexOf('ing') !== -1) {
      return '<img class="status-img" src="assets/images/status/icon_status_blue.png" /> ' + value;
    } else {
      return '<img class="status-img" src="assets/images/status/icon_status_grey.png" /> ' + value;
    }
  }

  ngDoCheck() {
    const changes = this.differ.diff(this.uploader.queue);
    if (changes && this.uploader.queue.length > 0) {
      this.uploader.queue = [this.uploader.queue.pop()];
      this.image.name = this.uploader.queue[0].file.name;
      this.curImagesize =  this.uploader.queue[0].file.size;
      this.uploader.options.headers[1].value = this.image.name;
    }
    if (!!this.image.name) {
      this.isSameImage = (this.tryDelNet.name === this.image.name) && (this.tryDelNet.size === this.curImagesize);
    }
  }

  ngOnDestroy() {
    clearInterval(this.timer);
    clearInterval(this.timerSize);
  }

  getImages() {
    const that = this;
    if (this.isFirstLoad) {
      $('#imageTable').bootstrapTable('showLoading');
    }
    this.getImageRecovery = false;
    this.imageRepoService.getImages().then((response: any) => {
      this.getImageRecovery = true;
      if (that.isFirstLoad) {
        that.isFirstLoad = false;
        $('#imageTable').bootstrapTable('hideLoading');
      }
      _.map(response, function(imageItem) {
        if (imageItem.upload_progress_rate === '100') {
          imageItem.upload_progress_rate = '99';
        }
        if (imageItem.upload_transfer_rate !== '') {
          imageItem.upload_transfer_rate = that.toFixRate(parseInt(imageItem.upload_transfer_rate));
        }
      });
      this.rowData = response;
      if (this.isDropdownOpen === false) {
        $('#imageTable').bootstrapTable('load', this.rowData);
      }
    }, function() {
      this.getImageRecovery = true;
      if (that.isFirstLoad) {
        that.isFirstLoad = false;
        $('#imageTable').bootstrapTable('hideLoading');
      }
    });
  }

  getDiskSize() {
    this.getSpaceRecovery = false;
    this.imageRepoService.getDiskSize().then((res: any) => {
      this.getSpaceRecovery = true;
      if (!!res && !!res.total_space && !!res.free_space) {
        this.totalSize = res.total_space;
        this.usedSize = res.total_space - res.free_space;
        if (parseInt(this.totalSize) !== 0) {
          this.perCentSize = this.toPercent(this.usedSize / this.totalSize);
          if ((this.usedSize / this.totalSize).toFixed(1) >= 0.8) {
            this.alarmTip = true;
          } else {
            this.alarmTip = false;
          }
        }
      } else {
        this.totalSize = 0;
        this.usedSize = 0;
        this.perCentSize = this.toPercent(0);
      }
      this.totalSizeStr = this.toFixUnit(this.totalSize);
      this.usedSizeStr = this.toFixUnit(this.usedSize);
      if (this.alarmTip) {
        $('.progress-bar-danger').css('width', this.perCentSize);
      } else {
        $('.progress-bar-info').css('width', this.perCentSize);
      }
    }, function () {
      this.getSpaceRecovery = true;
    });
  }

  toFixUnit(size: any) {
    if (parseInt(size) < 1024) {
      return size.toFixed(1) + 'KB';
    } else if (parseInt(size / 1024) < 1024) {
      return (size / 1024).toFixed(1) + 'MB';
    } else if (parseInt((size / 1024) / 1024) < 1024) {
      return ((size / 1024) / 1024).toFixed(1) + 'GB';
    } else {
      return (((size / 1024) / 1024) / 1024).toFixed(1) + 'TB';
    }
  }

  toPercent(data: any) {
    const strData = (data * 100).toFixed(1);
    const ret = strData.toString() + '%';
    return ret;
  }

  toFixRate(size: any) {
    if (parseInt(size) < 1024) {
      return size.toFixed(1) + 'KB/s';
    } else if (parseInt(size / 1024) < 1024) {
      return (size / 1024).toFixed(1) + 'MB/s';
    } else if (parseInt((size / 1024) / 1024) < 1024) {
      return ((size / 1024) / 1024).toFixed(1) + 'GB/s';
    } else {
      return (((size / 1024) / 1024) / 1024).toFixed(1) + 'TB/s';
    }
  }

  deleteModelShow(item: any) {
    $('#imageDeleteModal').modal('show');
  }

  confirm() {
    const that = this;
    if (that.chosenOption === 'deleteAll') {
      $('#imageDeleteModal').modal('hide');
      that.deleteImagefileAllInfo(that.tryDelNet);
    }
    if (that.chosenOption === 'deleteOnly') {
      $('#imageDeleteModal').modal('hide');
      that.deleteImagefileOnly(that.tryDelNet);
    }
    setTimeout(function() {
      that.chosenOption = 'deleteAll';
    }, 1000);
  }

  detail(item: any) {
    this.router.navigate(['detail', item.id], {relativeTo: this.route});
  }

  toPublish(item: any) {
    if (item.status !== 'uploaded') {
      $('#nopubModal').modal('show');
    } else {
      this.router.navigate(['publishImage', item.id], {relativeTo: this.route});
    }
  }

  toEdit(item: any) {
    if (item.status === 'uploading') {
      $('#noEditModal').modal('show');
    } else {
      this.router.navigate(['edit', item.id], {relativeTo: this.route});
    }
  }

  deleteImagefileAllInfo(item: any) {
    const that = this;
    this.imageRepoService.deleteAllImageFileInfo(item.id).then((response: any) => {
      that.isShowInfo = true;
      setTimeout(function () {
        that.isShowInfo = false;
      }, 1000);
      this.getImages();
      this.getDiskSize();
    });
  }

  deleteImagefileOnly(item: any) {
    const that = this;
    this.imageRepoService.deleteImageFileOnly(item.id).then((response: any) => {
      that.isShowInfo = true;
      setTimeout(function () {
        that.isShowInfo = false;
      }, 1000);
      that.getImages();
      that.getDiskSize();
    });
  }

  chooseModel(model: any) {
    this.image.name = '';
    this.image.url = '';
  }

  uploadImage() {
    this.router.navigate(['upload'], {relativeTo: this.route});
  }

  reUploadFile() {
    this.isShowLoading = true;
    if (!!this.curImagesize && this.curImagesize !== 0) {
      this.uploadNotEmptyImage();
    }else {
      this.isShowLoading = false;
    }
  }

  uploadNotEmptyImage() {
    const that = this;
    const postData = {
      id: that.tryDelNet.id,
      file_size: that.curImagesize / 1024,
      name: that.tryDelNet.name
    };
    this.http.post('/api/imagesvc/v1.0/imagefiles/onlyfile/reupload', postData)
      .subscribe((res: Response) => {
        that.isShowLoading = false;
        _.map(that.tryDelNet.links, function (link) {
          if (link.rel === 'self') {
            that.uploader.queue[0].ref = link.uri;
            return;
          }
        });
        that.uploader.queue[0].uploadTime = that.getUploadTime();
        that.uploader.options.headers[2].value = that.tryDelNet.id;
        that.uploader.options.headers[4].value = that.curImagesize;
        that.uploader.queue[0].upload();
        $('#uploadModal').modal('hide');
      }, function() {
        that.isShowLoading = false;
      });
  }

  getUploadTime() {
    return new Date().getTime();
  }

  toUpload(item: any) {
    $('#uploadModal').modal('show');
  }

  deleteNet() {
    const selectedItems: any[] = $('#imageTable').bootstrapTable('getSelections');

    for (const item of selectedItems) {
      this.deleteImagefileAllInfo(item);
    }
  }
  sureDel() {
    this.deleteImagefileAllInfo(this.tryDelNet);
  }

  cancle() {
    this.bothDelete = false;
    this.onlyFileileDelete = false;
    $('#imageDeleteModal').modal('hide');
  }

  initTable() {
    const that = this;
    $('#imageTable').bootstrapTable($.extend(this.gridOptions, {
      toolbar: '#toolbar1',
      data: this.rowData,
      columns: this.columnDefs
    }));

    $('.bootstrap-table .search input').attr('placeholder', this.translate.instant('WordForFilter'))
      .parent().append(`<span></span>`);

    $('#imageTable').on('show.bs.dropdown', function () {
      that.isDropdownOpen = true;
    });
    $('#imageTable').on('hide.bs.dropdown', function () {
      that.isDropdownOpen = false;
    });
  }
}
