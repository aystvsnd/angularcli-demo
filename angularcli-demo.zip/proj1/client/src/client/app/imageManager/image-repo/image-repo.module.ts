import { NgModule } from '@angular/core';
import { routing } from './image-repo.routes';
import { SharedModule } from '../../shared/index';

import {ImageRepoComponent} from './image-repo.component';
import {ImageRepoService} from './image-repo.service';
import {ImageUploadComponent} from './image-upload.component';
import {ImageDetailComponent} from './image-detail.component';
import { ImageEditComponent } from './image-edit.component';
import { ImageRepoPublishComponent } from './image-repo-publish.component';
import {AntMultiSelectModule} from '../../netResource/port-group/overview/index';

@NgModule({
  imports: [routing, SharedModule, AntMultiSelectModule],
  declarations: [ImageRepoComponent, ImageUploadComponent, ImageDetailComponent, ImageRepoPublishComponent,
    ImageEditComponent],
  providers: [ImageRepoService],
})

export class ImageRepoModule { }
