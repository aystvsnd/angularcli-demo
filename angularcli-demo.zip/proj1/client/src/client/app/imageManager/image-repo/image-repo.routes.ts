import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ImageRepoComponent} from './image-repo.component';
import {ImageUploadComponent} from './image-upload.component';
import {ImageDetailComponent} from './image-detail.component';
import { ImageRepoPublishComponent } from './image-repo-publish.component';
import { ImageEditComponent } from './image-edit.component';

const routes: Routes = [
  {
    path: 'imageRepo',
    children: [
      {path: '', component: ImageRepoComponent},
      {path: 'upload', component: ImageUploadComponent},
      {path: 'detail/:id', component: ImageDetailComponent},
      {path: 'publishImage/:id', component: ImageRepoPublishComponent},
      {path: 'edit/:id', component: ImageEditComponent}
    ]
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
