import { Injectable } from '@angular/core';
import {Response} from '@angular/http';
import { appConfig } from '../../app.config';
// import '../rxjs-operators';
//import * as _ from 'underscore';
import { ApiResourceService as Http } from '../../apiResource.service';
// import { Observable} from 'rxjs/Observable';

@Injectable()
export class ImageRepoService {
  uploader: any= [];

  constructor(public http: Http) {

  }

  getImages() {
    return this.http.get(appConfig.imageUrl + 'imagefiles').toPromise().then((res: Response) => {
      return res.json().imagefiles;
    });
  }

  getImage(id: any) {
    return this.http.get(appConfig.imageUrl + 'imagefiles/' + id).toPromise().then((res: Response) => {
      return res.json();
    });
  }

  editImageFile(id: string, data: any) {
    return this.http.put(appConfig.imageUrl + 'imagefiles/' + id, data).toPromise()
      .then((res: Response) => { console.log(''); });
  }

  deleteAllImageFileInfo(id: any) {
    return this.http.delete(appConfig.imageUrl + 'imagefiles/' + id).toPromise().then(() => {
      console.log('');
    });
  }

  deleteImageFileOnly(id: any) {
    return this.http.delete(appConfig.imageUrl + 'imagefiles/' + id + '/onlyfile').toPromise().then(() => {
      console.log('');
    });
  }

  clearPubInfo() {
    console.log('');
  }

  publish(id: any, data: any) {
    return this.http.post(appConfig.imageUrl + 'imagefiles/' + id, data).toPromise().then((res: Response) => {
      console.log('');
    });
  }

  getCloudenvs() {
    return this.http.get(appConfig.vrmServiceUrl + 'cloudenvs').toPromise().then((res: Response) => {
      return res.json().cloudEnvs;
    });
  }
  getDcs() {
    return this.http.get(appConfig.vrmServiceUrl + 'dcs').toPromise().then((res: Response) => {
      return res.json().dcs;
    });
  }

  getImageFiles() {
    return this.http.get(appConfig.imageUrl + 'imagefiles').toPromise().then((res: Response) => {
      return res.json().imagefiles;
    });
  }

  getImageFile(id: any) {
    return this.http.get(appConfig.imageUrl + 'imagefiles/' + id).toPromise().then((res: Response) => {
      return res.json();
    });
  }

  getDiskSize() {
    return this.http.get('/api/v1.0/reposvc/repos/repo_space_info').toPromise().then((res: Response) => {
      return res.json();
    });
  }
}

