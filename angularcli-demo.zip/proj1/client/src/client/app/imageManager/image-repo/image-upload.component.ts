
import {TranslateService} from '@ngx-translate/core';

import { Component, IterableDiffers, DoCheck } from '@angular/core';
import { FileUploader } from 'ng2-file-upload/ng2-file-upload';
import { Response } from '@angular/http';
import { Router } from '@angular/router';
import { ImageRepoService } from './image-repo.service';
import { ApiResourceService as Http } from '../../apiResource.service';
import { StorageService } from '../../storage.service';

@Component({
    moduleId: module.id,
    selector: 'img-upload',
    templateUrl: 'image-upload.component.html'
    })

export class ImageUploadComponent implements DoCheck {
  links: any = [{name: this.translate.instant('image.ImageResource'), url: 'main/image/imageSummary'},
    {name: this.translate.instant('image.ImageStorage'), url: '../', relative: true},
    {name: this.translate.instant('image.UploadImages')}
  ];
  imagefiles: any;
  image: Object;
  origin_url: any;
  diskFormat = '';
  containerFormat = '';
  firstName = '';
  firstSize = 0;
  firstFlag = true;
  isCorrectFtp = false;
  imageIsExist: boolean;
  isNameCharactor = false;
  differ: any;
  os_version = '';
  os_type_after = '';
  os_type = '';
  showPW = false;
  isShowInfo = false;
  infoMsgs: string[] = [this.translate.instant('image.UploadWait')];
  verOptions1: any = [];
  uploader: any = {queue: []};
  isShowLoading = false;
  osTypeOption: any = [
    {value: 'Linux', name: 'Ubuntu', 'verOptions': [
      {value: 'Ubuntu Linux(64-bit)', name: 'Ubuntu Linux(64-bit)', 'convertName': 'ubuntu64Guest', 'busName': 'lsiLogic'},
      {value: 'Ubuntu Linux(32-bit)', name: 'Ubuntu Linux(32-bit)', 'convertName': 'ubuntuGuest', 'busName': 'lsiLogic'}
    ]},
    {value: 'Linux', name: 'CentOS', 'verOptions': [
      {value: 'CentOS 4/5/6/6.5/7(64-bit)', name: 'CentOS 4/5/6/6.5/7(64-bit)', 'convertName': 'centos64Guest',
        'busName': 'lsiLogic'},
      {value: 'CentOS 4/5/6/6.5(32-bit)', name: 'CentOS 4/5/6/6.5(32-bit)', 'convertName': 'centosGuest',
        'busName': 'lsiLogic'}
    ]},
    {value: 'Linux', name: 'Red Hat', 'verOptions': [
      {value: 'Red Hat Enterprise Linux 7(64-bit)', name: 'Red Hat Enterprise Linux 7(64-bit)',
        'convertName': 'rhel7_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 6(64-bit)', name: 'Red Hat Enterprise Linux 6(64-bit)',
        'convertName': 'rhel6_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 6(32-bit)', name: 'Red Hat Enterprise Linux 6(32-bit)',
        'convertName': 'rhel6Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 5(64-bit)', name: 'Red Hat Enterprise Linux 5(64-bit)',
        'convertName': 'rhel5_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 5(32-bit)', name: 'Red Hat Enterprise Linux 5(32-bit)',
        'convertName': 'rhel5Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 4(64-bit)', name: 'Red Hat Enterprise Linux 4(64-bit)',
        'convertName': 'rhel4_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 4(32-bit)', name: 'Red Hat Enterprise Linux 4(32-bit)',
        'convertName': 'rhel4Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 3(64-bit)', name: 'Red Hat Enterprise Linux 3(64-bit)',
        'convertName': 'rhel3_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 3(32-bit)', name: 'Red Hat Enterprise Linux 3(32-bit)',
        'convertName': 'rhel3Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 2.1', name: 'Red Hat Enterprise Linux 2.1',
        'convertName': 'rhel2Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Fedora(64-bit)', name: 'Red Hat Fedora(64-bit)', 'convertName': 'redhat64Guest',
        'busName': 'lsiLogic'},
      {value: 'Red Hat Fedora(32-bit)', name: 'Red Hat Fedora(32-bit)', 'convertName': 'redhatGuest',
        'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 7 Server (64-bit)', name: 'Red Hat Enterprise Linux 7 Server (64-bit)',
        'convertName': 'rhel7_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 7 Client (64-bit)', name: 'Red Hat Enterprise Linux 7 Client (64-bit)',
        'convertName': 'rhel7_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 7 Workstation (64-bit)', name: 'Red Hat Enterprise Linux 7 Workstation (64-bit)',
        'convertName': 'rhel7_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 6.5 Server (64-bit)', name: 'Red Hat Enterprise Linux 6.5 Server (64-bit)',
        'convertName': 'rhel6_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 6.5 Client (64-bit)', name: 'Red Hat Enterprise Linux 6.5 Client (64-bit)',
        'convertName': 'rhel6_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 6.5 Workstation (64-bit)', name: 'Red Hat Enterprise Linux 6.5 Workstation (64-bit)',
        'convertName': 'rhel6_64Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 6.5 Server (32-bit)', name: 'Red Hat Enterprise Linux 6.5 Server (32-bit)',
        'convertName': 'rhel6Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 6.5 Client (32-bit)', name: 'Red Hat Enterprise Linux 6.5 Client (32-bit)',
        'convertName': 'rhel6Guest', 'busName': 'lsiLogic'},
      {value: 'Red Hat Enterprise Linux 6.5 Workstation (32-bit)', name: 'Red Hat Enterprise Linux 6.5 Workstation (32-bit)',
        'convertName': 'rhel6Guest', 'busName': 'lsiLogic'},
    ]},
    {value: 'Windows', name: 'Microsoft Windows Server', 'verOptions': [
      {value: 'Windows Server2008 R2(64-bit)',
        name: 'Windows Server2008 R2(64-bit)', 'convertName': 'windows7Server64Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 2000 Advanced Server',
        name: 'Windows 2000 Advanced Server', 'convertName': 'win2000AdvServGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 2000 Server',
        name: 'Windows 2000 Server', 'convertName': 'win2000ServGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Server 2003,Datacenter Edition(64-bit)(experimental)',
        name: 'Windows Server 2003,Datacenter Edition(64-bit)(experimental)',
        'convertName': 'winNetDatacenter64Guest', 'busName': 'lsiLogic'},
      {value: 'Windows Server 2003,Datacenter Edition',
        name: 'Windows Server 2003,Datacenter Edition', 'convertName': 'winNetDatacenterGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Server 2003,Enterprise Edition(64-bit)',
        name: 'Windows Server 2003,Enterprise Edition(64-bit)', 'convertName': 'winNetEnterprise64Guest',
        'busName': 'lsiLogic'},
      {value: 'Windows Server 2003,Enterprise Edition',
        name: 'Windows Server 2003,Enterprise Edition', 'convertName': 'winNetEnterpriseGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Server 2003,Standard Edition(64-bit)',
        name: 'Windows Server 2003,Standard Edition(64-bit)', 'convertName': 'winNetStandard64Guest',
        'busName': 'lsiLogic'},
      {value: 'Windows Server 2003,Standard Edition',
        name: 'Windows Server 2003,Standard Edition', 'convertName': 'winNetStandardGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Server 2003,Web Edition',
        name: 'Windows Server 2003,Web Edition', 'convertName': 'winNetWebGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Small Business Server 2003', name: 'Windows Small Business Server 2003',
        'convertName': 'winNetBusinessGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Server 2012 R2 SERVERSTANDARDCORE', name: 'Windows Server 2012 R2 SERVERSTANDARDCORE',
        'convertName': 'otherGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Server 2012 R2 SERVERSTANDARD', name: 'Windows Server 2012 R2 SERVERSTANDARD',
        'convertName': 'otherGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Server 2012 R2 SERVERDATACENTERCORE', name: 'Windows Server 2012 R2 SERVERDATACENTERCORE',
        'convertName': 'otherGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Server 2012 R2 SERVERDATACENTER', name: 'Windows Server 2012 R2 SERVERDATACENTER',
        'convertName': 'otherGuest', 'busName': 'lsiLogicsas'},
    ]},
    {value: 'Windows', name: 'Microsoft Windows', 'verOptions': [
      {value: 'Windows 10(64-bit)', name: 'Windows 10(64-bit)', 'convertName': 'windows10_64Guest',
        'busName': 'lsiLogicsas'},
      {value: 'Windows 10(32-bit)', name: 'Windows 10(32-bit)', 'convertName': 'windows10Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 8(64-bit)', name: 'Windows 8(64-bit)', 'convertName': 'windows8_64Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 8(32-bit)', name: 'Windows 8(32-bit)', 'convertName': 'windows8Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 7(64-bit)', name: 'Windows 7(64-bit)', 'convertName': 'windows7_64Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 7(32-bit)', name: 'Windows 7(32-bit)', 'convertName': 'windows7Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Vista(64-bit)', name: 'Windows Vista(64-bit)', 'convertName': 'winVista64Guest',
        'busName': 'lsiLogic'},
      {value: 'Windows Vista(32-bit)', name: 'Windows Vista(32-bit)', 'convertName': 'winVistaGuest',
        'busName': 'lsiLogicsas'},
      {value: 'Windows Longhorn (64 bit) (experimental)', name: 'Windows Longhorn (64 bit) (experimental)',
        'convertName': 'winLonghorn64Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows Longhorn (experimental)', name: 'Windows Longhorn (experimental)',
        'convertName': 'winLonghornGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows XP Professional(64-bit)', name: 'Windows XP Professional(64-bit)',
        'convertName': 'winXPPro64Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows XP Professional(32-bit)', name: 'Windows XP Professional(32-bit)',
        'convertName': 'winXPProGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows XP Home Edition', name: 'Windows XP Home Edition',
        'convertName': 'winXPHomeGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 2000 Professional', name: 'Windows 2000 Professional', 'convertName': 'win2000ProGuest',
        'busName': 'lsiLogicsas'},
      {value: 'Windows Millennium Edition', name: 'Windows Millennium Edition',
        'convertName': 'winMeGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows NT', name: 'Windows NT', 'convertName': 'winNTGuest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 98', name: 'Windows 98', 'convertName': 'win98Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 95', name: 'Windows 95', 'convertName': 'win95Guest', 'busName': 'lsiLogicsas'},
      {value: 'Windows 3.1', name: 'Windows 3.1', 'convertName': 'win31Guest', 'busName': 'lsiLogicsas'},
      {value: 'MS-DOS', name: 'MS-DOS', 'convertName': 'dosGuest', 'busName': 'lsiLogicsas'}
    ]},
    {value: 'Linux', name: 'Debian', 'verOptions': [
      {value: 'Debian GUN/Linux 8(64-bit)', name: 'Debian GUN/Linux 8(64-bit)', 'convertName': 'debian8_64Guest',
        'busName': 'lsiLogic'},
      {value: 'Debian GUN/Linux 8(32-bit)', name: 'Debian GUN/Linux 8(32-bit)', 'convertName': 'debian8Guest',
        'busName': 'lsiLogic'},
      {value: 'Debian GUN/Linux 7(64-bit)', name: 'Debian GUN/Linux 7(64-bit)', 'convertName': 'debian7_64Guest',
        'busName': 'lsiLogic'},
      {value: 'Debian GUN/Linux 7(32-bit)', name: 'Debian GUN/Linux 7(32-bit)', 'convertName': 'debian7Guest',
        'busName': 'lsiLogic'},
      {value: 'Debian GUN/Linux 6(64-bit)', name: 'Debian GUN/Linux 6(64-bit)', 'convertName': 'debian6_64Guest',
        'busName': 'lsiLogic'},
      {value: 'Debian GUN/Linux 6(32-bit)', name: 'Debian GUN/Linux 6(32-bit)', 'convertName': 'debian6Guest',
        'busName': 'lsiLogic'},
      {value: 'Debian GUN/Linux 5(64-bit)', name: 'Debian GUN/Linux 5(64-bit)', 'convertName': 'debian5_64Guest',
        'busName': 'lsiLogic'},
      {value: 'Debian GUN/Linux 5(32-bit)', name: 'Debian GUN/Linux 5(32-bit)', 'convertName': 'debian5Guest',
        'busName': 'lsiLogic'},
      {value: 'Debian GUN/Linux 4(64-bit)', name: 'Debian GUN/Linux 4(64-bit)', 'convertName': 'debian4_64Guest',
        'busName': 'lsiLogic'},
      {value: 'Debian GUN/Linux 4(32-bit)', name: 'Debian GUN/Linux 4(32-bit)', 'convertName': 'debian4Guest',
        'busName': 'lsiLogic'}
    ]},
    {value: 'Linux', name: 'SUSE', 'verOptions': [
      {value: 'SUSE Linux Enterprise 12(64-bit)', name: 'SUSE Linux Enterprise 12(64-bit)',
        'convertName': 'sles12_64Guest', 'busName': 'lsiLogic'},
      {value: 'SUSE Linux Enterprise 11(64-bit)', name: 'SUSE Linux Enterprise 11(64-bit)',
        'convertName': 'sles11_64Guest', 'busName': 'lsiLogic'},
      {value: 'SUSE Linux Enterprise 11(32-bit)', name: 'SUSE Linux Enterprise 11(32-bit)',
        'convertName': 'sles11Guest', 'busName': 'lsiLogic'},
      {value: 'SUSE Linux Enterprise 10(64-bit)', name: 'SUSE Linux Enterprise 10(64-bit)',
        'convertName': 'sles10_64Guest', 'busName': 'lsiLogic'},
      {value: 'SUSE Linux Enterprise 10(32-bit)', name: 'SUSE Linux Enterprise 10(32-bit)',
        'convertName': 'sles10Guest', 'busName': 'lsiLogic'},
      {value: 'SUSE Linux Enterprise 8/9(64-bit)', name: 'SUSE Linux Enterprise 8/9(64-bit)',
        'convertName': 'sles64Guest', 'busName': 'lsiLogic'},
      {value: 'SUSE Linux Enterprise 8/9(32-bit)', name: 'SUSE Linux Enterprise 8/9(32-bit)',
        'convertName': 'slesGuest', 'busName': 'lsiLogic'},
      {value: 'SUSE openSUSE(64-bit)', name: 'SUSE openSUSE(64-bit)',
        'convertName': 'opensuse64Guest', 'busName': 'lsiLogic'},
      {value: 'SUSE openSUSE(32-bit)', name: 'SUSE openSUSE(32-bit)', 'convertName': 'opensuseGuest', 'busName': 'lsiLogic'}
    ]},
    {value: 'Linux', name: 'Asianux', 'verOptions': [
      {value: 'Asianux 4(64-bit)', name: 'Asianux 4(64-bit)', 'convertName': 'asianux4_64Guest', 'busName': 'lsiLogic'},
      {value: 'Asianux 4(32-bit)', name: 'Asianux 4(32-bit)', 'convertName': 'asianux4Guest', 'busName': 'lsiLogic'},
      {value: 'Asianux 3(64-bit)', name: 'Asianux 3(64-bit)', 'convertName': 'asianux3_64Guest', 'busName': 'lsiLogic'},
      {value: 'Asianux 3(32-bit)', name: 'Asianux 3(32-bit)', 'convertName': 'asianux3Guest', 'busName': 'lsiLogic'}
    ]},
    {value: 'Linux', name: 'Oracle', 'verOptions': [
      {value: 'Oracle Linux 4/5/6/7(64-bit)', name: 'Oracle Linux 4/5/6/7(64-bit)', 'convertName': 'oracleLinux64Guest',
        'busName': 'lsiLogic'},
      {value: 'Oracle Linux 4/5/6(32-bit)', name: 'Oracle Linux 4/5/6(32-bit)', 'convertName': 'oracleLinuxGuest',
        'busName': 'lsiLogic'}
    ]},
    {value: this.translate.instant('image.Other'), name: this.translate.instant('image.Other')}
  ];
  imageOriginOption: any = [
    {value: 'local', name: this.translate.instant('image.LocalFiles')},
    {value: 'ftpNetwork', name: this.translate.instant('image.FtpNetFile')}
  ];
  imageFormatOption: any = [
                           {value: 'aki', name: 'AKI - Amazon Kernel Image'},
                           {value: 'ami', name: 'AMI - Amazon Machine Image'},
                           {value: 'ari', name: 'ARI - Amazon Ramdisk Image'},
                           {value: 'iso', name: 'ISO - Optical Disk Image'},
                           {value: 'qcow2', name: 'QCOW2 - QEMU Emulator'},
                           {value: 'raw', name: 'Raw'},
                           {value: 'vdi', name: 'VDI'},
                           {value: 'vhd', name: 'VHD'},
                           {value: 'vmdk', name: 'VMDK'},
                           {value: 'qed', name: 'QED'}
                           //{value:'ovf', name:'OVF'},
                           //{value:'ova', name:'OVA'}
                          ];
  vmware_adaptertype = [
    {value: '', 'name': this.translate.instant('image.Nothing')},
    {value: 'lsiLogic', name: 'lsiLogic'},
    {value: 'busLogic', name: 'busLogic'},
    {value: 'ide', name: 'ide'},
    {value: 'lsiLogicsas', name: 'lsiLogicsas'},
    {value: 'paraVirtual', name: 'paraVirtual'},
  ];
  vmware_disktype: any = [
    {value: '', 'name': this.translate.instant('image.Nothing')},
    {value: 'preallocated', name: 'preallocated'},
    {value: 'sparse', name: 'sparse'},
    {value: 'streamOptimized', name: 'streamOptimized'},
    {value: 'thin', name: 'thin'},
  ];
  containerFormatOption = [
    {value: 'ami', name: 'ami'},
    {value: 'ari', name: 'ari'},
    {value: 'aki', name: 'aki'},
    {value: 'bare', name: 'bare'},
    {value: 'ovf', name: 'ovf'},
    {value: 'ova', name: 'ova'},
    {value: 'docker', name: 'docker'}];
  curImagesize = 0;
  errMsgs = ['The image size can not be 0!'];
  isShowError = false;

  constructor(private translate: TranslateService, private http: Http,
              differs: IterableDiffers,
              private router: Router,
              private imageRepoService: ImageRepoService,
              private storageService: StorageService) {
      this.image = {
          name: '',
          origin: 'local',
          disk_format: 'vmdk',
          os_type: '',
          windows_auto_login: false,
          vmware_disktype: 'preallocated',
          vmware_adaptertype: '',
          public: 'true',
          protected: 'false',
          container_format: 'bare',
          set_image_password: false,
          service_market_use: false,
          ironic_use: false,
          product_key: ''
      };
      this.origin_url = {
          ip: '',
          port: '21',
          route: '',
          name: '',
          psw: '',
          type: 'ftp'
      };

      this.differ = differs.find([]).create(null);
      this.imageIsExist = false;
      this.accessToken = this.storageService.getAccessToken();
      // this.headers = new Headers({'Content-Type': 'application/json','Access-Token':this.accessToken});
      this.headers = {
          name: 'Access-Token',
          value: this.accessToken
      };
      this.fileName = {
          name: 'fileName',
          value: ''
      };
      this.repoId = {
          name: 'repoId',
          value: ''
      };
      this.checksum = {
          name: 'checksum',
          value: ''
      };
      this.fileSize = {
          name: 'fileSize',
          value: ''
      };
      this.filter = {};
      this.uploader = new FileUploader({url: '/api/imagesvc/v1.0/files/upload',
                                        headers: [this.headers, this.fileName, this.repoId, this.checksum, this.fileSize]});
  }
  // setNfType(nfType:any) {
  //     var nfTypeMap = {'GSM': 'BSC'};
  //     this.nfType =  _.has(nfTypeMap, nfType.toUpperCase()) ? _.property(nfType.toUpperCase())(nfTypeMap): nfType;
  // }
  // ngOnInit() {
  //   this.getImages();
  // }
  //
  // getImages() {
  //   this.imageRepoService.getImages().then((response:any)=> {
  //     this.imagefiles = response;
  //   });
  // }

  // //checkName() {
  //   this.imageIsExist = _.contains(_.pluck(this.imagefiles, 'name'), this.image.name);
  // }

  ngDoCheck() {
    if (this.image.origin === 'local') {
      this.isCorrectFtp = true;
      const changes = this.differ.diff(this.uploader.queue);
      if (changes && this.uploader.queue.length > 0) {
        this.uploader.queue = [this.uploader.queue.pop()];
        this.image.name = this.uploader.queue[0].file.name;
        this.curImagesize =  this.uploader.queue[0].file.size;
        // var fileDescribe = this.image.name.substr(0, this.image.name.lastIndexOf('.')).split('_');
        this.uploader.options.headers[1].value = this.image.name;
        // if (fileDescribe.length === 2) {
        //   this.setNfType(fileDescribe[0]);
        //   this.versionNo = fileDescribe[1];
        // }
      }
      if (this.image.name.length > 0 && this.firstName.length === 0 && this.firstFlag) {
        this.firstName = this.image.name;
        this.firstSize = this.curImagesize;
        this.dealImageInfo();
        this.firstFlag = false;
      }
      if (this.image.name.length > 0 && !this.firstFlag) {
        if (this.firstName !== this.image.name || this.firstSize !== this.curImagesize) {
          this.firstName = this.image.name;
          this.firstSize = this.curImagesize;
          this.dealImageInfo();
        }
      }
    } else {
      if (this.image.url && this.image.url.trim().lastIndexOf('/') > 6) {
        this.image.name = this.image.url.trim().substring(this.image.url.trim().lastIndexOf('/') + 1,
          this.image.url.trim().length);
      } else {
        this.image.name = '';
      }
      if (this.image.name.length > 0 && this.firstName.length === 0 && this.firstFlag) {
        this.firstName = this.image.name;
        this.dealImageInfo();
        this.firstFlag = false;
      }
      if (this.image.name.length > 0 && !this.firstFlag) {
        if (this.firstName !== this.image.name) {
          this.firstName = this.image.name;
          this.dealImageInfo();
        }
      }
      if (this.image.origin === 'ftpNetwork') {
        const reg = new RegExp('^(sftp|ftp)://.*');
        this.isCorrectFtp = reg.test(this.image.url);
      }
    }

    this.isNameCharactor = new RegExp('[\\u4E00-\\u9FFF]+', 'g').test(this.image.name);
  }

  dealImageInfo() {
    const that = this;
    if (this.image.name.lastIndexOf('.') !== -1) {
      this.diskFormat = this.image.name.trim().substring(this.image.name.trim().lastIndexOf('.') + 1,
        this.image.name.trim().length).toLowerCase();
      const ifo = _.filter(that.imageFormatOption, function(iformat) {
        return iformat.value === that.diskFormat;
      });
      if (ifo.length === 0) {
        if (that.diskFormat === 'img') {
          that.image.disk_format = 'raw';
        } else {
          that.image.disk_format = 'vmdk';
        }
      } else {
        that.image.disk_format = that.diskFormat;
      }
      const cfo = _.filter(that.containerFormatOption, function(cformat) {
        return cformat.value === that.diskFormat;
      });
      if (cfo.length === 0) {
        that.image.container_format = 'bare';
      } else {
        that.image.container_format = that.diskFormat;
      }
    } else {
      that.image.disk_format = 'vmdk';
      that.image.container_format = 'bare';
    }
  }

  getUploadTime() {
      return new Date().getTime();
  }

  uploadFile() {
    this.isShowError = false;
    this.isShowLoading = true;
    if (this.image.url) {
      this.uploadNotEmptyImage();
    } else if (!!this.curImagesize) {
      this.uploadNotEmptyImage();
    }else {
      this.isShowError = true;
      this.isShowLoading = false;
    }
  }

  uploadNotEmptyImage() {
    const that = this;
    if (!!this.image.os_type) {
      if (!!this.os_type_after) {
        this.image.os_type = this.image.os_type + ':' + this.os_type_after;
      }
    }
    if (this.image.disk_format !== 'vmdk') {
      this.image.vmware_adaptertype = '';
      this.image.vmware_disktype = '';
    }
    const postData = {
        disk_format: this.image.disk_format,
        min_disk: this.image.min_disk,
        min_ram: this.image.min_ram,
        name: this.image.name,
        protected: this.image.protected,
        public: this.image.public,
        os_type: this.image.os_type,
        os_version: this.os_version,
        vmware_adaptertype: this.image.vmware_adaptertype,
        vmware_disktype: this.image.vmware_disktype,
        url: '',
        container_format: this.image.container_format,
        service_market_use: this.image.service_market_use.toString(),
        ironic_use: this.image.ironic_use.toString(),
        product_key: this.image.product_key
    };

    if (that.image.set_image_password) {
      postData.set_image_password = 'True';
    } else {
      postData.set_image_password = 'False';
    }

    if (that.showPW) {
      if (that.image.windows_auto_login) {
        postData.windows_auto_logon = 'True';
      } else {
        postData.windows_auto_logon = 'False';
      }
    }

    if (this.image.url) {
      postData.url = this.image.url;
    }

    if (this.image.url !== '' && this.image.url !== undefined) {
        postData.url = this.image.url;
        this.http.post('/api/imagesvc/v1.0/imagefiles', postData)
            .subscribe((res: Response) => {
            that.isShowLoading = false;
            that.isShowInfo = true;
            setTimeout(function () {
              that.isShowInfo = false;
              window.history.back(-1);
            }, 2000);
          }, function() {
            that.isShowLoading = false;
          });
      setTimeout(function () {
        that.isShowLoading = false;
      }, 30000);
    } else {
        postData.file_size = this.curImagesize / 1024;
        this.http.post('/api/imagesvc/v1.0/imagefiles', postData)
            .subscribe((res: Response) => {
                that.isShowLoading = false;
                const links = res.json().links;
                _.map(links, function (link) {
                  if (link.rel === 'self') {
                    that.uploader.queue[0].ref = link.uri;
                    return;
                  }
                });

                that.uploader.queue[0].uploadTime = that.getUploadTime();
                that.uploader.options.headers[2].value = res.json().id;
                // that.uploader.options.headers[3].value = that.image.checksum.toString();
                // that.uploader.options.headers[4].value = Math.floor(that.uploader.queue[0].file.size/1024/1024);
                that.uploader.options.headers[4].value = that.uploader.queue[0].file.size;
                // that.uploader.queue[0].
                // that.uploader.queue[0].formData.push(data);
                that.uploader.queue[0].upload();
                // that.imageRepoService.setUploader(that.uploader);
                that.isShowInfo = true;
              setTimeout(function () {
                that.isShowInfo = false;
                window.history.back(-1);
              }, 2000);
            }, function() {
            that.isShowLoading = false;
          });
      setTimeout(function () {
        that.isShowLoading = false;
      }, 30000);
    }
  }

  chooseSys(sys: any) {
    this.image.os_type = '';
    this.image.vmware_adaptertype = '';
    this.os_type_after = '';
    if (sys.value.indexOf('Windows') !== -1) {
      this.image.os_type += 'windows';
      this.showPW = true;
    } else {
      this.image.product_key = '';
    }

    if (sys.value.indexOf('Linux') !== -1) {
      this.image.os_type += 'linux';
      this.showPW = false;
    }
    if (sys.name.indexOf(this.translate.instant('image.Other')) !== -1) {
      this.image.os_type += '';
      this.showPW = false;
    }
    this.verOptions1 = sys.verOptions;
  }

  modifyType(ver: any) {
    this.os_type_after = '';
    this.image.vmware_adaptertype = '';
    this.os_version = ver.name;
    if (ver !== null) {
      this.os_type_after = ver.convertName;
    }
    const that = this;
    _.forEach(this.osTypeOption, function(osType) {
      _.forEach(osType.verOptions, function(os_type) {
        if (that.os_version === os_type.name) {
          that.image.vmware_adaptertype = os_type.busName;
        }
      });
    });
  }

  chooseModel(model: any) {
    this.image.name = '';
    this.image.url = '';
    this.firstName = '';
    this.firstSize = 0;
    this.firstFlag = false;
    this.isCorrectFtp = false;
    if (this.image.origin === 'ftpNetwork') {
      $('#FTPModal').modal('show');
      this.image.url = this.origin_url.type + '://' + this.origin_url.name + ':' + this.origin_url.psw + '@' +
        this.origin_url.ip + ':' + this.origin_url.port + this.origin_url.route;
    }
  }

  changes() {
    if (!this.origin_url.port) {
      this.image.url = this.origin_url.type + '://' + this.origin_url.name + ':' + this.origin_url.psw + '@' +
        this.origin_url.ip + this.origin_url.route;
    }else {
      this.image.url = this.origin_url.type + '://' + this.origin_url.name + ':' + this.origin_url.psw + '@' +
        this.origin_url.ip + ':' + this.origin_url.port + this.origin_url.route;
    }
  }

  chooseFtp(type: any) {
    if (this.origin_url.type === 'sftp') {
      this.origin_url.port = '22';
    }else if (this.origin_url.type === 'ftp') {
      this.origin_url.port = '21';
    }
  }

  isCorrectIP(uri: any) {
    const reg = new RegExp
    ('((25[0-5]|2[0-4]\\d|[01]?\\d\\d?)\\.){3}(25[0-5]|2[0-4]\\d|[01]?\\d\\d?)|(hostname)$');
    return reg.test(uri) || uri === '';
  }

  isCorrectName(name: any) {
    const reg = new RegExp('^[0-9a-zA-Z_]{1,}$');
    return reg.test(name) || name === '';
  }

  isCorrectRoute(route: any) {
    const reg = new RegExp('^/.*[^/]$');
    return reg.test(route) || route === '';
  }

  CorrectRoute(route: any) {
    const reg = new RegExp('^/.*[^/]$');
    return reg.test(route);
  }

  confirm() {
    $('#FTPModal').modal('hide');
  }

  cancel() {
    window.history.back(-1);
  }
}
