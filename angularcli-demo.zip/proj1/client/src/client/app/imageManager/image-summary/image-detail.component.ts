
import {TranslateService} from '@ngx-translate/core';

import { Router, ActivatedRoute , Params} from '@angular/router';
import {Component, OnInit, OnDestroy} from '@angular/core';
import { ImageSummaryService } from './image-summary.service';

@Component({
  moduleId: module.id,
  templateUrl: 'image-detail.component.html',
})

export class ImageDetailComponent implements OnInit, OnDestroy {
  links: any = [ {name: this.translate.instant('image.ImageResource'),
  url: '../..', relative: true}, {name: this.translate.instant('image.ImageDetail')}];

  detail: any = '';

  id: any;

  constructor(private translate: TranslateService, private imageSummaryService: ImageSummaryService,
  private router: Router, private route: ActivatedRoute) {
    $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
  }

  ngOnInit() {
    this.route.params.forEach((params: Params) => {
      this.id = params['id'];
    });
    this.getImage();
  }

  getImage() {
    const that = this;
    this.imageSummaryService.getImage(this.id).then((response: any) => {
      if (!!response.virtual_size) {
        if (parseInt(response.virtual_size / 1024) < 1024) {
          response.virtual_size = (response.virtual_size / 1024).toFixed(1) + 'KB';
        } else if (parseInt((response.virtual_size / 1024) / 1024) < 1024) {
          response.virtual_size = ((response.virtual_size / 1024) / 1024).toFixed(1) + 'MB';
        } else if (parseInt(((response.virtual_size / 1024) / 1024) / 1024) < 1024) {
          response.virtual_size = (((response.virtual_size / 1024) / 1024) / 1024).toFixed(1) + 'GB';
        } else {
          response.virtual_size = ((((response.virtual_size / 1024) / 1024) / 1024) / 1024).toFixed(1) + 'TB';
        }
      }
      that.detail = response;
    });
  }
}
