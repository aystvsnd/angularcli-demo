import { TranslateService } from '@ngx-translate/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import {ImageSummaryService} from './image-summary.service';

@Component({
  moduleId: module.id,
  templateUrl: 'image-publish.component.html',
  styleUrls: ['image-publish.component.css'],
})

export class ImagePublishComponent implements OnInit {
  placeholder: string = this.translate.instant('image.SelectImage');
  id = '';
  images: any = [];
  cloudenvs: any = [];
  clouds: any = [];
  dcs: any = [];
  selectedItem: any = [];
  usedCloudEnvs: any[];
  isShowLoading = false;
  buttonShowLoading = false;
  isShowInfo = false;
  infoMsgs: string[] = [this.translate.instant('image.ReleaseWait')];
  imageObject: any;
  selected_image = '';
  selected_image_id = '';
  usedDcAndCloud= '';
  usedDcAndCloudArray: any = [];
  links: any = [
    {name: this.translate.instant('image.ImageResource'), url: '../', relative: true},
    {name: this.translate.instant('image.ReleaseMir')}
  ];

  gridOptions: any = {
    pagination: true,
    pageSize: 4,
    pageList: [4],
    search: true,
    strictSearch: false,
    searchText: '',
    paginationDetailHAlign: 'left',
    paginationHAlign: 'left',
    clickToSelect: false,
    singleSelect: true,
    sortable: true
  };

  rowData: any[];
  selectedRows: any[] = [];
  columnDefs: any[] = [
    {
      checkbox: true
    },
    {
      field: 'name',
      title: this.translate.instant('image.ImageName'),
      sortable: true
    },
    {
      field: 'updatedAt',
      title: this.translate.instant('image.UpdateTime'),
      sortable: true
    },
    {
      field: 'disk_format',
      title: this.translate.instant('image.ImageType'),
      sortable: true
    },
    {
      field: 'size',
      title: this.translate.instant('image.FileSize') + '(KB)',
      formatter: function (value, row, index) {
        return parseInt(row.size / 1024);
      },
      sortable: true
    }
  ];
  constructor(private translate: TranslateService, private imageSummaryService: ImageSummaryService,
              private router: Router) {
    $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
  }

  ngOnInit() {
    this.getImages();
    this.getCloudEnv();
    setTimeout(function() {
      this.isShowLoading = false;
    }, 20000);
  }

  getImages() {
    const that = this;
    this.isShowLoading = true;
    this.imageSummaryService.getImageFiles().then((response: any) => {
      this.images = response;
      that.isShowLoading = false;
    }, function() {
      that.isShowLoading = false;
    });
  }

  getCloudEnv() {
    const that = this;
    that.isShowLoading = true;
    this.imageSummaryService.getCloudenvs().then((res: any) => {
      that.clouds = res;
      that.imageSummaryService.getDcs().then((res: any) => {
        that.dcs = res;
        that.isShowLoading = false;
      }, function() {
        that.isShowLoading = false;
      });
    });
  }

  goToStorage() {
    this.router.navigate(['/main/image/imageRepo']);
  }

  //selectImage(image:any) {
  //  let that = this;
  //  that.cloudenvs = [];
  //  this.isShowLoading = true;
  //  this.id = image.id;
  //  this.imageSummaryService.getImageFile(this.id).then((response:any)=> {
  //    if(response.os_type === undefined) {
  //      response.os_type = '';
  //    }
  //    that.usedCloudEnvs = response.cloudenv_images;
  //    _.map(that.dcs, function(dc) {
  //      if(dc.cloudEnvs !== undefined && dc.cloudEnvs.length !== 0) {
  //        _.map(dc.cloudEnvs, function(dc_cloud) {
  //          _.map(that.clouds, function(cloud) {
  //            if(cloud.status !== 'abnormal' && cloud.id === dc_cloud.id) {
  //              if(that.usedCloudEnvs.length === 0) {
  //                that.cloudenvs.push({
  //                  'value': dc.name + '/' + dc_cloud.name,
  //                  'checked': false,
  //                  'macroValue': {
  //                    'dc_id': dc.id,
  //                    'dc_name': dc.name,
  //                    'cloudenvs_id': dc_cloud.id,
  //                    'cloudenvs_name': dc_cloud.name,
  //                    'cloudenvs_type': dc_cloud.envType,
  //                    'dc_checked':false,
  //                    'cloud_checked':false
  //                  }
  //                });
  //              } else {
  //                let hasEqual = false;
  //                for(let usedCloudEnv of that.usedCloudEnvs) {
  //                  if(usedCloudEnv.cloudenv_id === dc_cloud.id) {
  //                    hasEqual = true;
  //                    return;
  //                  }
  //                }
  //                if(!hasEqual) {
  //                  that.cloudenvs.push({
  //                    'value': dc.name + '/' + dc_cloud.name,
  //                    'checked': false,
  //                    'macroValue': {
  //                      'dc_id': dc.id,
  //                      'dc_name': dc.name,
  //                      'cloudenvs_id': dc_cloud.id,
  //                      'cloudenvs_name': dc_cloud.name,
  //                      'cloudenvs_type': dc_cloud.envType,
  //                      'dc_checked':false,
  //                      'cloud_checked':false
  //                    }
  //                  });
  //                }
  //              }
  //            }
  //          });
  //        });
  //      }
  //    });
  //    this.isShowLoading = false;
  //  }, function() {
  //    this.isShowLoading = false;
  //  });
  //}

  selectedMeterItems(data: any) {
    this.selectedItem = data;
  }

  imagePublish(type: any) {
    this.buttonShowLoading = true;
    const that = this;
    const selected = [];
    _.map(that.selectedItem, function (item) {
      const getted = _.filter(that.clouds, function (env) {
        return env.id === item.cloudenvs_id;
      });
      selected.push({cloudenvs_id: item.cloudenvs_id,
        cloudenvs_name: item.cloudenvs_name,
        cloudenvs_type: getted.length === 0 ? '' : getted[0].envType});
    });

    const data = {
      op_type: type,
      cloudenvs: selected
    };

    this.imageSummaryService.publish(this.selected_image_id, data).then(() => {
      this.buttonShowLoading = false;
      this.isShowInfo = true;
      setTimeout(function () {
        that.isShowInfo = false;
        that.router.navigate(['main/image/imageSummary']);
      }, 2000);
    }, function() {
      this.buttonShowLoading = false;
    });
  }

  cancel() {
    window.history.back(-1);
  }

  toSelectImage() {
    this.initImageTable();
    this.getImageFiles();
  }

  initImageTable() {
    $('#imageListModal').modal('show');
    $('#imageTable').bootstrapTable($.extend(this.gridOptions, {
      data: this.rowData,
      columns: this.columnDefs
    }));

    $('.bootstrap-table .search input').attr('placeholder', this.translate.instant('WordForFilter'))
      .parent().append(`<span></span>`);
  }

  getImageFiles() {
    this.imageSummaryService.getImageFiles().then((response: any) => {
      this.rowData = _.filter(response, function (rowData) {
        return rowData.status === 'uploaded';
      });
      $('#imageTable').bootstrapTable('load', this.rowData);
    });
  }

  confirm() {
    this.buttonShowLoading = true;
    this.imageObject = $('#imageTable').bootstrapTable('getSelections');
    this.usedDcAndCloud = '';
    this.selected_image = this.imageObject[0].name;
    this.selected_image_id = this.imageObject[0].id;
    this.publishedCloud();
    //this.dealHint();
    this.imageObject = [];
    $('#imageListModal').modal('hide');
  }

  publishedCloud() {
    const that = this;
    that.cloudenvs = [];
    this.imageSummaryService.getImageFile(this.selected_image_id).then((response: any) => {
      if (response.os_type === undefined) {
        response.os_type = '';
      }
      that.usedCloudEnvs = response.cloudenv_images;
      _.map(that.dcs, function(dc) {
        if (dc.cloudEnvs !== undefined && dc.cloudEnvs.length !== 0) {
          _.map(dc.cloudEnvs, function(dc_cloud) {
            _.map(that.usedCloudEnvs, function(cloud) {
              if (cloud.image_status === 'active' && cloud.cloudenv_id === dc_cloud.id) {
                if (!that.usedDcAndCloud) {
                  that.usedDcAndCloud = dc.name + '/' + cloud.cloudenv_name;
                } else {
                  that.usedDcAndCloud = that.usedDcAndCloud + ',' + dc.name + '/' + cloud.cloudenv_name;
                }
              }
            });
            _.map(that.clouds, function(cloud) {
              if (cloud.status !== 'abnormal' && cloud.id === dc_cloud.id) {
                if (that.usedCloudEnvs.length === 0) {
                  that.cloudenvs.push({
                    'value': dc.name + '/' + dc_cloud.name,
                    'checked': false,
                    'macroValue': {
                      'dc_id': dc.id,
                      'dc_name': dc.name,
                      'cloudenvs_id': dc_cloud.id,
                      'cloudenvs_name': dc_cloud.name,
                      'cloudenvs_type': dc_cloud.envType,
                      'dc_checked': false,
                      'cloud_checked': false
                    }
                  });
                } else {
                  let hasEqual = false;
                  for (const usedCloudEnv of that.usedCloudEnvs) {
                    if (usedCloudEnv.cloudenv_id === dc_cloud.id) {
                      hasEqual = true;
                      return;
                    }
                  }
                  if (!hasEqual) {
                    that.cloudenvs.push({
                      'value': dc.name + '/' + dc_cloud.name,
                      'checked': false,
                      'macroValue': {
                        'dc_id': dc.id,
                        'dc_name': dc.name,
                        'cloudenvs_id': dc_cloud.id,
                        'cloudenvs_name': dc_cloud.name,
                        'cloudenvs_type': dc_cloud.envType,
                        'dc_checked': false,
                        'cloud_checked': false
                      }
                    });
                  }
                }
              }
            });
          });
        }
      });
      that.usedDcAndCloudArray = that.usedDcAndCloud.split(',');
      that.buttonShowLoading = false;
    }, function() {
      that.buttonShowLoading = false;
    });
  }

  //dealHint() {
  //  let arr = this.usedDcAndCloud.split('')
  //  for(let i = 0; i < arr.length; i+=58) {
  //    arr[i] += '\\n';
  //  }
  //  this.usedDcAndCloud = arr.join('');
  //}

  cancle() {
    $('#table-imageTable').bootstrapTable('uncheckAll');
    this.imageObject = [];
    $('#imageListModal').modal('hide');
  }
}
