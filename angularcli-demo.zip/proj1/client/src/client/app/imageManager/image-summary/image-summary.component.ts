
import {TranslateService} from '@ngx-translate/core';

import { Router, ActivatedRoute, } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ImageSummaryService } from './image-summary.service';
import { StorageService } from '../../storage.service';

@Component({
  moduleId: module.id,
  templateUrl: 'image-summary.component.html',
})

export class ImageSummaryComponent implements OnInit, OnDestroy {

  timer: any;
  delMessage : any = {
    title: this.translate.instant('image.DelImage'),
    message: this.translate.instant('image.IsDelImage'),
    confirmText: this.translate.instant('CONFIRM'),
    cancelText: this.translate.instant('CANCEL'),
    type: 'exclamation'
  };
  delTableMessage : any = {
    title: this.translate.instant('image.DelImage'),
    message: this.translate.instant('image.IsDelImage') + '?',
    confirmText: this.translate.instant('CONFIRM'),
    cancelText: this.translate.instant('CANCEL'),
    type: 'exclamation'
  };
  getImageRecovery = true;
  tryDelNet: any = {};
  isFirstLoad = true;
  unPublishImage = {};
  window: window= window;
  isShowLoading = false;
  infoMsgs: string[] = [this.translate.instant('gengyun.deltesuccess')];
  isShowInfo = false;
  rowData: any[];
  selectedRows: any[] = [];
  columnDefs: any[] = [
    {
      checkbox: true
    },
    {
      field: 'name',
      title: this.translate.instant('Name'),
      events: 'operateEvents',
      formatter: function (value, row, index) {
        return `<a  href="javascript:void(0);" class="detail">${value}</a>`;
      },
      sortable: true
    },
    {
      field: 'dc_name',
      title: this.translate.instant('image.Dc'),
      sortable: true
    },
    {
      field: 'cloudenv_name',
      title: this.translate.instant('CloudEnv'),
      sortable: true
    },
    {
      field: 'size',
      title: this.translate.instant('image.FileSize'),
      formatter: function (value, row, index) {
        if (parseInt(row.size / 1024) < 1024) {
          return (row.size / 1024).toFixed(1) + 'KB';
        } else if (parseInt((row.size / 1024) / 1024) < 1024) {
          return ((row.size / 1024) / 1024).toFixed(1) + 'MB';
        } else if (parseInt(((row.size / 1024) / 1024) / 1024) < 1024) {
          return (((row.size / 1024) / 1024) / 1024).toFixed(1) + 'GB';
        } else {
          return ((((row.size / 1024) / 1024) / 1024) / 1024).toFixed(1) + 'TB';
        }
      },
      sortable: true
    },
    {
      field: 'disk_format',
      title: this.translate.instant('image.DiskType'),
      sortable: true
    },
    {
      field: 'created_at',
      title: this.translate.instant('image.CreateTime'),
      sortable: true
    },
    {
      field: 'progress_ratio',
      title: this.translate.instant('image.ReleaseSchedule'),
      width: 100,
      formatter: function (value, row, index) {
        if (row.transfer_rate !== '' && (row.status === 'saving' || row.status === 'queued')) {
          return `<div class="progress" style="margin-bottom:0">
            <div class="progress-bar progress-bar-success" role =""progressbar"
                 aria-valuemin="0%" aria-valuemax="100%" style="width:${row.progress_ratio}%">
            <span class="sr-only" style="position:inherit">${row.progress_ratio}%</span>
            </div>
            </div>`;
        } else {
          return `<span>--</span>`;
        }
          //}
        //else if(row.progress_ratio === '0') {
        //    return `<span></span>`;
          //}
          //else if (row.status === 'active') {
          //  return `<div class="progress" style="margin-bottom:0">
          //  <div class="progress-bar progress-bar-success" role =""progressbar"
          //       aria-valuemin="100%" aria-valuemax="100%" style="width:100%">
          //  <span class="sr-only" style="position:inherit">100%</span>
          //  </div>
          //  </div>`;
          //}
      }
    },
    {
      field: 'transfer_rate',
      title: this.translate.instant('image.ReleaseRate'),
      width: 90,
      formatter: function (value, row, index) {
        if (row.transfer_rate !== '' && (row.status === 'saving' || row.status === 'queued')) {
          return row.transfer_rate;
        } else {
          return `<span>--</span>`;
        }
        //if (row.status === 'saving' || row.status === 'queued') {
        //  return row.transfer_rate;
        //} else {
        //  return '--';
        //}
      }
    },
    //{
    //  field: 'protected',
    //  title: this.translate.instant('image.IsProtect'),
    //  sortable: true
    //},
    {
      field: 'status',
      title: this.translate.instant('Status'),
      width: 110,
      formatter: function (value, row, index) {
        if (row.status === 'queued' || row.status === 'saving') {
          return `<img src="assets/images/loading_grey_s2.gif"><span>${value}</span>`;
        } else if (value.toLowerCase() === 'active') {
          return '<img class="status-img" src="assets/images/status/icon_status_green.png" />' + value;
        } else if (value.toLowerCase() === 'uploading') {
          return `<span>${value}</span>`;
        } else {
          return `<span>${value}</span>`;
        }
      },
      sortable: true
    },
    {
      field: 'oper',
      title: this.translate.instant('Operation'),
      width: '140px',
      cellStyle: (value, row, index, field) => {
        return {
          css: {'min-width': '123px'}
        };
      },
      events: 'operateEvents',
      visible: this.storageService.getUserOperRights('Cloud Environment Image', 'DELETE'),
      formatter: (value, row, index) => {
        if (this.storageService.getUserOperRights('Cloud Environment Image', 'DELETE')) {
          const strPartOne = '<div class="btn-group table-operate-float">' +
            '<button class="btn btn-default table-operate-btn delete" data-toggle="modal" data-target="#deleteModalOne">'
            + this.translate.instant('Delete') + '</button></div>';
          return strPartOne;
        }
      }
    }
    // {
    //   field: 'disk_format',
    //   title: this.translate.instant('image.temp15')
    // },
    // {
    //   field: 'os_type',
    //   title: this.translate.instant('image.temp16')
    // },
    // {
    //   field: 'public',
    //   title: this.translate.instant('image.temp18')
    // },
    // {
    //   field: 'protect',
    //   title: this.translate.instant('image.temp19')
    // },
    // {
    //   field: 'os_version',
    //   title: this.translate.instant('image.temp49')
    // },
    // {
    //   field: 'createdAt',
    //   title: this.translate.instant('image.CreateTime')
    // },
    // {
    //   field: 'updatedAt',
    //   title: this.translate.instant('image.UpdateTime')
    // },
    // {
    //   field: '',
    //   title: this.translate.instant('image.temp50'),
    //   formatter: function (value, row, index) {
    //     return `<div class="progress" style="margin-bottom:0">
    //                 <div class="progress-bar progress-bar-success" role="progressbar"
    //                      aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"
    //                      style="width:${row.upload_progress_rate}">
    //                     <span class="sr-only" style="position:inherit">${row.upload_progress_rate}</span>
    //                 </div>
    //             </div>`;
    //   }
    // },
    // {
    //   field: 'upload_transfer_rate',
    //   title: this.translate.instant('image.temp51'),
    // },
    // {
    //   title: this.translate.instant('Operation'),
    //   width: 160,
    //   field: 'operate',
    //   events: 'operateEvents',
    //   formatter: function (value, row, index) {
    //     return ['<div class="btn-group table-operate-float">\
    //     <button class="btn btn-default authority table-operate-btn">请选择</button>\
    //     <button class="btn btn-default dropdown-toggle table-operate-btn" id="dropdownMenu" \
    //                      data-toggle="dropdown" ><span class="caret"></span>\
    //                   </button>\
    //     <ul class="dropdown-menu dropdown-menu-top table-operate-ulfont" role="menu" aria-labelledby="dropdownMenu1">\
    //                   <li role="presentation">\
    //                    <a href="javascript:void(0);" class="delete" data-toggle="modal" data-target="#deleteModal">删除</a>\
    //                   </li>\
    //     </ul>\
    //     </div>'
    //     ].join('');
    //   }
    // }
  ];

  gridOptions: any = {
    pagination: true,
    pageSize: 10,
    pageList: [10, 25, 50, 100],
    search: true,
    strictSearch: false,
    searchText: '',
    paginationDetailHAlign: 'left',
    paginationHAlign: 'left',
    clickToSelect: false,
    sortable: true,
    sortName: 'created_at',
    sortOrder: 'desc'
  };

  constructor(private translate: TranslateService, private imageSummaryService: ImageSummaryService,
  private router: Router, private route: ActivatedRoute, private storageService: StorageService) {
    const that = this;
    //$.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    if (that.storageService.getCurrentLang() === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }
    this.window.operateEvents = {
      'click .detail': function (e, value, row , index) {
        that.detail(row);
      },
      'click .delete': function(e, value, row, index) {
        that.delMessage.message = that.translate.instant('image.IsDelImage') + row.name + '?';
        that.unPublish(row);
      }
       //'click .delete': function (e, value, row ,index) {
       //  that.tryDelNet = row;
       //  that.delMessage.message = '删除镜像: ' + that.tryDelNet.name +
       //    ', 确认要执行吗？';
       //},
    };
  }

  ngOnInit() {
    const that = this;
    this.initTable();
    this.getImages();
    this.timer = setInterval(function () {
      if (that.getImageRecovery) {
        that.getImages();
      }
    }, 2000);
  }

  ngOnDestroy() {
    clearInterval(this.timer);
  }

  statusFormatter(value, row, index) {
    if (value.toLowerCase() === 'active') {
      return '<img class="status-img" src="assets/images/status/icon_status_green.png" />' + value;
    } else if (value.toLowerCase() === 'error') {
      return '<img class="status-img" src="assets/images/status/icon_status_red.png" />' + value;
    } else if (value.indexOf('ing') !== -1) {
      return '<img class="status-img" src="assets/images/status/icon_status_blue.png" /> ' + value;
    } else {
      return '<img class="status-img" src="assets/images/status/icon_status_grey.png" /> ' + value;
    }
  }
  getImages() {
    const that = this;
    if (this.isFirstLoad) {
      $('#imageTable').bootstrapTable('showLoading');
    }
    this.getImageRecovery = false;
    this.imageSummaryService.getImages().then((response: any) => {
      this.getImageRecovery = true;
      if (that.isFirstLoad) {
        that.isFirstLoad = false;
        $('#imageTable').bootstrapTable('hideLoading');
      }
      _.map(response, function(imageItem) {
        if (imageItem.transfer_rate !== '') {
          imageItem.transfer_rate = that.toFixRate(parseInt(imageItem.transfer_rate));
        }
      });
      this.rowData = response;
      $('#imageTable').bootstrapTable('load', this.rowData);
    }, function() {
      this.getImageRecovery = true;
      if (that.isFirstLoad) {
        that.isFirstLoad = false;
        $('#imageTable').bootstrapTable('hideLoading');
      }
    });
    setTimeout(function () {
      $('#imageTable').bootstrapTable('hideLoading');
      this.isShowLoading = false;
    }, 10000);
  }

  detail(item: any) {
    this.router.navigate(['detail', item.id], {relativeTo: this.route});
  }

  toFixRate(size: any) {
    if (parseInt(size) < 1024) {
      return size.toFixed(1) + 'KB/s';
    } else if (parseInt(size / 1024) < 1024) {
      return (size / 1024).toFixed(1) + 'MB/s';
    } else if (parseInt((size / 1024) / 1024) < 1024) {
      return ((size / 1024) / 1024).toFixed(1) + 'GB/s';
    } else {
      return (((size / 1024) / 1024) / 1024).toFixed(1) + 'TB/s';
    }
  }

  imageStorage() {
    this.router.navigate(['main/image/imageRepo']);
  }

  unPublish(image: any) {
    this.unPublishImage = image;
  }

  showPublishPage() {
    this.router.navigate(['imagePublish'], {relativeTo: this.route});
  }
  // deleteSelected(item:any) {
  //   this.imageSummaryService.deleteImage(item.id).then((response:any)=> {this.getImages();});
  // }
  //
  // uploadImage() {
  //   this.router.navigate(['upload'], {relativeTo: this.route});
  // }
  //
  // deleteNet() {
  //   let selectedItems: any[] = $('#imageTable').bootstrapTable('getSelections');
  //
  //   for (let item of selectedItems) {
  //     this.deleteSelected(item);
  //   }
  // }
  // sureDel() {
  //   this.deleteSelected(this.tryDelNet);
  // }
//initTable() {}
  initTable() {
     const that = this;
    $('#imageTable').bootstrapTable($.extend(this.gridOptions, {
      toolbar: '#toolbar1',
      data: this.rowData,
      columns: this.columnDefs
    }));

    $('.bootstrap-table .search input').attr('placeholder', this.translate.instant('WordForFilter'))
      .parent().append(`<span></span>`);

    $('#imageTable').parents('.fixed-table-container').append(`<div class="fixed-table-footerButtons">
          <button id="delete-image-btn" data-toggle="modal" data-target="#deleteModal" disabled>
          ${this.translate.instant('Delete')}
      </button>
      </div>`);

    $('#imageTable').on('check.bs.table uncheck.bs.table ' +
      'check-all.bs.table uncheck-all.bs.table', function () {
      $('#delete-image-btn').prop('disabled', !$('#imageTable').bootstrapTable('getSelections').length);
    });

    $('#imageTable').on('check.bs.table', function (row, $element) {
      that.selectedRows.push($element.id);
      that.checkSelectItem();
    });

    $('#imageTable').on('uncheck.bs.table', function (row, $element) {
      that.selectedRows = _.without(that.selectedRows, $element.id);
      that.checkSelectItem();
    });

    $('#imageTable').on('check-all.bs.table', function (rows, $element) {
      that.selectedRows = _.pluck($element, 'id');
      clearInterval(that.timer);
    });

    $('#imageTable').on('uncheck-all.bs.table', function (row, $element) {
      that.selectedRows = [];
      that.timer = setInterval(function () {
        if (that.getImageRecovery) {
          that.getImages();
        }
      }, 2000);
    });
  }

  checkSelectItem() {
    const that = this;
    if (that.selectedRows.length !== 0) {
      clearInterval(that.timer);
    } else {
      that.timer = setInterval(function () {
        if (that.getImageRecovery) {
          that.getImages();
        }
      }, 2000);
    }
  }

  sureDel() {
    const that = this;
    for (let i = 0; i < this.selectedRows.length; i++) {
      this.imageSummaryService.unpublish(this.selectedRows[i]).then(() => {
        that.isShowInfo = true;
        setTimeout(function () {
          that.isShowInfo = false;
        }, 1000);
        that.getImages();
      });
    }
    that.selectedRows = [];
    that.timer = setInterval(function () {
      if (that.getImageRecovery) {
        that.getImages();
      }
    }, 2000);
  }

  sureDelOne() {
    const that = this;
    this.imageSummaryService.unpublish(this.unPublishImage.id).then(() => {
      that.isShowInfo = true;
      setTimeout(function () {
        that.isShowInfo = false;
      }, 1000);
      this.getImages();
    });
  }
}
