import { NgModule } from '@angular/core';
import { routing } from './image-summary.routes';
import { SharedModule } from '../../shared/index';

import {ImageSummaryService} from './image-summary.service';
import {ImageDetailComponent} from './image-detail.component';
import {ImageSummaryComponent} from './image-summary.component';
import { ImagePublishComponent } from './image-publish.component';
import {AntMultiSelectModule} from '../../netResource/port-group/overview/index';

@NgModule({
  imports: [routing, SharedModule, AntMultiSelectModule],
  declarations: [ImageSummaryComponent, ImageDetailComponent, ImagePublishComponent],
  providers: [ImageSummaryService],
})

export class ImageSummaryModule { }
