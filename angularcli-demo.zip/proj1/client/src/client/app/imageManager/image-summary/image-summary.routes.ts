import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ImageSummaryComponent} from './image-summary.component';
import {ImageDetailComponent} from './image-detail.component';
import { ImagePublishComponent } from './image-publish.component';

const routes: Routes = [
  {
    path: 'imageSummary',
    children: [
      {path: '', component: ImageSummaryComponent},
      {path: 'detail/:id', component: ImageDetailComponent},
      {path: 'imagePublish', component: ImagePublishComponent}
    ]
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
