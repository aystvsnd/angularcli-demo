import { Injectable } from '@angular/core';
import {Response} from '@angular/http';
import { appConfig } from '../../app.config';
import { ApiResourceService as Http } from '../../apiResource.service';

@Injectable()
export class ImageSummaryService {
  uploader: any= [];

  constructor(public http: Http) {

  }

  getImages() {
    return this.http.get(appConfig.imageUrl + 'images').toPromise().then((res: Response) => {
      return res.json().images;
    });
  }

  getImage(id: any) {
    return this.http.get(appConfig.imageUrl + 'images/' + id).toPromise().then((res: Response) => {
      return res.json();
    });
  }

  getImageFiles() {
    return this.http.get(appConfig.imageUrl + 'imagefiles').toPromise().then((res: Response) => {
      return res.json().imagefiles;
    });
  }

  getImageFile(id: any) {
    return this.http.get(appConfig.imageUrl + 'imagefiles/' + id).toPromise().then((res: Response) => {
      return res.json();
    });
  }

  deleteEnvPort(imageId: any) {
    return;
  }

  getDcs() {
    return this.http.get(appConfig.vrmServiceUrl + 'dcs').toPromise().then((res: Response) => {
      return res.json().dcs;
    });
  }

  getCloudenvs() {
    return this.http.get(appConfig.vrmServiceUrl + 'cloudenvs').toPromise().then((res: Response) => {
      return res.json().cloudEnvs;
    });
  }

  publish(id: any, data: any) {
    return this.http.post(appConfig.imageUrl + 'imagefiles/' + id, data).toPromise().then((res: Response) => {
      console.log('');
    });
  }

  unpublish(id: any) {
    return this.http.delete(appConfig.imageUrl + 'images/' + id).toPromise().then(() => {
      console.log('');
    });
  }
}

