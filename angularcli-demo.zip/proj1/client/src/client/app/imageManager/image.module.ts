import { NgModule } from '@angular/core';
import {ImageRepoModule} from './image-repo/image-repo.module';
import {ImageSummaryModule} from './image-summary/image-summary.module';

@NgModule({
  imports: [ImageRepoModule, ImageSummaryModule]
})

export class ImageModule { }
