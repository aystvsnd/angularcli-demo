export interface Alarm {
  alarmId: string;
  alarmCode: string;
  alarmCodeName: string;
  alarmObjectCloudId: string;
  alarmObjectType: string;
  alarmObjectId: string;
  alarmObjectName: string;
  alarmLevel: string;
  alarmEventType: string;
  alarmEventTime: string;
  alarmSuggestion: string;
  alarmAdditionalText: string;
  alarmCause: string;
  alarmImpact: string;
}

export interface RelateModule {
  relatedModelId: string;
  relatedModelName: string;
  relatedModelSuggestion: string;
  relatedModelImpact: string;
  relatedModelLevel: string;
  relatedModelStartTime: string;
  relatedModelLocation: string;
  relatedObjectCloudId: string;
  relatedObjectType: string;
  relatedObjectId: string;
  relatedObjectName: string;
  alarms: Alarm[];
}

export interface CauseAlarm {
  objectImg: string;
  objectName: string;
  alarmImg: string;
  alarmDesc: string;
  newObjectName: string;
  cloudId: string;
  objectId: string;
  objectType: string;
  alarmId: string;
}

export interface AbsoluteLink {
  name: string;
  url: string;
}

export interface PageSend {
  alarmId: string;
  titleFromhealty: boolean;
}

export interface ColumnDef {
  field: string;
  align: string;
  title: string;
  events: string;
  formatter: any;
}

export interface ModelMsg {
  modelType: string;
  modelId: string;
  alarmId: string;
}

export interface ModelInfo {
  modelObjectCloudId: string;
  modelObjectId: string;
  modelObjectName: string;
  modelObjectType: string;
}
