/**
 * Created by 6092002302 on 2017/4/17.
 */
import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {routing} from './analysis.routes';
import {SharedModule} from '../../shared/index';
import {InsightCommonModule} from '../common/common.module';
import {SmartAnalysisComponent} from './smart-analysis.component';
import {SmartAnalysisDetailComponent} from './smart-analysis-detail.component';
import {AnalysisService} from './analysis.service';

@NgModule({
  imports: [CommonModule, SharedModule, InsightCommonModule, FormsModule, routing],

  declarations: [SmartAnalysisComponent, SmartAnalysisDetailComponent],

  exports: [],

  providers: [AnalysisService],
})
export class AnalysisModule {}
