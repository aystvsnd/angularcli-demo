/**
 * Created by 6092002302 on 2017/4/17.
 */
import {ModuleWithProviders} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {SmartAnalysisComponent} from './smart-analysis.component';
import {SmartAnalysisDetailComponent} from './smart-analysis-detail.component';

const routes: Routes = [
  {
    path: 'alarm',
    children: [
      {
        path: 'smart-analysis',
        component: SmartAnalysisComponent
      },
      {
        path: 'smart-analysis-detail',
        component: SmartAnalysisDetailComponent
      }
    ]
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
