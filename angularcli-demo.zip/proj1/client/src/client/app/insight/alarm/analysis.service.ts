/**
 * Created by 6092002302 on 2017/4/17.
 */
import { Injectable } from '@angular/core';
import { ApiResourceService as Http } from '../../apiResource.service';

@Injectable()

export class AnalysisService {

  constructor(public http: Http) {
  }

  getAnalysisDetail(modelId : any) {
    return this.http.get('/api/v1/fia/relatedModel?relatedModelId=' + modelId).toPromise().then(
      (res) => {
        return res.json();
      }
    );
  }

}
