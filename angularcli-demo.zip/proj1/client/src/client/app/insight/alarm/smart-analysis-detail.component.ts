/**
 * Created by 6092002302 on 2017/5/4.
 */
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {AnalysisService} from './analysis.service';
import {TranslateService} from '@ngx-translate/core';
import { CommonFunctionService } from '../common/common-function.service';
import { Router } from '@angular/router';
import * as Relate from './analysis.interface';

@Component({
  moduleId: module.id,
  styleUrls: [ '../css/common.css', 'smart-analysis-detail.component.less'],
  templateUrl: 'smart-analysis-detail.component.html',
})

export class SmartAnalysisDetailComponent implements OnInit {

  modelId : string;
  analysisDetail : Relate.RelateModule;
  causeAlarms : Relate.CauseAlarm[];
  absoluteLinks : Relate.AbsoluteLink[];
  analysisDesc : string;

  pageSrc : string;
  pageSrcName : string;
  pageSend : Relate.PageSend = {
    alarmId: '',
    titleFromhealty : false
  };

  constructor(private activatedRoute: ActivatedRoute, private service: AnalysisService,
  private translate : TranslateService, private commonFunctionService: CommonFunctionService, private router : Router) {
    const that = this;
    this.activatedRoute.params.subscribe(params => {
      that.modelId = params.modelId;
      that.pageSrc = params.pageSrc;
      that.pageSrcName = params.pageSrcName;
      that.pageSend.alarmId = params.pageSrcAlarmId;
    });
  }

  ngOnInit() {
    const that = this;
    this.service.getAnalysisDetail(this.modelId).then((res : Relate.RelateModule) => {
      that.analysisDetail = res;
      that.getAnalysisDetail(that.analysisDetail);
    });
  }

  getAnalysisDetail(analysisDetail : Relate.RelateModule) {

    this.analysisDesc = analysisDetail.relatedModelName;

    analysisDetail.modelImg = this.alarmImgChioce(analysisDetail.relatedModelLevel, analysisDetail.relatedModelImpact);

    analysisDetail.impact = this.impactChoose(analysisDetail.relatedModelImpact);
    analysisDetail.level = this.levelChoose(analysisDetail.relatedModelLevel, analysisDetail.relatedModelImpact);

    analysisDetail.startTime = this.commonFunctionService.serverTimeToLocalTime(analysisDetail.relatedModelStartTime);
    analysisDetail.objectImg = this.getObjectImage(analysisDetail.relatedObjectType);

    analysisDetail.suggestions = this.splitSuggestion(analysisDetail.relatedModelSuggestion);
    this.getCauseAlarms(analysisDetail.alarms);
  }

  getCauseAlarms(sourceAlarms : Relate.Alarm[]) {
    this.causeAlarms = [];
    for (const sourceAlarm of sourceAlarms) {

      const alarm = {objectImg : '', objectName : '', alarmImg : '', alarmDesc : '', newObjectName : '',
        cloudId: '', objectId: '', objectType: '', alarmId : ''};

      alarm.objectImg = this.getObjectImage(sourceAlarm.alarmObjectType);
      alarm.objectName = sourceAlarm.alarmObjectName;
      alarm.newObjectName = this.commonFunctionService.cutStr(alarm.objectName, 16);

      alarm.alarmImg = this.alarmImgChioce(sourceAlarm.alarmLevel, sourceAlarm.alarmImpact);
      alarm.alarmDesc = sourceAlarm.alarmCodeName;

      alarm.alarmId = sourceAlarm.alarmId;
      alarm.cloudId = sourceAlarm.alarmObjectCloudId;
      alarm.objectId = sourceAlarm.alarmObjectId;

      alarm.objectType = sourceAlarm.alarmObjectType;
      this.causeAlarms.push(alarm);
    }
  }

  splitSuggestion(alarmSuggestion : string) {
    let str = [];
    if (  alarmSuggestion.trim() === ''
      || alarmSuggestion.toLowerCase().trim() === 'none'
      || alarmSuggestion === 'No action is required.') {
      alarmSuggestion = 'The Suggestion of this alarm is temporarily unknown,please' +
        ' contact the ZTE technical support for help';
      str.push(alarmSuggestion);
      return str;
    }
    if (alarmSuggestion.match(/\d+\./g) === null && alarmSuggestion.indexOf('\n') === -1) {
      str.push(alarmSuggestion);
      return str;
    }
    if (alarmSuggestion.match(/\d+\./g)) {
      str = alarmSuggestion.split(/\d+\./g);
      str.shift();
      return str;
    }
    str.push(alarmSuggestion);
    return str;
  }

  alarmImgChioce(alarmLevel : string, alarmImact : any) {
    alarmImact = alarmImact.toLowerCase();
    if (alarmLevel === 'critical' || alarmLevel === 'Critical') {
      return {'health': 'assets/images/insight/svg/monitorObject/4_health_min.svg',
        'risk': 'assets/images/insight/svg/monitorObject/4_risk_min.svg',
        'efficiency': 'assets/images/insight/svg/monitorObject/4_efficiency_min.svg'}[alarmImact];
    }
    if (alarmLevel === 'major' || alarmLevel === 'Major') {
      return {'health': 'assets/images/insight/svg/monitorObject/3_health_min.svg',
        'risk': 'assets/images/insight/svg/monitorObject/3_risk_min.svg',
        'efficiency': 'assets/images/insight/svg/monitorObject/3_efficiency_min.svg'}[alarmImact];
    }
    if (alarmLevel === 'minor' || alarmLevel === 'Minor') {
      return {'health': 'assets/images/insight/svg/monitorObject/2_health_min.svg',
        'risk': 'assets/images/insight/svg/monitorObject/2_risk_min.svg',
        'efficiency': 'assets/images/insight/svg/monitorObject/2_efficiency_min.svg'}[alarmImact];
    }
    if (alarmLevel === 'warning' || alarmLevel === 'Warning') {
      return {'health': 'assets/images/insight/svg/monitorObject/1_health_min.svg',
        'risk': 'assets/images/insight/svg/monitorObject/1_risk_min.svg',
        'efficiency': 'assets/images/insight/svg/monitorObject/1_efficiency_min.svg'}[alarmImact];
    }
  }

  levelChoose(level : string, impact : string) {

    if (level === 'critical' || level === 'Critical') {

      return this.translate.instant('fm.critical');
    } else if (level === 'major' || level === 'Major') {

      return this.translate.instant('fm.major');
    } else if (level === 'minor' || level === 'Minor') {

      return this.translate.instant('fm.minor');
    } else if (level === 'warning' || level === 'Warning') {

      return this.translate.instant('fm.warning');
    }
    return '';
  }

  impactChoose(impact : string) {
    impact = impact.toLowerCase();
    if (impact === 'health') {
      return this.translate.instant('fm.impact_health');
    } else if (impact === 'risk') {
      return this.translate.instant('fm.impact_risk');
    } else if (impact === 'efficiency') {
      return this.translate.instant('fm.impact_efficiency');
    }
  }

  getObjectImage(objectType : string) {
    let image = '';
    if (objectType.toLowerCase().indexOf('vm') !== -1) {

      image = 'assets/images/insight/svg/0_VM_line.svg';
    } else if (objectType.toLowerCase().indexOf('host') !== -1) {

      image = 'assets/images/insight/svg/0_host_line.svg';
    }

    return image;
  }

  goBackToAnalysis() {
    this.router.navigate(['/main/insight/alarm/smart-analysis']);
  }

  getBackToAlarm() {
    this.router.navigate(['/main/alarm/currentalarm']);
  }

  goBackToAlarmDetail() {
    this.router.navigate(['/main/alarm/currentalarm/detail',
      {alarmId: this.pageSend.alarmId, titleFromhealty: false}]);
  }

  gotObjectDetail() {
    const objectId = {envId: this.analysisDetail.relatedObjectCloudId,
      vmId: this.analysisDetail.relatedObjectId};
    const objectToString = JSON.stringify(objectId);

    const objectname = this.analysisDetail.relatedObjectName;

    this.router.navigate(['/main/insight/monitorObject/monitor-obj-detail',
      {name: objectname, type: this.analysisDetail.relatedObjectType, objectId: objectToString}]);
  }

  gotoAlarmObject(alarm : Relate.CauseAlarm) {
    const objectId = {envId: alarm.cloudId,
      vmId: alarm.objectId};
    const objectToString = JSON.stringify(objectId);

    const objectname = alarm.objectName;

    this.router.navigate(['/main/insight/monitorObject/monitor-obj-detail',
      {name: objectname, type: alarm.objectType, objectId: objectToString}]);
  }
  gotoAlarmDetail(alarm: Relate.CauseAlarm) {
    this.router.navigate(['/main/alarm/currentalarm/detail',
      {alarmId: alarm.alarmId, titleFromhealty: false}]);
  }
}
