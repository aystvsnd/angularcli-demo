/**
 * Created by 6092002302 on 2017/5/3.
 */

import { Component, OnInit } from '@angular/core';

import {StorageService } from '../../storage.service';
import { CommonFunctionService } from '../common/common-function.service';
import {TranslateService} from '@ngx-translate/core';
import { Router } from '@angular/router';
import * as Relate from './analysis.interface';

@Component({
  moduleId: module.id,
  templateUrl: 'smart-analysis.component.html',
  styleUrls: [ '../css/common.css', 'smart-analysis.component.less'],
})

export class SmartAnalysisComponent implements OnInit {

  imgStyle : any = `display: inline-block;
    width: 20px; height: 20px`;
  alarmTip : any = `white-space: nowrap;
    transform: translate(-50%, -50%);
    left: 50%;
    top: -15px;
    opacity: 0;`;
  alarmLevel : any = `cursor: pointer;
    position: relative`;
  topArrow : any = `border-top-color: #ddd`;

  absoluteLinks : Relate.AbsoluteLink[];
  window : window = window;
  columnDefs : Relate.ColumnDef[] = [
    {
      field: 'id',
      align: 'left',
      title: this.translate.instant('insight.smartAnalysis.Sequence'),
      formatter: function (value, row, index) {
        return  index + 1;
      }
    },
    {
      field: 'modelLevel',
      align: 'middle',
      title: this.translate.instant('insight.smartAnalysis.Impact'),
      events: 'operateEvents',
      formatter: function(value, row, index) {
        const imgSrc = that.alarmImgChioce(row.modelLevel, row.modelImpact);

        const level = that.levelChoose(row.modelLevel, row.modelImpact);
        const impact = that.impactChoose(row.modelImpact);
        return `<div style="${that.alarmLevel}">
                    <div class="tooltip top" role="tooltip" style="${that.alarmTip}">
                        <div class="tooltip-arrow my-arrow-top" style="${that.topArrow}"></div>
                        <div class="alarm-arrow my-arrow-bottom"></div>
                        <div class="tooltip-inner tip-content">
                        ${impact}: ${level}
                    </div>
                    </div>
                    <div class="impact-level">
                      <img style="${that.imgStyle}" src=${imgSrc}>
                    </div>
                </div>`;
      }
    },

    {
      field: 'modelName',
      align: 'left',
      title: this.translate.instant('insight.smartAnalysis.AnalysisResult'),
      events: 'operateEvents',
      formatter: function(value, row, index) {
        return `<a href="javascript:void(0);" class="detail">${value}</a>`;
      }
    },

    {
      field: 'modelSuggestion',
      align: 'left',
      title: this.translate.instant('insight.smartAnalysis.Suggestion'),
      formatter: function (value, row, index) {
        const newValue = that.commonFunctionService.cutStr(value, 20);
        return `<pre data-toggle="tooltip" data-placement="top" title="${value}">${newValue}</pre>`;
      }
    },
    {
      field: 'modelObjectType',
      align: 'left',
      title: this.translate.instant('insight.smartAnalysis.ObjectType'),
      formatter: function (value, row, index) {
          let img = that.getObjectImage(value);
          return `<img style="${that.imgStyle}" src=${img}><span>${value}</span>`;
        /*if(value === 'vm') {
          return `<img style="${that.imgStyle}" src="assets/images/insight/svg/0_VM_line.svg"><span>${value}</span>`;
        } else if (value === 'host') {
          return `<img style="${that.imgStyle}" src="assets/images/insight/svg/0_host_line.svg"><span>${value}</span>`;
        }*/
      }
    },

    {
      field: 'modelObjectName',
      align: 'left',
      title: this.translate.instant('insight.smartAnalysis.ObjectName'),
      events: 'operateEvents',
      formatter: function(value, row, index) {
        if (row.modelObjectType === 'vm') {
          return `<a href="javascript:void(0);" class="objectDetail">${value}</a>`;
        } else {
          return `${value}`;
        }

      }
    },

    {
      field: 'modelAlarmNum',
      align: 'left',
      title: this.translate.instant('insight.smartAnalysis.RelatedAlarmNumber')
    },
    {
      field: 'modelStartTime',
      align: 'left',
      title: this.translate.instant('insight.smartAnalysis.TimeofOccurrence'),
      formatter: function(value, row, index) {
        return that.commonFunctionService.serverTimeToLocalTime(value);
      },
    }
  ];

  gridOptions: any = {
    method: 'get',
    queryParams: params => this.queryParams(params, this),
    columns: this.columnDefs,
    sidePagination: 'server',
    pagination: true,                    //是否开启分页
    pageSize: 10,                         //单页数量
    pageNumber: 1,
    pageList: [10, 20],
    paginationDetailHAlign: 'right',      //分页详情水平位置
    paginationHAlign: 'right',            //分页条水平位置
    clickToSelect: false,                //单击行选中
    search: true,
    escape:true
  };


  queryParams(params: any, that: any) {
    const tmp = {
      pageSize: params.limit,
      currentPage: params.offset / params.limit + 1,
      fuzzy: params.search,
    };

    return tmp;
  }

  initTable() {
    $('#table-smart-analysis').bootstrapTable($.extend(this.gridOptions, {
      url: '/api/v1/fia/allAlarmModels',
      dataField: 'alarmModels',
      responseHandler: function (res) {

        const VolumeOptList = {
          'total': res.total,
          'alarmModels': res.modelList
        };
        return VolumeOptList;
      },

    }));
  }

  constructor(private storageService: StorageService, private commonFunctionService: CommonFunctionService,
             private  translate: TranslateService, private router: Router) {

    const that = this;

    this.absoluteLinks = [
      {name: this.translate.instant('insight.smartAnalysis.CurrentAlarms'), url: '/main/alarm/currentalarm'},
      {name: this.translate.instant('insight.smartAnalysis.SmartAnalysis'), url: ''}
    ];

    if (that.storageService.getCurrentLang() === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }

    this.window.operateEvents = {

      'mouseover .impact-level': function (e, value, row, index) {
        $('.tooltip').eq(index).css('opacity', '1.0');
      },
      'mouseout .impact-level': function (e, value, row, index) {
        $('.tooltip').eq(index).css('opacity', '0');
      },
      'click .detail': function(e, value, row, index) {
        that.gotoDetail(row);
      },
      'click .objectDetail': function(e, value, row, index) {
        that.gotoObjectDetail(row);
      }
    };
  }



  ngOnInit() {
    this.initTable();
  }

  getObjectImage(objectType : any) {
    var image = '';
    if(objectType.toLowerCase().indexOf('vm') !== -1) {

      image = 'app/insight/images/svg/0_VM_line.svg';
    } else if(objectType.toLowerCase().indexOf('host') !== -1) {

      image = 'app/insight/images/svg/0_host_line.svg';
    } else if(objectType.toLowerCase().indexOf('cloudenv') !== -1) {

      image = 'app/insight/images/svg/0_cloud-env.svg';
    } else if(objectType.toLowerCase().indexOf('cloud') !== -1) {

      image = 'app/insight/images/svg/0_cloud-env.svg';
    } else if(objectType.toLowerCase().indexOf('chassis') !== -1) {

      image = 'app/insight/images/svg/0_chasis.svg';
    } else if(objectType.toLowerCase().indexOf('system') !== -1) {

      image = 'app/insight/images/svg/alarm_system.svg';
    } else if(objectType.toLowerCase().indexOf('switch') !== -1) {

      image = 'app/insight/images/svg/alarm_switch.svg';
    } else if(objectType.toLowerCase().indexOf('server') !== -1) {

      image = 'app/insight/images/svg/alarm_server.svg';
    } else if(objectType.toLowerCase().indexOf('rack') !== -1) {

      image = 'app/insight/images/svg/alarm_rack.svg';
    } else if(objectType.toLowerCase().indexOf('router') !== -1) {

      image = 'app/insight/images/svg/alarm_router.svg';
    } else if(objectType.toLowerCase().indexOf('storage') !== -1) {

      image = 'app/insight/images/svg/alarm_storage.svg';
    } else if(objectType.toLowerCase().indexOf('volume') !== -1) {

      image = 'app/insight/images/svg/alarm_volume.svg';
    }
    return image;
  }

  alarmImgChioce(alarmLevel : string, alarmImact : any) {

    alarmImact = alarmImact.toLowerCase();
    if (alarmLevel === 'critical' || alarmLevel === 'Critical') {
      return {'health': 'assets/images/insight/svg/monitorObject/4_health_min.svg',
        'risk': 'assets/images/insight/svg/monitorObject/4_risk_min.svg',
        'efficiency': 'assets/images/insight/svg/monitorObject/4_efficiency_min.svg'}[alarmImact];
    }
    if (alarmLevel === 'major' || alarmLevel === 'Major') {
      return {'health': 'assets/images/insight/svg/monitorObject/3_health_min.svg',
        'risk': 'assets/images/insight/svg/monitorObject/3_risk_min.svg',
        'efficiency': 'assets/images/insight/svg/monitorObject/3_efficiency_min.svg'}[alarmImact];
    }
    if (alarmLevel === 'minor' || alarmLevel === 'Minor') {
      return {'health': 'assets/images/insight/svg/monitorObject/2_health_min.svg',
        'risk': 'assets/images/insight/svg/monitorObject/2_risk_min.svg',
        'efficiency': 'assets/images/insight/svg/monitorObject/2_efficiency_min.svg'}[alarmImact];
    }
    if (alarmLevel === 'warning' || alarmLevel === 'Warning') {
      return {'health': 'assets/images/insight/svg/monitorObject/1_health_min.svg',
        'risk': 'assets/images/insight/svg/monitorObject/1_risk_min.svg',
        'efficiency': 'assets/images/insight/svg/monitorObject/1_efficiency_min.svg'}[alarmImact];
    }
  }

  levelChoose(level : string, impact : string) {

    if (level === 'critical' || level === 'Critical') {

      return this.translate.instant('fm.critical');
    } else if (level === 'major' || level === 'Major') {

      return this.translate.instant('fm.major');
    } else if (level === 'minor' || level === 'Minor') {

      return this.translate.instant('fm.minor');
    } else if (level === 'warning' || level === 'Warning') {

      return this.translate.instant('fm.warning');
    }
    return '';
  }

  impactChoose(impact : string) {
    impact = impact.toLowerCase();
    if (impact === 'health') {
      return this.translate.instant('fm.impact_health');
    } else if (impact === 'risk') {
      return this.translate.instant('fm.impact_risk');
    } else if (impact === 'efficiency') {
      return this.translate.instant('fm.impact_efficiency');
    }
  }

  gotoDetail(modelMsg: Relate.ModelMsg) {
    if (modelMsg.modelType === 'relatedModel') {
      this.router.navigate(['/main/insight/alarm/smart-analysis-detail',
        {modelId: modelMsg.modelId, pageSrc: 'smartAnalysis'}]);
    }
    if (modelMsg.modelType === 'causalModel') {
      this.router.navigate(['/main/alarm/currentalarm/detail',
        {alarmId: modelMsg.alarmId, titleFromhealty: 'smartAnalysis'}]);
    }
  }
  gotoObjectDetail(modelInfo : Relate.ModelInfo) {

    const objectId = {envId: modelInfo.modelObjectCloudId, vmId: modelInfo.modelObjectId};
    const objectToString = JSON.stringify(objectId);
    this.router.navigate(['/main/insight/monitorObject/monitor-obj-detail',
      {name: modelInfo.modelObjectName, type: modelInfo.modelObjectType, objectId: objectToString}]);
  }
}
