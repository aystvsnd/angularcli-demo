import { Injectable } from '@angular/core';

import {TranslateService} from '@ngx-translate/core';

@Injectable()
export class CommonFunctionService {

  constructor( private translate: TranslateService ) {

  }

  /**
   * js截取字符串，中英文都能用
   * @param str：需要截取的字符串
   * @param len: 需要截取的长度
   */
  cutStr(str, len) {
    let str_length = 0;
    let str_len = 0;
    let   str_cut, a;
    str_cut = '';
    str_len = str.length;
    for (let i = 0; i < str_len; i++) {
      a = str.charAt(i);
      str_length++;
      if (escape(a).length > 4) {
        //中文字符的长度经编码之后大于4
        str_length++;
      }
      str_cut = str_cut.concat(a);
      if (str_length >= len) {
        str_cut = str_cut.concat('...');
        return str_cut;
      }
    }
    //如果给定字符串小于指定长度，则返回源字符串；
    if (str_length < len) {
      return str;
    }
  }

  getStrLength(str) {
    let str_length = 0;
    let str_len = 0;
    let   a;

    str_len = str.length;

    for (let i = 0; i < str_len; i++) {
      a = str.charAt(i);
      str_length++;
      if (escape(a).length > 4) {
        //中文字符的长度经编码之后大于4
        str_length++;
      }
    }

    return str_length;
  }

  unicode2Chr(str) {
    return unescape(str.replace(/\\/g, '%'));
  }

  serverTimeToLocalTime(inputIntTime: any) {
    if (inputIntTime === '') {
      return '';
    }
    let localTime = '';
    inputIntTime = new Date(inputIntTime).getTime();
    const offset: number = (new Date()).getTimezoneOffset();
    localTime = (new Date(inputIntTime - offset * 60000)).toISOString();
    localTime = localTime.substr(0, localTime.lastIndexOf('.'));
    localTime = localTime.replace('T', ' ');
    return localTime;
  }

  getDateDiff(inputIntTime: any) {
    const second = 1000;
    const minute = 1000 * 60;
    const hour = minute * 60;
    const day = hour * 24;
    const month = day * 30;
    const now = new Date().getTime();
    /*inputIntTime = this.serverTimeToLocalTime(inputIntTime);*/
    inputIntTime = new Date(inputIntTime).getTime();
    const diffValue = now - inputIntTime;
    if (diffValue < 0) {
      return this.serverTimeToLocalTime(inputIntTime);
    }
    const monthC = diffValue / month;
    const weekC = diffValue / (7 * day);
    const dayC = diffValue / day;
    const hourC = diffValue / hour;
    const minC = diffValue / minute;
    const secC = diffValue / second;
    let result = '';
    if (monthC >= 1) {
      result = result + parseInt(monthC) + this.translate.instant('insight.MonthsAgo');
    } else if (weekC >= 1) {
      result = result + parseInt(weekC) + this.translate.instant('insight.WeeksAgo');
    } else if (dayC >= 1) {
      result = result + parseInt(dayC) + this.translate.instant('insight.DaysAgo');
    } else if (hourC >= 1) {
      result = result + parseInt(hourC) + this.translate.instant('insight.HoursAgo');
    } else if (minC >= 1) {
      result = result + parseInt(minC) + this.translate.instant('insight.MinutesAgo');
    } else {
      result = result + parseInt(secC) + this.translate.instant('insight.SecondsAgo');
    }
    return result;
  }

}
