import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';

import { EmailAddComponent } from './email-add.component';
import { SearchComponent } from './search.component';
import {DataValidityCheckPipe} from './data-validity-check.pipe';

import { CommonFunctionService } from './common-function.service';
import {NameLongToShortPipe} from './name-longtoshort.pipe';


@NgModule({
    imports: [CommonModule, FormsModule],
    declarations: [EmailAddComponent, SearchComponent, DataValidityCheckPipe, NameLongToShortPipe],
    exports: [EmailAddComponent, SearchComponent, FormsModule, DataValidityCheckPipe, CommonModule,
      TranslateModule, NameLongToShortPipe],
    providers: [CommonFunctionService],
})

export class InsightCommonModule { }
