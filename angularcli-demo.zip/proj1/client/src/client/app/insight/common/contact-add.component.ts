// import {Component, EventEmitter, Input, Output} from '@angular/core';
//
// @Component({
//   selector: 'contact-add',
//   template: `
//       <input [(ngModel)]="inputEmail">
//       <button (click)="pushEmail()">添加</button>
//       <ul>
//         <li *ngFor="let email of emails; let i = index">{{email}}<button (click)="deleteEmail(i)">DELETE</button></li>
//       </ul>
//     `,
// })
// export class ContactAddComponent {
//   inputEmail: string;
//   @Input() emails: string[];
//   @Output() ValueChange: EventEmitter<string[]>;
//
//   constructor() {
//     this.ValueChange = new EventEmitter<string[]>();
//   }
//
//   pushEmail() {
//     this.emails.push(this.inputEmail);
//     this.inputEmail = '';
//     this.ValueChange.emit(this.emails);
//   }
//
//   deleteEmail(index: number) {
//     console.log(index, this.emails);
//     this.emails.splice(index, 1);
//     console.log(this.emails);
//     this.ValueChange.emit(this.emails);
//   }
// }
