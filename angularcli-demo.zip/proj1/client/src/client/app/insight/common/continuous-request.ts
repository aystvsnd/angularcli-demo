import {Subject} from 'rxjs/Subject';

export class ContinuousRequest {
  public reqTimes;
  private arc;
    private delay = 200;
    private timeout = Number.MAX_VALUE;
    constructor(
        private service,
        private ifContinue: Function,
        private func: Function,
        ...arc,
    ) {
        this.arc = arc;
    }

    public toPormise() {
      const that = this;
        return new Promise<any>((resolve, reject) => {
            const subject = new Subject<any>();
            const subscribtion = subject.subscribe(p => {
                p.then(res => {
                    if (that.ifContinue(res) && that.reqTimes > 0 ) {
                      setTimeout(() => subject.next(that.func.apply(that.service, that.arc)), that.delay);
                      that.reqTimes = that.reqTimes - 1;
                    } else {
                      subscribtion.unsubscribe();
                        resolve(res);
                    }
                }).catch(err => {
                    subscribtion.unsubscribe();
                    reject(err);
                });
            });

            subject.next(that.func.apply(that.service, that.arc));
        });
    }

    public setDelay(time) {
      this.delay = time;
    }

    public setTimeout(times) {
      this.timeout = times;
      this.reqTimes = this.timeout;
    }

    public getTimeout( ) {
     return this.reqTimes;
    }
}
