/**
 * Created by insight on 17-1-3.
 */
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'dataValidityCheck'})
export class DataValidityCheckPipe implements PipeTransform {
  transform(value: number, args = '') {
    return value === -1 ? '--' : (args === '-p' ? value + '%' : value);
  }
}
