import {Component, EventEmitter, Input, Output, OnInit} from '@angular/core';

@Component({
  selector: 'email-add',
  styles: [`
    div {
      border: solid 1px #ddd;
      padding: 0 5px 0;
      width: 400px;
    }

    span {
      background: #ddd;
      border-radius: 11px;color: #333;
      display: inline-block;
      line-height: 20px;
      margin-right: 10px;
      padding: 0 4px 0 10px;
    }

    p {
      color: #ff6661;
    }

    input {
      border: none;
      height: 30px;
    }

    input:focus {
      outline: none;
    }

    button {
      background: none;
      border: none;
      padding: 0 6px 0;
    }
  `],
  template: `
    <div [style.border-color]="isInputEmailInvalid?'#ff6661':'#ddd'">
      <span *ngFor="let item of emailList">{{item}}<button (click)="deleteEmail(item)">x</button></span>
      <input [(ngModel)]="inputEmail" (keyup.enter)="pushEmail()" (keyup)="checkEmail()"
      [style.width]="getWidth()" [style.color]="isInputEmailInvalid?'#ff6661':'#333'">
    </div>
    <p *ngIf="isInputEmailInvalid">邮箱格式错误，请修正。</p>
  `,
})
export class EmailAddComponent implements OnInit {
  @Input() opsEmailAdd: string[];
  isInputEmailInvalid: boolean;
  @Output() opsEmailAddChange = new EventEmitter<string[]>();

  inputEmail: string;
  emailList: string[];

  constructor() {
    this.isInputEmailInvalid = false;
  }

  ngOnInit() {
    this.emailList = this.opsEmailAdd;
  }

  pushEmail() {
    if (this.isEmailValid(this.inputEmail)) {
      this.emailList.push(this.inputEmail);
      this.inputEmail = '';
      this.opsEmailAddChange.emit(this.emailList);
    }
  }

  isEmailValid(email: string): boolean {
    return email.match(/^([0-9A-Za-z\-_\.]+)@([0-9a-z]+\.[a-z]{2,3}(\.[a-z]{2})?)$/g) !== null;
  }

  checkEmail() {

    if (this.inputEmail === '' || this.isEmailValid(this.inputEmail)) {
      this.isInputEmailInvalid = false;
    } else {
      this.isInputEmailInvalid = true;
    }
  }

  getWidth() {
    let length = 0;

    if ((length + parseInt($('input').prev('span').css('width')) + 10) > 400) {
      length = parseInt($('input').prev('span').css('width')) + 10;
    } else {
      length += parseInt($('input').prev('span').css('width')) + 10;
    }

    return (((383 - length % 388) > 150) ? (383 - length % 388) : 150) + 'px';
  }

  deleteEmail(email: string) {
    this.emailList.splice(this.emailList.indexOf(email), 1);
  }
}
