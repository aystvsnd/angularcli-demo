/**
 * Created by 6092002303 on 2017/3/17.
 */

import { Pipe, PipeTransform } from '@angular/core';
import { CommonFunctionService } from './common-function.service';

@Pipe({name: 'nameLongToShort'})
export class NameLongToShortPipe implements PipeTransform {

  constructor (private commonFunctionService: CommonFunctionService) {}

  transform(name: string, characters: number): string {
    if (typeof characters === 'undefined') {
      characters = 16;
    }
      const showname = this.commonFunctionService.cutStr(name, characters);
      return showname;

  }
}
