/**
 * Created by 10192595 on 2016/10/15.
 * 使用时在标签中绑定KeyUp事件，触发方式与javascript中的keyup相同，事件中含有输入框中字符串
 * 示例：
 * <search (KeyUp)="search($event)"></search>
 *
 * search(content: string){
 *   console.log(content);
 * }
 *
 */
import {Component, EventEmitter, Input, Output} from '@angular/core';

@Component({
  selector: 'search-keyword',
  template: `
  <div class="search">
    <input type="text" placeholder="输入关键字搜索" [ngModel]="opsSearch" (ngModelChange)="opsSearchChange.emit($event)">
    <button><img src="assets/images/icon_search_mirror.png"></button>
  </div>`,
  styles: [`
  div{
	  border: 1px solid #dddddd;
    border-radius: 2px;
    float: right;
    margin: 15px 0;
  }

  input{
    background: none;
    border: none;
    line-height: 30px;
    padding: 0 30px 0 8px;
    width: 210px;
  }

  button{
    background: none;
    border: none;
  }

  button:focus{
    outline: none;
  }

  input:focus{
    outline: none;
  }
`],
})
export class SearchComponent {
  @Input() opsSearch: string;
  @Output() opsSearchChange = new EventEmitter<string>();
  @Output() KeyUp = new EventEmitter<string>();

  private textInputValue: string;


  ReturnContent() {
    this.KeyUp.emit(this.textInputValue);
  }
}
