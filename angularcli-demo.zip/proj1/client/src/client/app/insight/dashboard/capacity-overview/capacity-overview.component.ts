/**
 * Created by 6092002302 on 2017/7/4.
 */
import {Component, OnInit, Input} from '@angular/core';
import {InsightDashboardService} from '../dashboard.service';
import {Dcs} from '../dashboard.interface'
import * as capaOverview from './capacity-overview.interface';

@Component({
  moduleId: module.id,
  templateUrl: 'capacity-overview.component.html',
  selector: 'capacity-overview',
  styleUrls: ['capacity-overview.component.less'],
})

export class CapacityOverviewComponent implements OnInit {

  @Input() currentDc : string;
  switchName : string[] = [];
  dcList : Dcs[];
  currentDcId : string;
  dcObjs : capaOverview.object[] = [];
  capacityUsedList : capaOverview.capacityUsed[] = [];
  capaReclaimedList : capaOverview.capacityReclaimed[] = [];
  public dashboardPosition : {tabName: string, dcName: string};

  data = [1, 2, 4, 6, 9, 10, 5, 3, 2, 1];
  constructor(private service: InsightDashboardService) {

  }

  ngOnInit() {
    this.service.getDcList().then((res) => {
      this.dcList = res.dcs;
      if (!_.isEmpty(this.dcList)) {
        this.getDcsName(this.dcList);
      }
    });
  }

  getDcsName(dcs : any) {

    for (const dc of dcs) {
      this.switchName.push(dc.name);
    }
  }

  changeContent(dcName : string) {
    this.currentDc = dcName;
    this.currentDcId = this.getDcId(this.currentDc);

    this.getObjs(this.currentDcId);
    this.getCapacityUsed(this.currentDcId);

    this.getCapacityReclaim(this.currentDcId);
    this.dashboardPosition = {tabName: 'capacityOverview', dcName: this.currentDc};
    sessionStorage.setItem('dashboardPosition',JSON.stringify(this.dashboardPosition));
  }

  getDcId(name : string) {

    for (const dc of this.dcList) {
      if (name === dc.name) {
        return dc.id;
      }
    }
  }


  getObjs(dcId: string) {
    this.service.getDcObjs(dcId).then((res)=> {
      this.dcObjs = res.objs;
      this.dcObjs.forEach((dcObj)=> {
        dcObj.objImg = this.getObjsImg(dcObj.type);
      });
    });
  }

  getCapacityUsed(dcId : string) {
    this.capacityUsedList = [];
    this.capacityUsedList.push({name: 'core', total: 30,
      pieInfo: [{name: 'used', value: 15}, {name: 'remain', value: 15}], usedPercent: '50%',
      colors:['#5cb85c', '#c2c6c9']});
    this.capacityUsedList.push({name: 'memory', total: 100,
      pieInfo: [{name: 'used', value: 15}, {name: 'remain', value: 15}], usedPercent: '70%',
      colors:['#f7c515', '#c2c6c9']});
    this.capacityUsedList.push({name: 'disk', total: 200,
      pieInfo: [{name: 'used', value: 15}, {name: 'remain', value: 15}], usedPercent: '90%',
      colors: ['#ff5b55', '#c2c6c9']});
  }

  getCapacityReclaim(dcId: string) {
    this.capaReclaimedList = [];

    this.service.getCapaReclaimed(dcId).then((res)=> {
      let reclaimCapacity = res.reclaimCapacity;
      reclaimCapacity.forEach((reclaim)=> {
        this.capaReclaimedList.push({name: reclaim.name, value: reclaim.value, unit: reclaim.unit});
      });
    });
  }

  getObjsImg(type : string) {
    return {
      vm: 'assets/images/insight/svg/VM.svg',
      host: 'assets/images/insight/svg/host.svg',
      ha: 'assets/images/insight/svg/Aggregate.svg',
      az: 'assets/images/insight/svg/AZ.svg',
      cloudEnv: 'assets/images/insight/svg/cloud-environment.svg',
    }[type];
  }
}
