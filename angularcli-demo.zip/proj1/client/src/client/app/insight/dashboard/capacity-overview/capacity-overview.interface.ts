export interface object {
  type: string;
  total: number;
  objImg?: string;
}

interface pieInfo{
  name: string;
  value: number;
}
export interface capacityUsed {
  name: string;
  total: number;
  pieInfo: pieInfo[];
  usedPercent: string;
  colors: string[];
}

export interface capacityReclaimed {
  name : string;
  value: number;
  unit: string;
}
