/**
 * Created by 6092002302 on 2017/7/10.
 */
import {OnInit, Component, Input, OnChanges, SimpleChanges, Output, EventEmitter} from '@angular/core';
import {Option} from "./rect-chart.interface";

declare const d3;
@Component({
  moduleId: module.id,
  template: `
              <svg></svg>
              <div id="myTooltip">
                <p>区间</p>
                <p>个数</p>
              </div>
            `,
  selector: 'rect-chart',
  styleUrls: ['rect-chart.component.less'],
})
export class RectChartComponent implements OnChanges, OnInit {

  @Input() srcData: number[];
  @Input() padding: any;
  @Input() linear: any;
  @Input() domain: Array<number>;
  svg : any;
  option: any;
  rect: any;
  text: any;
  rectStep: number;
  dataSet : {name: string, value: number, height: number}[];

  constructor() {
    this.option = {
      svgStyle: {width: 380,height: 130,},
      padding: {top: 0, bottom: 40, left: 20, right: 0},
      rectWidth: 12,
      linear: {
       height: 90,
        width: 350
      }
    };
  }

  ngOnChanges(changes: SimpleChanges) {
    if(this.svg) {

    }
  }

  ngOnInit() {
    this.rectStep = 350 / this.srcData.length;

    this.svg = d3.select('svg')
        .attr('width', this.option.svgStyle.width)
        .attr('height', this.option.svgStyle.height);
    this.initData();
    this.drawAxis();
    this.drawbar();
    this.drawShadow();
  }

  initData() {
    this.dataSet = [];
    let maxValue = Math.max.apply(Math,this.srcData);
    this.srcData.forEach((data)=> {

      const height = this.option.linear.height / maxValue * data;

      this.dataSet.push({name: '', value: data, height: height});
    });
  }

  drawAxis() {

    let xScale = d3.scale.linear()
      .domain([0, 50])
      .range([0, 350]);

    let axis = d3.svg.axis()
      .scale(xScale)
      .orient('bottom');

    let gAxis = this.svg.append('g')
      .attr('transform', `translate(${this.option.padding.left}, ${this.option.linear.height})`)
      .attr('class', 'axis');

    axis(gAxis);
  }

  drawbar() {
    let self = this;
    let padding = self.option.padding;
    let bar = self.option.bar;
    this.rect = this.svg.append('g')
      .selectAll('rect')
      .data(this.dataSet)
      .enter()
      .append('rect')
      .attr('fill', '#7fd5ff')
      .attr('x', (d, i)=> { return padding.left + (this.rectStep - this.option.rectWidth) / 2  + i *  this.rectStep;})
      .attr('y', (d)=> {return this.option.svgStyle.height - padding.bottom - d.height;})
      .attr('width', this.option.rectWidth)
      .attr('height', (d)=>{
        return d.height;
      });
  }

  drawShadow() {
    let self = this;
    let padding = self.option.padding;
    let bar = self.option.bar;
    self.svg.append('g').selectAll('rect')
      .data(this.dataSet)
      .enter()
      .append('rect')
      .attr('fill', '#7fd5ff')
      .attr('x', (d, i)=> {return padding.left + i *  bar.rectStep;})
      .attr('y', padding.top)
      .attr('width', 35)
      .attr('height', 140)
      .attr('style', 'opacity:0')
      .on('mouseover', function() {
        let hovered = d3.select(this);
        hovered.style('opacity', 0.3);
        self.showTooltip();
      })
      .on('mouseout', function() {
      let mouseout = d3.select(this);
        mouseout.style('opacity', 0);
        self.hideTooltip();
    });
  }

  addLinear() {
    this.svg.append('g')
      .append('path')
      .attr('d', 'M20,160 H350')
      .attr('stroke-width', 2)
      .attr('stroke', '#c2c6c9');
  }

  addText() {
    this.addTickText();
    this.addLabelText();
  }

  addTickText() {
    const padding = this.option.padding;
    const svgStyle = this.option.svgStyle;
    this.svg.append('g').selectAll('text')
      .data(this.option.linear.xAxis.tick)
      .enter()
      .append('text')
      .attr('x', (d, i)=> {
        return {
          0: padding.left,
          1: (svgStyle.width - padding.left - padding.right) / 2,
          2: svgStyle.width - padding.right,
        }[i];
      })
      .attr('y', svgStyle.height - padding.bottom + 15)
      .attr('fill', '#c2c6c9')
      .text((d)=> {
        return d;
      });
  }

  addLabelText() {
    let self = this;
    const padding = this.option.padding;
    let bar = self.option.bar;
    this.svg.append('g').selectAll('text')
      .data(this.dataSet)
      .enter()
      .append('text')
      .attr('fill', '#7c868d')
      .attr('text-anchor', 'middle')
      .attr('x', (d, i)=> {return padding.left + bar.gap + i *  bar.rectStep})
      .attr('y', (d)=> {return this.option.svgStyle.height -  padding.bottom - d.height})
      .attr('dx', bar.rectWidth / 2)
      .attr('dy', '1em')
      .text((d)=> {return d.value});
  }


  showTooltip() {
    const left = (d3.event.pageX + 20);
    const top = (d3.event.pageY - 40);

    $('#myTooltip').css('top', top+'px')
      .css('left', left+'px')
      .css('display', 'inline-block');
  }

  hideTooltip() {
    $('#myTooltip').css('display', 'none');
  }
}
