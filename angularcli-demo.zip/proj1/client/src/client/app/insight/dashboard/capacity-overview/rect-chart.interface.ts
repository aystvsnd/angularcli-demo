/**
 * Created by 6092002302 on 2017/7/10.
 */


interface SvgStyle {
  width: number;
  height: number;
}

interface RectPadding {
  top: number;
  bottom: number;
  left: number;
  right: number;
}


export interface Option {
  svgStyle: SvgStyle;
  padding: RectPadding;
}
