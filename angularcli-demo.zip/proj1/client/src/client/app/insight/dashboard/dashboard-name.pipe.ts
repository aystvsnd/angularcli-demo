
import { Pipe, PipeTransform } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Pipe({name: 'dashboardName'})
export class DashboardNamePipe implements PipeTransform {

  constructor (private translate : TranslateService) {
    console.log('TODO');
  }

  transform(name: string): string {

    const showname = name;
    if (showname === 'info') {

      return this.translate.instant('insight.dashboard.Normal');
    } else if (showname === 'critical') {

      return this.translate.instant('insight.dashboard.Critical');
    } else if (showname === 'major') {

      return this.translate.instant('insight.dashboard.Major');
    } else if (showname === 'minor') {

      return this.translate.instant('insight.dashboard.Minor');
    } else if (showname === 'warning') {

      return this.translate.instant('insight.dashboard.Warning');
    } else if (showname === 'cpu_util') {

      return 'CPU';
    } else if (showname === 'VM_MEM_UTIL') {

      return this.translate.instant('insight.dashboard.Memory');
    } else if (showname === 'diskIOPS') {

      return this.translate.instant('insight.dashboard.DiskIOPS');
    } else if (showname === 'netBiIORate') {

      return this.translate.instant('insight.dashboard.NetworkBidirectionalTransmittedRate');
    } else if (showname === 'vm') {
      return this.translate.instant('insight.dashboard.Vms');
    } else if (showname === 'host') {
      return this.translate.instant('insight.dashboard.host');
    }
    return showname;
  }

}
