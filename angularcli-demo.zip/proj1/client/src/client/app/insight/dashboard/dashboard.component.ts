import {Component, OnInit} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  moduleId: module.id,
  selector: 'dash-board',
  styleUrls: ['dashboard.component.less', '../css/common.css'],
  templateUrl: 'dashboard.component.html',
})

export class DashboardComponent implements OnInit {
  activeString: any;

  dashboardPosition : {tabName: string, dcName: string};
  currentTab : string;
  currentDc : string;

  constructor(private translate: TranslateService) {

  }

  ngOnInit() {
    this.dashboardPosition = JSON.parse(sessionStorage.getItem('dashboardPosition'));
    if(this.dashboardPosition) {
      this.currentTab = this.dashboardPosition.tabName;
      this.currentDc = this.dashboardPosition.dcName;
    } else {
      this.currentTab = 'system';
      this.currentDc = '';
    }
  }

  choseTab(name: string) {
    this.currentTab = name;
    if(name === 'system') {
      sessionStorage.setItem('dashboardPosition', JSON.stringify({tabName: 'system', dcName: ''}));
    }
  }
}

