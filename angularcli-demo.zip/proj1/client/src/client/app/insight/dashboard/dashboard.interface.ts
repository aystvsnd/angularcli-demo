export interface Dcs {
  id: string;
  name : string;
}

interface Obj {
  id: string;
  name: string;
  alarms: number;
  alarmLevel: string;
}

interface Health {
  level : string;
  total: number;
  objs: Obj[];
}

export interface Healths {
  id: string;
  name: string;
  total: number;
  healths: Health[];
}

export interface PieInfo {
  name : string;
  value: number;
}

export interface Time {
  name: string;
  value: string;
}

export interface ObjsInfo {
  level: string;
  objTotal: number;
  alarmsInfo: Obj[];
  alarmImg: string;
}

export interface TopList {
  id: string;
  name: string;
  currentValue: number;
  last24HourTrend: Time[];
}

export interface HealthTop {
  meter: string;
  toplist : TopList[];
}
