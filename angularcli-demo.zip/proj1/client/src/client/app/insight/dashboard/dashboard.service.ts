import {Injectable} from '@angular/core';
import {Headers, Response} from '@angular/http';
import { ApiResourceService as Http } from '../../apiResource.service';

@Injectable()
export class InsightDashboardService {
   headers = new Headers({'Content-Type': 'application/json'});
  constructor(public http: Http) {

  }

  getDcList() {
    return this.http.get('/api/v1/smartTopo/dashboard/dclist').toPromise().then((res : Response) => {
      return res.json();
    });
  }

  getDcHealth(type : any, dcId : any) {
    return this.http.get('/api/v1/smartTopo/dashboard/health?type=' + type + '&dcId=' + dcId).toPromise().then((res : Response) => {
      return res.json();
    });
  }

  getDcTop(type : any, dcId: any) {
    return this.http.get('/api/v1/smartOm/dashboard/healthToplist?type=' + type + '&dcId=' + dcId).toPromise().then((res: Response) => {
      return res.json();
    });
  }

  getDcObjs(dcId : string) {
    return this.http.get('/api/v1/smartTopo/dashboard/virtualObjectCount?dcId=' + dcId).toPromise().then((res: Response)=> {
      return res.json();
    });
  }

  getCapaReclaimed(dcId: string) {
    return this.http.get('/api/v1/smartTopo/dashboard/reclaimResource?dcId='+ dcId).toPromise().then((res: Response)=>{
      return res.json();
    })
  }
}
