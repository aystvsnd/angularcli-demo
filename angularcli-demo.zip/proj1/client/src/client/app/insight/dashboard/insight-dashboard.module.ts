import {NgModule} from '@angular/core';

import {routing} from './dashboard.routes';
import {DashboardComponent} from './dashboard.component';
import {InsightDashboardService} from './dashboard.service';
import {ObjectRunningComponent} from './running/object-running.component';
import {PieChartComponent} from './running/pie-chart.component';
import {DashboardNamePipe} from './dashboard-name.pipe';
import {DashboardModule} from '../../monitor/dashboard/dashboard.module';
import {MiniLineComponent} from './running/mini-line.component';
import {InsightCommonModule} from '../common/common.module';
import {CapacityOverviewComponent} from './capacity-overview/capacity-overview.component';
import {RectChartComponent} from './capacity-overview/rect-chart.component';
import {SharedModule} from '../../shared/index';
import {SwitchModule} from '../shared/switch/index';

@NgModule({
  imports: [SharedModule, routing, DashboardModule, InsightCommonModule,SwitchModule],

  declarations: [DashboardComponent,ObjectRunningComponent, PieChartComponent, DashboardNamePipe,
    MiniLineComponent, CapacityOverviewComponent, RectChartComponent],
  providers: [InsightDashboardService],

})

export class InsightDashboardModule { }
