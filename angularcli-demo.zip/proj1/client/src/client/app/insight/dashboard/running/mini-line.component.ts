/**
 * Created by 6092002302 on 2017/5/20.
 */
import {Component, Input, OnChanges, SimpleChanges, ViewChild, AfterViewInit} from '@angular/core';
declare var echarts: any;
declare var $: any;
@Component({
  moduleId: module.id,
  template: `
                <div #dom class="mini-line">
                </div>
                `,
  selector: 'mini-line',
  styleUrls: ['object-running.component.less'],
})
export class MiniLineComponent implements AfterViewInit, OnChanges {

  @Input() data = [];
  @Input() name= 'chart';
  @Input() number= '';

  @ViewChild('dom') dom: any;
  option : any;
  element : any;
  ngOnChanges(changes: SimpleChanges) {

    if (this.option && changes['data']) {

      this.option.series[0].data = this.data.map((item) => {
        return {
          name: item.value,
          value: [item.time, item.value],
        };
      });
      this.element.setOption(this.option, true);
    }
  }
  ngAfterViewInit() {
    if (this.data && this.dom) {

      const miniChart = this.dom.nativeElement;

      this.option = {
        grid : {height: 30, top: 5, bottom: 5, left: 0, right: 0},
        tooltip : {trigger: 'axis', confine: true,
          position: function (point, params, dom, rect, size) {
            // 固定在顶部
            return [point[0], '50%'];
          }
        },
        xAxis: {
          show: false,
          type: 'time',
          axisTick : {inside: true},
          splitLine : {show: false},
          boundaryGap : false,
        },
        yAxis: {
          max: 100,
          show: false,
          axisLabel : {show: false},
          axisTick : {show: false},
          splitLine : {show: false},
        },

        series: [{
          type: 'line',
          name: '值',
          hoverAnimation: false,
          showSymbol: false,
          lineStyle: {
            normal: {
              color: '#00abff',
              width: 1,
            }
          },
          data: this.data.map(function (item) {
            return {
              name: item.value,
              value: [item.time, item.value],
            };
          }),
        }]};

      this.element = echarts.init(miniChart);
      this.element.setOption(this.option);
    }
  }

  ngOnDestroy() {
    if (this.element) {
      this.element.dispose();
    }
  }
}
