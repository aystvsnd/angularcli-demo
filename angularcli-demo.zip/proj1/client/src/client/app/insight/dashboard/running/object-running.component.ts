/**
 * Created by 6092002302 on 2017/5/16.
 */
import {Component, OnInit, Input} from '@angular/core';
import {InsightDashboardService} from '../dashboard.service';
import { Router } from '@angular/router';

import * as dashboardInterface from '../dashboard.interface';
@Component({
  moduleId: module.id,
  templateUrl: 'object-running.component.html',
  selector: 'object-running',
  styleUrls: ['object-running.component.less'],
})

export class ObjectRunningComponent implements OnInit {

  @Input() type;
  @Input() currentDc;

  public dcList : dashboardInterface.Dcs[];
  public switchName : string[] = [];
  public dcInfo : dashboardInterface.Healths;
  public pieInfo : dashboardInterface.PieInfo[];
  public objsDetail : dashboardInterface.ObjsInfo;
  public currentDcName : string;
  public currentDcId : string;

  public dcTop : dashboardInterface.HealthTop[];

  public pieColor = ['#ff322b', '#fc803e', '#feb731', '#ffe326', '#5cb85c'];

  public dashboardPosition : {tabName: string, dcName: string};

  constructor(private service: InsightDashboardService, private router: Router) {
    console.log('todo');
  }

  ngOnInit() {

    this.service.getDcList().then((res) => {
        this.dcList = res.dcs;
        if (!_.isEmpty(this.dcList)) {
            this.getDcsName(this.dcList);
        }
    });

  }

  getHealths(dcId : string) {
    this.service.getDcHealth(this.type, dcId).then((res) => {
      this.dcInfo = res;

      this.getPieInfo(this.dcInfo);
      this.getFirstLevelDetail(this.dcInfo);
    });
  }

  getDcTop(dcId : string) {
    const that = this;

    this.dcTop = [];
    if (this.type === 'vm') {
      this.service.getDcTop(this.type, dcId).then((res) => {
        that.dcTop = res.healthToplist;
      });
    }
  }

  changeContent(activeString : string) {
    this.currentDcName = activeString;
    this.currentDcId = this.getDcId(this.currentDcName);

    this.getHealths(this.currentDcId);
    this.getDcTop(this.currentDcId);

    this.dashboardPosition = {tabName: this.type, dcName: this.currentDcName};
    sessionStorage.setItem('dashboardPosition',JSON.stringify(this.dashboardPosition));
  }

  getDcId(name : string) {

    for (const dc of this.dcList) {
      if (name === dc.name) {
        return dc.id;
      }
    }
  }

  getDcsName(dcs : any) {

    for (const dc of dcs) {
      this.switchName.push(dc.name);
    }
  }

  getPieInfo(dcInfo : any) {
    this.pieInfo = [];

    for (const health of dcInfo.healths) {

      this.pieInfo.push({name: health.level, value: health.total});
    }
  }

  getFirstLevelDetail(dcInfo : any) {

    const objsInfo = {level: 'critical', objTotal: 0, alarmsInfo: [], alarmImg: this.getAlarmImg('critical')};

    if (dcInfo.total === 0) {
      this.objsDetail = {level: '', objTotal: 0, alarmsInfo: [], alarmImg: this.getAlarmImg('unknown')};
    } else {
      for (const health of dcInfo.healths) {

        if (health.total > 0) {

          objsInfo.level = health.level;
          objsInfo.alarmImg = this.getAlarmImg(health.level);
          objsInfo.objTotal = health.total;
          objsInfo.alarmsInfo = this.getAlarmInfo(health.objs);
          break;
        }
      }
      this.objsDetail = objsInfo;
    }
  }

  getChosenDetail(level : any) {
    const objsInfo = {level: '', objTotal: 0, alarmsInfo: [], alarmImg: ''};

    if (level === '') {
      this.objsDetail = {level: '', objTotal: 0, alarmsInfo: [], alarmImg: this.getAlarmImg('unknown')};
    } else {
      for (const health of this.dcInfo.healths) {

        if (level === health.level) {
          objsInfo.level = health.level;
          objsInfo.objTotal = health.total;
          objsInfo.alarmsInfo = this.getAlarmInfo(health.objs);
          objsInfo.alarmImg = this.getAlarmImg(level);
          break;
        }
      }
      this.objsDetail = objsInfo;
    }
  }

  getAlarmImg(level : string) {
    return {
      critical: 'assets/images/insight/svg/monitorObject/4_health_min.svg',
      major: 'assets/images/insight/svg/monitorObject/3_healthg_min.svg',
      minor: 'assets/images/insight/svg/monitorObject/2_health_min.svg',
      warning: 'assets/images/insight/svg/monitorObject/1_health_min.svg',
      info: 'assets/images/insight/svg/monitorObject/0_health_min.svg',
      unknown: 'assets/images/insight/svg/monitorObject/unknown_health_min.svg'
    }[level];
  }


  getAlarmInfo(objs : any) {

    const alarmInfo = [];
    for (const obj of objs) {

      alarmInfo.push({objName: obj.name, alarms: obj.alarms, objId: obj.id});
    }
    return alarmInfo;
  }

  gotoObjectDetail(objInfo : any) {

    this.router.navigate(['/main/insight/monitorObject/monitor-obj-detail',
      {name: objInfo.objName, type: this.type, objectId: objInfo.objId}]);
  }
}

