/**
 * Created by 6092002302 on 2017/5/16.
 */

import {OnInit, Component, Input, OnChanges, SimpleChanges, Output, EventEmitter} from '@angular/core';
declare var echarts: any;
declare var $: any;
@Component({
  moduleId: module.id,
  templateUrl: 'pie-chart.component.html',
  selector: 'pie-chart',
  styleUrls: ['object-running.component.less'],
})
export class PieChartComponent implements OnInit, OnChanges {

  @Input()
  type: string;

  @Input()
  title: string;

  @Input()
  labels: string[];

  @Input()
  fontTSize = '28';

  @Input()
  datas: any = [];

  @Input()
  colors: string[] = [
    '#40c0ff', '#96db59', '#f9d450', '#ff8480', '#e6e6e6', '#7a91f3', '#9e81d1',
    '#40b0a6', '#40f3c5', '#40d2df', '#889ea8'
  ];
  @Output() chosenLevel = new EventEmitter();

  element: any;

  option: any;

  currRate: any = 0;

  currLabel: string;

  ngOnChanges(changes: SimpleChanges) {
    if (this.option && changes['datas']) {

      this.option.series[0].data = this.initDatas();
      this.element.setOption(this.option, true);
    }
  }

  initDatas(): any[] {
    const currData = [];
    let count = 0;
    this.currRate = 0;
    this.currLabel = '';

    const isAllZero = this.datas.every((data) => {
      return data.value === 0;
    });
    if (isAllZero === true) {
      currData.push({
        value: 0,
        name: '',
        itemStyle: {
          normal: {
            color: '#c2c6c9',
          }
        }
      });
    } else {
      for (let i = 0; i < this.datas.length; i++) {
        currData.push({
          value: this.datas[i].value,
          name: this.datas[i].name,
          itemStyle: {
            normal:
              {color: (this.colors && this.colors[i]) ? this.colors[i] : ''}
          },
          // tooltip: {show: false},
          label: {
            normal: {
              show: false,
              textStyle: {fontSize: 20, color: '#555555'},
              formatter: this.title
            }
          }
        });
        count += this.datas[i];
      }
    }

    this.getCurrentDisplay(this.datas);

    return currData;
  }

  ngOnInit() {

    const that = this;
    $(document).ready(function() {
      const pie = $('#echartsRate-' + that.type);

      that.element = echarts.init(pie[0]);
      that.option = {
        tooltip: {
          trigger: 'item',
          formatter: (params: any, ticket: any, callback: any) => {
            that.currRate = (params.value === '' ? '0' : params.value);
            that.currLabel = params.name;
            return '';
          }
        },
        series: [{
           //hoverAnimation: false,
          type: 'pie',
          radius: ['75%', '88%'],
          center: ['50%', '50%'],
          label: {normal: {show: false, position: 'center'}},
          data: [{
            value: 0,
            name: 'Usage',
            itemStyle: {normal: {color: '#5DF55E'}},
            label: {
              normal: {
                formatter: '{d}%',
                textStyle: {fontSize: this.fontTSize, color: '#5DF55E'}
              }
            }
          }]
        }]
      };
      if (that.datas) {
        that.option.series[0].data = that.initDatas();
      }
      that.element.setOption(that.option);
      that.element.on('click',  function eConsole(param) {
        that.chosenLevel.emit(param.name);
      });
    });
  }

  getCurrentDisplay(datas : any) {
    for (let  i = 0; i < datas.length; i++) {
      if (datas[i].value !== 0) {
        this.currRate = datas[i].value;
        this.currLabel = datas[i].name;
        break;
      }
    }
  }

  ngOnDestroy() {
    if (this.element) {
      this.element.dispose();
    }
  }
}

