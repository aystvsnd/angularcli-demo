import {Component, OnInit, OnDestroy} from '@angular/core';
import {ActivatedRoute, Params, Router} from '@angular/router';

import 'rxjs/add/operator/switchMap';
import {Subscription} from 'rxjs';

import {HealthService} from './health.service';
import * as HealthInterface from './health.interface';
import {ContinuousRequest} from '../common/continuous-request';
import {SendMessageService} from '../../sendMessage.service';
import {TranslateService} from '@ngx-translate/core';

import { CommonFunctionService } from '../common/common-function.service';

class ResourceHealthDetail {
    public healthStatus: string;
    public objectInfo: {
        objectId: string;
        name: string;
        type: string;
        aggregates: string;
        cause: string;
        advice: string;
        operation: string;
        az: string;
        cloudEnvName?: string;
        cloudId?: string;
    };
    public currentAlarms: {
        total: number;
        criticalNum: number;
        majorNum: number;
        minorNum: number;
        warningNum: number;
    };
    public workload: {
        cpu: {load: number, status: string};
        mem : {load: number, status: string};
        disk : {load: number, status: string};
        net : {load: number, status: string};
        warning : number;
        cause : string;
        advice : string;
    };
    public childrenResource: HealthInterface.ResourceInfo[];
    public optStatus: string;
    public _data = {};

    constructor(detail) {
      this.healthStatus = detail.healthStatus;
      this.objectInfo = detail.objectInfo;
      this.currentAlarms = detail.currentAlarms;
      this.workload = detail.workload;
      this.childrenResource = detail[{
        vm: 'cloudDisk',
        host: 'hostVmsHealthOverview',
      }[this.objectInfo.type]];
      this.optStatus = detail.optStatus;

      _.each(['cause', 'advice'], key => this.objectInfo[key]
        += _.isEmpty(this.objectInfo[key]) || _.last(this.objectInfo[key]) === '.' ? '' : '.');

      this._data = detail;
    }

    public getChildrenResourceTotal(): number {
        return this.childrenResource.length;
    }

    public getGoodChildrenResource(): number {
        return this.childrenResource.filter((item) => {
            return item.healthStatus === 'good';
        }).length;
    }

    public getNormalChildrenResource(): number {
        return this.childrenResource.filter((item) => {
            return item.healthStatus === 'normal';
        }).length;
    }

    public getBadChildrenResource(): number {
        return this.childrenResource.filter((item) => {
            return item.healthStatus === 'bad';
        }).length;
    }

    public sliceChildrenResourceIntoRows(length: number) {
        const array = [];
        this.childrenResource.forEach((item, index) => {
            if (index % length === 0) {
                array.push([]);
            }
            array[Math.floor(index / length)].push(item);
        });

        return array;
    }

}

@Component({
    moduleId: module.id,
    styleUrls: ['../css/common.css', 'health-detail.component.less'],
    templateUrl: 'health-detail.component.html',
})
export class HealthDetailComponent implements OnInit, OnDestroy {
    detail: ResourceHealthDetail;
    links = [];
    childrenResource = [];
    isMovingVm = false;
    hasVmBeenMoved = false;
    workloadList = [];
  private subscription: Subscription;

  constructor(
        private activatedRoute: ActivatedRoute,
        private service: HealthService,
        private router: Router,
        private translate: TranslateService,
        private sendMessageService: SendMessageService,
        private commonFunctionService: CommonFunctionService ) {
  }

    ngOnInit() {

        const that = this;

        this.activatedRoute.params
            .switchMap((params: Params) => {
              return this.service.getHealthDetail(params['cloudId'], `${params['resourceType']}s`, params['id']);
            })
            .subscribe(res => {
              this.isMovingVm = false;
              this.hasVmBeenMoved = false;

              this.workloadList = this.generateWorkloadList(res.workload);

              this.detail = new ResourceHealthDetail(res);

              this.detail.objectInfo.name = that.commonFunctionService.unicode2Chr(this.detail.objectInfo.name);

              this.links = [{name: this.translate.instant('insight.health.HealthImprove'),
                  url: '/main/insight/health/health-promote'},
                  {name: `${this.detail.objectInfo.name}
                  ${this.translate.instant('insight.health.HealthLevel')}`}];
              if (this.hasChildrenResource()) {
                this.childrenResource =
                  this.detail.sliceChildrenResourceIntoRows(this.detail.childrenResource.length > 30 ? 20 : 10);
              }
              if (this.detail.optStatus === 'processing') {
                  this.isMovingVm = true;
                  new ContinuousRequest(
                    this.service,
                    res => res.finished === 'false',
                    this.service.getMoveVmResult,
                    this.detail.objectInfo.cloudId,
                    this.detail.objectInfo.objectId
                  ).toPormise().then(res => {
                    this.isMovingVm = false;
                    if (res.result === 'success') {
                      this.hasVmBeenMoved = true;
                      this.sendMessageService.insightSendSucMsg(that.translate.instant('insight.health.moveSuccess'));
                    } else {
                      let failReason;
                      if (res.result === 'failure') {
                        failReason = res.failReason;
                      } else if (res.result === 'no response') {
                        failReason = that.translate.instant('insight.health.serverNoResponse');
                      } else {
                        failReason = 'unknown';
                      }
                      this.sendMessageService.sendResponseMsg(`The moving of vm failed, failure reason: ${failReason}`);
                    }
                  });
                }

            });

    }

    ngOnDestroy() {
      if (this.subscription) {
        this.subscription.unsubscribe();
      }
    }

    setPercentBarStyle(resourceState: {load: number, status: string}) {
        return _.isEmpty(resourceState)
          ? {}
          : {
            'width.%': resourceState.load === -1 ? 100 : resourceState.load,
            'background': resourceState.load === -1 ? 'none' : {
                good: '#1898eb',
                normal: '#fdb026',
                bad: '#f66661',
              }[resourceState.status],
          };
    }

    gotoChildResourceDetail(item) {
      if (this.detail.objectInfo.type === 'host') {
        this.router.navigate(['/main/insight/health/health-detail', item.objectId,
          {cloudId: this.detail.objectInfo.cloudId, resourceType: 'vm'}]);
      }
    }

    moveVm() {

      const that = this;

      this.service.postMoveVmSbj.next({
        title: 'request',
        cloudId: this.detail.objectInfo.cloudId,
        objectId: this.detail.objectInfo.objectId,
      });

      this.subscription = this.service.postMoveVmSbj
        .filter(info => info.title === 'response')
        .subscribe(()  => {

          this.isMovingVm = true;

          new ContinuousRequest(
            this.service,
            res => {return res.finished === 'false'; },
            this.service.getMoveVmResult,
            this.detail.objectInfo.cloudId,
            this.detail.objectInfo.objectId
          ).toPormise().then(res => {
            this.isMovingVm = false;
            if (res.result === 'success') {
              this.hasVmBeenMoved = true;
              this.sendMessageService.insightSendSucMsg(that.translate.instant('insight.health.moveSuccess'));
            } else {
              let failReason;
              if (res.result === 'failure') {
                failReason = res.failReason;
              } else if (res.result === 'no response') {
                failReason = that.translate.instant('insight.health.serverNoResponse');
              } else {
                failReason = 'unknown';
              }
              this.sendMessageService.sendResponseMsg(`The moving of vm failed, failure reason: ${failReason}`);
            }
          });
        });
    }

    gotoAlarm() {
      this.router.navigate(['alarm', {'objectId': this.detail.objectInfo.objectId,
          'objectName': this.detail.objectInfo.name,
          'objPath': location.pathname.replace(/\/uniportal\//, '')}], {relativeTo: this.activatedRoute});
    }

    gotoHistoryLine() {
    console.log(this.detail, this.detail.objectInfo.cloudId);
      this.router.navigate(['/main/insight/health/health-historyLine',
        {cloudId : this.detail.objectInfo.cloudId, objectId : this.detail.objectInfo.objectId,
          objectType : this.detail.objectInfo.type, objectName: this.detail.objectInfo.name}]);
    }

  hasChildrenResource() {
    return _.isEmpty(this.detail) ? false : _.contains(['vm', 'host'], this.detail.objectInfo.type);
  }

  private generateWorkloadList(workload) {
    const resourceName = {
      diskSpace: 'DISK SPACE',
      diskIO: 'DISK I/O',
      cpu: 'CPU',
      mem: 'MEM',
      disk: 'DISK',
      net: 'NET',
    };

    return _.chain(workload)
      .pick(_.keys(resourceName))
      .pairs()
      .map(item => _.defaults({name: resourceName[item[0]]}, item[1]))
      .value();
  }
}
