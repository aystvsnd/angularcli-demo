/**
 * Created by 6092002302 on 2017/2/6.
 */
import {Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

declare var echarts: any;
declare var jQuery: any;
@Component({
  moduleId: module.id,
  template: `<div id="health-history-line" class="health-history-line">
               
            </div>`,
  selector: 'health-history-line',
  styles: [
    `
     .health-history-line { 
        width: 550px;
        height: 300px;
        display: flex;
        flex-flow: column;
     }
     `
  ]
})

export class HealthHistoryLineComponent implements OnInit {
  @Input() data;
  dataType : any = [];
  option : any = {};
  constructor(
    private translate: TranslateService,
  ) {}
  ngOnInit() {
    const that = this;
    const pie = jQuery('#health-history-line');
    if (this.data.name !== 'net') {
      pie.attr('id', `health-history-line${this.data.name}`);
      this.option = {
        grid : {top: 10, left: 20, right: 70, },
        tooltip : {trigger: 'axis'},
        xAxis: {
            splitNumber : 6,
            type: 'time',
            axisTick : {inside: true},
            splitLine : {show: false},
            boundaryGap : false,
            axisLabel : {
                textStyle: {color: '#000'},
                formatter: function(value) {
                    if (that.data.value.counter.dateRange === 'last6Hours') {
                     return that.last6HoursFormat(new Date(value), 'hh:mm');
                    } else {
                      return that.otherTimeFormat(new Date(value));
                    }
                }
            },
        },
        yAxis: {
            max : (that.data.maxValue === null) ? null : that.data.yAxisMax * 1.2,
            axisLabel : {show: false},
            axisTick : {show: false},
            splitLine : {show: false},
        },
        /*"dataZoom": [{
          "show": true,
          "height": 30,
          "xAxisIndex": [
            0
          ],
          bottom: 30,
          "start": 10,
          "end": 80,
          handleIcon: 'path://M306.1,413c0,2.2-1.8,4-4,4h-59.8c-2.2,0-4-1.8-4-4V200.8c0-2.2,1.8-4,4-4h59.8c2.2,0,4,1.8,4,4V413z',
          handleSize: '100%',
          handleStyle:{
            color:"#d3dee5",

          },
          borderColor:"#d8e1e9"


        }, {
          "type": "inside",
          "show": true,
          "height": 15,
          "start": 1,
          "end": 35
        }],*/
        series: [{
          type: 'line',
          name: that.translate.instant('insight.health.Value'),
          hoverAnimation: false,
          symbolSize: 6,
          showSymbol: false,
          data: this.data.value.counterChart.map(function (item) {
            const time = item.time * 60000;
            const value = item.value.toFixed(2);
            return {
              name: value,
              value: [time, value],
            };
          }),
          markPoint: {
            symbol: 'circle',
            symbolSize: '8',
            data: [
              {type: 'max', name: that.translate.instant('insight.health.MaxValue')},
              {type: 'min', name: that.translate.instant('insight.health.MiniValue')},
            ],
            label: {
              normal: {show: false, /*position:'top',formatter:'{b}'*/}
            }
          },
          markLine: {
            symbol: false,
            label: {
              normal: {show: true, position: 'end', formatter: '{b}\n{c}%'},
            },
            lineStyle: {
              normal: {type: 'solid', color: '#7f7f7f', width: 1, fontWeight: 'bold', fontSize: 14}
            },
            data: [
              {name : that.translate.instant('insight.health.High'), yAxis: this.data.value.counter.highThreshold },
              {name : that.translate.instant('insight.health.Low'), yAxis: this.data.value.counter.lowThreshold}
            ]
          },
        },
        ]
      };
      const echarts_pie = echarts.init(document.querySelector(`#health-history-line${this.data.name}`));
      echarts_pie.setOption(this.option);
    } else {
      this.option = {
        grid: {top: 5, left: 20, bottom: 80},
        tooltip : {trigger: 'axis'},
        xAxis: {
            type: 'time',
            splitLine : {show: false},
            axisTick  : {inside: true },
            boundaryGap : false,
            splitNumber : 6,
            axisLabel : {
                textStyle: {color: '#000'},
                formatter: function(value) {
                    if (that.data.value[0].counter.dateRange === 'last6Hours') {
                        return that.last6HoursFormat(new Date(value), 'hh:mm');
                    } else {
                        return that.otherTimeFormat(new Date(value));
                    }
                }
            },
        },
        yAxis: {
          axisLabel: {show: false},
          axisTick: {show: false},
          splitLine: {show: false},
        },
        series: [{
          type: 'line',
          name: that.translate.instant('insight.health.Value'),
          hoverAnimation: false,
          symbolSize: 6,
          showSymbol: false,
          data: this.data.value[0].counterChart.map(function (item) {
            const time = item.time * 60000;
            const value = item.value.toFixed(7);
            return {
              name: item.value,
              value: [time, value],
            };
          }),
          markPoint: {
            symbol: 'circle',
            symbolSize: '8',
            data: [
              {type: 'max', name: that.translate.instant('insight.health.MaxValue')},
              {type: 'min', name: that.translate.instant('insight.health.MiniValue')}
            ],
            label: {
              normal: {show: false, }
            }
          },
          markLine: {
            symbol: false,
            label: {
              normal: {show: true, position: 'start', formatter: '{b}{c}'},
            },
            lineStyle: {
              normal: {
                type: 'solid',
                color: '#7f7f7f',
                width: 1,
                fontWeight: 'bold',
                fontSize: 14
              }
            },
            data: [
              {name : that.translate.instant('insight.health.High'), yAxis: this.data.value[0].counter.highThreshold},
              {name : that.translate.instant('insight.health.Low'), yAxis: this.data.value[0].counter.lowThreshold}
            ]
          },
        }, {
          type: 'line',
          name: that.translate.instant('insight.health.Value'),
          hoverAnimation: false,
          symbolSize: 6,
          showSymbol: false,
          data: this.data.value[1].counterChart.map(function (item) {
            const time = item.time * 60000;
            const value = item.value.toFixed(7);
            return {
              name: item.value,
              value: [time, value]
            };
          }),
          markPoint: {
            symbol: 'circle',
            symbolSize: '8',
            data: [
              {type: 'max', name: that.translate.instant('insight.health.MaxValue')},
              {type: 'min', name: that.translate.instant('insight.health.MiniValue')}
            ],
            label: {
              normal: {show: false, }
            }
          },
        },
        ]
      };
      pie.attr('id', `health-history-line-${this.data.objectName}`);
      const echarts_pie = echarts.init(document.querySelector(`#health-history-line-${this.data.objectName}`));
      echarts_pie.setOption(this.option);
    }
  }

  last6HoursFormat(date, fmt) {
    const o = {
      'M+': date.getMonth() + 1,
      'd+': date.getDate(),
      'h+': date.getHours(),
      'm+': date.getMinutes(),
      's+': date.getSeconds(),
      'q+': Math.floor((date.getMonth() + 3) / 3),
      'S': date.getMilliseconds()
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
    for (const k in o)
      if (new RegExp('(' + k + ')').test(fmt)) fmt =
        fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)));
    return fmt;
  }

  otherTimeFormat(date) {
    const month = date.getMonth() + 1;
    const day = date.getDate();

    return month + '-' + day + ' ' + this.last6HoursFormat(date, 'hh:mm');
  }
}

