import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import {HealthService} from './health.service';
import {TranslateService} from '@ngx-translate/core';
const SUCCESS = 1;
const FAIL = 0;
@Component({
  moduleId: module.id,
  templateUrl: 'health-history.component.html',
  styleUrls: [ '../css/common.css', 'health-history.component.css'],
})

export class HealthHistoryComponent implements OnInit {
  historyNet : any = [];
  historyLine : any = [];
  historyAll: any = {};
  netMsg : any = {};
  dateRange : any;
  dateRangeList : any;
  objectName : any;
  endTime : any;
  startTime : any;
  sendHistory : any = {};
  isShowAll = false;
  isShowLoading= true;
  loading : any = this.translate.instant('fm.loading');
  constructor(private healthService : HealthService, private router: Router,
              private activatedRoute: ActivatedRoute, private translate: TranslateService, ) {
    this.dateRangeList = ['LastSixHours', 'LastOneDay', 'LastOneWeek'];
    this.dateRange = this.dateRangeList[0];
    this.endTime = parseInt((new Date().getTime() / 60000).toString());
    this.startTime = this.endTime - 60 * 6;
    this.sendHistory.name = 'all';
    const that = this;
    this.activatedRoute.params.subscribe(params => {
      that.sendHistory.cloudId = params.cloudId;
      that.sendHistory.objectId = params.objectId;
      that.sendHistory.objectType = params.objectType;
      that.objectName = params.objectName;
    });
    this.readData();
  }

  ngOnInit() {
    const that = this;
    setTimeout(function(){
      that.isShowLoading = false;
    }, 6000);
  }

  readData() {
    this.historyLine = [];
    this.historyNet = [];
    this.sendHistory.dateRange = this.dateRange;
    this.sendHistory.endTime = this.endTime;
    this.sendHistory.startTime = this.startTime;
    const that = this;
    that.isShowLoading = true;
    this.healthService.postHistoryLine(this.sendHistory).then(res => {
      that.isShowLoading = false;
      that.getHistoryMsg(res, that);
    });
  }

  getHistoryMsg(res : any, that : any) {
    for (const item of res.chartList) {
      if (item.counter.name.indexOf('net') >= 0) {
        this.netMsgHander(item);
      } else {
        this.commonMsgHander(item, that);
      }
    }
  }

  updateDisplay(searchTime : any) {
    this.dateRange = searchTime;
    this.endTime = parseInt((new Date().getTime() / 60000).toString());
    this.startTime = {
      'LastSixHours' : this.endTime - 60 * 6,
      'LastOneDay' : this.endTime - 60 * 24,
      'LastOneWeek' : this.endTime - 60 * 24 * 7
    }[searchTime];
    this.readData();
  }

  netMsgHander(netItem : any) {
    this.netMsg = {};
    if (this.historyNet.length !== 0) {
      const isPair = this.netMsgPair(netItem);
      if (isPair === 0) {
        this.netMsg.netName = 'NET';
        this.creatNetMsg(netItem);
      }
    } else {
      this.netMsg.netName = 'NET';
      this.creatNetMsg(netItem);
    }
  }

  creatNetMsg(netItem : any) {
    this.netMsg.name = 'net';
    if (netItem.counterChart.length === 0) {
      this.netMsg.currentLine1Value = null;
      this.netMsg.currentLine1Status = null;
    } else {
      this.netMsg.currentLine1Value = netItem.counterChart[netItem.counterChart.length - 1].value.toFixed(7);
      this.netMsg.currentLine1Status = this.getStatus(this.netMsg.currentLine1Value);
    }
    this.netMsg.objectName = netItem.counter.objectName;
    this.netMsg.value = [];
    this.netMsg.value.push(netItem);
    this.historyNet.push(this.netMsg);
  }

  netMsgPair(netItem : any) {
    for (const item of this.historyNet) {
      if (netItem.counter.objectName === item.objectName) {
        if (netItem.counterChart.length === 0) {
          item.currentLine2Value = null;
          item.currentLine2Status = null;
        } else {
          item.currentLine2Value = netItem.counterChart[netItem.counterChart.length - 1].value.toFixed(7);
          item.currentLine2Status = this.getStatus(item.currentLine2Value);
        }
        item.value.push(netItem);
        return SUCCESS;
      }
    }
    return FAIL;
  }

  commonMsgHander(item : any, that : any) {
    this.historyAll = {};
    this.historyAll.name = this.getGraphTitle(item.counter.name);
    if (item.counterChart.length === 0) {
      this.historyAll.currentValue = null;
      this.historyAll.currentStatus = null;
    } else {
      this.historyAll.currentValue = item.counterChart[item.counterChart.length - 1].value.toFixed(2);
      this.historyAll.currentStatus = this.getStatus(this.historyAll.currentValue);
    }
    this.historyAll.maxValue = this.getItemMaxValue(item.counterChart);
    this.historyAll.yAxisMax = this.historyAll.maxValue > item.counter.highThreshold
      ? this.historyAll.maxValue : item.counter.highThreshold;
    this.historyAll.value = item;
    this.historyLine.push(that.historyAll);
  }

  getGraphTitle(name : any) {
    let title = name.split('.')[0];
    title = title.toLocaleUpperCase();
    return title;
  }

  getItemMaxValue(chartMsg : any) {
    let maxValue;
    if (chartMsg.length === 0) {
      maxValue = null;
    } else if (chartMsg.length === 1) {
      maxValue = chartMsg[0].value;
    } else {
      for (const item of chartMsg) {
        if (item === chartMsg[0]) {
          maxValue = item.value;
        } else {
          if (maxValue < item.value) {
            maxValue = item.value;
          }
        }
      }
    }
    return maxValue;
  }

  HideMore() {
    this.isShowAll = false;
    console.log(this.isShowAll);
  }

  ShowMore() {
    this.isShowAll = true;
    console.log(this.isShowAll);
  }
  getStatus(value : any) {
    if (value <= 30) {
      return 'good';
    }
    if (30 < value  && value <= 70) {
      return 'normal';
    }
    if (value > 70) {
      return 'bad';
    }
  }

  setPercentBarStyle(load: number, status: string) {
    return {
      'width.%': load === -1 ? 100 : load,
      'background': load === -1 ? 'none' : {
          good: '#1898eb',
          normal: '#fdb026',
          bad: '#f66661',
        }[status],
    };
  }

  goBack() {
    window.history.back(-1);
  }

  getBackToHealthPromote() {
    this.router.navigate(['main/insight/health/health-promote']);
  }
}



