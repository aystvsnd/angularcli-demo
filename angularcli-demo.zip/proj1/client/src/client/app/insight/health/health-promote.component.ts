/**
 * Created by 10192595 on 2016/11/30.
 */
import {Component, OnInit, OnDestroy} from '@angular/core';
import {Router} from '@angular/router';

import * as HealthInterface from './health.interface';
import {HealthService} from './health.service';
import {SendMessageService} from '../../sendMessage.service';
import {URL_LIST} from '../insight.config';

import {TranslateService} from '@ngx-translate/core';
import {StorageService } from '../../storage.service';
import {ContinuousRequest} from '../common/continuous-request';
import {Subscription} from 'rxjs';

import { CommonFunctionService } from '../common/common-function.service';

@Component({
  moduleId: module.id,
  templateUrl: 'health-promote.component.html',
  styleUrls: ['../css/common.css', 'health-promote.component.less'],
})
export class HealthPromoteComponent implements OnInit, OnDestroy {
  list: HealthInterface.AbnormalHealthInfo[];
  //keyword: string;
  selectedResourceType: string;
  exportData: any = {

  };
  //itemCount:number;
  window: window = window;

  columnDefs: any[] = [
    {
      field: 'name',
      align: 'left',
      title: this.translate.instant('insight.health.ResourceName'),
      events: 'operateEvents',
      formatter: function (value, row, index) {
        const newStr = _this.commonFunctionService.unicode2Chr(value);
        return `<a href="javascript:void(0);" class="detail">${newStr}</a>`;
      }
    },
    {
      field: 'type',
      align: 'left',
      title: this.translate.instant('insight.health.ResourceType')
    },
    {
      field: 'cloudEnvName',
      align: 'left',
      title: this.translate.instant('insight.health.CloudEnvironment')
    },
    {
      field: 'az',
      align: 'left',
      title: this.translate.instant('insight.health.AZ')
    },
    {
      field: 'aggregates',
      align: 'left',
      title: this.translate.instant('insight.health.Aggregates')
    },
    {
      field: 'cause',
      align: 'left',
      title: this.translate.instant('insight.health.Cause')
    },
    {
      field: 'advice',
      align: 'left',
      title: this.translate.instant('insight.health.proposal')
    },
    {
      field: 'operation',
      align: 'center',
      title: this.translate.instant('insight.health.operation'),
      formatter: (value, row, index) => {
        if (value !== '') {
          if (row.optStatus === 'processing') {
            return '<span class="moving"><img src="assets/images/insight/process.png">'
              + this.translate.instant('insight.health.moving') + '</span>';
          } else {
            return `<button class="table-btn" >${value}</button>`;
          }
        } else {
          return '';
        }

      }
    }
  ];

  gridOptions: any = {
    method: 'get',
    queryParams: params => this.queryParams(params, this),
    columns: this.columnDefs,
    sidePagination: 'server',
    pagination: true, //是否开启分页
    pageSize: 10, //单页数量�
    pageNumber: 1,
    pageList: [10, 20],
    paginationDetailHAlign: 'right', //分页详情水平位置�
    paginationHAlign: 'right', //分页条水平位置��
    search: true,
    escape:true,
    customSearch: function(text) {
      console.log('search:', text);
    }
  };

  private subscriptions = [];

  constructor(
    private service: HealthService,
    private router: Router,
    private sendMessageService: SendMessageService,
    private translate: TranslateService,
    private storageService: StorageService,
    private commonFunctionService: CommonFunctionService) {

      if (this.storageService.getCurrentLang() === 'en') {
        $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
      } else {
        $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
      }

      this.selectedResourceType = 'all';
      //this.keyword = '';
      this.window.operateEvents = {
        'click .detail': function (e, value, row, index) {
          router.navigate(['/main/insight/health/health-detail', row.objectId,
            {cloudId: row.cloudId, resourceType: row.type}]);
        }
      };


    }

  ngOnInit() {
    this.initTable();
  }

  ngOnDestroy() {
    this.subscriptions.forEach(item  => {
      (item as Subscription).unsubscribe();
    });
  }

  /*
  doFilter() {
    this.itemCount = 0;

    jQuery('tbody tr').each((index, tr) => {
      if (jQuery(tr).children('td').is((n, td) => {
            return (jQuery(td).text() as string).indexOf(this.keyword) > -1
          }) && (this.selectedResourceType === 'all'
                  || (jQuery(tr).children('[axis="resource-type"]').text() as string) === this.selectedResourceType)) {
          tr.style.display = 'table-row';
          this.itemCount++;
      } else {
          tr.style.display = 'none';
      }
    });
  } */

  queryParams(params: any, that: any) {
    const tmp = {
      pageSize: params.limit,
      currentPage: params.offset / params.limit + 1,
      fuzzy: params.search,
    };

    //that.SetExportData(that,tmp);

    that.isShowLoading = true;
    return tmp;
  }

  initTable() {
    const that = this;

    $('#table-health-promote').bootstrapTable($.extend(this.gridOptions, {
      url: `${URL_LIST.SmartPmUrl}workloadException/objects`,
      dataField: 'healthPromoteInfo',
      responseHandler: function (res) {

        const HealthPromoteInfo = {
          'total': res.total,
          'healthPromoteInfo': res.objectList
        };

        return HealthPromoteInfo;
      },
      onLoadSuccess: data => {
        const tableItemList = document.querySelectorAll('tbody tr');
        data.healthPromoteInfo.forEach((item, index) => {
          if (item.operation !== '') {
            if (item.optStatus === 'processing') {
              this.getMoveVmResult(item, index);
            } else {
              tableItemList[index].querySelector('button').addEventListener('click', event => {
                console.log(event.target);
                this.service.postMoveVmSbj.next({
                  title: 'request',
                  cloudId: item.cloudId,
                  objectId: item.objectId,
                });

                const subscription = this.service.postMoveVmSbj
                  .filter(info => info.title === 'response' && info.hostId === item.objectId)
                  .subscribe(()  => {
                    subscription.unsubscribe();
                    const moving = document.createElement('span');
                    moving.className = 'moving';
                    const img = document.createElement('img');
                    img.setAttribute('src', 'assets/images/insight/process.png');
                    moving.appendChild(img);
                    moving.appendChild(document.createTextNode(this.translate.instant('insight.health.moving')));

                    event.target.parentElement.replaceChild(moving, event.target);

                    this.getMoveVmResult(item, index);
                  });
              });
            }
          }
        });
      }
    }));

    $('.bootstrap-table .search input').attr('placeholder', that.translate.instant('fm.importKey'))
      .parent().append(`<span></span>`);
  }

  getMoveVmResult(item, index) {
    const that = this;
    const tableItemList = document.querySelectorAll('tbody tr');

    new ContinuousRequest(this.service, res => !(res.finished === 'true'), this.service.getMoveVmResult, item.cloudId, item.objectId)
      .toPormise()
      .then(res => {
        if (res.result === 'success') {
          this.sendMessageService.insightSendSucMsg(`${that.translate.instant('insight.dashboard.host')}
          ${item.name}${that.translate.instant('insight.health.moveSuccess')}`);
        } else {
          let failReason;
          if (res.result === 'failure') {
            failReason = res.failReason;
          } else if (res.result === 'no response') {
            failReason = that.translate.instant('insight.health.serverNoResponse');
          } else {
            failReason = 'unknown';
          }

          failReason = item.name + ' ' +
                       that.translate.instant('insight.health.moveFailReason') +
                       failReason;
          failReason = this.commonFunctionService.cutStr(failReason, 60);

          console.log(failReason.length);

          this.sendMessageService.sendResponseMsg(failReason);

          /*this.sendMessageService.sendResponseMsg(`${that.translate.instant('insight.dashboard.host')}
          ${item.name}${that.translate.instant('insight.health.moveFail')}${failReason}`);*/
        }
        console.log(res);
        const moving = tableItemList[index].querySelector('.moving');
        const $button = document.createElement('button');
        $button.className = 'table-btn';
        $button.appendChild(document.createTextNode(item.operation));
        $button.setAttribute('disabled', 'true');
        moving.parentElement.replaceChild($button, moving);

        const aHref =  tableItemList[index].querySelector('a');
        const span = document.createElement('span');
        span.innerHTML = aHref.innerText;
        aHref.parentElement.replaceChild(span, aHref);
      });
  }
}
