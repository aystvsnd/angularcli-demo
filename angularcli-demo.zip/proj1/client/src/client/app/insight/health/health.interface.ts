/**
 * Created by 10192595 on 2016/11/30.
 */
export interface AbnormalHealthInfo {
  objectId: string;
  name: string;
  type: string;
  aggregates: string;
  cause: string;
  advice: string;
  operation: string;
  az: string;
  cloudEnvName?: string;
}

export interface AbnormalHealthList {
  objectList: AbnormalHealthInfo[];
}

interface CurrentAlarm {
  total: number;
  criticalNum: number;
  majorNum: number;
  minorNum: number;
  warningNum: number;
}

interface WorkLoad {
  cpuLoad: number;
  memLoad : number;
  diskLoad : number;
  netLoad : number;
  warning : number;
  cause : string;
  advice : string;
}

export interface ResourceInfo {
  objectId: string;
  objectName: string;
  healthStatus?: string;
}

export interface ResourceHealthDetail {
  healthStatus: string;
  objectInfo: AbnormalHealthInfo;
  currentAlarms: CurrentAlarm;
  workLoad: WorkLoad;
}

export interface VmHealthDetail extends ResourceHealthDetail {
  hostBelongToHealth: ResourceInfo;
  cloudDisk: ResourceInfo[];
}

export interface HostHealthDetail extends ResourceHealthDetail {
  hostVmsHealthOverview: ResourceInfo[];
}
