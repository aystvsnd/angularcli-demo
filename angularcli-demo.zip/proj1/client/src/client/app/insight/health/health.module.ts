import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';

import {routing} from './health.routes';
import {HealthService} from './health.service';
import {HealthPromoteComponent} from './health-promote.component';
import {HealthDetailComponent} from './health-detail.component';
import {SharedModule} from '../../shared/index';
import {InsightCommonModule} from '../common/common.module';
import {MoveVmConfirmDialogComponent} from './move-vm-confirm-dialog.component';
import {CurrentAlarmModule} from '../../fm/currentAlarm/current-alarm.module';
import {HealthHistoryComponent} from './health-history.component';
import {HealthHistoryLineComponent} from './health-history-line.component';

@NgModule({
  imports: [CommonModule, routing, SharedModule, InsightCommonModule, FormsModule, routing, CurrentAlarmModule],
  declarations: [HealthPromoteComponent, HealthDetailComponent, MoveVmConfirmDialogComponent,
    HealthHistoryComponent, HealthHistoryLineComponent],
    providers: [HealthService],
})
export class HealthModule {}
