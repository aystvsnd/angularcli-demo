import {ModuleWithProviders} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {HealthPromoteComponent} from './health-promote.component';
import {HealthDetailComponent} from './health-detail.component';
import {CurrentAlarmComponent} from '../../fm/currentAlarm/current-alarm.component';
import {CurrentAlarmDetailComponent} from '../../fm/currentAlarm/current-alarm-detail.component';
import {HealthHistoryComponent} from './health-history.component';

const routes: Routes = [
  {
    path: 'health',
    children: [{
      path: 'health-detail/:id',
      component: HealthDetailComponent,
      },
      {
        path: 'health-detail/:id/alarm',
        component: CurrentAlarmComponent,
      },
      {
        path: 'health-detail/alarm/detail',
        component: CurrentAlarmDetailComponent,
      },
      {
        path: 'health-promote',
        component: HealthPromoteComponent,
      },
      {
        path: 'health-historyLine',
        component: HealthHistoryComponent,
      }
    ]
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);

