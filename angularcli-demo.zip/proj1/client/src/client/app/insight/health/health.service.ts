import {Injectable} from '@angular/core';
import {Response} from '@angular/http';

import 'rxjs/add/operator/toPromise';
import {Subject} from 'rxjs/Subject';

import { ApiResourceService as Http } from '../../apiResource.service';
import {URL_LIST} from '../insight.config';

@Injectable()
export class HealthService {
  public postMoveVmSbj = new Subject<any>();

  constructor(private http: Http) {

  }

  getAbnormalHealthList(pageSize: number, pageIndex: number): Promise<{total: number; objectList: any[]}> {
    return this.http.get(`${URL_LIST.SmartPmUrl}workloadException/objects?pageSize=${pageSize}&currentPage=${pageIndex}`)
      .toPromise()
      .then((res: Response) => {
        return res.json();
      });
  }

  postMoveVm(cloudId: string, hostId: string) {
    this.http.post(`${URL_LIST.SmartPmUrl}healthOptimize/move/vm`, {cloudId: cloudId, hostId: hostId})
      .catch()
      .subscribe();
  }

  getMoveVmResult(cloudId: string, hostId: string) {
    return this.http.get(`${URL_LIST.SmartPmUrl}healthOptimize/${cloudId}/move/vm/result/${hostId}`).toPromise().then(res => res.json());
  }

  getHealthDetail(cloudId: string, resourType: string, objectId: string) {
    return this.http.get(`${URL_LIST.SmartPmUrl}healthDetail/${cloudId}/${resourType}/${objectId}`)
      .toPromise()
      .then(res => {
        return res.json();
      });
  }
  postHistoryLine(historyMsg : any) {
    return this.http.post('/api/v1/smartPm/counterHistory', historyMsg).toPromise().then(
      (res : Response) => {
        return res.json();
      }
    );
  }
}
