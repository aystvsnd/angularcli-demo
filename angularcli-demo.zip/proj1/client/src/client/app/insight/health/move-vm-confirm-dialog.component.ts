import {Component, OnInit, OnDestroy} from '@angular/core';

import {HealthService} from './health.service';
import {Subscription} from 'rxjs';

@Component({
  moduleId: module.id,
  template: `
    <div class="background" *ngIf="isShown">
      <div class="dialog">
        <div class="head">
          <p>{{"insight.health.moveVm" | translate}}</p>
          <span (click)="isShown=false"></span>
        </div>
        <div class="content">
          <div class="info">
            <div style="margin-left: 10px;">
            <img src="assets/images/insight/pop_alarm.png">
            </div>
            <p style="margin-left: 20px;line-height:20px;">{{"insight.health.ConfirmInfo" | translate}}</p>
          </div>
          <div class="fill"></div>
          <div class="button-area">
            <button class="normal" (click)="confirm()">{{"insight.health.Confirm" | translate}}</button>
            <button class="cancel" (click)="isShown=false">{{"insight.health.Cancel" | translate}}</button>
          </div>
          <div class="foot"></div>
        </div>
      </div>
    </div>
      `,
  selector: 'move-vm-confirm-dialog',
  styleUrls: ['move-vm-confirm-dialog.component.less', '../css/common.css'],
})
export class MoveVmConfirmDialogComponent implements OnInit, OnDestroy {
  private isShown = false;
  private data;
  private subscription: Subscription;

  constructor(
    private healthService: HealthService,
  ) {}

  ngOnInit() {
    this.subscription = this.healthService.postMoveVmSbj
      .filter(info => info.title === 'request')
      .subscribe((info) => {
        this.data = {
          cloudId: info.cloudId,
          hostId: info.objectId,
        };
        this.isShown = true;
      });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  confirm() {
    this.healthService.postMoveVm(this.data.cloudId, this.data.hostId);
    this.isShown = false;
    this.healthService.postMoveVmSbj.next({title: 'response', hostId: this.data.hostId});
  }
}
