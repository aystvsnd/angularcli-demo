/**
 * Created by 10192595 on 2016/11/8.
 */

import {Component} from '@angular/core';
import {Router} from '@angular/router';
import {TranslateService} from '@ngx-translate/core';


@Component({
  moduleId: module.id,
  styles: [`
    .title {
      color: #333;
      font-size: 24px;
      margin: 0;
    }

    .tip {
      color: #999;
      font-size: 14px !important;
      margin: 14px 0 16px !important;
    }

    div {
      text-align: center;
      margin-top: 122px;
    }

    img {
      margin-bottom: 36px;
    }
  `],
  styleUrls: ['css/common.css'],
  template: `
    <div>
      <img src="assets/images/insight/cloud%201-08.png">
      <p class="title">{{IndexTitle}}</p>
      <p class="tip">{{IndexTip}}</p>
      <button class="key" (click)="configCloudEnvironment()">{{ConfigEnv}}</button>
    </div>
  `,
})

export class InsightIndexComponent {

  IndexTitle: any;
  IndexTip: any;
  ConfigEnv: any;

  constructor(private router: Router, private translate: TranslateService) {
    this.IndexTitle = this.translate.instant('insight.IndexTitle');
    this.IndexTip = this.translate.instant('insight.IndexTip');
    this.ConfigEnv = this.translate.instant('insight.ConfigEnv');
  }

  configCloudEnvironment() {
    this.router.navigate(['/main/insight/ops-insight-config/cloud-environment-config']);
  }
}

