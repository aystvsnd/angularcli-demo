export const lowVolumeRiskThreshold = 50;
export const highVolumeRiskThreshold = 80;
const BASE_URL = '/api/v1';

export const URL_LIST = {
  SmartPmUrl: `${BASE_URL}/smartPm/`,
  SmartTopo: `${BASE_URL}/smartTopo/`,
};
