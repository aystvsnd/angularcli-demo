import { NgModule } from '@angular/core';
import { SharedModule} from '../shared/shared.module';

import { routing } from './insight.routes';
import { InsightIndexComponent} from './insight-index.component';

import {AnalysisModule} from './alarm/analysis.module';
import {StrategyModule} from './strategy/strategy.module';
import {MonitorObjectModule} from './monitorObject/monitor-object.module';
import {TopologyModule} from './topology/topology.module';
import {PortDiagnoseModule} from './port-diagnose/port-diagnose.module';
import {HealthModule} from './health/health.module';
import {OpsInsightConfigModule} from './ops-insight-config/ops-insight-config.module';
import {InsightDashboardModule} from './dashboard/insight-dashboard.module';
import {VolumeModule} from './volume/volume.module';

@NgModule({
  declarations: [InsightIndexComponent],
  imports: [SharedModule, AnalysisModule, StrategyModule, MonitorObjectModule, TopologyModule, PortDiagnoseModule,
    HealthModule, OpsInsightConfigModule, InsightDashboardModule, VolumeModule, routing],
})

export class InsightModule { }
