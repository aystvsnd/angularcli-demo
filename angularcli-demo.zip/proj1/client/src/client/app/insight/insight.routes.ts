import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {InsightIndexComponent} from './insight-index.component';

const routes: Routes = [
  {path: `index`, component: InsightIndexComponent},
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
