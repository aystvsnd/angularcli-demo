/**
 * Created by 6092002303 on 2017/3/16.
 */
import { Component , OnInit , Input, Output, EventEmitter  } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {TranslateService} from '@ngx-translate/core';
import {StorageService } from '../../../../storage.service';
import { KyButtonComponent, KyLoadingComponent, KyProcessBarComponent} from '../../../../shared/kylib/index';
import { MonitorObjectService } from './../../monitor-object.service';

@Component({
  moduleId: module.id,
  selector: 'monitor-obj-cpi-reclaimhost',
  directives: [KyButtonComponent, KyLoadingComponent, KyProcessBarComponent],
  styleUrls: [ '../../../css/common.css', '../monitor-obj-detail.component.less',
    '../../../css/tooltip.less'],
  templateUrl: 'monitor-obj-cpi-reclaimhost.component.html'
})

export class MonitorObjCpiReclaimHostComponent implements OnInit {
  @Input() aboutMeInfo;
  @Input() relatedObjectInfo;
  @Input() siblingNum;
  @Input() childrenNum;
  @Output() reclaimMinImg = new EventEmitter();

  window: window = window;
  name: any;
  objectId: string;
  objectType: string;
  headNames: Array<any>;
  activeString: any;
  imgUrlsMax: string;
  reclaimCapSlideBlock: any;

  reclaimCapWords: string;
  reclaimWordAdd = '';

  reclaimList: any;

  siblingNum: number;
  childrenNum: number;

  tipName: string;
  tipType: string;
  tipAlarms: number;
  tipHealth: string;
  tipRisk: string;
  tipEfficiency: string;
  tipWorkload: string;
  tipRemainCapa: string;
  tipReclaimCapa: string;
  tipStress: string;

  constructor(private monitorObjectService: MonitorObjectService, private activatedRoute: ActivatedRoute,
              private router: Router, private translate: TranslateService,
              private storageService: StorageService) {

    this.activatedRoute.params.subscribe(params => {
      this.objectId = params['objectId'];
      this.name = params['name'];
      this.objectType = params['type'];
      console.log(this.objectId);
    });

    if (this.storageService.getCurrentLang() === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }
    this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/4_recyclable_max.svg';
    this.reclaimCapSlideBlock = [50, 75];

  }

  ngOnInit() {

    this.monitorObjectService.getReclaimCapInfo(this.objectId, this.objectType)
      .then((res: Response) => {
        const that = this;
        that.reclaimList = res;
        if ( res.cpuOccup !== null ) {
          if ( res.cpuOccup.reclaim !== -1) {
            that.reclaimList['cpuOccup'].reclaim = (+res.cpuOccup.reclaim).toFixed(0);
          } else {
            that.reclaimList['cpuOccup'].reclaim = (+res.cpuOccup.reclaim);
          }
          if ( res.cpuOccup.reclaimPer !== -1) {
            that.reclaimList['cpuOccup'].reclaimPer = (+res.cpuOccup.reclaimPer).toFixed(2);
          } else {
            that.reclaimList['cpuOccup'].reclaimPer = (+res.cpuOccup.reclaimPer);
          }
          that.reclaimList['cpuOccup'].cause = res.cpuOccup.cause;
          that.reclaimList['cpuOccup'].level = res.cpuOccup.level;
        } else {
          that.reclaimList['cpuOccup'].reclaim = (+that.reclaimList['cpuOccup'].reclaim).toFixed(0);
          that.reclaimList['cpuOccup'].reclaimPer = (+that.reclaimList['cpuOccup'].reclaimPer).toFixed(2);
          that.reclaimList['cpuOccup'].cause = that.reclaimList['cpuOccup'].cause;
          that.reclaimList['cpuOccup'].level = that.reclaimList['cpuOccup'].level;
        }

        if ( res.memOccup !== null ) {
          if ( res.memOccup.reclaim !== -1) {
            that.reclaimList['memOccup'].reclaim = (+res.memOccup.reclaim).toFixed(2);
          } else {
            that.reclaimList['memOccup'].reclaim = (+res.memOccup.reclaim);
          }
          if (res.memOccup.reclaimPer !== -1) {
            that.reclaimList['memOccup'].reclaimPer = (+res.memOccup.reclaimPer).toFixed(2);
          } else {
            that.reclaimList['memOccup'].reclaimPer = (+res.memOccup.reclaimPer);
          }
          that.reclaimList['memOccup'].cause = res.memOccup.cause;
          that.reclaimList['memOccup'].level = res.memOccup.level;
        } else {
          that.reclaimList['memOccup'].reclaim = (+that.reclaimList['memOccup'].reclaim).toFixed(2);
          that.reclaimList['memOccup'].reclaimPer = (+that.reclaimList['memOccup'].reclaimPer).toFixed(2);
          that.reclaimList['memOccup'].cause = that.reclaimList['memOccup'].cause;
          that.reclaimList['memOccup'].level = that.reclaimList['memOccup'].level;
        }

        if ( res.diskSpaceOccup !== null) {
          if ( res.diskSpaceOccup.reclaim !== -1) {
            that.reclaimList['diskSpaceOccup'].reclaim = (+res.diskSpaceOccup.reclaim).toFixed(2);
          } else {
            that.reclaimList['diskSpaceOccup'].reclaim = (+res.diskSpaceOccup.reclaim);
          }
          if ( res.diskSpaceOccup.reclaimPer !== -1) {
            that.reclaimList['diskSpaceOccup'].reclaimPer = (+res.diskSpaceOccup.reclaimPer).toFixed(2);
          } else {
            that.reclaimList['diskSpaceOccup'].reclaimPer = (+res.diskSpaceOccup.reclaimPer);
          }
          that.reclaimList['diskSpaceOccup'].cause = res.diskSpaceOccup.cause;
          that.reclaimList['diskSpaceOccup'].level = res.diskSpaceOccup.level;
        } else {
          that.reclaimList['diskSpaceOccup'].reclaim = (+that.reclaimList['diskSpaceOccup'].reclaim).toFixed(2);
          that.reclaimList['diskSpaceOccup'].reclaimPer = (+that.reclaimList['diskSpaceOccup'].reclaimPer).toFixed(2);
          that.reclaimList['diskSpaceOccup'].cause = that.reclaimList['diskSpaceOccup'].cause;
          that.reclaimList['diskSpaceOccup'].level = that.reclaimList['diskSpaceOccup'].level;
        }
        that.reclaimList.LastCalcTime = this.changeToDate(res.LastCalcTime);
        that.reclaimList['curStrategy'] = res.curStrategy;
        this.reclaimCapSlideBlock[0] = +that.reclaimList['curStrategy'].low;
        this.reclaimCapSlideBlock[1] = +that.reclaimList['curStrategy'].high;
        if (this.reclaimCapSlideBlock[0] < 0 || this.reclaimCapSlideBlock[0] > 100) {this.reclaimCapSlideBlock[0] = 0; }
        if (this.reclaimCapSlideBlock[1] > 100 || this.reclaimCapSlideBlock[1] < 0) {this.reclaimCapSlideBlock[1] = 100; }
        if (res.curStrategy.oversize !== -1) {
          that.reclaimList['curStrategy'].oversize = (+res.curStrategy.oversize).toFixed(0);
        } else {
          that.reclaimList['curStrategy'].oversize = (+res.curStrategy.oversize);
        }
        if (res.curStrategy.idle !== -1) {
          that.reclaimList['curStrategy'].idle = (+res.curStrategy.idle).toFixed(0);
        } else {
          that.reclaimList['curStrategy'].idle = (+res.curStrategy.idle);
        }
        if (res.curStrategy.poweroff !== -1) {
          that.reclaimList['curStrategy'].poweroff = (+res.curStrategy.poweroff).toFixed(0);
        } else {
          that.reclaimList['curStrategy'].poweroff = (+res.curStrategy.poweroff);
        }

        if (that.reclaimList.level === 'high' ) {
          this.reclaimMinImg.emit('high');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/1_recyclable_max.svg';
          this.reclaimCapWords = this.translate.instant('insight.Objects.CriticalReclaim');

          let cpuPer, memPer, diskPer;
          if ( res.cpuOccup !== null && res.cpuOccup.reclaimPer !== -1) {
            cpuPer = +that.reclaimList.cpuOccup.reclaimPer;
          } else {
            cpuPer = -1;
          }

          if ( res.memOccup !== null && res.memOccup.reclaimPer !== -1) {
            memPer = +that.reclaimList.memOccup.reclaimPer;
          } else {
            memPer = -1;
          }

          if ( res.diskSpaceOccup !== null && res.diskSpaceOccup.reclaimPer !== -1) {
            diskPer = +that.reclaimList.diskSpaceOccup.reclaimPer;
          } else {
            diskPer = -1;
          }
          let tempNum = +cpuPer;
          if (tempNum > memPer) {
            this.reclaimWordAdd = 'CPU';
          } else if (tempNum === memPer) {
            this.reclaimWordAdd = 'CPU' + ', ' + that.translate.instant('insight.Objects.Memory');
          } else if (tempNum < memPer) {
            tempNum = memPer;
            this.reclaimWordAdd = that.translate.instant('insight.Objects.Memory');
          }

          if (tempNum < diskPer) {
            this.reclaimWordAdd = that.translate.instant('insight.Objects.DiskSpace');
            tempNum = diskPer;
          } else if (tempNum === diskPer) {
            this.reclaimWordAdd = this.reclaimWordAdd + ', ' + that.translate.instant('insight.Objects.DiskSpace');
          }

          if (tempNum === -1) {
            this.reclaimWordAdd = '';
          }

        } else if (that.reclaimList.level === 'middle') {
          this.reclaimMinImg.emit('middle');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/2_recyclable_max.svg';
          this.reclaimCapWords = this.translate.instant('insight.Objects.Warning');
        } else if (that.reclaimList.level === 'low') {
          this.reclaimMinImg.emit('low');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/3_recyclable_max.svg';
          this.reclaimCapWords = this.translate.instant('insight.Objects.Normal');
        } else  if (that.reclaimList.level === '--') {
          this.reclaimMinImg.emit('--');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/4_recyclable_max.svg';
          this.reclaimCapWords = '--';
        }

        that.reclaimList['history'] = res.history.concat();
        this.reclaimEcharts( that.reclaimList['history'] );

      });

  }

  reclaimEcharts( date: any ) {

    const option3 = {
      tooltip : {
        trigger: 'axis',
        axisPointer: {
          //type: 'cross',
          label: {
            backgroundColor: '#6a7985'
          }
        }
      },
      grid: {
        left: '0%',
        right: '3%',
        bottom: '3%',
        top: '20%',
        containLabel: true
      },
      xAxis : [
        {
          type : 'category',
          boundaryGap : false,
          data : [],
          show : false
        }
      ],
      yAxis : [
        {
          type : 'value',
          show : false,
          max: 100
        }
      ],
      series : [
        {
          name: this.translate.instant('insight.Objects.ReclaimCapa'),
          type: 'line',
          stack: '总量',
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          areaStyle: {
            normal: {opacity: 0.3}
          },
          itemStyle: {
            normal: {color: '#00aaff'}
          },
          symbol: 'none',
          data: date
        }
      ]
    };
    const dom3: any = document.getElementById('reclaimEchart');
    const myChart3: any = echarts.init(dom3, 'macarons');
    myChart3.setOption(option3);
  }


  showTooltip (e, item) {
    this.tipName = item.name;
    if (item.type === 'host') {
      this.tipType = this.translate.instant('insight.Objects.HostList');
    } else {
      this.tipType = item.type;
    }
    this.tipAlarms = item.alarms;
    this.tipHealth = item.health;
    this.tipRisk = item.risk;
    this.tipEfficiency = item.efficiency;
    this.tipWorkload = item.workload;
    this.tipRemainCapa = item.remainCapacity;
    this.tipReclaimCapa = item.reclaimCapacity;
    this.tipStress = item.stress;

  }

  hideTooltip() {
    //$('.tipBox').css('display', 'none');
  }

  mousePosition(ev) {
    ev = ev || window.event;
    if (ev.pageX || ev.pageY) {
      return {x: ev.pageX, y: ev.pageY};
    }
    return {
      x: ev.clientX + document.body.scrollLeft - document.body.clientLeft,
      y: ev.clientY + document.body.scrollTop - document.body.clientTop
    };
  }

  changeToDate(data) {
    const myTime = data * 1000;
    const myDate = new Date(myTime);

    const str = myDate.getFullYear() + '-' + this.transformDigitString(( myDate.getMonth() + 1)) + '-' +
      this.transformDigitString(myDate.getDate()) + ' ' +  this.transformDigitString(myDate.getHours()) + ':' +
      this.transformDigitString(myDate.getMinutes());

    return str;
  }

  transformDigitString(str: any) {

    if (str < 10) {
      return '0' + str;
    } else {
      return str;
    }
  }

}

