/**
 * Created by 6092002303 on 2017/3/16.
 */
import { Component , OnInit , Input, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {TranslateService} from '@ngx-translate/core';
import {StorageService } from '../../../../storage.service';
import { KyButtonComponent, KyLoadingComponent, KyProcessBarComponent} from '../../../../shared/kylib/index';
import { MonitorObjectService } from './../../monitor-object.service';

@Component({
  moduleId: module.id,
  selector: 'monitor-obj-cpi-remain',
  directives: [KyButtonComponent, KyLoadingComponent, KyProcessBarComponent],
  styleUrls: [ '../../../css/common.css', '../monitor-obj-detail.component.less',
    '../../../css/tooltip.less'],
  templateUrl: 'monitor-obj-cpi-remain.component.html'
})

export class MonitorObjCpiRemainComponent implements OnInit {
  @Input() aboutMeInfo;
  @Input() relatedObjectInfo;
  @Input() siblingNum;
  @Input() childrenNum;
  @Output() remainMinImg = new EventEmitter();

  window: window = window;
  name: any;
  objectId: string;
  objectType: string;
  headNames: Array<any>;
  activeString: any;
  imgUrlsMax: string;
  remainCapSlideBlock: any;

  remainCapWords: string;
  remainWordAdd = '';
  remainList: any;
  remainCpuCheck: any = false;
  remainMemCheck: any = false;
  remainDiskCheck: any = false;
  remainNetInCheck: any = false;
  remainNetOutCheck: any = false;
  remainNetIOCheck: any = false;

  siblingNum: number;
  childrenNum: number;

  tipName: string;
  tipType: string;
  tipAlarms: number;
  tipHealth: string;
  tipRisk: string;
  tipEfficiency: string;
  tipWorkload: string;
  tipRemainCapa: string;
  tipReclaimCapa: string;
  tipStress: string;

  remainPolicyWord: string;

  columnDefsRemainCap : any[] = [
    {
      field: 'check',
      align: 'left',
      title: this.translate.instant('insight.Objects.Indicators'),
      formatter: function (value, row, index) {
        return `<div>
                  <span style="font-size: 13px">${value}</span>
                  <div>`;
      }
    },
    {
      field: 'total',
      align: 'right',
      title: this.translate.instant('insight.Objects.TotalCapa'),
      formatter: function (value, row, index) {
        return `<div>
                  <span style="font-size: 13px">${value}</span>
                  <div>`;
      }
    },
    {
      field: 'remain',
      align: 'right',
      title: this.translate.instant('insight.Objects.RemainCapacity'),
      formatter: function (value, row, index) {
        return `<div>
                  <span style="font-size: 13px">${value}</span>
                  <div>`;
      }
    },
    {
      field: 'suggestSize',
      align: 'center',
      title: this.translate.instant('insight.Objects.SuggestionSize'),
      formatter: function (value, row, index) {
        if (row.flag === 'over') {
          return `<div class="suggestSize">
                    <img class="arrowImg" src="assets/images/insight/svg/monitorObject/up_line_arrow.svg">
                    <span style="font-size: 13px">${value}</span>
                    <div>`;
        } else if (row.flag === 'under') {
          return `<div class="suggestSize">
                    <img class="arrowImg" src="assets/images/insight/svg/monitorObject/down_line_arrow.svg">
                    <span style="font-size: 13px">${value}</span>
                    <div>`;
        } else {
          return `<div div class="suggestSize">
                   <div class="rectArea"></div>
                    <span style="font-size: 13px">${value}</span>
                    <div>`;
        }
      }
    }

  ];

  gridOptionsRemainCap: any = {
    method: 'get',
    columns: this.columnDefsRemainCap,
    sidePagination: 'server',
    escape:true
  };

  initTableRemainCap() {
    const that = this;
    $('#remaincap').bootstrapTable($.extend(this.gridOptionsRemainCap, {
      url: '/api/v1/smartOm/monitorObject/cpi/remainCapacity?objectId=' + this.objectId + '&type=' + this.objectType,
      dataField: 'checks',
      responseHandler: function (res) {
        const remainChecks = [];
        for (const attr in res) {
          switch (attr) {
            case 'cpuOccup': {
              if ( res.cpuOccup !== null ) {
                const cpucheck = 'CPU';
                const cpuOccup = {
                  check: cpucheck,
                  total: that.remainList.cpuOccup.cores + ' VCPU',
                  remain: that.remainList.cpuOccup.remainPer + '%',
                  flag: that.remainList.cpuOccup.flag,
                  suggestSize: that.remainList.cpuOccup.suggestSize + ' VCPU'
                };
                remainChecks.push(cpuOccup);
              }
            }; break;
            case 'memOccup': {
              if (  res.memOccup !== null ) {
                const memcheck = that.translate.instant('insight.Objects.Memory');
                const memOccup = {
                  check: memcheck,
                  total: that.remainList.memOccup.total + ' MB',
                  remain: that.remainList.memOccup.remainPer + '% (' + that.remainList.memOccup.remain + ' MB)',
                  flag: that.remainList.memOccup.flag,
                  suggestSize: that.remainList.memOccup.suggestSize + ' MB'
                };
                remainChecks.push(memOccup);
              }
            }; break;
            case 'diskSpaceOccup': {
              if (  res.diskSpaceOccup !== null ) {
                const diskSpacecheck = that.translate.instant('insight.Objects.DiskSpace');
                const diskSpaceOccup = {
                  check: diskSpacecheck,
                  total: that.remainList.diskSpaceOccup.total + ' GB',
                  remain: that.remainList.diskSpaceOccup.remainPer + '% (' + that.remainList.diskSpaceOccup.remain + ' GB)',
                  flag: that.remainList.diskSpaceOccup.flag,
                  suggestSize: that.remainList.diskSpaceOccup.suggestSize + ' GB'
                };
                remainChecks.push(diskSpaceOccup);
              }
            }; break;
            case 'networkIncomingRate': {
              if (  res.networkIncomingRate !== null ) {
                const netIncheck = that.translate.instant('insight.Objects.InRate');
                const networkIncomingRate = {
                  check: netIncheck,
                  total: that.remainList.networkIncomingRate.total + ' Kbps',
                  remain: that.remainList.networkIncomingRate.remainPer + '% (' + that.remainList.networkIncomingRate.remain + ' Kbps)',
                  flag: that.remainList.networkIncomingRate.flag,
                  suggestSize: that.remainList.networkIncomingRate.suggestSize + ' Kbps',
                };
                remainChecks.push(networkIncomingRate);
              }
            }; break;
            case 'networkOutgoingRate': {
              if (  res.networkOutgoingRate !== null ) {
                const netOutcheck = that.translate.instant('insight.Objects.OutRate');
                const networkOutgoingRate = {
                  check: netOutcheck,
                  total: that.remainList.networkOutgoingRate.total + ' Kbps',
                  remain: that.remainList.networkOutgoingRate.remainPer + '% (' + that.remainList.networkOutgoingRate.remain + ' Kbps)',
                  flag: that.remainList.networkOutgoingRate.flag,
                  suggestSize: that.remainList.networkOutgoingRate.suggestSize + ' Kbps',
                };
                remainChecks.push(networkOutgoingRate);
              }
            }; break;
            case 'networkBidirectRate': {
              if (  res.networkBidirectRate !== null ) {
                const netIOcheck = that.translate.instant('insight.Objects.IORate');
                const networkBidirectRate = {
                  check: netIOcheck,
                  total: that.remainList.networkBidirectRate.total + ' Kbps',
                  remain: that.remainList.networkBidirectRate.remainPer + '% (' + that.remainList.networkBidirectRate.remain + ' Kbps)',
                  flag: that.remainList.networkBidirectRate.flag,
                  suggestSize: that.remainList.networkBidirectRate.suggestSize + ' Kbps',
                };
                remainChecks.push(networkBidirectRate);
              }
            }; break;
          }
        }

        const checks = {
          'curStrategy': res.curStrategy,
          'checks' : remainChecks
        };
        return checks;
      }
    }));
  }

  constructor(private monitorObjectService: MonitorObjectService, private activatedRoute: ActivatedRoute,
              private router: Router, private translate: TranslateService,
              private storageService: StorageService) {

    this.activatedRoute.params.subscribe(params => {
      this.objectId = params['objectId'];
      this.name = params['name'];
      this.objectType = params['type'];
      console.log(this.objectId);
    });

    if (this.storageService.getCurrentLang() === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }
    this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/4_capacity_max.svg';
    this.remainCapSlideBlock = [25, 50];

    this.remainList = {
      'level': '--',
      'type': 'vm',
      'cpuOccup': {
        'cores': 0,
        'peakPer': 0,
        'averagePer': 0,
        'remainPer': 0,
        'suggestSize': 0,
        'flag': 'normal',
        'history': {
          'total': [],
          'suggestSize': [],
          'average': [],
          'used': []
        }
      },
      'memOccup': {
        'total': 0,
        'peak': 0,
        'peakPer': 0,
        'average': 0,
        'remain': 0,
        'remainPer': 0,
        'suggestSize': 0,
        'flag': 'normal',
        'history': {
          'total': [],
          'suggestSize': [],
          'average': [],
          'used': []
        }
      },
      'diskSpaceOccup': {
        'total': 0,
        'peak': 0,
        'peakPer': 0,
        'average': 0,
        'remain': 0,
        'remainPer': 0,
        'suggestSize': 0,
        'flag': 'normal',
        'history': {
          'total': [],
          'suggestSize': [],
          'average': [],
          'used': []
        }
      },
      'networkIncomingRate': {
        'total': 0,
        'peak': 0,
        'peakPer': 0,
        'average': 0,
        'remain': 0,
        'remainPer': 0,
        'suggestSize': 0,
        'flag': 'normal',
        'history': {
          'total': [],
          'suggestSize': [],
          'average': [],
          'used': []
        }
      },
      'networkOutgoingRate': {
        'total': 0,
        'peak': 0,
        'peakPer': 0,
        'average': 0,
        'remain': 0,
        'remainPer': 0,
        'suggestSize': 0,
        'flag': 'normal',
        'history': {
          'total': [],
          'suggestSize': [],
          'average': [],
          'used': []
        }
      },
      'networkBidirectRate': {
        'total': 0,
        'peak': 0,
        'peakPer': 0,
        'average': 0,
        'remain': 0,
        'remainPer': 0,
        'suggestSize': 0,
        'flag': 'normal',
        'history': {
          'total': [],
          'suggestSize': [],
          'average': [],
          'used': []
        }
      },
      'history': [],
      'LastCalcTime': '',
      'curStrategy': {
        'low': 0,
        'high': 100,
        'checks': [
          'cpuOccup',
          'memOccup',
          'diskSpaceOccup',
          'networkIncomingRate',
          'networkOutgoingRate',
          'networkBidirectRate'
        ],
        'algo': 'peakOnly',
        'wndSize': 0
      }
    };

  }

  ngOnInit() {

    this.monitorObjectService.getRemainCapInfo(this.objectId, this.objectType)
      .then((res: Response) => {
        const that = this;
        that.remainList.level = res.level;
        that.remainList.type = res.type;

        if ( res.cpuOccup !== null ) {
          if ( +res.cpuOccup.cores === -1 ) {
            that.remainList.cpuOccup.cores = '--';
          } else {
            that.remainList.cpuOccup.cores = (+res.cpuOccup.cores).toFixed(0);
          }
          if ( +res.cpuOccup.peakPer === -1 ) {
            that.remainList.cpuOccup.peakPer = '--';
          } else {
            that.remainList.cpuOccup.peakPer = (+res.cpuOccup.peakPer).toFixed(2);
          }
          if ( +res.cpuOccup.averagePer === -1 ) {
            that.remainList.cpuOccup.averagePer = '--';
          } else {
            that.remainList.cpuOccup.averagePer = (+res.cpuOccup.averagePer).toFixed(2);
          }
          if ( +res.cpuOccup.remainPer === -1 ) {
            that.remainList.cpuOccup.remainPer = '--';
          } else {
            that.remainList.cpuOccup.remainPer = (+res.cpuOccup.remainPer).toFixed(2);
          }
          if ( +res.cpuOccup.suggestSize === -1 ) {
            that.remainList.cpuOccup.suggestSize = '--';
          } else {
            that.remainList.cpuOccup.suggestSize = (+res.cpuOccup.suggestSize).toFixed(0);
          }
          that.remainList.cpuOccup.flag = res.cpuOccup.flag;
          that.remainList.cpuOccup.history = (+res.cpuOccup.history).toFixed(2);
        } else {
          that.remainList.cpuOccup.cores = (+that.remainList.cpuOccup.cores).toFixed(0);
          that.remainList.cpuOccup.peakPer = (+that.remainList.cpuOccup.peakPer).toFixed(2);
          that.remainList.cpuOccup.averagePer = (+that.remainList.cpuOccup.averagePer).toFixed(2);
          that.remainList.cpuOccup.remainPer = (+that.remainList.cpuOccup.remainPer).toFixed(2);
          that.remainList.cpuOccup.suggestSize = (+that.remainList.cpuOccup.suggestSize).toFixed(0);
          that.remainList.cpuOccup.flag = that.remainList.cpuOccup.flag;
          that.remainList.cpuOccup.history = (+that.remainList.cpuOccup.history).toFixed(2);
        }

        if ( res.memOccup !== null ) {
          if ( +res.memOccup.total === -1 ) {
            that.remainList.memOccup.total = '--';
          } else {
            that.remainList.memOccup.total = (+res.memOccup.total).toFixed(2);
          }
          if ( +res.memOccup.peak === -1 ) {
            that.remainList.memOccup.peak = '--';
          } else {
            that.remainList.memOccup.peak = (+res.memOccup.peak).toFixed(2);
          }
          if ( +res.memOccup.peakPer === -1 ) {
            that.remainList.memOccup.peakPer = '--';
          } else {
            that.remainList.memOccup.peakPer = (+res.memOccup.peakPer).toFixed(2);
          }
          if ( +res.memOccup.average === -1 ) {
            that.remainList.memOccup.average = '--';
          } else {
            that.remainList.memOccup.average = (+res.memOccup.average).toFixed(2);
          }
          if ( +res.memOccup.remain === -1 ) {
            that.remainList.memOccup.remain = '--';
          } else {
            that.remainList.memOccup.remain = (+res.memOccup.remain).toFixed(2);
          }
          if ( +res.memOccup.remainPer === -1 ) {
            that.remainList.memOccup.remainPer = '--';
          } else {
            that.remainList.memOccup.remainPer = (+res.memOccup.remainPer).toFixed(2);
          }
          if ( +res.memOccup.suggestSize === -1 ) {
            that.remainList.memOccup.suggestSize = '--';
          } else {
            that.remainList.memOccup.suggestSize = (+res.memOccup.suggestSize).toFixed(2);
          }
          that.remainList.memOccup.flag = res.memOccup.flag;
          that.remainList.memOccup.history = (+res.memOccup.history).toFixed(2);
        } else {
          that.remainList.memOccup.total = (+that.remainList.memOccup.total).toFixed(2);
          that.remainList.memOccup.peak = (+that.remainList.memOccup.peak).toFixed(2);
          that.remainList.memOccup.peakPer = (+that.remainList.memOccup.peakPer).toFixed(2);
          that.remainList.memOccup.average = (+that.remainList.memOccup.average).toFixed(2);
          that.remainList.memOccup.remain = (+that.remainList.memOccup.remain).toFixed(2);
          that.remainList.memOccup.remainPer = (+that.remainList.memOccup.remainPer).toFixed(2);
          that.remainList.memOccup.suggestSize = (+that.remainList.memOccup.suggestSize).toFixed(2);
          that.remainList.memOccup.flag = that.remainList.memOccup.flag;
          that.remainList.memOccup.history = (+that.remainList.memOccup.history).toFixed(2);
        }

        if ( res.diskSpaceOccup !== null ) {
          if ( +res.diskSpaceOccup.total === -1 ) {
            that.remainList.diskSpaceOccup.total = '--';
          } else {
            that.remainList.diskSpaceOccup.total = (+res.diskSpaceOccup.total).toFixed(2);
          }
          if ( +res.diskSpaceOccup.peak === -1 ) {
            that.remainList.diskSpaceOccup.peak = '--';
          } else {
            that.remainList.diskSpaceOccup.peak = (+res.diskSpaceOccup.peak).toFixed(2);
          }
          if ( +res.diskSpaceOccup.peakPer === -1 ) {
            that.remainList.diskSpaceOccup.peakPer = '--';
          } else {
            that.remainList.diskSpaceOccup.peakPer = (+res.diskSpaceOccup.peakPer).toFixed(2);
          }
          if ( +res.diskSpaceOccup.average === -1 ) {
            that.remainList.diskSpaceOccup.average = '--';
          } else {
            that.remainList.diskSpaceOccup.average = (+res.diskSpaceOccup.average).toFixed(2);
          }
          if ( +res.diskSpaceOccup.remain === -1 ) {
            that.remainList.diskSpaceOccup.remain = '--';
          } else {
            that.remainList.diskSpaceOccup.remain = (+res.diskSpaceOccup.remain).toFixed(2);
          }
          if ( +res.diskSpaceOccup.remainPer === -1 ) {
            that.remainList.diskSpaceOccup.remainPer = '--';
          } else {
            that.remainList.diskSpaceOccup.remainPer = (+res.diskSpaceOccup.remainPer).toFixed(2);
          }
          if ( +res.diskSpaceOccup.suggestSize === -1 ) {
            that.remainList.diskSpaceOccup.suggestSize = '--';
          } else {
            that.remainList.diskSpaceOccup.suggestSize = (+res.diskSpaceOccup.suggestSize).toFixed(2);
          }
          that.remainList.diskSpaceOccup.flag = res.diskSpaceOccup.flag;
          that.remainList.diskSpaceOccup.history = (+res.diskSpaceOccup.history).toFixed(2);
        } else {
          that.remainList.diskSpaceOccup.total = (+that.remainList.diskSpaceOccup.total).toFixed(2);
          that.remainList.diskSpaceOccup.peak = (+that.remainList.diskSpaceOccup.peak).toFixed(2);
          that.remainList.diskSpaceOccup.peakPer = (+that.remainList.diskSpaceOccup.peakPer).toFixed(2);
          that.remainList.diskSpaceOccup.average = (+that.remainList.diskSpaceOccup.average).toFixed(2);
          that.remainList.diskSpaceOccup.remain = (+that.remainList.diskSpaceOccup.remain).toFixed(2);
          that.remainList.diskSpaceOccup.remainPer = (+that.remainList.diskSpaceOccup.remainPer).toFixed(2);
          that.remainList.diskSpaceOccup.suggestSize = (+that.remainList.diskSpaceOccup.suggestSize).toFixed(2);
          that.remainList.diskSpaceOccup.flag = that.remainList.diskSpaceOccup.flag;
          that.remainList.diskSpaceOccup.history = (+that.remainList.diskSpaceOccup.history).toFixed(2);
        }

        if ( res.networkIncomingRate !== null ) {
          if ( +res.networkIncomingRate.total === -1 ) {
            that.remainList.networkIncomingRate.total = '--';
          } else {
            that.remainList.networkIncomingRate.total = (+res.networkIncomingRate.total).toFixed(2);
          }
          if ( +res.networkIncomingRate.peak === -1 ) {
            that.remainList.networkIncomingRate.peak = '--';
          } else {
            that.remainList.networkIncomingRate.peak = (+res.networkIncomingRate.peak).toFixed(2);
          }
          if ( +res.networkIncomingRate.peakPer === -1 ) {
            that.remainList.networkIncomingRate.peakPer = '--';
          } else {
            that.remainList.networkIncomingRate.peakPer = (+res.networkIncomingRate.peakPer).toFixed(2);
          }
          if ( +res.networkIncomingRate.average === -1 ) {
            that.remainList.networkIncomingRate.average = '--';
          } else {
            that.remainList.networkIncomingRate.average = (+res.networkIncomingRate.average).toFixed(2);
          }
          if ( +res.networkIncomingRate.remain === -1 ) {
            that.remainList.networkIncomingRate.remain = '--';
          } else {
            that.remainList.networkIncomingRate.remain = (+res.networkIncomingRate.remain).toFixed(2);
          }
          if ( +res.networkIncomingRate.remainPer === -1 ) {
            that.remainList.networkIncomingRate.remainPer = '--';
          } else {
            that.remainList.networkIncomingRate.remainPer = (+res.networkIncomingRate.remainPer).toFixed(2);
          }
          if ( +res.networkIncomingRate.suggestSize === -1 ) {
            that.remainList.networkIncomingRate.suggestSize = '--';
          } else {
            that.remainList.networkIncomingRate.suggestSize = (+res.networkIncomingRate.suggestSize).toFixed(2);
          }
          that.remainList.networkIncomingRate.flag = res.networkIncomingRate.flag;
          that.remainList.networkIncomingRate.history = (+res.networkIncomingRate.history).toFixed(2);
        } else {
          that.remainList.networkIncomingRate.total = (+that.remainList.networkIncomingRate.total).toFixed(2);
          that.remainList.networkIncomingRate.peak = (+that.remainList.networkIncomingRate.peak).toFixed(2);
          that.remainList.networkIncomingRate.peakPer = (+that.remainList.networkIncomingRate.peakPer).toFixed(2);
          that.remainList.networkIncomingRate.average = (+that.remainList.networkIncomingRate.average).toFixed(2);
          that.remainList.networkIncomingRate.remain = (+that.remainList.networkIncomingRate.remain).toFixed(2);
          that.remainList.networkIncomingRate.remainPer = (+that.remainList.networkIncomingRate.remainPer).toFixed(2);
          that.remainList.networkIncomingRate.suggestSize = (+that.remainList.networkIncomingRate.suggestSize).toFixed(2);
          that.remainList.networkIncomingRate.flag = that.remainList.networkIncomingRate.flag;
          that.remainList.networkIncomingRate.history = (+that.remainList.networkIncomingRate.history).toFixed(2);
        }

        if ( res.networkOutgoingRate !== null ) {
          if ( +res.networkOutgoingRate.total === -1 ) {
            that.remainList.networkOutgoingRate.total = '--';
          } else {
            that.remainList.networkOutgoingRate.total = (+res.networkOutgoingRate.total).toFixed(2);
          }
          if ( +res.networkOutgoingRate.peak === -1 ) {
            that.remainList.networkOutgoingRate.peak = '--';
          } else {
            that.remainList.networkOutgoingRate.peak = (+res.networkOutgoingRate.peak).toFixed(2);
          }
          if ( +res.networkOutgoingRate.peakPer === -1 ) {
            that.remainList.networkOutgoingRate.peakPer = '--';
          } else {
            that.remainList.networkOutgoingRate.peakPer = (+res.networkOutgoingRate.peakPer).toFixed(2);
          }
          if ( +res.networkOutgoingRate.average === -1 ) {
            that.remainList.networkOutgoingRate.average = '--';
          } else {
            that.remainList.networkOutgoingRate.average = (+res.networkOutgoingRate.average).toFixed(2);
          }
          if ( +res.networkOutgoingRate.remain === -1 ) {
            that.remainList.networkOutgoingRate.remain = '--';
          } else {
            that.remainList.networkOutgoingRate.remain = (+res.networkOutgoingRate.remain).toFixed(2);
          }
          if ( +res.networkOutgoingRate.remainPer === -1 ) {
            that.remainList.networkOutgoingRate.remainPer = '--';
          } else {
            that.remainList.networkOutgoingRate.remainPer = (+res.networkOutgoingRate.remainPer).toFixed(2);
          }
          if ( +res.networkOutgoingRate.suggestSize === -1 ) {
            that.remainList.networkOutgoingRate.suggestSize = '--';
          } else {
            that.remainList.networkOutgoingRate.suggestSize = (+res.networkOutgoingRate.suggestSize).toFixed(2);
          }
          that.remainList.networkOutgoingRate.flag = res.networkOutgoingRate.flag;
          that.remainList.networkOutgoingRate.history = (+res.networkOutgoingRate.history).toFixed(2);
        } else {
          that.remainList.networkOutgoingRate.total = (+that.remainList.networkOutgoingRate.total).toFixed(2);
          that.remainList.networkOutgoingRate.peak = (+that.remainList.networkOutgoingRate.peak).toFixed(2);
          that.remainList.networkOutgoingRate.peakPer = (+that.remainList.networkOutgoingRate.peakPer).toFixed(2);
          that.remainList.networkOutgoingRate.average = (+that.remainList.networkOutgoingRate.average).toFixed(2);
          that.remainList.networkOutgoingRate.remain = (+that.remainList.networkOutgoingRate.remain).toFixed(2);
          that.remainList.networkOutgoingRate.remainPer = (+that.remainList.networkOutgoingRate.remainPer).toFixed(2);
          that.remainList.networkOutgoingRate.suggestSize = (+that.remainList.networkOutgoingRate.suggestSize).toFixed(2);
          that.remainList.networkOutgoingRate.flag = that.remainList.networkOutgoingRate.flag;
          that.remainList.networkOutgoingRate.history = (+that.remainList.networkOutgoingRate.history).toFixed(2);
        }

        if ( res.networkBidirectRate !== null ) {
          if ( +res.networkBidirectRate.total === -1 ) {
            that.remainList.networkBidirectRate.total = '--';
          } else {
            that.remainList.networkBidirectRate.total = (+res.networkBidirectRate.total).toFixed(2);
          }
          if ( +res.networkBidirectRate.peak === -1 ) {
            that.remainList.networkBidirectRate.peak = '--';
          } else {
            that.remainList.networkBidirectRate.peak = (+res.networkBidirectRate.peak).toFixed(2);
          }
          if ( +res.networkBidirectRate.peakPer === -1 ) {
            that.remainList.networkBidirectRate.peakPer = '--';
          } else {
            that.remainList.networkBidirectRate.peakPer = (+res.networkBidirectRate.peakPer).toFixed(2);
          }
          if ( +res.networkBidirectRate.average === -1 ) {
            that.remainList.networkBidirectRate.average = '--';
          } else {
            that.remainList.networkBidirectRate.average = (+res.networkBidirectRate.average).toFixed(2);
          }
          if ( +res.networkBidirectRate.remain === -1 ) {
            that.remainList.networkBidirectRate.remain = '--';
          } else {
            that.remainList.networkBidirectRate.remain = (+res.networkBidirectRate.remain).toFixed(2);
          }
          if ( +res.networkBidirectRate.remainPer === -1 ) {
            that.remainList.networkBidirectRate.remainPer = '--';
          } else {
            that.remainList.networkBidirectRate.remainPer = (+res.networkBidirectRate.remainPer).toFixed(2);
          }
          if ( +res.networkBidirectRate.suggestSize === -1 ) {
            that.remainList.networkBidirectRate.suggestSize = '--';
          } else {
            that.remainList.networkBidirectRate.suggestSize = (+res.networkBidirectRate.suggestSize).toFixed(2);
          }
          that.remainList.networkBidirectRate.flag = res.networkBidirectRate.flag;
          that.remainList.networkBidirectRate.history = (+res.networkBidirectRate.history).toFixed(2);
        } else {
          that.remainList.networkBidirectRate.total = (+that.remainList.networkBidirectRate.total).toFixed(2);
          that.remainList.networkBidirectRate.peak = (+that.remainList.networkBidirectRate.peak).toFixed(2);
          that.remainList.networkBidirectRate.peakPer = (+that.remainList.networkBidirectRate.peakPer).toFixed(2);
          that.remainList.networkBidirectRate.average = (+that.remainList.networkBidirectRate.average).toFixed(2);
          that.remainList.networkBidirectRate.remain = (+that.remainList.networkBidirectRate.remain).toFixed(2);
          that.remainList.networkBidirectRate.remainPer = (+that.remainList.networkBidirectRate.remainPer).toFixed(2);
          that.remainList.networkBidirectRate.suggestSize = (+that.remainList.networkBidirectRate.suggestSize).toFixed(2);
          that.remainList.networkBidirectRate.flag = that.remainList.networkBidirectRate.flag;
          that.remainList.networkBidirectRate.history = (+that.remainList.networkBidirectRate.history).toFixed(2);
        }
        that.remainList.LastCalcTime = this.changeToDate(res.LastCalcTime);
        that.remainList['curStrategy'] = res.curStrategy;
        this.remainCapSlideBlock[0] = +that.remainList['curStrategy'].low;
        this.remainCapSlideBlock[1] = +that.remainList['curStrategy'].high;
        if (this.remainCapSlideBlock[0] < 0 || this.remainCapSlideBlock[0] > 100) {this.remainCapSlideBlock[0] = 0; }
        if (this.remainCapSlideBlock[1] > 100 || this.remainCapSlideBlock[1] < 0) {this.remainCapSlideBlock[1] = 100; }

        if (that.remainList['curStrategy'].algo === 'peakOnly') {
          this.remainPolicyWord = this.translate.instant('insight.Objects.PeakValue');
        } else if (that.remainList['curStrategy'].algo === 'peakStress') {
          this.remainPolicyWord = this.translate.instant('insight.Objects.PeakValue') +
            this.translate.instant('insight.Objects.UseStressPeak');
        } else if (that.remainList['curStrategy'].algo === 'average') {
          this.remainPolicyWord = this.translate.instant('insight.Objects.AverValue');
        }

        for (let i = 0; i < that.remainList['curStrategy'].checks.length; i++) {
          switch (that.remainList['curStrategy'].checks[i]) {
            case 'cpuOccup': {this.remainCpuCheck = true; }; break;
            case 'memOccup': {this.remainMemCheck = true; }; break;
            case 'diskSpaceOccup': {this.remainDiskCheck = true; }; break;
            case 'networkIncomingRate': {this.remainNetInCheck = true; }; break;
            case 'networkOutgoingRate': {this.remainNetOutCheck = true; }; break;
            case 'networkBidirectRate': {this.remainNetIOCheck = true; }; break;
          }
        }

        this.initTableRemainCap();

        if (that.remainList.level === 'high' ) {
          this.remainMinImg.emit('high');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/1_capacity_max.svg';
          this.remainCapWords = this.translate.instant('insight.Objects.CriticalRemain');

          let cpuPer, memPer, diskPer, inPer, outPer, ioPer;

          if (this.remainCpuCheck === true && that.remainList.cpuOccup.remainPer !== '--') {
            cpuPer = +that.remainList.cpuOccup.remainPer;
          } else {
            cpuPer = 111;
          }
          if (this.remainMemCheck === true && that.remainList.memOccup.remainPer !== '--') {
            memPer = +that.remainList.memOccup.remainPer;
          } else {
            memPer = 111;
          }
          if (this.remainDiskCheck === true && that.remainList.diskSpaceOccup.remainPer !== '--') {
            diskPer = +that.remainList.diskSpaceOccup.remainPer;
          } else {
            diskPer = 111;
          }
          if (this.remainNetInCheck === true && that.remainList.networkIncomingRate.remainPer !== '--') {
            inPer = +that.remainList.networkIncomingRate.remainPer;
          } else {
            inPer = 111;
          }
          if (this.remainNetOutCheck === true && that.remainList.networkOutgoingRate.remainPer !== '--') {
            outPer = +that.remainList.networkOutgoingRate.remainPer;
          } else {
            outPer = 111;
          }
          if (this.remainNetIOCheck === true && that.remainList.networkBidirectRate.remainPer !== '--') {
            ioPer = +that.remainList.networkBidirectRate.remainPer;
          } else {
            ioPer = 111;
          }
          let tempNum = +cpuPer;
          if (tempNum < memPer) {
            this.remainWordAdd = 'CPU';
          } else if (tempNum === memPer) {
            this.remainWordAdd = 'CPU' + ', ' + that.translate.instant('insight.Objects.Memory');
          } else if (tempNum > memPer) {
            tempNum = memPer;
            this.remainWordAdd = that.translate.instant('insight.Objects.Memory');
          }

          if (tempNum > diskPer) {
            this.remainWordAdd = that.translate.instant('insight.Objects.DiskSpace');
            tempNum = diskPer;
          } else if (tempNum === diskPer) {
            this.remainWordAdd = this.remainWordAdd + ', ' + that.translate.instant('insight.Objects.DiskSpace');
          }

          if (tempNum > inPer) {
            this.remainWordAdd = that.translate.instant('insight.Objects.InRate');
            tempNum = inPer;
          } else if (tempNum === inPer) {
            this.remainWordAdd = this.remainWordAdd + ', ' + that.translate.instant('insight.Objects.InRate');
          }

          if (tempNum > outPer) {
            this.remainWordAdd = that.translate.instant('insight.Objects.OutRate');
            tempNum = outPer;
          } else if (tempNum === outPer) {
            this.remainWordAdd = this.remainWordAdd + ', ' + that.translate.instant('insight.Objects.OutRate');
          }

          if (tempNum > ioPer) {
            this.remainWordAdd = that.translate.instant('insight.Objects.IORate');
            tempNum = ioPer;
          } else if (tempNum === ioPer) {
            this.remainWordAdd = this.remainWordAdd + ', ' + that.translate.instant('insight.Objects.IORate');
          }

          if (tempNum > 100) {
            this.remainWordAdd = '';
          }

        } else if (that.remainList.level === 'middle') {
          this.remainMinImg.emit('middle');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/2_capacity_max.svg';
          this.remainCapWords = this.translate.instant('insight.Objects.Warning');
        } else if (that.remainList.level === 'low') {
          this.remainMinImg.emit('low');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/3_capacity_max.svg';
          this.remainCapWords = this.translate.instant('insight.Objects.Normal');
        } else if (that.remainList.level === '--') {
          this.remainMinImg.emit('--');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/4_capacity_max.svg';
          this.remainCapWords = '--';
        }

        that.remainList['history'] = res.history.concat();
        this.remainEcharts( that.remainList['history'] );

      });

  }

  remainEcharts( date: any ) {

    const option2 = {
      tooltip : {
        trigger: 'axis',
        axisPointer: {
          //type: 'cross',
          label: {
            backgroundColor: '#6a7985'
          }
        }
      },
      grid: {
        left: '0%',
        right: '3%',
        bottom: '3%',
        top: '20%',
        containLabel: true
      },
      xAxis : [
        {
          type : 'category',
          boundaryGap : false,
          data : [],
          show : false
        }
      ],
      yAxis : [
        {
          type : 'value',
          show : false,
          max: 100
        }
      ],
      series : [
        {
          name: this.translate.instant('insight.Objects.RemainCapa'),
          type: 'line',
          stack: '总量',
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          areaStyle: {
            normal: {opacity: 0.3}
          },
          itemStyle: {
            normal: {color: '#00aaff'}
          },
          symbol: 'none',
          data: date
        }
      ]
    };
    const dom2: any = document.getElementById('remainEchart');
    const myChart2: any = echarts.init(dom2, 'macarons');
    myChart2.setOption(option2);
  }

  showTooltip (e, item) {
    this.tipName = item.name;
    if (item.type === 'host') {
      this.tipType = this.translate.instant('insight.Objects.HostList');
    } else {
      this.tipType = item.type;
    }
    this.tipAlarms = item.alarms;
    this.tipHealth = item.health;
    this.tipRisk = item.risk;
    this.tipEfficiency = item.efficiency;
    this.tipWorkload = item.workload;
    this.tipRemainCapa = item.remainCapacity;
    this.tipReclaimCapa = item.reclaimCapacity;
    this.tipStress = item.stress;

  }

  hideTooltip() {
    //$('.tipBox').css('display', 'none');
  }

  mousePosition(ev) {
    ev = ev || window.event;
    if (ev.pageX || ev.pageY) {
      return {x: ev.pageX, y: ev.pageY};
    }
    return {
      x: ev.clientX + document.body.scrollLeft - document.body.clientLeft,
      y: ev.clientY + document.body.scrollTop - document.body.clientTop
    };
  }

  changeToDate(data) {
    const myTime = data * 1000;
    const myDate = new Date(myTime);

    const str = myDate.getFullYear() + '-' + this.transformDigitString(( myDate.getMonth() + 1)) + '-' +
      this.transformDigitString(myDate.getDate()) + ' ' +  this.transformDigitString(myDate.getHours()) + ':' +
      this.transformDigitString(myDate.getMinutes());

    return str;
  }

  transformDigitString(str: any) {

    if (str < 10) {
      return '0' + str;
    } else {
      return str;
    }
  }

}

