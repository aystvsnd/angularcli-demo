/**
 * Created by 6092002303 on 2017/3/16.
 */
import { Component , OnInit , Input, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {TranslateService} from '@ngx-translate/core';
import {StorageService } from '../../../../storage.service';
import { KyButtonComponent, KyLoadingComponent, KyProcessBarComponent} from '../../../../shared/kylib/index';
import { MonitorObjectService } from './../../monitor-object.service';

@Component({
  moduleId: module.id,
  selector: 'monitor-obj-cpi-stress',
  directives: [KyButtonComponent, KyLoadingComponent, KyProcessBarComponent],
  styleUrls: [ '../../../css/common.css', '../monitor-obj-detail.component.less',
    '../../../css/tooltip.less'],
  templateUrl: 'monitor-obj-cpi-stress.component.html'
})

export class MonitorObjCpiStressComponent implements OnInit {
  @Input() aboutMeInfo;
  @Input() relatedObjectInfo;
  @Input() siblingNum;
  @Input() childrenNum;
  @Output() stressMinImg = new EventEmitter();

  window: window = window;
  name: any;
  objectId: string;
  objectType: string;
  headNames: Array<any>;
  activeString: any;
  imgUrlsMax: string;
  stressSlideBlock: any;

  stressWords: string;
  stressWordAdd = '';

  stressList: any;
  stressCpuCheck: any = false;
  stressMemCheck: any = false;
  stressNetInCheck: any = false;
  stressNetOutCheck: any = false;
  stressNetIOCheck: any = false;

  siblingNum: number;
  childrenNum: number;

  tipName: string;
  tipType: string;
  tipAlarms: number;
  tipHealth: string;
  tipRisk: string;
  tipEfficiency: string;
  tipWorkload: string;
  tipRemainCapa: string;
  tipReclaimCapa: string;
  tipStress: string;

  columnDefs : any[] = [
    {
      field: 'check',
      align: 'left',
      title: this.translate.instant('insight.Objects.Indicators'),
      formatter: function (value, row, index) {
        return `<div>
                  <span style="font-size: 13px">${value}</span>
                  <div>`;
      }
    },
    {
      field: 'total',
      align: 'right',
      title: this.translate.instant('insight.Objects.TotalCapa'),
      formatter: function (value, row, index) {
        return `<div>
                  <span style="font-size: 13px">${value}</span>
                  <div>`;
      }
    },

    {
      field: 'stressLine',
      align: 'right',
      title: this.translate.instant('insight.Objects.StressLine'),
      formatter: function (value, row, index) {
        return `<div>
                  <span  style="font-size: 13px">> ${value}%</span>
                  <div>`;
      }
    },

    {
      field: 'stressValue',
      align: 'right',
      title: this.translate.instant('insight.Objects.StressValue'),
      formatter: function (value, row, index) {
        return `<div>
                  <span  style="font-size: 13px"> ${value}%</span>
                  <div>`;
      }
    }

  ];

  gridOptions: any = {
    method: 'get',
    columns: this.columnDefs,
    sidePagination: 'server',
    escape:true
  };


  initTableStress() {
    const that = this;
    $('#stressdetails').bootstrapTable($.extend(this.gridOptions, {
      url: '/api/v1/smartOm/monitorObject/cpi/stress?objectId=' + this.objectId + '&type=' + this.objectType,
      dataField: 'checks',
      responseHandler: function (res) {
        const stressChecks = [];
        for (const attr in res) {
          switch (attr) {
            case 'cpuOccup': {
              if ( res.cpuOccup !== null ) {
                const cpucheck = 'CPU';
                const cpuOccup = {
                  check: cpucheck,
                  total: that.stressList.cpuOccup.total + ' VCPU',
                  stressLine: that.stressList.cpuOccup.stressLine,
                  stressValue: that.stressList.cpuOccup.stressValue
                };
                stressChecks.push(cpuOccup);
              }
            }; break;
            case 'memOccup': {
              if (  res.memOccup !== null ) {
                const memcheck = that.translate.instant('insight.Objects.Memory');
                const memOccup = {
                  check: memcheck,
                  total: that.stressList.memOccup.total + ' MB',
                  stressLine: that.stressList.memOccup.stressLine,
                  stressValue: that.stressList.memOccup.stressValue
                };
                stressChecks.push(memOccup);
              }
            }; break;
            case 'networkIncomingRate': {
              if (  res.networkIncomingRate !== null ) {
                const netIncheck = that.translate.instant('insight.Objects.InRate');
                const networkIncomingRate = {
                  check: netIncheck,
                  total: that.stressList.networkIncomingRate.total + ' Kbps',
                  stressLine: that.stressList.networkIncomingRate.stressLine,
                  stressValue: that.stressList.networkIncomingRate.stressValue
                };
                stressChecks.push(networkIncomingRate);
              }
            }; break;
            case 'networkOutgoingRate': {
              if (  res.networkOutgoingRate !== null ) {
                const netOutcheck = that.translate.instant('insight.Objects.OutRate');
                const networkOutgoingRate = {
                  check: netOutcheck,
                  total: that.stressList.networkOutgoingRate.total + ' Kbps',
                  stressLine: that.stressList.networkOutgoingRate.stressLine,
                  stressValue: that.stressList.networkOutgoingRate.stressValue
                };
                stressChecks.push(networkOutgoingRate);
              }
            }; break;
            case 'networkBidirectRate': {
              if (  res.networkBidirectRate !== null ) {
                const netIOcheck = that.translate.instant('insight.Objects.IORate');
                const networkBidirectRate = {
                  check: netIOcheck,
                  total: that.stressList.networkBidirectRate.total + ' Kbps',
                  stressLine: that.stressList.networkBidirectRate.stressLine,
                  stressValue: that.stressList.networkBidirectRate.stressValue
                };
                stressChecks.push(networkBidirectRate);
              }
            }; break;
          }
        }

        const checks = {
          'curStrategy': res.curStrategy,
          'checks' : stressChecks
        };
        return checks;
      }
    }));
  }

  constructor(private monitorObjectService: MonitorObjectService, private activatedRoute: ActivatedRoute,
              private router: Router, private translate: TranslateService,
              private storageService: StorageService) {

    this.activatedRoute.params.subscribe(params => {
      this.objectId = params['objectId'];
      this.name = params['name'];
      this.objectType = params['type'];
      console.log(this.objectId);
    });

    if (this.storageService.getCurrentLang() === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }
    this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/4_pressure_max.svg';
    this.stressSlideBlock = [10, 80];

    this.stressList = {
      'level': '--',
      'type': 'vm',
      'cpuOccup': {
        'total': 0,
        'stressLine': 0,
        'stressValue': 0
      },
      'memOccup': {
        'total': 0,
        'stressLine': 0,
        'stressValue': 0
      },
      'networkIncomingRate': {
        'total': 0,
        'stressLine': 0,
        'stressValue': 0
      },
      'networkOutgoingRate': {
        'total': 0,
        'stressLine': 0,
        'stressValue': 0
      },
      'networkBidirectRate': {
        'total': 0,
        'stressLine': 0,
        'stressValue': 0
      },
      'history': [],
      'LastCalcTime': '',
      'curStrategy': {
        'low': 0,
        'high': 100,
        'checks': [
          'cpuOccup',
          'memOccup',
          'networkIncomingRate',
          'networkOutgoingRate',
          'networkBidirectRate'
        ],
        'wndSize': 0
      }
    };

  }

  ngOnInit() {

    this.monitorObjectService.getStressInfo(this.objectId, this.objectType)
      .then((res: Response) => {
        const that = this;
        that.stressList.level = res.level;
        that.stressList.type = res.type;

        if ( res.cpuOccup !== null ) {
          if ( +res.cpuOccup.total === -1 ) {
            that.stressList.cpuOccup.total = '--';
          } else {
            that.stressList.cpuOccup.total = (+res.cpuOccup.total).toFixed(0);
          }
          if ( +res.cpuOccup.stressLine === -1 ) {
            that.stressList.cpuOccup.stressLine = '--';
          } else {
            that.stressList.cpuOccup.stressLine = (+res.cpuOccup.stressLine).toFixed(2);
          }
          if ( +res.cpuOccup.stressValue === -1 ) {
            that.stressList.cpuOccup.stressValue = '--';
          } else {
            that.stressList.cpuOccup.stressValue = (+res.cpuOccup.stressValue).toFixed(2);
          }
        } else {
          that.stressList.cpuOccup.total = (+that.stressList.cpuOccup.total).toFixed(2);
          that.stressList.cpuOccup.stressLine = (+that.stressList.cpuOccup.stressLine).toFixed(2);
          that.stressList.cpuOccup.stressValue = (+that.stressList.cpuOccup.stressValue).toFixed(2);
        }

        if ( res.memOccup !== null ) {
          if ( +res.memOccup.total === -1 ) {
            that.stressList.memOccup.total = '--';
          } else {
            that.stressList.memOccup.total = (+res.memOccup.total).toFixed(2);
          }
          if ( +res.memOccup.stressLine === -1 ) {
            that.stressList.memOccup.stressLine = '--';
          } else {
            that.stressList.memOccup.stressLine = (+res.memOccup.stressLine).toFixed(2);
          }
          if ( +res.memOccup.stressValue === -1 ) {
            that.stressList.memOccup.stressValue = '--';
          } else {
            that.stressList.memOccup.stressValue = (+res.memOccup.stressValue).toFixed(2);
          }
        } else {
          that.stressList.memOccup.total = (+that.stressList.memOccup.total).toFixed(2);
          that.stressList.memOccup.stressLine = (+that.stressList.memOccup.stressLine).toFixed(2);
          that.stressList.memOccup.stressValue = (+that.stressList.memOccup.stressValue).toFixed(2);
        }

        if ( res.networkIncomingRate !== null ) {
          if ( +res.networkIncomingRate.total === -1 ) {
            that.stressList.networkIncomingRate.total = '--';
          } else {
            that.stressList.networkIncomingRate.total = (+res.networkIncomingRate.total).toFixed(2);
          }
          if ( +res.networkIncomingRate.stressLine === -1 ) {
            that.stressList.networkIncomingRate.stressLine = '--';
          } else {
            that.stressList.networkIncomingRate.stressLine = (+res.networkIncomingRate.stressLine).toFixed(2);
          }
          if ( +res.networkIncomingRate.stressValue === -1 ) {
            that.stressList.networkIncomingRate.stressValue = '--';
          } else {
            that.stressList.networkIncomingRate.stressValue = (+res.networkIncomingRate.stressValue).toFixed(2);
          }
        } else {
          that.stressList.networkIncomingRate.total = (+that.stressList.networkIncomingRate.total).toFixed(2);
          that.stressList.networkIncomingRate.stressLine = (+that.stressList.networkIncomingRate.stressLine).toFixed(2);
          that.stressList.networkIncomingRate.stressValue = (+that.stressList.networkIncomingRate.stressValue).toFixed(2);
        }

        if ( res.networkOutgoingRate !== null ) {
          if ( +res.networkOutgoingRate.total === -1 ) {
            that.stressList.networkOutgoingRate.total = '--';
          } else {
            that.stressList.networkOutgoingRate.total = (+res.networkOutgoingRate.total).toFixed(2);
          }
          if ( +res.networkOutgoingRate.stressLine === -1 ) {
            that.stressList.networkOutgoingRate.stressLine = '--';
          } else {
            that.stressList.networkOutgoingRate.stressLine = (+res.networkOutgoingRate.stressLine).toFixed(2);
          }
          if ( +res.networkOutgoingRate.stressValue === -1 ) {
            that.stressList.networkOutgoingRate.stressValue = '--';
          } else {
            that.stressList.networkOutgoingRate.stressValue = (+res.networkOutgoingRate.stressValue).toFixed(2);
          }
        } else {
          that.stressList.networkOutgoingRate.total = (+that.stressList.networkOutgoingRate.total).toFixed(2);
          that.stressList.networkOutgoingRate.stressLine = (+that.stressList.networkOutgoingRate.stressLine).toFixed(2);
          that.stressList.networkOutgoingRate.stressValue = (+that.stressList.networkOutgoingRate.stressValue).toFixed(2);
        }

        if ( res.networkBidirectRate !== null ) {
          if ( +res.networkBidirectRate.total === -1 ) {
            that.stressList.networkBidirectRate.total = '--';
          } else {
            that.stressList.networkBidirectRate.total = (+res.networkBidirectRate.total).toFixed(2);
          }
          if ( +res.networkBidirectRate.stressLine === -1 ) {
            that.stressList.networkBidirectRate.stressLine = '--';
          } else {
            that.stressList.networkBidirectRate.stressLine = (+res.networkBidirectRate.stressLine).toFixed(2);
          }
          if ( +res.networkBidirectRate.stressValue === -1 ) {
            that.stressList.networkBidirectRate.stressValue = '--';
          } else {
            that.stressList.networkBidirectRate.stressValue = (+res.networkBidirectRate.stressValue).toFixed(2);
          }
        } else {
          that.stressList.networkBidirectRate.total = (+that.stressList.networkBidirectRate.total).toFixed(2);
          that.stressList.networkBidirectRate.stressLine = (+that.stressList.networkBidirectRate.stressLine).toFixed(2);
          that.stressList.networkBidirectRate.stressValue = (+that.stressList.networkBidirectRate.stressValue).toFixed(2);
        }
        that.stressList.LastCalcTime = this.changeToDate(res.LastCalcTime);
        that.stressList['curStrategy'] = res.curStrategy;
        this.stressSlideBlock[0] = +that.stressList['curStrategy'].low;
        this.stressSlideBlock[1] = +that.stressList['curStrategy'].high;
        if (this.stressSlideBlock[0] < 0 || this.stressSlideBlock[0] > 100) {this.stressSlideBlock[0] = 0; }
        if (this.stressSlideBlock[1] > 100 || this.stressSlideBlock[1] < 0) {this.stressSlideBlock[1] = 100; }

        for (let i = 0; i < that.stressList['curStrategy'].checks.length; i++) {
          switch (that.stressList['curStrategy'].checks[i]) {
            case 'cpuOccup': {this.stressCpuCheck = true; }; break;
            case 'memOccup': {this.stressMemCheck = true; }; break;
            case 'networkIncomingRate': {this.stressNetInCheck = true; }; break;
            case 'networkOutgoingRate': {this.stressNetOutCheck = true; }; break;
            case 'networkBidirectRate': {this.stressNetIOCheck = true; }; break;
          }
        }

        this.initTableStress();

        if (that.stressList.level === 'high' ) {
          this.stressMinImg.emit('high');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/1_pressure_max.svg';
          this.stressWords = this.translate.instant('insight.Objects.CriticalStress');

          let cpuValue, memValue, inValue, outValue, ioValue;

          if (this.stressCpuCheck === true && that.stressList.cpuOccup.stressValue !== '--') {
            cpuValue = +that.stressList.cpuOccup.stressValue;
          } else {
            cpuValue = -1;
          }
          if (this.stressMemCheck === true && that.stressList.memOccup.stressValue !== '--') {
            memValue = +that.stressList.memOccup.stressValue;
          } else {
            memValue = -1;
          }
          if (this.stressNetInCheck === true && that.stressList.networkIncomingRate.stressValue !== '--') {
            inValue = +that.stressList.networkIncomingRate.stressValue;

          } else {
            inValue = -1;
          }
          if (this.stressNetOutCheck === true && that.stressList.networkOutgoingRate.stressValue !== '--') {
            outValue = +that.stressList.networkOutgoingRate.stressValue;
          } else {
            outValue = -1;
          }
          if (this.stressNetIOCheck === true && that.stressList.networkBidirectRate.stressValue !== '--') {
            ioValue = +that.stressList.networkBidirectRate.stressValue;
          } else {
            ioValue = -1;
          }
          let tempNum = +cpuValue;
          if ( tempNum > memValue) {
            this.stressWordAdd = 'CPU';
          } else if ( tempNum === memValue) {
            this.stressWordAdd = 'CPU' + ', ' + that.translate.instant('insight.Objects.Memory');
          } else if ( tempNum < memValue) {
            tempNum = memValue;
            this.stressWordAdd = that.translate.instant('insight.Objects.Memory');
          }

          if (tempNum < inValue) {
            this.stressWordAdd = that.translate.instant('insight.Objects.InRate');
            tempNum = inValue;
          } else if (tempNum === inValue) {
            this.stressWordAdd = this.stressWordAdd + ', ' + that.translate.instant('insight.Objects.InRate');
          }

          if (tempNum < outValue) {
            this.stressWordAdd = that.translate.instant('insight.Objects.OutRate');
            tempNum = outValue;
          } else if (tempNum === outValue) {
            this.stressWordAdd = this.stressWordAdd + ', ' + that.translate.instant('insight.Objects.OutRate');
          }

          if (tempNum < ioValue) {
            this.stressWordAdd = that.translate.instant('insight.Objects.IORate');
            tempNum = ioValue;
          } else if (tempNum === ioValue) {
            this.stressWordAdd = this.stressWordAdd + ', ' + that.translate.instant('insight.Objects.IORate');
          }

          if (tempNum === -1 ) {
            this.stressWordAdd = '';
          }

        } else if (that.stressList.level === 'middle') {
          this.stressMinImg.emit('middle');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/2_pressure_max.svg';
          this.stressWords = this.translate.instant('insight.Objects.Warning');
        } else if (that.stressList.level === 'low') {
          this.stressMinImg.emit('low');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/3_pressure_max.svg';
          this.stressWords = this.translate.instant('insight.Objects.Normal');
        } else if (that.stressList.level === '--') {
          this.stressMinImg.emit('--');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/4_pressure_max.svg';
          this.stressWords = '--';
        }

        that.stressList['history'] = res.history.concat();
        this.stressEcharts( that.stressList['history'] );

      });

  }
  stressEcharts( date: any ) {

    const option4 = {
      tooltip : {
        trigger: 'axis',
        axisPointer: {
          //type: 'cross',
          label: {
            backgroundColor: '#6a7985'
          }
        }
      },
      grid: {
        left: '0%',
        right: '3%',
        bottom: '3%',
        top: '20%',
        containLabel: true
      },
      xAxis : [
        {
          type : 'category',
          boundaryGap : false,
          data : [],
          show : false
        }
      ],
      yAxis : [
        {
          type : 'value',
          show : false,
          max: 100
        }
      ],
      series : [
        {
          name: this.translate.instant('insight.Objects.Stress'),
          type: 'line',
          stack: '总量',
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          areaStyle: {
            normal: {opacity: 0.3}
          },
          itemStyle: {
            normal: {color: '#00aaff'}
          },
          symbol: 'none',
          data: date
        }
      ]
    };
    const dom4: any = document.getElementById('stressEchart');
    const myChart4: any = echarts.init(dom4, 'macarons');
    myChart4.setOption(option4);
  }

  showTooltip (e, item) {

    this.tipName = item.name;
    if (item.type === 'host') {
      this.tipType = this.translate.instant('insight.Objects.HostList');
    } else {
      this.tipType = item.type;
    }
    this.tipAlarms = item.alarms;
    this.tipHealth = item.health;
    this.tipRisk = item.risk;
    this.tipEfficiency = item.efficiency;
    this.tipWorkload = item.workload;
    this.tipRemainCapa = item.remainCapacity;
    this.tipReclaimCapa = item.reclaimCapacity;
    this.tipStress = item.stress;

  }

  hideTooltip() {
    //$('.tipBox').css('display', 'none');
  }

  mousePosition(ev) {
    ev = ev || window.event;
    if (ev.pageX || ev.pageY) {
      return {x: ev.pageX, y: ev.pageY};
    }
    return {
      x: ev.clientX + document.body.scrollLeft - document.body.clientLeft,
      y: ev.clientY + document.body.scrollTop - document.body.clientTop
    };
  }

  changeToDate(data) {
    const myTime = data * 1000;
    const myDate = new Date(myTime);

    const str = myDate.getFullYear() + '-' + this.transformDigitString(( myDate.getMonth() + 1)) + '-' +
      this.transformDigitString(myDate.getDate()) + ' ' +  this.transformDigitString(myDate.getHours()) + ':' +
      this.transformDigitString(myDate.getMinutes());

    return str;
  }

  transformDigitString(str: any) {

    if (str < 10) {
      return '0' + str;
    } else {
      return str;
    }
  }

}

