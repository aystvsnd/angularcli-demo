/**
 * Created by 6092002303 on 2017/3/16.
 */
import { Component , OnInit , Input, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {TranslateService} from '@ngx-translate/core';
import {StorageService } from '../../../../storage.service';
import { KyButtonComponent, KyLoadingComponent, KyProcessBarComponent} from '../../../../shared/kylib/index';
import { MonitorObjectService } from './../../monitor-object.service';

@Component({
  moduleId: module.id,
  selector: 'monitor-obj-cpi-workload',
  directives: [KyButtonComponent, KyLoadingComponent, KyProcessBarComponent],
  styleUrls: [ '../../../css/common.css', '../monitor-obj-detail.component.less',
    '../../../css/tooltip.less'],
  templateUrl: 'monitor-obj-cpi-workload.component.html'
})

export class MonitorObjCpiWorkloadComponent implements OnInit {
  @Input() aboutMeInfo;
  @Input() relatedObjectInfo;
  @Input() siblingNum;
  @Input() childrenNum;
  @Output() wlMinImg = new EventEmitter();

  window: window = window;
  name: any;
  objectId: string;
  objectType: string;
  headNames: Array<any>;
  activeString: any;
  imgUrlsMax: string;
  workLoadSlideBlock: any;

  workLoadWords: string;
  wlWordAdd = '';

  workloadList: any;

  wlCpuCheck: any = false;
  wlMemCheck: any = false;
  wlDiskCheck: any = false;
  wlNetInCheck: any = false;
  wlNetOutCheck: any = false;
  wlNetIOCheck: any = false;

  siblingNum: number;
  childrenNum: number;
  workloadIOName = '--';

  tipName: string;
  tipType: string;
  tipAlarms: number;
  tipHealth: string;
  tipRisk: string;
  tipEfficiency: string;
  tipWorkload: string;
  tipRemainCapa: string;
  tipReclaimCapa: string;
  tipStress: string;

  constructor(private monitorObjectService: MonitorObjectService, private activatedRoute: ActivatedRoute,
              private router: Router, private translate: TranslateService,
              private storageService: StorageService) {

    this.activatedRoute.params.subscribe(params => {
      this.objectId = params['objectId'];
      this.name = params['name'];
      this.objectType = params['type'];
      console.log(this.objectId);
    });

    if (this.storageService.getCurrentLang() === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }

    this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/4_workload_max.svg';
    this.workLoadSlideBlock = [20, 40];

    this.workloadList = {
      'level': '--',
      'type': 'vm',
      'cpuOccup': {
        'cores': 0,
        'utili': 0,
        'level': '--'
      },
      'memOccup': {
        'used': 0,
        'total': 0,
        'utili': 0,
        'level': '--'
      },
      'diskSpaceOccup': {
        'used': 0,
        'total': 0,
        'utili': 0,
        'level': '--'
      },
      'networkIncomingRate': {
        'name': '--',
        'rate': 0,
        'bandWidth': 0,
        'utili': 0,
        'level': '--'
      },
      'networkOutgoingRate': {
        'name': '--',
        'rate': 0,
        'bandWidth': 0,
        'utili': 0,
        'level': '--'
      },
      'networkBidirectRate': {
        'name': '--',
        'rate': 0,
        'bandWidth': 0,
        'utili': 0,
        'level': '--'
      },
      'history': [],
      'LastCalcTime': '',
      'curStrategy': {
        'low': 1,
        'high': 99,
        'checks': [
          'cpuOccup',
          'memOccup',
          'diskSpaceOccup',
          'networkIncomingRate',
          'networkOutgoingRate',
          'networkBidirectRate'
        ],
        'wndSize': 0
      }
    };

  }

  ngOnInit() {
    this.monitorObjectService.getWorkLoadInfo(this.objectId, this.objectType)
      .then((res: Response) => {
        const that = this;

        that.workloadList.level = res.level;
        that.workloadList.type = res.type;

        if ( res.cpuOccup !== null ) {
          if ( +res.cpuOccup.cores !== -1 ) {
            that.workloadList.cpuOccup.cores = (+res.cpuOccup.cores).toFixed(0);
          } else {
            that.workloadList.cpuOccup.cores = res.cpuOccup.cores;
          }
          if ( +res.cpuOccup.utili === -1) {
            that.workloadList.cpuOccup.utili = '--';
          } else {
            that.workloadList.cpuOccup.utili = (+res.cpuOccup.utili).toFixed(2);
          }
          that.workloadList.cpuOccup.level = res.cpuOccup.level;
        } else {
          that.workloadList.cpuOccup.cores = (+that.workloadList.cpuOccup.cores).toFixed(0);
          that.workloadList.cpuOccup.utili = (+that.workloadList.cpuOccup.utili).toFixed(2);
          that.workloadList.cpuOccup.level = that.workloadList.cpuOccup.level;
        }

        if ( res.memOccup !== null ) {
          if ( +res.memOccup.used !== -1 ) {
            that.workloadList.memOccup.used = (+res.memOccup.used).toFixed(2);
          } else {
            that.workloadList.memOccup.used = (+res.memOccup.used);
          }
          if ( +res.memOccup.total !== -1 ) {
            that.workloadList.memOccup.total = (+res.memOccup.total).toFixed(2);
          } else {
            that.workloadList.memOccup.total = (+res.memOccup.total);
          }
          if ( +res.memOccup.utili === -1) {
            that.workloadList.memOccup.utili = '--';
          } else {
            that.workloadList.memOccup.utili = (+res.memOccup.utili).toFixed(2);
          }
          that.workloadList.memOccup.level = res.memOccup.level;
        } else {
          that.workloadList.memOccup.used = (+that.workloadList.memOccup.used).toFixed(2);
          that.workloadList.memOccup.total = (+that.workloadList.memOccup.total).toFixed(2);
          that.workloadList.memOccup.utili = (+that.workloadList.memOccup.utili).toFixed(2);
          that.workloadList.memOccup.level = that.workloadList.memOccup.level;
        }

        if ( res.diskSpaceOccup !== null ) {
          if ( +res.diskSpaceOccup.used !== -1 ) {
            that.workloadList.diskSpaceOccup.used = (+res.diskSpaceOccup.used).toFixed(2);
          } else {
            that.workloadList.diskSpaceOccup.used = (+res.diskSpaceOccup.used);
          }
          if ( +res.diskSpaceOccup.total !== -1 ) {
            that.workloadList.diskSpaceOccup.total = (+res.diskSpaceOccup.total).toFixed(2);
          } else {
            that.workloadList.diskSpaceOccup.total = (+res.diskSpaceOccup.total);
          }
          if ( +res.diskSpaceOccup.utili === -1) {
            that.workloadList.diskSpaceOccup.utili = '--';
          } else {
            that.workloadList.diskSpaceOccup.utili = (+res.diskSpaceOccup.utili).toFixed(2);
          }
          that.workloadList.diskSpaceOccup.level = res.diskSpaceOccup.level;
        } else {
          that.workloadList.diskSpaceOccup.used = (+that.workloadList.diskSpaceOccup.used).toFixed(2);
          that.workloadList.diskSpaceOccup.total = (+that.workloadList.diskSpaceOccup.total).toFixed(2);
          that.workloadList.diskSpaceOccup.utili = (+that.workloadList.diskSpaceOccup.utili).toFixed(2);
          that.workloadList.diskSpaceOccup.level = that.workloadList.diskSpaceOccup.level;
        }

        if ( res.networkIncomingRate !== null ) {
          that.workloadList.networkIncomingRate.name = res.networkIncomingRate.name;
          that.workloadIOName =  res.networkIncomingRate.name;
          if ( +res.networkIncomingRate.rate !== -1 ) {
            that.workloadList.networkIncomingRate.rate = (+res.networkIncomingRate.rate).toFixed(2);
          } else {
            that.workloadList.networkIncomingRate.rate = (+res.networkIncomingRate.rate);
          }
          if ( +res.networkIncomingRate.bandWidth !== -1 ) {
            that.workloadList.networkIncomingRate.bandWidth = (+res.networkIncomingRate.bandWidth).toFixed(2);
          } else {
            that.workloadList.networkIncomingRate.bandWidth = (+res.networkIncomingRate.bandWidth);
          }
          if ( +res.networkIncomingRate.utili === -1) {
            that.workloadList.networkIncomingRate.utili = '--';
          } else {
            that.workloadList.networkIncomingRate.utili = (+res.networkIncomingRate.utili).toFixed(2);
          }
          that.workloadList.networkIncomingRate.level = res.networkIncomingRate.level;
        } else {
          that.workloadList.networkIncomingRate.name = that.workloadList.networkIncomingRate.name;
          that.workloadList.networkIncomingRate.rate = (+that.workloadList.networkIncomingRate.rate).toFixed(2);
          that.workloadList.networkIncomingRate.bandWidth = (+that.workloadList.networkIncomingRate.bandWidth).toFixed(2);
          that.workloadList.networkIncomingRate.utili = (+that.workloadList.networkIncomingRate.utili).toFixed(2);
          that.workloadList.networkIncomingRate.level = that.workloadList.networkIncomingRate.level;
        }

        if ( res.networkOutgoingRate !== null ) {
          that.workloadList.networkOutgoingRate.name = res.networkOutgoingRate.name;
          that.workloadIOName =  res.networkOutgoingRate.name;
          if ( +res.networkOutgoingRate.rate !== -1 ) {
            that.workloadList.networkOutgoingRate.rate = (+res.networkOutgoingRate.rate).toFixed(2);
          } else {
            that.workloadList.networkOutgoingRate.rate = (+res.networkOutgoingRate.rate);
          }
          if ( +res.networkOutgoingRate.bandWidth !== -1 ) {
            that.workloadList.networkOutgoingRate.bandWidth = (+res.networkOutgoingRate.bandWidth).toFixed(2);
          } else {
            that.workloadList.networkOutgoingRate.bandWidth = (+res.networkOutgoingRate.bandWidth);
          }
          if ( +res.networkOutgoingRate.utili === -1) {
            that.workloadList.networkOutgoingRate.utili = '--';
          } else {
            that.workloadList.networkOutgoingRate.utili = (+res.networkOutgoingRate.utili).toFixed(2);
          }
          that.workloadList.networkOutgoingRate.level = res.networkOutgoingRate.level;
        } else {
          that.workloadList.networkOutgoingRate.name = that.workloadList.networkOutgoingRate.name;
          that.workloadList.networkOutgoingRate.rate = (+that.workloadList.networkOutgoingRate.rate).toFixed(2);
          that.workloadList.networkOutgoingRate.bandWidth = (+that.workloadList.networkOutgoingRate.bandWidth).toFixed(2);
          that.workloadList.networkOutgoingRate.utili = (+that.workloadList.networkOutgoingRate.utili).toFixed(2);
          that.workloadList.networkOutgoingRate.level = that.workloadList.networkOutgoingRate.level;
        }

        if ( res.networkBidirectRate !== null ) {
          that.workloadList.networkBidirectRate.name = res.networkBidirectRate.name;
          that.workloadIOName =  res.networkBidirectRate.name;
          if ( +res.networkBidirectRate.rate !== -1 ) {
            that.workloadList.networkBidirectRate.rate = (+res.networkBidirectRate.rate).toFixed(2);
          } else {
            that.workloadList.networkBidirectRate.rate = (+res.networkBidirectRate.rate);
          }
          if ( +res.networkBidirectRate.bandWidth !== -1 ) {
            that.workloadList.networkBidirectRate.bandWidth = (+res.networkBidirectRate.bandWidth).toFixed(2);
          } else {
            that.workloadList.networkBidirectRate.bandWidth = (+res.networkBidirectRate.bandWidth);
          }
          if ( +res.networkBidirectRate.utili === -1) {
            that.workloadList.networkBidirectRate.utili = '--';
          } else {
            that.workloadList.networkBidirectRate.utili = (+res.networkBidirectRate.utili).toFixed(2);
          }
          that.workloadList.networkBidirectRate.level = res.networkBidirectRate.level;
        } else {
          that.workloadList.networkBidirectRate.name = that.workloadList.networkBidirectRate.name;
          that.workloadList.networkBidirectRate.rate = (+that.workloadList.networkBidirectRate.rate).toFixed(2);
          that.workloadList.networkBidirectRate.bandWidth = (+that.workloadList.networkBidirectRate.bandWidth).toFixed(2);
          that.workloadList.networkBidirectRate.utili = (+that.workloadList.networkBidirectRate.utili).toFixed(2);
          that.workloadList.networkBidirectRate.level = that.workloadList.networkBidirectRate.level;
        }
        that.workloadList.LastCalcTime = this.changeToDate(res.LastCalcTime);
        that.workloadList['curStrategy'] = res.curStrategy;
        this.workLoadSlideBlock[0] = +that.workloadList['curStrategy'].low;
        this.workLoadSlideBlock[1] = +that.workloadList['curStrategy'].high;
        if (this.workLoadSlideBlock[0] < 0 || this.workLoadSlideBlock[0] > 100) {this.workLoadSlideBlock[0] = 0; }
        if (this.workLoadSlideBlock[1] > 100 || this.workLoadSlideBlock[1] < 0) {this.workLoadSlideBlock[1] = 100; }

        for (let i = 0; i < that.workloadList['curStrategy'].checks.length; i++) {
          switch (that.workloadList['curStrategy'].checks[i]) {
            case 'cpuOccup': {this.wlCpuCheck = true; }; break;
            case 'memOccup': {this.wlMemCheck = true; }; break;
            case 'diskSpaceOccup': {this.wlDiskCheck = true; }; break;
            case 'networkIncomingRate': {this.wlNetInCheck = true; }; break;
            case 'networkOutgoingRate': {this.wlNetOutCheck = true; }; break;
            case 'networkBidirectRate': {this.wlNetIOCheck = true; }; break;
          }
        }

        if (that.workloadList.level === 'high' ) {
          this.wlMinImg.emit('high');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/1_workload_max.svg';
          this.workLoadWords = this.translate.instant('insight.Objects.CriticalWorkload');

          let cpuUtili, memUtili, diskUtili, inUtili, outUtili, ioUtili;

          if (this.wlCpuCheck === true && that.workloadList.cpuOccup.utili !== '--') {
            cpuUtili = +that.workloadList.cpuOccup.utili;
          } else {
            cpuUtili = -1;
          }
          if (this.wlMemCheck === true && that.workloadList.memOccup.utili !== '--') {
            memUtili = +that.workloadList.memOccup.utili;
          } else {
            memUtili = -1;
          }
          if (this.wlDiskCheck === true && that.workloadList.diskSpaceOccup.utili !== '--') {
            diskUtili = +that.workloadList.diskSpaceOccup.utili;
          } else {
            diskUtili = -1;
          }
          if (this.wlNetInCheck === true && that.workloadList.networkIncomingRate.utili !== '--') {
            inUtili = +that.workloadList.networkIncomingRate.utili;
          } else {
            inUtili = -1;
          }
          if (this.wlNetOutCheck === true && that.workloadList.networkOutgoingRate.utili !== '--') {
            outUtili = +that.workloadList.networkOutgoingRate.utili;
          } else {
            outUtili = -1;
          }
          if (this.wlNetIOCheck === true && that.workloadList.networkBidirectRate.utili !== '--') {
            ioUtili = +that.workloadList.networkBidirectRate.utili;
          } else {
            ioUtili = -1;
          }
          let tempNum = +cpuUtili;
          if (tempNum > memUtili) {
            this.wlWordAdd = 'CPU';
          } else if (tempNum === memUtili) {
            this.wlWordAdd = 'CPU' + ', ' + that.translate.instant('insight.Objects.Memory');
          } else if (tempNum < memUtili) {
            tempNum = memUtili;
            this.wlWordAdd = that.translate.instant('insight.Objects.Memory');
          }

          if (tempNum < diskUtili) {
            this.wlWordAdd = that.translate.instant('insight.Objects.DiskSpace');
            tempNum = diskUtili;
          } else if (tempNum === diskUtili) {
            this.wlWordAdd = this.wlWordAdd + ', ' + that.translate.instant('insight.Objects.DiskSpace');
          }

          if (tempNum < inUtili) {
            this.wlWordAdd = that.translate.instant('insight.Objects.InRate');
            tempNum = inUtili;
          } else if (tempNum === inUtili) {
            this.wlWordAdd = this.wlWordAdd + ', ' + that.translate.instant('insight.Objects.InRate');
          }

          if (tempNum < outUtili) {
            this.wlWordAdd = that.translate.instant('insight.Objects.OutRate');
            tempNum = outUtili;
          } else if (tempNum === outUtili) {
            this.wlWordAdd = this.wlWordAdd + ', ' + that.translate.instant('insight.Objects.OutRate');
          }

          if (tempNum < ioUtili) {
            this.wlWordAdd = that.translate.instant('insight.Objects.IORate');
            tempNum = ioUtili;
          } else if (tempNum === ioUtili) {
            this.wlWordAdd = this.wlWordAdd + ', ' + that.translate.instant('insight.Objects.IORate');
          }

          if (tempNum === -1) {
            this.wlWordAdd = '';
          }

        } else if (that.workloadList.level === 'middle') {
          this.wlMinImg.emit('middle');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/2_workload_max.svg';
          this.workLoadWords = this.translate.instant('insight.Objects.Warning');
        } else if (that.workloadList.level === 'low') {
          this.wlMinImg.emit('low');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/3_workload_max.svg';
          this.workLoadWords = this.translate.instant('insight.Objects.Normal');
        } else if (that.workloadList.level === '--') {
          this.wlMinImg.emit('--');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/4_workload_max.svg';
          this.workLoadWords = '--';
        }
        that.workloadList['history'] = res.history.concat();
        this.workloadEcharts( that.workloadList['history'] );
      });

  }

  workloadEcharts( date: any ) {

    const option1 = {
      tooltip : {
        trigger: 'axis',
        axisPointer: {
          //type: 'cross',
          label: {
            backgroundColor: '#6a7985'
          }
        }
      },
      grid: {
        left: '0%',
        right: '3%',
        bottom: '3%',
        top: '20%',
        containLabel: true
      },
      xAxis : [
        {
          type : 'category',
          boundaryGap : false,
          data : [],
          show : false
        }
      ],
      yAxis : [
        {
          type : 'value',
          show : false,
          max: 100
        }
      ],
      series : [
        {
          name: this.translate.instant('insight.Objects.Workload'),
          type: 'line',
          stack: '总量',
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          areaStyle: {
            normal: {opacity: 0.3}
          },
          itemStyle: {
            normal: {color: '#00aaff'}
          },
          symbol: 'none',
          data: date
        }
      ]
    };
    const dom1: any = document.getElementById('wlEchart');
    const myChart1: any = echarts.init(dom1, 'macarons');
    myChart1.setOption(option1);
  }

  showTooltip (e, item) {

    this.tipName = item.name;
    if (item.type === 'host') {
      this.tipType = this.translate.instant('insight.Objects.HostList');
    } else {
      this.tipType = item.type;
    }
    this.tipAlarms = item.alarms;
    this.tipHealth = item.health;
    this.tipRisk = item.risk;
    this.tipEfficiency = item.efficiency;
    this.tipWorkload = item.workload;
    this.tipRemainCapa = item.remainCapacity;
    this.tipReclaimCapa = item.reclaimCapacity;
    this.tipStress = item.stress;

  }

  hideTooltip() {
    //$('.tipBox').css('display', 'none');
  }

  mousePosition(ev) {
    ev = ev || window.event;
    if (ev.pageX || ev.pageY) {
      return {x: ev.pageX, y: ev.pageY};
    }
    return {
      x: ev.clientX + document.body.scrollLeft - document.body.clientLeft,
      y: ev.clientY + document.body.scrollTop - document.body.clientTop
    };
  }

  changeToDate(data) {
    const myTime = data * 1000;
    const myDate = new Date(myTime);

    const str = myDate.getFullYear() + '-' + this.transformDigitString(( myDate.getMonth() + 1)) + '-' +
      this.transformDigitString(myDate.getDate()) + ' ' +  this.transformDigitString(myDate.getHours()) + ':' +
      this.transformDigitString(myDate.getMinutes());

    return str;
  }

  transformDigitString(str: any) {

    if (str < 10) {
      return '0' + str;
    } else {
      return str;
    }
  }

}
