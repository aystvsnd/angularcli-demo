/**
 * Created by 6092002303 on 2017/3/16.
 */
import { Component , OnInit , Input, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {TranslateService} from '@ngx-translate/core';
import {StorageService } from '../../../../storage.service';
import { KyButtonComponent, KyLoadingComponent, KyProcessBarComponent} from '../../../../shared/kylib/index';
import { MonitorObjectService } from './../../monitor-object.service';

@Component({
  moduleId: module.id,
  selector: 'monitor-obj-cpi-workloadhost',
  directives: [KyButtonComponent, KyLoadingComponent, KyProcessBarComponent],
  styleUrls: [ '../../../css/common.css', '../monitor-obj-detail.component.less',
    '../../../css/tooltip.less'],
  templateUrl: 'monitor-obj-cpi-workloadhost.component.html'
})

export class MonitorObjCpiWorkloadHostComponent implements OnInit {
  @Input() aboutMeInfo;
  @Input() relatedObjectInfo;
  @Input() siblingNum;
  @Input() childrenNum;
  @Output() wlMinImg = new EventEmitter();

  window: window = window;
  name: any;
  objectId: string;
  objectType: string;
  headNames: Array<any>;
  activeString: any;
  imgUrlsMax: string;
  workLoadSlideBlock: any;

  workLoadWords: string;

  workloadList: any;

  wlCpuCheck: any = false;
  wlMemCheck: any = false;
  wlDiskCheck: any = false;
  wlNetInCheck: any = false;
  wlNetOutCheck: any = false;
  wlNetIOCheck: any = false;

  siblingNum: number;
  childrenNum: number;
  workloadIOName = '--';

  tipName: string;
  tipType: string;
  tipAlarms: number;
  tipHealth: string;
  tipRisk: string;
  tipEfficiency: string;
  tipWorkload: string;
  tipRemainCapa: string;
  tipReclaimCapa: string;
  tipStress: string;

  cpuPieOption:any;
  cpuPieDataArray:any;
  memPieOption:any;
  memPieDataArray:any;
  diskPieOption:any;
  diskPieDataArray:any;

  constructor(private monitorObjectService: MonitorObjectService, private activatedRoute: ActivatedRoute,
              private router: Router, private translate: TranslateService,
              private storageService: StorageService) {

    this.activatedRoute.params.subscribe(params => {
      this.objectId = params['objectId'];
      this.name = params['name'];
      this.objectType = params['type'];
      console.log(this.objectId);
    });

    if (this.storageService.getCurrentLang() === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }

    this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/4_workload_max.svg';
    this.workLoadSlideBlock = [20, 40];

  }

  ngOnInit() {
    this.monitorObjectService.getWorkLoadInfo(this.objectId, this.objectType)
      .then((res: Response) => {
        const that = this;
        that.workloadList = res;
        console.log(that.workloadList);
        this.workLoadSlideBlock[0] = +that.workloadList['curStrategy'].low;
        this.workLoadSlideBlock[1] = +that.workloadList['curStrategy'].high;
        if (this.workLoadSlideBlock[0] < 0 || this.workLoadSlideBlock[0] > 100) {this.workLoadSlideBlock[0] = 0; }
        if (this.workLoadSlideBlock[1] > 100 || this.workLoadSlideBlock[1] < 0) {this.workLoadSlideBlock[1] = 100; }
        for (let i = 0; i < that.workloadList['curStrategy'].checks.length; i++) {
          switch (that.workloadList['curStrategy'].checks[i]) {
            case 'cpuOccup': {this.wlCpuCheck = true; }; break;
            case 'memOccup': {this.wlMemCheck = true; }; break;
            case 'diskSpaceOccup': {this.wlDiskCheck = true; }; break;
            case 'networkIncomingRate': {this.wlNetInCheck = true; }; break;
            case 'networkOutgoingRate': {this.wlNetOutCheck = true; }; break;
            case 'networkBidirectRate': {this.wlNetIOCheck = true; }; break;
          }
        }

        if (that.workloadList.level === 'high' ) {
          this.wlMinImg.emit('high');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/1_workload_max.svg';
          this.workLoadWords = this.translate.instant('insight.Objects.CriticalWorkload');
        } else if (that.workloadList.level === 'middle') {
          this.wlMinImg.emit('middle');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/2_workload_max.svg';
          this.workLoadWords = this.translate.instant('insight.Objects.Warning');
        } else if (that.workloadList.level === 'low') {
          this.wlMinImg.emit('low');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/3_workload_max.svg';
          this.workLoadWords = this.translate.instant('insight.Objects.Normal');
        } else if (that.workloadList.level === '--') {
          this.wlMinImg.emit('--');
          this.imgUrlsMax = 'assets/images/insight/svg/monitorObject/4_workload_max.svg';
          this.workLoadWords = '--';
        }
        this.workloadEcharts( that.workloadList['history'] );

        this.cpuPieDataArray = this.objToStringArray(that.workloadList.cpuOccup.used.vmList);
        this.memPieDataArray = this.objToStringArray(that.workloadList.memOccup.used.vmList);
        this.diskPieDataArray = this.objToStringArray(that.workloadList.diskSpaceOccup.used.vmList);
        this.cpuPieOption = [
          {
            data: [
              {value: that.workloadList.cpuOccup.selfUsed, name: '自身开销'},
              {value: that.workloadList.cpuOccup.used.usage, name: '已使用'},
              {value: that.workloadList.cpuOccup.free, name: '空闲'}
            ]
          },
          {
            data: this.cpuPieDataArray
          }
        ];

        this.memPieOption = [
          {
            data: [
              {value: that.workloadList.memOccup.selfUsed, name: '自身开销'},
              {value: that.workloadList.memOccup.used.usage, name: '已使用'},
              {value: that.workloadList.memOccup.free, name: '空闲'}
            ]
          },
          {
            data: this.memPieDataArray
          }
        ];

        this.diskPieOption = [
          {
            data: [
              {value: that.workloadList.diskSpaceOccup.selfUsed, name: '自身开销'},
              {value: that.workloadList.diskSpaceOccup.used.usage, name: '已使用'},
              {value: that.workloadList.diskSpaceOccup.free, name: '空闲'}
            ]
          },
          {
            data: this.diskPieDataArray
          }
        ];

      });

  }

  objToStringArray(tempObjArray: any[]) {
    let strName: string;
    let strValue: number;
    let pieData:{}[]=[];
    for (let i = 0; i < tempObjArray.length; i++) {
      for ( const attr in tempObjArray[i]) {
        switch (attr) {
          case 'name': strName = tempObjArray[i][attr]; break;
          case 'usage': strValue = tempObjArray[i][attr]; break;
          default: break;
        }
      }
      pieData.push(this.objStory( strValue,strName));
    }
    return pieData;
  }

  objStory(value,name) {
    return {
      value: value,
      name: name
    };
  }

  workloadEcharts( date: any ) {

    const option1 = {
      tooltip : {
        trigger: 'axis',
        axisPointer: {
          //type: 'cross',
          label: {
            backgroundColor: '#6a7985'
          }
        }
      },
      grid: {
        left: '0%',
        right: '3%',
        bottom: '3%',
        top: '20%',
        containLabel: true
      },
      xAxis : [
        {
          type : 'category',
          boundaryGap : false,
          data : [],
          show : false
        }
      ],
      yAxis : [
        {
          type : 'value',
          show : false,
          max: 100
        }
      ],
      series : [
        {
          name: this.translate.instant('insight.Objects.Workload'),
          type: 'line',
          stack: '总量',
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          areaStyle: {
            normal: {opacity: 0.3}
          },
          itemStyle: {
            normal: {color: '#00aaff'}
          },
          symbol: 'none',
          data: date
        }
      ]
    };
    const dom1: any = document.getElementById('wlEchart');
    const myChart1: any = echarts.init(dom1, 'macarons');
    myChart1.setOption(option1);
  }

  showTooltip (e, item) {

    this.tipName = item.name;
    if (item.type === 'host') {
      this.tipType = this.translate.instant('insight.Objects.HostList');
    } else {
      this.tipType = item.type;
    }
    this.tipAlarms = item.alarms;
    this.tipHealth = item.health;
    this.tipRisk = item.risk;
    this.tipEfficiency = item.efficiency;
    this.tipWorkload = item.workload;
    this.tipRemainCapa = item.remainCapacity;
    this.tipReclaimCapa = item.reclaimCapacity;
    this.tipStress = item.stress;

  }

  hideTooltip() {
    //$('.tipBox').css('display', 'none');
  }

  mousePosition(ev) {
    ev = ev || window.event;
    if (ev.pageX || ev.pageY) {
      return {x: ev.pageX, y: ev.pageY};
    }
    return {
      x: ev.clientX + document.body.scrollLeft - document.body.clientLeft,
      y: ev.clientY + document.body.scrollTop - document.body.clientTop
    };
  }

  changeToDate(data) {
    const myTime = data * 1000;
    const myDate = new Date(myTime);

    const str = myDate.getFullYear() + '-' + this.transformDigitString(( myDate.getMonth() + 1)) + '-' +
      this.transformDigitString(myDate.getDate()) + ' ' +  this.transformDigitString(myDate.getHours()) + ':' +
      this.transformDigitString(myDate.getMinutes());

    return str;
  }

  transformDigitString(str: any) {

    if (str < 10) {
      return '0' + str;
    } else {
      return str;
    }
  }

}
