/**
 * Created by 6092002303 on 2017/3/16.
 */
import { Component , OnInit , Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {TranslateService} from '@ngx-translate/core';
import {StorageService } from '../../../../storage.service';
import { KyButtonComponent, KyLoadingComponent, KyProcessBarComponent} from '../../../../shared/kylib/index';
import { MonitorObjectService } from './../../monitor-object.service';

@Component({
  moduleId: module.id,
  selector: 'monitor-obj-detail-comprehensiveindex',
  directives: [KyButtonComponent, KyLoadingComponent, KyProcessBarComponent],
  styleUrls: [ '../../../css/common.css', '../monitor-obj-detail.component.less',
                '../../../css/tooltip.less'],
  templateUrl: 'monitor-obj-detail-cpi.component.html'
})

export class MonitorObjDetailComprehensiveindexComponent implements OnInit {
  @Input() aboutMeInfo;
  @Input() relatedObjectInfo;
  @Input() siblingNum;
  @Input() childrenNum;

  window: window = window;
  name: any;
  objectId: string;
  objectType: string;
  headNames: Array<any>;
  activeString: any;
  imgUrlsMin: Array<any>;

  constructor(private monitorObjectService: MonitorObjectService, private activatedRoute: ActivatedRoute,
              private router: Router, private translate: TranslateService,
              private storageService: StorageService) {

    this.activatedRoute.params.subscribe(params => {
      this.objectId = params['objectId'];
      this.name = params['name'];
      this.objectType = params['type'];
      console.log(this.objectId);
    });

    if (this.storageService.getCurrentLang() === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }

    this.headNames = [this.translate.instant('insight.Objects.Workload'), this.translate.instant('insight.Objects.RemainCapa'),
      this.translate.instant('insight.Objects.ReclaimCapa'), this.translate.instant('insight.Objects.Stress')];
    this.imgUrlsMin = ['assets/images/insight/svg/monitorObject/4_workload_min.svg',
      'assets/images/insight/svg/monitorObject/4_capacity_min.svg',
      'assets/images/insight/svg/monitorObject/4_recyclable_min.svg',
      'assets/images/insight/svg/monitorObject/4_pressure_min.svg'];
  }

  ngOnInit() {
    console.log('CPI OnInit!');
  }

  showContent(activeString : any) {
    this.activeString = activeString;
  }

  showWlMinImg(imgString : any) {
    switch (imgString) {
      case 'high':
        this.imgUrlsMin[0] = 'assets/images/insight/svg/monitorObject/1_workload_min.svg'; break;
      case 'middle':
        this.imgUrlsMin[0] = 'assets/images/insight/svg/monitorObject/2_workload_min.svg'; break;
      case 'low':
        this.imgUrlsMin[0] = 'assets/images/insight/svg/monitorObject/3_workload_min.svg'; break;
      case '--':
        this.imgUrlsMin[0] = 'assets/images/insight/svg/monitorObject/4_workload_min.svg';
    }
  }

  showRemainMinImg(imgString : any) {
    switch (imgString) {
      case 'high':
        this.imgUrlsMin[1] = 'assets/images/insight/svg/monitorObject/1_capacity_min.svg'; break;
      case 'middle':
        this.imgUrlsMin[1] = 'assets/images/insight/svg/monitorObject/2_capacity_min.svg'; break;
      case 'low':
        this.imgUrlsMin[1] = 'assets/images/insight/svg/monitorObject/3_capacity_min.svg'; break;
      case '--':
        this.imgUrlsMin[1] = 'assets/images/insight/svg/monitorObject/4_capacity_min.svg';
    }
  }

  showReclaimMinImg(imgString : any) {
    switch (imgString) {
      case 'high':
        this.imgUrlsMin[2] = 'assets/images/insight/svg/monitorObject/1_recyclable_min.svg'; break;
      case 'middle':
        this.imgUrlsMin[2] = 'assets/images/insight/svg/monitorObject/2_recyclable_min.svg'; break;
      case 'low':
        this.imgUrlsMin[2] = 'assets/images/insight/svg/monitorObject/3_recyclable_min.svg'; break;
      case '--':
        this.imgUrlsMin[2] = 'assets/images/insight/svg/monitorObject/4_recyclable_min.svg';
    }
  }

  showStressMinImg(imgString : any) {
    switch (imgString) {
      case 'high':
        this.imgUrlsMin[3] = 'assets/images/insight/svg/monitorObject/1_pressure_min.svg'; break;
      case 'middle':
        this.imgUrlsMin[3] = 'assets/images/insight/svg/monitorObject/2_pressure_min.svg'; break;
      case 'low':
        this.imgUrlsMin[3] = 'assets/images/insight/svg/monitorObject/3_pressure_min.svg'; break;
      case '--':
        this.imgUrlsMin[3] = 'assets/images/insight/svg/monitorObject/4_pressure_min.svg';
    }
  }

}
