import {Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MonitorObjectService } from '../../monitor-object.service';
import {TranslateService} from '@ngx-translate/core';
//import { INDEX_LIST } from './indicator.config';

@Component({
  moduleId: module.id,
  selector: 'monitor-obj-historycurve',
  styleUrls: ['../../../css/common.css', '../monitor-obj-detail.component.less',
                  '../timeline/monitor-obj-timeline.component.less',
                  './monitor-obj-historycurve.component.less',
                '../timeline/monitor-obj-timeline-alarms-diagram.component.less'
  ],
  templateUrl: 'monitor-obj-historycurve.component.html'
})

export class MonitorObjHistoryCurveComponent implements OnInit, OnChanges {
  @Input() startTime;
  @Input() endTime;
  @Input() currentTime;
  @Input() periodType;
  @Input() relatedObjectInfo;
  receivedMeters: any;
  iconIndexView = 'each';
  objectId: any;
  objectType: any;
  objTypeIcon: any = `width:20px;height:20px;margin-right:5px;`;
  selectObject: any;
  indicators: any = [];
  indicatorTrees: {
    objectId: string,
    objectType: string,
    objectName: string;
    indicatorList: Array<string>
  }[] = [];
  //indexList:Array<any> = INDEX_LIST;
 /* objList:Array<any> = [
    '自身'
  ];*/
   indexList: Array<any> = [
  {name: this.translate.instant('insight.Objects.CpuUtilization'), value: 'C100010004'},
  {name: this.translate.instant('insight.Objects.vCpuNum'), value: 'C100010001'},
  {name: this.translate.instant('insight.Objects.CpuUtiPeak'), value: 'C100010005'},
  {name: this.translate.instant('insight.Objects.CpuUtiTrough'), value: 'C100010006'},
  {name: this.translate.instant('insight.Objects.PeakCpuRemainCap'), value: 'C100018013'},
  {name: this.translate.instant('insight.Objects.AverCpuRemainCap'), value: 'C100018019'},
  {name: this.translate.instant('insight.Objects.CpuRemainCap'), value: 'C100018025'},
  {name: this.translate.instant('insight.Objects.CpuStress'), value: 'C100018007'},
  {name: this.translate.instant('insight.Objects.CpuReclaimCap'), value: 'C100018043'},
  {name: this.translate.instant('insight.Objects.MemTotal'), value: 'C100011001'},
  {name: this.translate.instant('insight.Objects.MemUsed'), value: 'C100011004'},
  {name: this.translate.instant('insight.Objects.MemUsedPeak'), value: 'C100011005'},
  {name: this.translate.instant('insight.Objects.AverMemUsage'), value: 'P100010001'},
  {name: this.translate.instant('insight.Objects.MemStress'), value: 'C100018008'},
  {name: this.translate.instant('insight.Objects.PeakMemRemainCap'), value: 'C100018014'},
  {name: this.translate.instant('insight.Objects.AverMemRemainCap'), value: 'C100018020'},
  {name: this.translate.instant('insight.Objects.MemRemainCap'), value: 'C100018026'},
  {name: this.translate.instant('insight.Objects.MemReclaimCap'), value: 'C100018044'},
  {name: this.translate.instant('insight.Objects.DiskSpaceTotal'), value: 'C100012001'},
  {name: this.translate.instant('insight.Objects.DiskSpaceUsed'), value: 'C100012004'},
  {name: this.translate.instant('insight.Objects.DiskUsedPeak'), value: 'C100012005'},
  {name: this.translate.instant('insight.Objects.DiskIOReadRate'), value: 'C100012010'},
  {name: this.translate.instant('insight.Objects.DiskIOWriteRate'), value: 'C100012013'},
  {name: this.translate.instant('insight.Objects.AverDiskUsage'), value: 'P100011001'},
  {name: this.translate.instant('insight.Objects.PeakDiskRemainCap'), value: 'C100018015'},
  {name: this.translate.instant('insight.Objects.AverDiskRemainCap'), value: 'C100018021'},
  {name: this.translate.instant('insight.Objects.DiskRemainCap'), value: 'C100018027'},
  {name: this.translate.instant('insight.Objects.DiskReclaimCap'), value: 'C100018045'},
  {name: this.translate.instant('insight.Objects.CurNumOfvNICs'), value: 'C100013001'},
  {name: this.translate.instant('insight.Objects.MaxNumOfvNICs'), value: 'C100013002'},
  {name: this.translate.instant('insight.Objects.MinNumOfvNICs'), value: 'C100013003'},
  {name: this.translate.instant('insight.Objects.NetInRate'), value: 'C100040001'},
  {name: this.translate.instant('insight.Objects.NetOutRate'), value: 'C100040004'},
  {name: this.translate.instant('insight.Objects.NetInBandwidth'), value: 'C100040007'},
  {name: this.translate.instant('insight.Objects.NetOutBandwidth'), value: 'C100040010'},
  {name: this.translate.instant('insight.Objects.NetInRatePeak'), value: 'C100040002'},
  {name: this.translate.instant('insight.Objects.NetOutRatePeak'), value: 'C100040005'},
  {name: this.translate.instant('insight.Objects.NetInRateTrough'), value: 'C100040003'},
  {name: this.translate.instant('insight.Objects.NetOutRateTrough'), value: 'C100040006'},
  {name: this.translate.instant('insight.Objects.NetInBytes'), value: 'C100040027'},
  {name: this.translate.instant('insight.Objects.NetOutBytes'), value: 'C100040028'},
  {name: this.translate.instant('insight.Objects.NetInPackets'), value: 'C100040029'},
  {name: this.translate.instant('insight.Objects.NetOutPackets'), value: 'C100040030'},
  {name: this.translate.instant('insight.Objects.NetInLostPackets'), value: 'C100040031'},
  {name: this.translate.instant('insight.Objects.NetOutLostPackets'), value: 'C100040032'},
  {name: this.translate.instant('insight.Objects.NetInErrorPackets'), value: 'C100040033'},
  {name: this.translate.instant('insight.Objects.NetOutErrorPackets'), value: 'C100040034'},
  {name: this.translate.instant('insight.Objects.NetInWorkload'), value: 'C100018002'},
  {name: this.translate.instant('insight.Objects.NetOutWorkload'), value: 'C100018003'},
  {name: this.translate.instant('insight.Objects.NetBiTransWorkload'), value: 'C100018004'},
  {name: this.translate.instant('insight.Objects.NetInStress'), value: 'C100018009'},
  {name: this.translate.instant('insight.Objects.NetOutStress'), value: 'C100018010'},
  {name: this.translate.instant('insight.Objects.NetBiTransStress'), value: 'C100018011'},
  {name: this.translate.instant('insight.Objects.PeakNetInRemainCap'), value: 'C100018016'},
  {name: this.translate.instant('insight.Objects.PeakNetOutRemainCap'), value: 'C100018017'},
  {name: this.translate.instant('insight.Objects.PeakNetBiTransRemainCap'), value: 'C100018018'},
  {name: this.translate.instant('insight.Objects.AverNetInRemainCap'), value: 'C100018022'},
  {name: this.translate.instant('insight.Objects.AverNetOutRemainCap'), value: 'C100018023'},
  {name: this.translate.instant('insight.Objects.AverNetBiTransRemainCap'), value: 'C100018024'},
  {name: this.translate.instant('insight.Objects.NetInRemainCap'), value: 'C100018028'},
  {name: this.translate.instant('insight.Objects.NetOutRemainCap'), value: 'C100018029'},
  {name: this.translate.instant('insight.Objects.NetBiTransRemainCap'), value: 'C100018030'},
  {name: this.translate.instant('insight.Objects.Workload'), value: 'C100018006'},
  {name: this.translate.instant('insight.Objects.Stress'), value: 'C100018012'},
  {name: this.translate.instant('insight.Objects.RemainCapacity'), value: 'C100018031'},
  {name: this.translate.instant('insight.Objects.ReclaimCapacity'), value: 'C100018046'},
];
  selectIndex: any = 'C100010004';
  selectIndexList: Array<any> = ['C100010004'];
  window: window = window;
  constructor(private monitorObjectService: MonitorObjectService,
              private translate: TranslateService,
              private activatedRoute: ActivatedRoute) {

    this.activatedRoute.params.subscribe(params => {
      this.objectId = params['objectId'];
      this.objectType = params['type'];
      console.log('objectId:' + this.objectId + ',type:' + this.objectType);
    });

  }

  ngOnInit() {
    this.indexHistoryCurve();
  }

  ngOnChanges(changes: SimpleChanges) {
    for (const propName in changes) {
      console.log(propName.toString());
      if (propName === 'periodType') {
        this.indexHistoryCurve();
        break;
      }
    }
  }

  showMergeEcharts(data: any) {
    const that = this;
    const dom1: any = document.getElementById('indexCurveMerge');
    let eles = dom1.querySelectorAll('div');
    _.each(eles, function(ele) {
      echarts.dispose(ele);
    });
    dom1.innerHTML = '';
    let div = document.createElement('div');
    div.style.height = '220px';
    div.style.width = '1100px';
    dom1.appendChild(div);
    const option1 = {
      tooltip: {
        trigger: 'axis'
      },
      legend: {
        orient: 'horizontal',
        x: 'center',
        y: 'bottom',
        padding: 0,
        data: []
      },
      grid: {
        left: '3%',
        right: '5%',
        bottom: '10%',
        top: '5%',
        containLabel: true
      },
      xAxis: {
        min: (that.startTime).toFixed(0),
        max: (that.endTime).toFixed(0),
        type: 'time',
        splitLine: {
          show: false
        },
        axisLabel: {
          formatter: function(val) {
            return that.changeToDate(val);
          }
        }
      },
      yAxis: {
        min: 0,
        max: 100,
        type: 'value',
        axisLine: {
          show: false
        },
        axisTick: {
          show: false
        }
      },
      series: []
    };
    _.each(data, function (datum) {
      _.each(datum.meters, function(meter) {
        let series = {
            name: datum.objectName + ' ' + _.find(that.indexList, function(index) {
              return meter.id === index.value;
            }).name,
            type: 'line',
            data: meter['data'].map(function (item) {
              return {
                value: [item.time * 60000, item.value.toFixed(2)]
              };
            })
          };
          option1.series.push(series);
          option1.legend.data.push(datum.objectName + ' ' +
            _.find(that.indexList, function(index) {
              return meter.id === index.value;
            }).name);
        });
      });
    const myChart1: any = echarts.init(div, 'macarons');
    myChart1.setOption(option1);
  }
  showEachEcharts(data: any) {
    const that = this;
    const dom2: any = document.getElementById('indexCurveEach');
    let eles = dom2.querySelectorAll('div');
    _.each(eles, function(ele) {
      echarts.dispose(ele);
    });
    dom2.innerHTML = '';
    _.each(data, function (datum) {
      _.each(datum.meters, function(meter) {
        let div = document.createElement('div');
        div.style.height = '150px';
        div.style.width = '1100px';
        dom2.appendChild(div);
        const option2 = {
          tooltip: {
            trigger: 'axis'
          },
          legend: {
            orient: 'horizontal',
            x: 'center',
            y: 'bottom',
            padding: 0,
            data: []
          },
          grid: {
            left: '3%',
            right: '5%',
            bottom: '10%',
            top: '5%',
            containLabel: true
          },
          xAxis: {
            min: (that.startTime).toFixed(0),
            max: (that.endTime).toFixed(0),
            type: 'time',
            splitLine: {
              show: false
            },
            axisLabel: {
              formatter: function(val) {
                return that.changeToDate(val);
              }
            }
          },
          yAxis: {
            min: 0,
            max: 100,
            type: 'value',
            axisLine: {
              show: false
            },
            axisTick: {
              show: false
            }
          },
          series: [
            {
              name: datum.objectName + ' ' + _.find(that.indexList, function(index) {
                return meter.id === index.value;
              }).name,
              type: 'line',
              stack: '总量',
              data: meter['data'].map(function (item) {
                return {
                  value: [item.time * 60000, item.value.toFixed(2)],
                };
              })
            }
          ]
        };
        option2.legend.data.push(datum.objectName + ' ' +
          _.find(that.indexList, function(index) {
            return meter.id === index.value;
          }).name);
        
        const myChart2: any = echarts.init(div, 'macarons');
        myChart2.setOption(option2);
      });
    });
    
  }
  showThresholdEcharts() {
    const option3 = {
      tooltip: {
        trigger: 'axis'
      },
      grid: {
        left: '3%',
        right: '5%',
        bottom: '3%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: ['13:00', '13:05', '15:00', '16:00', '17:00', '18:00', '19:00']
      },
      yAxis: {
        type: 'value',
        axisLine: {
          show: false
        },
        axisTick: {
          show: false
        }
      },
      series: [
        {
          name: 'L',
          type: 'line',
          data: [65, 22, 71, 30, 44, 39 , 9],
          lineStyle: {
            normal: {
              opacity: 0
            }
          },
          /* areaStyle: {
           normal: {
           color: '#fff',
           }
           },*/
          stack: '总量',
          symbol: 'none'
        },
        {
          name: 'U',
          type: 'line',
          data: [85, 62, 95, 88, 72, 99 , 44],
          lineStyle: {
            normal: {
              opacity: 0
            }
          },
          areaStyle: {
            normal: {
              color: '#00aaff',
              opacity: 0.3
            }
          },
          stack: '总量',
          symbol: 'none'
        },
        {
          name: 'CPU压力',
          type: 'line',
          //stack: '总量',
          data: [75, 42, 91, 34, 69, 89 , 20],
          hoverAnimation: false,
          symbolSize: 6,
          itemStyle: {
            normal: {
              color: '#00aaff'
            }
          },
          showSymbol: false
        }
      ]
    };
    const dom3: any = document.getElementById('indexCurveThreshold');
    const myChart3: any = echarts.init(dom3, 'macarons');
    myChart3.setOption(option3);
  }
  selectIndexViewIcon(iconType: any) {
    this.iconIndexView = iconType;
    if (this.iconIndexView === 'merge') {
      $('.mergeDiv').css('display', 'block');
      $('.eachDiv').css('display', 'none');
      $('.thresholdDiv').css('display', 'none');
      this.showMergeEcharts(this.receivedMeters);
    }
    if (this.iconIndexView === 'each') {
      $('.mergeDiv').css('display', 'none');
      $('.eachDiv').css('display', 'block');
      $('.thresholdDiv').css('display', 'none');
      this.showEachEcharts(this.receivedMeters);
    }
    if (this.iconIndexView === 'threshold') {
      $('.mergeDiv').css('display', 'none');
      $('.eachDiv').css('display', 'none');
      $('.thresholdDiv').css('display', 'block');
      this.showThresholdEcharts();
    }
    if (this.iconIndexView === 'closeall') {
      $('.mergeDiv').css('display', 'none');
      $('.eachDiv').css('display', 'none');
      $('.thresholdDiv').css('display', 'none');
    }

  }

  findName(value : string) {
    const select =   _.find(this.indexList, (item) => {

      return item.value === value;
    });
    return select.name;
  }
  changeToDate(data) {
    // var myTime = data * 60000;
    const myDate = new Date(data);
    const str = myDate.getFullYear() + '-' + this.transformDigitString(( myDate.getMonth() + 1)) + '-' +
      this.transformDigitString(myDate.getDate()) + ' ' +  this.transformDigitString(myDate.getHours()) + ':' +
      this.transformDigitString(myDate.getMinutes());
    return str;
  }

  changeObj() {

    const selectValue = $('#selectObj').val();
    this.selectObject = selectValue;
    this.indexHistoryCurve();
  }

  changeIndex() {
    const selectValue = $('#selectIndex').val();
    this.selectIndexList = [];
    this.selectIndex = selectValue.toString();
    this.selectIndexList.push(this.selectIndex);
    this.indexHistoryCurve();
  }

  selectIcon(iconType: any) {
    this.iconSelectedType = iconType;
  }

  indexHistoryCurve() {
    const that = this;
    const IndexArray = [];
    IndexArray.push();
    let period;
    if ( this.periodType === this.translate.instant('insight.Objects.SixHours')) {
      period = '5m';
    } else if (this.periodType === this.translate.instant('insight.Objects.OneDays')) {
      period = '15m';
    } else if (this.periodType === this.translate.instant('insight.Objects.OneWeeks')) {
      period = '1h';
    }
    // const PostStr = {
    //   objectId: this.objectId,
    //   objectType: this.objectType,
    //   beginTime: Math.round(this.startTime / 60000),
    //   endTime: Math.round(this.endTime / 60000),
    //   meters: {
    //     period: period,
    //     list: this.selectIndexList
    //   }
    // };
    const PostStr = [];
    this.receivedMeters = [];
    _.each(this.indicatorTrees, function(indicatorTree) {
      let PostStr = {
        objectId: indicatorTree.objectId,
        objectType: indicatorTree.objectType,
        beginTime: Math.round(that.startTime / 60000),
        endTime: Math.round(that.endTime / 60000),
        meters: {
          period: period,
          list: indicatorTree.indicatorList
        }
      };

      that.monitorObjectService.postObjAndIndex(PostStr).then((res: Response) => {
        that.receivedMeters = _.union(that.receivedMeters,
          [{
            objectId: indicatorTree.objectId,
            objectType: indicatorTree.objectType,
            objectName: indicatorTree.objectName,
            meters: res.meters
          }]);
        that.showMergeEcharts(that.receivedMeters);
        that.showEachEcharts(that.receivedMeters);
      });
    });

  }

  transformDigitString(str: any) {
    if (str < 10) {
      return '0' + str;
    } else {
      return str;
    }
  }

  optionsSelected(indicators: any){
    let that = this;
    this.indicators = indicators;
    this.selectIndexList = [];
    this.indicatorTrees = [];
    _.each(this.indicators, function(indicator) {
      let index = _.findIndex(that.indicatorTrees, function(indicatorTree) {
        if (indicator.objectId === indicatorTree.objectId
          && indicator.objectType === indicatorTree.objectType)
          return true;
        else
          return false;
      });
      if (index === -1) {
        that.indicatorTrees.push({
          objectId: indicator.objectId,
          objectType: indicator.objectType,
          objectName: indicator.objectName,
          indicatorList: [indicator.id]
        });
      } else {
        that.indicatorTrees[index].indicatorList.push(indicator.id);
      }
    });
    console.log("final_out=", this.indicatorTrees);
    this.indexHistoryCurve();
  }

  selectIndicator() {
    $('#indicatorsSelector').modal('show');
  }

}

