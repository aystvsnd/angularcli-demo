import { Component , OnInit , Input} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {TranslateService} from '@ngx-translate/core';
import {StorageService } from '../../../storage.service';
import { MonitorObjectService } from './../monitor-object.service';

import { CommonFunctionService } from '../../common/common-function.service';
import { AuthService } from '../../../core/index';
import { Observable} from 'rxjs/Observable';
import {ApiResourceService as Http} from '../../../apiResource.service';
import { DelDcMessage } from './monitor-obj-detail.interface';


@Component({
  moduleId: module.id,
  selector: 'monitor-obj-detail-overview',
  styleUrls: [ '../../css/common.css', 'monitor-obj-detail.component.less', '../../css/tooltip.less'],
  templateUrl: 'monitor-obj-detail-overview.component.html'
})

export class MonitorObjDetailOverviewComponent implements OnInit {
  objectStatusInfo: any;
  @Input() aboutMeInfo;
  @Input() relatedObjectInfo;
  @Input() siblingNum;
  @Input() childrenNum;
  objectId: any;
  objectType: any;
  siblingNum: number;
  childrenNum: number;
  iconSelectedType = 'health';

  healthLevel = 0;
  riskLevel = 0;
  efficiencyLevel = 0;

  tipName: string;
  tipType: string;
  tipAlarms: number;
  tipHealth: string;
  tipRisk: string;
  tipEfficiency: string;

  //tipToolCol :any = `position: relative;cursor: pointer;`;
  alertIconTip: any = `display: inline-block;
    width:20px;
    height:20px;
    background-image: url('assets/images/alert_icon_all.png');
    background-repeat: no-repeat;
    position:relative;top:3px;`;

  /*tip_tag:any = `display:inline-block;
  opacity:0;
  -moz-opacity:0;
  filter:Alpha(opacity=0);
  position:absolute;
  left:50%;color:#000;white-space:nowrap;transform: translate(-50%,-50%);`;*/
  tip_area: any = `height:24px;
  padding:0 10px;
  border:1px solid #e6e6e6;`;
  /*tip_areaCopy:any = `height:24px;
  padding:0 10px;`;
  tip_arrow:any = `float:left;
  position:relative;
  left:50%;`;*/
  tip_angle: any = `position:relative;
  left:-50%;
  top: -11px;
  display:inline-block;
  width:0px;
  height:0px;
  border-left:4px solid transparent;
  border-right:4px solid transparent;
  border-top:4px solid #e6e6e6;`;
  /*tip_angleWhite:any = `position: relative;
    left: -4px;
    top: -20px;
    display: block;
    width: 0px;
    height: 0px;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 4px solid #fff;`;
*/
  imgStyle : any = `display: inline-block;
    width: 20px; height: 20px`;
  alarmTip : any = `white-space: nowrap;
    transform: translate(-50%, -50%);
    left: 50%;
    top: -15px;
    opacity: 1;
    display: none`;
  alarmLevel : any = `cursor: pointer;
    position: relative`;
  topArrow : any = `border-top-color: #ddd`;

  window: window = window;

  reason = '';
  alarmType = '';
  modalLable: string = this.translate.instant('fm.confirmInfo');
  modalTitle = '';

  hasRightSmartAlarms = false;
  hasRightCurrentAlarms = false;

  delDcMessage: DelDcMessage = {
    title: this.translate.instant('fm.DeleteAlarm'),
    message:  this.translate.instant('fm.delConfirm'),
    confirmText: this.translate.instant('Confirm'),
    cancelText: this.translate.instant('Cancel'),
    type: 'exclamation',
    mode: 'tip',
    tip: this.translate.instant('fm.fm_delete_tip')
  };

  selectedRows: Array= [];

  columnDefs : any[] = [
    {
      field: 'level',
      align: 'middle',
      title: this.translate.instant('insight.Objects.Impact'),
      events: 'operateEvents',
      formatter: function (value, row, index) {
        const levelVaule = value.toLowerCase();
        if (levelVaule === 'critical' && row.impact === 'health') {
          return that.showLevelContent('fm.impact_health', 'fm.critical', 0, 0);
        } else if (levelVaule === 'critical'  && row.impact === 'risk') {
          return that.showLevelContent('fm.impact_risk', 'fm.critical', 0, -22);
        } else if (levelVaule === 'critical'  && row.impact === 'efficiency') {
          return that.showLevelContent('fm.impact_efficiency', 'fm.critical', 0, -42);
        } else if (levelVaule === 'critical'  && (row.impact !== 'health' || row.impact !== 'risk' || row.impact !== 'efficiency') ) {
          return that.showLevelContent('fm.level', 'fm.critical', 0, -62);
        } else if (levelVaule === 'major'  && row.impact === 'health') {
          return that.showLevelContent('fm.impact_health', 'fm.major', -20, 0);
        } else if (levelVaule === 'major' && row.impact === 'risk') {
          return that.showLevelContent('fm.impact_risk', 'fm.major', -20, -22);
        } else if (levelVaule === 'major' && row.impact === 'efficiency') {
          return that.showLevelContent('fm.impact_efficiency', 'fm.major', -20, -42);
        } else if (levelVaule === 'major'  && (row.impact !== 'health' || row.impact !== 'risk' || row.impact !== 'efficiency') ) {
          return that.showLevelContent('fm.level', 'fm.major', -20, -62);
        } else if (levelVaule === 'minor' && row.impact === 'health') {
          return that.showLevelContent('fm.impact_health', 'fm.minor', -40, 0);
        } else if (levelVaule === 'minor'  && row.impact === 'risk') {
          return that.showLevelContent('fm.impact_risk', 'fm.minor', -40, -22);
        } else if (levelVaule === 'minor'  && row.impact === 'efficiency') {
          return that.showLevelContent('fm.impact_efficiency', 'fm.minor', -40, -42);
        } else if (levelVaule === 'minor'  && (row.impact !== 'health' || row.impact !== 'risk' || row.impact !== 'efficiency') ) {
          return that.showLevelContent('fm.level', 'fm.minor', -40, -62);
        } else if (levelVaule === 'warning'  && row.impact === 'health') {
          return that.showLevelContent('fm.impact_health', 'fm.warning', -60, 0);
        } else if (levelVaule === 'warning' && row.impact === 'risk') {
          return that.showLevelContent('fm.impact_risk', 'fm.warning', -60, -22);
        } else if (levelVaule === 'warning' && row.impact === 'efficiency') {
          return that.showLevelContent('fm.impact_efficiency', 'fm.warning', -60, -42);
        } else if (levelVaule === 'warning'  && (row.impact !== 'health' || row.impact !== 'risk' || row.impact !== 'efficiency') ) {
          return that.showLevelContent('fm.level', 'fm.warning', -60, -62);
        } else {
          return `<div class="impactLevel"><div style class="tooltip tooltip2"></div>-</div>`;
        }
      }
    },
    {
      field: 'description',
      align: 'left',
      title: this.translate.instant('insight.Objects.DetailOfAlarm'),
      events: 'operateEvents',
      formatter: function (value, row, index) {
        const newValue = that.commonFunctionService.cutStr(value, 20);
        return `<a href="javascript:void(0);" class="detail">
        <pre data-toggle="tooltip" data-placement="top" title="${value}">${newValue}</pre></a>`;
      }
    },
    {
      field: 'suggestion',
      align: 'left',
      title: this.translate.instant('insight.Objects.Suggestion'),
      formatter: function (value, row, index) {
        const newValue = that.commonFunctionService.cutStr(value, 20);
        return `<pre data-toggle="tooltip" data-placement="top" title="${value}">${newValue}</pre>`;
      }
    },
    {
      field: 'alarmTime',
      align: 'left',
      title: this.translate.instant('insight.Objects.OccurTime'),
      formatter: function (value, row, index) {
        return that.commonFunctionService.serverTimeToLocalTime(value);
      }
    },
    {
      field: 'confirmStatus',
      align: 'left',
      title: this.translate.instant('insight.Objects.StatusConfirm'),
      formatter: function (value, row, index) {
        if (value === 'confirmed') {
          return that.translate.instant('fm.Confirm');
        }else {
          return that.translate.instant('fm.NoConfirm');
        }
      }
    },
    {
      field: 'operate',
      align: 'center',
      events: 'operateEvents',
      width: 150,
      title: this.translate.instant('insight.Objects.Actions'),
      formatter: function (value, row, index) {

        if (that.authService.containEveryRights(['Current Alarm#DELETE', 'Current Alarm Confirm#PUT'])) {

          if ( row.confirmStatus === 'unconfirmed') {
            return `<div class="btn-group ">
                         <button class="btn btn-default confirm ">${that.translate.instant('Confirm')}</button>
                         <button class="btn btn-default dropdown-toggle" data-toggle="dropdown"><span class="caret"></span>
                         </button>
                         <ul class="dropdown-menu dropdown-menu-top">
                            <li>
                            <a data-target="#DelConfirm" data-toggle="modal" class="clear">${that.translate.instant('Delete')}</a>
                                <!--<a data-target="#DelConfirm" data-toggle="modal">删除</a>-->

                            </li>
                         </ul>
                   </div>`;
          }else {
            return `<div class="btn-group " style="width:170px;">
                         <button class="btn btn-default unconfirm " style="width:140px;">${that.translate.instant('fm.unconfirm')}</button>
                         <button class="btn btn-default dropdown-toggle " data-toggle="dropdown" ><span class="caret"></span>
                         </button>
                         <ul class="dropdown-menu dropdown-menu-top">
                            <li>
                                <a data-target="#DelConfirm" data-toggle="modal" class="clear">${that.translate.instant('Delete')}</a>
                            </li>
                         </ul>
                   </div>`;
          }

        }else if (that.authService.containEveryRights(['Current Alarm#DELETE'])) {
          return `<div class="btn-group">
                <button data-target="#DelConfirm" data-toggle="modal" class="clear btn btn-default ">
                ${that.translate.instant('Delete')}</button>
                </div>`;

        }else {
          if ( row.confirmStatus === 'unconfirmed') {
            return `<div class="btn-group ">
                         <button class="btn btn-default confirm ">${that.translate.instant('Confirm')}</button>
                   </div>`;
          }else {
            return `<div class="btn-group" style="width:170px;">
                         <button class="btn btn-default unconfirm " style="width:140px;">${that.translate.instant('fm.unconfirm')}</button>
                   </div>`;
          }

        }

      }
    }
  ];

  columnAnalysis : any[] = [
    {
      field: 'id',
      align: 'left',
      title: this.translate.instant('insight.smartAnalysis.Sequence'),
      formatter: function (value, row, index) {
        return  index + 1;
      }
    },
    {
      field: 'modelLevel',
      align: 'middle',
      title: this.translate.instant('insight.smartAnalysis.Impact'),
      events: 'operateEvents',
      formatter: function(value, row, index) {
        const imgSrc = that.alarmImgChioce(row.modelLevel, row.modelImpact);

        const level = that.levelChoose(row.modelLevel, row.modelImpact);
        const impact = that.impactChoose(row.modelImpact);
        return `<div style="${that.alarmLevel}">
                    <div class="tooltip top tooltip1" role="tooltip" style="${that.alarmTip}">
                        <div class="tooltip-arrow my-arrow-top" style="${that.topArrow}"></div>
                        <div class="alarm-arrow my-arrow-bottom"></div>
                        <div class="tooltip-inner tip-content">
                        ${impact}: ${level}
                    </div>
                    </div>
                    <div class="impact-level">
                      <img style="${that.imgStyle}" src=${imgSrc}>
                    </div>
                </div>`;
      }
    },

    {
      field: 'modelName',
      align: 'left',
      title: this.translate.instant('insight.smartAnalysis.AnalysisResult'),
      events: 'operateEvents',
      formatter: function(value, row, index) {
        const newValue = that.commonFunctionService.cutStr(value, 20);
        return `<a href="javascript:void(0);" class="analysis-detail"
            data-toggle="tooltip" data-placement="top" title="${value}">${newValue}</a>`;
      }
    },

    {
      field: 'modelSuggestion',
      align: 'left',
      title: this.translate.instant('insight.smartAnalysis.Suggestion'),
      formatter: function (value, row, index) {
        const newValue = that.commonFunctionService.cutStr(value, 20);
        return `<pre data-toggle="tooltip" data-placement="top" title="${value}">${newValue}</pre>`;
      }
    },
    {
      field: 'modelObjectType',
      align: 'left',
      title: this.translate.instant('insight.smartAnalysis.ObjectType'),
    },

    {
      field: 'modelObjectName',
      align: 'left',
      title: this.translate.instant('insight.smartAnalysis.ObjectName'),
    },

    {
      field: 'modelAlarmNum',
      align: 'left',
      title: this.translate.instant('insight.smartAnalysis.RelatedAlarmNumber')
    },
    {
      field: 'modelStartTime',
      align: 'left',
      title: this.translate.instant('insight.smartAnalysis.TimeofOccurrence'),
      formatter: function (value, row, index) {
        return that.commonFunctionService.serverTimeToLocalTime(value);
      }
    }
  ];
  gridOptions: any = {
    method: 'get',
    queryParams: params => this.queryParams(params, this),
    //columns: this.columnDefs,
    sidePagination: 'server',
    pagination: true, //是否开启分页
    pageSize: 10, //单页数量
    pageNumber: 1,
    pageList: [10, 20],
    paginationDetailHAlign: 'right', //分页详情水平位置
    paginationHAlign: 'right', //分页条水平位置
    clickToSelect: false, //单击行选中
    search: false,
    escape:true
  };

  queryParams(params: any, that: any) {
    const tmp = {
      pageSize: params.limit,
      currentPage: params.offset / params.limit + 1,
      fuzzy: params.search,
    };

    return tmp;
  }

  initTable() {

    const that = this;

    if (true === that.hasRightCurrentAlarms) {

      const objectIdToAlarm = JSON.parse(this.objectId).vmId;

      let tempColumnDefs: any = _.clone(that.columnDefs);
      if (!that.authService.containSomeRights(['Current Alarm#DELETE', 'Current Alarm Confirm#PUT'])) {
        tempColumnDefs = _.filter( tempColumnDefs , function(x){
          return x.field !== 'operate';
        });
      }

      this.gridOptions.columns = tempColumnDefs;

      $('#table-overview').bootstrapTable($.extend(this.gridOptions, {
        url: '/api/v1.0/fm/alarmsWithDetail?objectId=' + objectIdToAlarm,
        dataField: 'alarms',
        responseHandler: function (res) {

          const alarms = {
            'total': res.total,
            'alarms': res.alarms
          };
          return alarms;
        }

      }));

    }

    if (true === that.hasRightSmartAlarms) {

      const object = {cloudId: JSON.parse(this.objectId).envId, objectType: this.objectType,
        objectId: JSON.parse(this.objectId).vmId};
      const objectToString = JSON.stringify(object);

      $('#table-analysis').bootstrapTable($.extend(this.gridOptions, {

        url: '/api/v1/fia/allAlarmModels?object=' + objectToString,
        dataField: 'analysis',
        columns: that.columnAnalysis,
        responseHandler: function (res) {

          const analysis = {
            'total': res.pageNum,
            'analysis': res.modelList,
          };
          return analysis;
        }
      }));
    }

  }

  constructor(private monitorObjectService: MonitorObjectService, private activatedRoute: ActivatedRoute,
              private router: Router, private translate: TranslateService,
              private storageService: StorageService, private  http: Http,
              private commonFunctionService: CommonFunctionService, private authService: AuthService) {

    if (this.storageService.getCurrentLang() === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }

    this.activatedRoute.params.subscribe(params => {
      this.objectId = params['objectId'];
      this.objectType = params['type'];
      console.log(this.objectId);
    });

    const that = this;
    /*this.window.goDetailEvents = {
      'mouseover .impact-level': function (e, value, row, index) {
      $('.tooltip2').eq(index).css('opacity','1.0');
      },
      'mouseout .impact-level': function (e, value, row, index) {
        $('.tooltip2').eq(index).css('opacity','0');
      },
      'click .detail': function (e, value, row, index) {
        that.gotoDetail(row);
      },
      'click .confirm': function (e, value, row, index) {
        that.selectedRows = [];
        that.selectedRows.push(row);
        that.alarmConfirm();
      },
      'click .unconfirm': function (e, value, row, index) {
        that.selectedRows = [];
        that.selectedRows.push(row);
        that.alarmUnConfirm();
      },
      'click .clear': function (e, value, row, index) {
        that.selectedRows = [];
        that.selectedRows.push(row);
      }

    };*/

    this.objectStatusInfo = {
      'health': '',
      'risk': '',
      'efficiency': ''
    };

    this.window.operateEvents = {
      'mouseover .impact-level': function (e, value, row, index) {
        $('.tooltip1').eq(index).css('display', 'block');
        //$('.tooltip1').eq(index).css('opacity','1.0');
      },
      'mouseout .impact-level': function (e, value, row, index) {
        $('.tooltip1').eq(index).css('display', 'none');
        //$('.tooltip1').eq(index).css('opacity','0');
      },
      'mouseover .impactLevel': function (e, value, row, index) {
        $('.tooltip2').eq(index).css('display', 'block');
      },
      'mouseout .impactLevel': function (e, value, row, index) {
        $('.tooltip2').eq(index).css('display', 'none');
      },
      'click .analysis-detail': function(e, value, row, index) {
        that.gotoAnlysis(row);
      },
      'click .detail': function (e, value, row, index) {
        that.gotoDetail(row);
      },
      'click .confirm': function (e, value, row, index) {
        that.selectedRows = [];
        that.selectedRows.push(row);
        that.alarmConfirm();
      },
      'click .unconfirm': function (e, value, row, index) {
        that.selectedRows = [];
        that.selectedRows.push(row);
        that.alarmUnConfirm();
      },
      'click .clear': function (e, value, row, index) {
        that.selectedRows = [];
        that.selectedRows.push(row);
      }
    };

    if (that.authService.containEveryRights(['Smart Alarm Analysis#View'])) {
      that.hasRightSmartAlarms = true;
    }

    if (that.authService.containEveryRights(['Current Alarm#GET'])) {
      that.hasRightCurrentAlarms = true;
    }

  }

  ngOnInit() {

    const that = this;

    setTimeout(function () {
      that.initTable();
    }, 100);


    this.monitorObjectService.getOverviewImpact(this.objectId, this.objectType)
      .then((res: any) => {
        this.objectStatusInfo.health = res.impact.health;
        this.objectStatusInfo.risk = res.impact.risk;
        this.objectStatusInfo.efficiency = res.impact.efficiency;
        console.log(this.objectStatusInfo);
        this.getStatusLevel();
      });

  }

  showLevelContent(field: string, level: string, px1: number, px2: number) {
    const that = this;
    const val = ` <div style="${that.alarmLevel}">
                  <div class="tooltip top tooltip2" role="tooltip" style="${that.alarmTip}">
                      <div class="tooltip-arrow my-arrow-top" style="${that.topArrow}"></div>
                      <div class="alarm-arrow my-arrow-bottom"></div>
                      <div class="tooltip-inner tip-content">` +
                      that.translate.instant(field) + `&nbsp:&nbsp` + that.translate.instant(level) +
                      `</div>
                  </div>

                  <div class="impactLevel">
                      <span  style="${that.alertIconTip} background-position:${px1}px ${px2}px;"></span>
                  </div>
              </div>
              `;
    return val;
  }

  gotoDetail(selectItem: any) {

    const alarmDetail = {
      'alarmId': selectItem.self.split('/').pop(),
      'faultModelId': selectItem.faultModelId,
      'titleFromhealty': false,
      'objectName': selectItem.objectName,
      'objectPath': selectItem.objectPath,
      'objectId': selectItem.objectId,
    };

    this.router.navigate(['/main/alarm/currentalarm/detail', alarmDetail]);

  }

  getStatusLevel() {

    const levelList = {
      'critical': 4,
      'major': 3,
      'minor': 2,
      'warning': 1,
      'info': 0
    };

    if (levelList[this.objectStatusInfo.health] !== undefined) {
      this.healthLevel = levelList[this.objectStatusInfo.health];
    } else {
      this.healthLevel = 'unknown';
    }

    if (levelList[this.objectStatusInfo.risk] !== undefined) {
      this.riskLevel = levelList[this.objectStatusInfo.risk];
    } else {
      this.riskLevel = 'unknown';
    }

    if (levelList[this.objectStatusInfo.efficiency] !== undefined) {
      this.efficiencyLevel = levelList[this.objectStatusInfo.efficiency];
    } else {
      this.efficiencyLevel = 'unknown';
    }

  }

  selectIcon(iconType: any) {
    this.iconSelectedType = iconType;
  }

  showTooltip (e, item) {
    /*$('.tipBox').css('display', 'block');
    $('.tipBox').css('position','absolute');
    var mousePos = this.mousePosition(e);
    var  xOffset = 10;
    var  yOffset = 180;
    $('.tipBox').css('top',(mousePos.y - yOffset) + 'px').css('left',(mousePos.x + xOffset) + 'px');
*/
    this.tipName = item.name;
    this.tipAlarms = item.alarms;
    this.tipHealth = item.health;
    this.tipRisk = item.risk;
    this.tipEfficiency = item.efficiency;
    if (item.type === 'host') {
      this.tipType = this.translate.instant('insight.Objects.HostList');
    } else {
      this.tipType = item.type;
    }

  }

  hideTooltip() {
    //$('.tipBox').css('display', 'none');
  }

  mousePosition(ev) {
    ev = ev || window.event;
    if (ev.pageX || ev.pageY) {
      return {x: ev.pageX, y: ev.pageY};
    }
    return {
      x: ev.clientX + document.body.scrollLeft - document.body.clientLeft,
      y: ev.clientY + document.body.scrollTop - document.body.clientTop
    };
  }

  alarmConfirm() {
    this.reason = '';
    this.modalTitle = this.translate.instant('fm.confirmAlarm');
    this.modalLable = this.translate.instant('fm.confirmDiscription');
    this.alarmType = 'confirmed';
    $('#confirmModal').modal('show');
  }


  alarmUnConfirm() {
    this.reason = '';
    this.modalTitle = this.translate.instant('fm.unconfirm');
    this.modalLable = this.translate.instant('fm.unconfirmDiscription');
    this.alarmType = 'unconfirmed';
    $('#confirmModal').modal('show');
  }

  sureDel() {
    this.deleteCurAlarms();
    this.monitorObjectService.getOverviewImpact(this.objectId, this.objectType)
      .then((res: any) => {
        this.objectStatusInfo.health = res.impact.health;
        this.objectStatusInfo.risk = res.impact.risk;
        this.objectStatusInfo.efficiency = res.impact.efficiency;
        console.log(this.objectStatusInfo);
        this.getStatusLevel();
      });

  }

  deleteCurAlarms() {
    const that = this;
    that.batchDeleteAlarms().subscribe(() => {
      that.selectedRows = [];
      $('#table-overview').bootstrapTable('refresh');
    });
  }

  batchDeleteAlarms() {
    const that = this;
    const selectedCurAlarms: any[] = that.selectedRows;
    return  Observable.from(selectedCurAlarms).flatMap( item => {
      return that.deleteOneAlarm(item);
    });
  }

  deleteOneAlarm(item : any) {
    const url = item['self'];
    return this.http.delete(url);
  }

  confirm() {
    const data: any = {
      alarmIds: [],
      confirmation: {
        state: this.alarmType,
        reason: this.reason,
        operator: this.storageService.getUserName(),
        time: new Date()
      }
    };

    const that = this;


    const selectedCurAlarms: any[] = that.selectedRows;

    for (const item of selectedCurAlarms) {
      const alarmId = item.self.split('/').pop();
      data.alarmIds.push(alarmId);
    }

    that.monitorObjectService.postAlarmComfirmInfo(data)
      .then((res: any) => {
        $('#table-overview').bootstrapTable('refresh');
        that.selectedRows = [];
      });

    $('#confirmModal').modal('hide');
  }

  cancle() {
    $('#confirmModal').modal('hide');
  }

  alarmImgChioce(alarmLevel : any, alarmImact : any) {
    alarmImact = alarmImact.toLowerCase();
    if (alarmLevel === 'critical' || alarmLevel === 'Critical') {
      return {'health': 'assets/images/insight/svg/monitorObject/4_health_min.svg',
        'risk': 'assets/images/insight/svg/monitorObject/4_risk_min.svg',
        'efficiency': 'assets/images/insight/svg/monitorObject/4_efficiency_min.svg'}[alarmImact];
    }
    if (alarmLevel === 'major' || alarmLevel === 'Major') {
      return {'health': 'assets/images/insight/svg/monitorObject/3_health_min.svg',
        'risk': 'assets/images/insight/svg/monitorObject/3_risk_min.svg',
        'efficiency': 'assets/images/insight/svg/monitorObject/3_efficiency_min.svg'}[alarmImact];
    }
    if (alarmLevel === 'minor' || alarmLevel === 'Minor') {
      return {'health': 'assets/images/insight/svg/monitorObject/2_health_min.svg',
        'risk': 'assets/images/insight/svg/monitorObject/2_risk_min.svg',
        'efficiency': 'assets/images/insight/svg/monitorObject/2_efficiency_min.svg'}[alarmImact];
    }
    if (alarmLevel === 'warning' || alarmLevel === 'Warning') {
      return {'health': 'assets/images/insight/svg/monitorObject/1_health_min.svg',
        'risk': 'assets/images/insight/svg/monitorObject/1_risk_min.svg',
        'efficiency': 'assets/images/insight/svg/monitorObject/1_efficiency_min.svg'}[alarmImact];
    }
  }

  levelChoose(level : any, impact : any) {

    if (level === 'critical' || level === 'Critical') {

      return this.translate.instant('fm.critical');
    } else if (level === 'major' || level === 'Major') {

      return this.translate.instant('fm.major');
    } else if (level === 'minor' || level === 'Minor') {

      return this.translate.instant('fm.minor');
    } else if (level === 'warning' || level === 'Warning') {

      return this.translate.instant('fm.warning');
    }
    return '';
  }

  impactChoose(impact : any) {
    impact = impact.toLowerCase();
    if (impact === 'health') {
      return this.translate.instant('fm.impact_health');
    } else if (impact === 'risk') {
      return this.translate.instant('fm.impact_risk');
    } else if (impact === 'efficiency') {
      return this.translate.instant('fm.impact_efficiency');
    }
  }

  gotoAnlysis(modelMsg: any) {
    if (modelMsg.modelType === 'relatedModel') {
      this.router.navigate(['/main/insight/alarm/smart-analysis-detail',
        {modelId: modelMsg.modelId, pageSrc: 'smartAnalysis'}]);
    }
    if (modelMsg.modelType === 'causalModel') {
      this.router.navigate(['/main/alarm/currentalarm/detail',
        {alarmId: modelMsg.alarmId, titleFromhealty: 'smartAnalysis'}]);
    }
  }

}
