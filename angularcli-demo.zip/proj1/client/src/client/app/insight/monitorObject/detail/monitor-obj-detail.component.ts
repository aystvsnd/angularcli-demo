import { Component , OnInit} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {TranslateService} from '@ngx-translate/core';

import { MonitorObjectService } from './../monitor-object.service';
import { AboutMeInfo } from 'monitor-obj-detail.interface';
import { RelatedObjectInfo } from 'monitor-obj-detail.interface';
import { AuthService } from '../../../core/index';

@Component({
  moduleId: module.id,
  selector: 'monitor-obj-detail',
  styleUrls: [ '../../css/common.css', 'monitor-obj-detail.component.less'],
  templateUrl: 'monitor-obj-detail.component.html'
})

export class MonitorObjDetailComponent implements OnInit {

  absoluteLinks: any;
  name: any;
  type: any;
  objectId: any;
  aboutMeInfo: AboutMeInfo;
  relatedObjectInfo: RelatedObjectInfo;
  siblingNum: number;
  childrenNum: number;
  timelineStartCheckNum = 0;

  smartConfigRights = false;

  constructor(private monitorObjectService: MonitorObjectService, private activatedRoute: ActivatedRoute,
              private router: Router, private translate: TranslateService, private authService: AuthService) {

    this.activatedRoute.params.subscribe(params => {

      this.name = params['name'];
      this.type = params['type'];
      this.objectId = params['objectId'];
      this.absoluteLinks = [
        {name: this.translate.instant('insight.Objects.MonitoredObjects'), url: 'main/insight/monitorObject/monitor-obj-list'},
        {name: this.name, url: ''}
      ];

    });

  }

  ngOnInit() {
    this.monitorObjectService.getAboutMeInfo(this.objectId, this.type)
      .then((res: AboutMeInfo) => {

        this.aboutMeInfo = res;
        /*if (this.aboutMeInfo.objType === 'vm') {
          this.aboutMeInfo.objType = this.translate.instant('insight.Objects.Vm');
        } else {
          this.aboutMeInfo.objType = this.translate.instant('insight.Objects.HostList');
        }*/

        if (this.aboutMeInfo.powerStatus === 'RUNNING') {
          this.aboutMeInfo.powerStatus = this.translate.instant('insight.Objects.PowerOn');
        } else if (this.aboutMeInfo.powerStatus === 'SHUTDOWN') {
          this.aboutMeInfo.powerStatus = this.translate.instant('insight.Objects.PowerOff');
        } else {
          this.aboutMeInfo.powerStatus = this.translate.instant('insight.Objects.Unknown');
        }

      });

    this.monitorObjectService.getRelatedObjectInfo(this.objectId)
      .then((res: RelatedObjectInfo) => {
        const that = this;
        that.relatedObjectInfo = res;
        that.relatedObjectInfo.parent = res.parent;
        that.relatedObjectInfo.sibling = res.sibling;
        that.relatedObjectInfo.children = res.children;
        that.siblingNum = that.relatedObjectInfo.sibling.length;
        that.childrenNum = that.relatedObjectInfo.children.length;
      });


    if ( this.authService.containEveryRights(['Smart Config#View', 'Smart Config#Modify']) ) {
      this.smartConfigRights = true;
    } else {
      this.smartConfigRights = false;
    }

  }

  timelineStartCheck() {
    this.timelineStartCheckNum++;
  }

  goToDefaultPolicy(strategyName: any, strategyStatus: any) {
    const strategyDetail = {
      'strategyName': strategyName,
      'strategyStatus': strategyStatus
    };
    this.router.navigate(['/main/insight/strategy/strategy-detail',
      strategyDetail]);
  }

}
