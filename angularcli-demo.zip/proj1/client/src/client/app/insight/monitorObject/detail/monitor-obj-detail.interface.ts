export interface AboutMeInfo {
  objType: string;
  powerStatus: string;
  cpuCores: string;
  mem: string;
  disk: string;
  nic: string;
  os: string;
  hostBelongTo: string;
  az: string;
  cluster: string;
  cloudEnv: string;
  dc: string;
  mirror: string;
  ipAddr: string;
}

export interface DelDcMessage {
  title: string;
  message: string;
  confirmText: string;
  cancelText: string;
  type: string;
  mode: string;
  tip: string;
}

interface Obj {
  objectId: string;
  name: string;
  type: string;
  alarms: number;
  health: string;
  risk: string;
  efficiency: string;
  workload: string;
  remainCapacity: string;
  reclaimCapacity: string;
  stress: string;
}

export interface RelatedObjectInfo {
  parent: Obj;
  sibling: Obj[];
  children: Obj[];
}
