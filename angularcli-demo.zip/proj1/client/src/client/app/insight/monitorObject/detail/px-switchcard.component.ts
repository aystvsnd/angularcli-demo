/**
 * Created by 6092002303 on 2017/3/23.
 */
import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
declare var $: any;
@Component({
  moduleId: module.id,
  template: `
             <div class="switchcard">

               <span *ngFor="let item of headInfo" id="show-{{item.id}}" (click) ="onClickMe(item)">
               <img width="20px" height="20px" src={{imgUrls[item.id]}}>{{item.name}}
               </span>

             </div>

            `,
  selector: 'px-switchcard',
  styles: [
    `
        .switchcard {
          display: flex;
          height: 30px;
          border: solid 1px #bbb;
          border-radius: 3px;
        }

         .switchcard span {
            display: flex;
            flex: auto;
            justify-content: center;
            align-items: center;
            width: 120px;
            border-right: solid 1px #bbb;
            color: #7c868d;
         }

          .switchcard span:hover {
            background: #f8f8f8;
          }

         .switchcard  span:last-of-type {
            border-right: solid 0px #bbb;
         }

          .switchcard span.active {
            background: #eeeeee;
            color: #4d5761;
          }

          .switchcard span:not(.active) {
            cursor: pointer;
          }
    `
  ]
})


export class PxSwitchcardComponent implements OnInit {
  @Input() imgUrls;
  @Input() headNames;
  @Output() headActive = new EventEmitter();

  $showActive : any;
  $forbidActive : any;
  headInfo: any;

  ngOnInit() {
    const that = this;

    that.headInfo = [];

    for (let i = 0; i < that.headNames.length; i++) {

      const obj = new Object();
      obj.name = that.headNames[i];
      obj.id = i;
      /*obj.imgUrl = that.imgUrls[i];*/
      that.headInfo.push(obj);
    }
    $(document).ready(function() {
      that.onClickMe(that.headInfo[0]);
    });
  }


  onClickMe(item: any) {
    this.$forbidActive = $('.switchcard span').removeClass('active');
    this.$showActive = $('#show-' + item.id).addClass('active');
    this.headActive.emit(item.name);
    console.log(item);
  }
}
