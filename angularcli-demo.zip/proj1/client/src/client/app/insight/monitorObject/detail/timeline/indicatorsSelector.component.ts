import { Component, OnInit, OnChanges, Input, Output, EventEmitter} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
//import { PmService } from '../../pm.service';
import { TreeStyle, TreeModel, NodeEvent, NodeSelectedEvent } from '../../../shared/insight-tree/tree.types';
import {Subject} from 'rxjs/Subject';
import {TranslateService} from '@ngx-translate/core';

@Component({
  moduleId: module.id,
  selector: 'indicators-select',
  templateUrl: 'indicatorsSelector.component.html',
  styleUrls: ['indicatorsSelector.component.less'],
})

export class IndicatorsSelectorComponent implements OnInit, OnChanges {
  abstract;
  @Input() options;
  @Output() optionsSelected: EventEmitter<any> = new EventEmitter();
  
  objectTrees: Array<TreeModel> = [];
  indicatorsTrees: Array<TreeModel> = [
    {
        value: 'CPU',
        id: 'CPU',
        children: [
            {value: this.translate.instant('insight.Objects.CpuUtilization'), id: 'C100010004', enabled: true},
            {value: this.translate.instant('insight.Objects.vCpuNum'), id: 'C100010001', enabled: true},
            {value: this.translate.instant('insight.Objects.CpuUtiPeak'), id: 'C100010005', enabled: true},
            {value: this.translate.instant('insight.Objects.CpuUtiTrough'), id: 'C100010006', enabled: true},
            {value: this.translate.instant('insight.Objects.PeakCpuRemainCap'), id: 'C100018013', enabled: true},
            {value: this.translate.instant('insight.Objects.AverCpuRemainCap'), id: 'C100018019', enabled: true},
            {value: this.translate.instant('insight.Objects.CpuRemainCap'), id: 'C100018025', enabled: true},
            {value: this.translate.instant('insight.Objects.CpuStress'), id: 'C100018007', enabled: true},
            {value: this.translate.instant('insight.Objects.CpuReclaimCap'), id: 'C100018043', enabled: true}
        ] as Array<TreeModel>,
        enabled: true
    },
    {
        value: '内存',
        id: '内存',
        children: [
            {value: this.translate.instant('insight.Objects.MemTotal'), id: 'C100011001', enabled: true},
            {value: this.translate.instant('insight.Objects.MemUsed'), id: 'C100011004', enabled: true},
            {value: this.translate.instant('insight.Objects.MemUsedPeak'), id: 'C100011005', enabled: true},
            {value: this.translate.instant('insight.Objects.AverMemUsage'), id: 'P100010001', enabled: true},
            {value: this.translate.instant('insight.Objects.MemStress'), id: 'C100018008', enabled: true},
            {value: this.translate.instant('insight.Objects.PeakMemRemainCap'), id: 'C100018014', enabled: true},
            {value: this.translate.instant('insight.Objects.AverMemRemainCap'), id: 'C100018020', enabled: true},
            {value: this.translate.instant('insight.Objects.MemRemainCap'), id: 'C100018026', enabled: true},
            {value: this.translate.instant('insight.Objects.MemReclaimCap'), id: 'C100018044', enabled: true}
        ] as Array<TreeModel>,
        enabled: true
    },
    {
        value: '磁盘',
        id: '磁盘',
        children: [
            {value: this.translate.instant('insight.Objects.DiskSpaceTotal'), id: 'C100012001', enabled: true},
            {value: this.translate.instant('insight.Objects.DiskSpaceUsed'), id: 'C100012004', enabled: true},
            {value: this.translate.instant('insight.Objects.DiskUsedPeak'), id: 'C100012005', enabled: true},
            {value: this.translate.instant('insight.Objects.DiskIOReadRate'), id: 'C100012010', enabled: true},
            {value: this.translate.instant('insight.Objects.DiskIOWriteRate'), id: 'C100012013', enabled: true},
            {value: this.translate.instant('insight.Objects.AverDiskUsage'), id: 'P100011001', enabled: true},
            {value: this.translate.instant('insight.Objects.PeakDiskRemainCap'), id: 'C100018015', enabled: true},
            {value: this.translate.instant('insight.Objects.AverDiskRemainCap'), id: 'C100018021', enabled: true},
            {value: this.translate.instant('insight.Objects.DiskRemainCap'), id: 'C100018027', enabled: true},
            {value: this.translate.instant('insight.Objects.DiskReclaimCap'), id: 'C100018045', enabled: true}
        ] as Array<TreeModel>,
        enabled: true
    },
    {
        value: 'NIC',
        id: 'NIC',
        children: [
            {value: this.translate.instant('insight.Objects.CurNumOfvNICs'), id: 'C100013001', enabled: true},
            {value: this.translate.instant('insight.Objects.MaxNumOfvNICs'), id: 'C100013002', enabled: true},
            {value: this.translate.instant('insight.Objects.MinNumOfvNICs'), id: 'C100013003', enabled: true}
        ] as Array<TreeModel>,
        enabled: true
    },
    {
        value: 'Net',
        id: 'Net',
        children: [
            {value: this.translate.instant('insight.Objects.NetInRate'), id: 'C100040001', enabled: true},
            {value: this.translate.instant('insight.Objects.NetOutRate'), id: 'C100040004', enabled: true},
            {value: this.translate.instant('insight.Objects.NetInBandwidth'), id: 'C100040007', enabled: true},
            {value: this.translate.instant('insight.Objects.NetOutBandwidth'), id: 'C100040010', enabled: true},
            {value: this.translate.instant('insight.Objects.NetInRatePeak'), id: 'C100040002', enabled: true},
            {value: this.translate.instant('insight.Objects.NetOutRatePeak'), id: 'C100040005', enabled: true},
            {value: this.translate.instant('insight.Objects.NetInRateTrough'), id: 'C100040003', enabled: true},
            {value: this.translate.instant('insight.Objects.NetOutRateTrough'), id: 'C100040006', enabled: true},
            {value: this.translate.instant('insight.Objects.NetInBytes'), id: 'C100040027', enabled: true},
            {value: this.translate.instant('insight.Objects.NetOutBytes'), id: 'C100040028', enabled: true},
            {value: this.translate.instant('insight.Objects.NetInPackets'), id: 'C100040029', enabled: true},
            {value: this.translate.instant('insight.Objects.NetOutPackets'), id: 'C100040030', enabled: true},
            {value: this.translate.instant('insight.Objects.NetInLostPackets'), id: 'C100040031', enabled: true},
            {value: this.translate.instant('insight.Objects.NetOutLostPackets'), id: 'C100040032', enabled: true},
            {value: this.translate.instant('insight.Objects.NetInErrorPackets'), id: 'C100040033', enabled: true},
            {value: this.translate.instant('insight.Objects.NetOutErrorPackets'), id: 'C100040034', enabled: true},
            {value: this.translate.instant('insight.Objects.NetInWorkload'), id: 'C100018002', enabled: true},
            {value: this.translate.instant('insight.Objects.NetOutWorkload'), id: 'C100018003', enabled: true},
            {value: this.translate.instant('insight.Objects.NetBiTransWorkload'), id: 'C100018004', enabled: true},
            {value: this.translate.instant('insight.Objects.NetInStress'), id: 'C100018009', enabled: true},
            {value: this.translate.instant('insight.Objects.NetOutStress'), id: 'C100018010', enabled: true},
            {value: this.translate.instant('insight.Objects.NetBiTransStress'), id: 'C100018011', enabled: true},
            {value: this.translate.instant('insight.Objects.PeakNetInRemainCap'), id: 'C100018016', enabled: true},
            {value: this.translate.instant('insight.Objects.PeakNetOutRemainCap'), id: 'C100018017', enabled: true},
            {value: this.translate.instant('insight.Objects.PeakNetBiTransRemainCap'), id: 'C100018018', enabled: true},
            {value: this.translate.instant('insight.Objects.AverNetInRemainCap'), id: 'C100018022', enabled: true},
            {value: this.translate.instant('insight.Objects.AverNetOutRemainCap'), id: 'C100018023', enabled: true},
            {value: this.translate.instant('insight.Objects.AverNetBiTransRemainCap'), id: 'C100018024', enabled: true},
            {value: this.translate.instant('insight.Objects.NetInRemainCap'), id: 'C100018028', enabled: true},
            {value: this.translate.instant('insight.Objects.NetOutRemainCap'), id: 'C100018029', enabled: true},
            {value: this.translate.instant('insight.Objects.NetBiTransRemainCap'), id: 'C100018030', enabled: true}
        ] as Array<TreeModel>,
        enabled: true
    },
    {
        value: 'other',
        id: 'other',
        children: [
            {value: this.translate.instant('insight.Objects.Workload'), id: 'C100018006', enabled: true},
            {value: this.translate.instant('insight.Objects.Stress'), id: 'C100018012', enabled: true},
            {value: this.translate.instant('insight.Objects.RemainCapacity'), id: 'C100018031', enabled: true},
            {value: this.translate.instant('insight.Objects.ReclaimCapacity'), id: 'C100018046', enabled: true}
        ] as Array<TreeModel>,
        enabled: true
    }
  ];

  objectsLeafs: Array<TreeModel> = [];
  objectsSelectedLeaf: TreeModel;

  indicatorsLeafs: Array<TreeModel> = [];
  indicatorsCheckedLeafs: {leaf: TreeModel, object: TreeModel}[] = [];
  
  selectedIndicators: Array<any> = [];
  indicatorsSelectedLists: Array<any> = [];

  objectTreeStyle: TreeStyle = {
    isPlusImage: false,
    isCheckBox: false,
    nodeWidth: '100px',
    nodeDisplayCharacter: 45,
  };
  indicatorTreeStyle: TreeStyle = {
    isPlusImage: false,
    isCheckBox: true,
    nodeWidth: '200px',
    nodeDisplayCharacter: 45,
  };

  searchObjectsContext: string;
  searchIndicatorsContext: string;

  objectsNodeCheckedSubject: Subject<NodeSelectedEvent> = new Subject<NodeSelectedEvent>();
  indicatorsNodeCheckedSubject: Subject<NodeSelectedEvent> = new Subject<NodeSelectedEvent>();

  objectsNodeSelectedSubject: Subject<NodeSelectedEvent> = new Subject<NodeSelectedEvent>();
  indicatorsNodeSelectedSubject: Subject<NodeSelectedEvent> = new Subject<NodeSelectedEvent>();

  indicatorsUnCheckedNode: Subject<TreeModel> = new Subject<TreeModel>();
  indicatorsAllNodeUnChecked: Subject<boolean> = new Subject<boolean>();
  objectsContextCleared: Subject<string> = new Subject<string>();
  indicatorsContextCleared: Subject<string> = new Subject<string>();
  displayCharacterNum: number = 25;

  @Input() objectId: string;
  @Input() objectType: string;
  @Input() objectName: string;

  constructor(private translate: TranslateService, private activatedRoute: ActivatedRoute) {
    this.activatedRoute.params.subscribe(params => {
      this.objectId = params['objectId'];
      this.objectType = params['type'];
      this.objectName = params['name'];
      console.log('objectId:' + this.objectId + ',type:' + this.objectType + ',name:' + this.objectName);
    });
  }

  ngOnInit() {
    $('.tableSearch .inputSearch').attr('placeholder', this.translate.instant('pm.searchPlaceholder'));
    this.objectsNodeCheckedSubject.subscribe((e:NodeEvent) => {
      console.log('objectsNodeCheckedSubject=',e);
    });
    this.indicatorsNodeCheckedSubject.subscribe((e:NodeEvent) => {
      console.log('indicatorsNodeCheckedSubject=',e);
      this.onIndicatorsNodeChecked(e);
    });
    this.objectsNodeSelectedSubject.subscribe((e:NodeEvent) => {
      console.log('objectsNodeSelectedSubject=',e);
      if (e.node.children === undefined || e.node.children === null)
        this.onObjectNodeSelected(e);
    });
    this.indicatorsNodeSelectedSubject.subscribe((e:NodeEvent) => {
      console.log('indicatorsNodeSelectedSubject=',e);
    });
  }

  ngOnChanges() {
    if(this.options !== undefined) {
      this.selectedIndicators = [];
      this.objectTrees = [];
      this.indicatorsSelectedLists = [];
      this.indicatorsCheckedLeafs = [];
      this.indicatorsAllNodeUnChecked.next(true);
      this.constructObjectsTrees();
      this.initIndicatorsTrees();
    }

  }
// interface Obj {
//   objectId: string;
//   name: string;
//   type: string;
//   alarms: number;
//   health: string;
//   risk: string;
//   efficiency: string;
//   workload: string;
//   remainCapacity: string;
//   reclaimCapacity: string;
//   stress: string;
// };

// export interface RelatedObjectInfo {
//   parent: Obj;
//   sibling: Obj[];
//   children: Obj[];
// };

  constructObjectsTrees() {
    const that = this;
    const tmp = [];
    let self = <TreeModel>{
      value: "自身",
      id: this.objectId,
      type: this.objectType,
      enabled: true,
      name: this.objectName,
    };
    let parent = <TreeModel>{
      value: "父级对象",
      id: "parent",
      children: [],
      enabled: true,
    };
    let children = <TreeModel>{
      value: "子级对象",
      id: "children",
      children: [],
      enabled: true,
    };
    let sibling = <TreeModel>{
      value: "兄弟级对象",
      id: "sibling",
      children: [],
      enabled: true,
    };
    let parentValue;
    if (that.options.parent.type === 'host') {
      parentValue = `<p><img src="assets/images/insight/svg/host.svg">`;
    } else if (that.options.parent.type === 'vm') {
      parentValue = `<p><img src="assets/images/insight/svg/VM.svg">`;
    } else if (that.options.parent.type === 'disk') {
      parentValue = `<p><img src="assets/images/insight/svg/Volumes.svg">`;
    }

    let indicators = {}

    parent.children.push(<TreeModel>{
      value: parentValue + `<span>` + that.options.parent.name + `</span></p>`,
      id: that.options.parent.objectId,
      parent: parent,
      enabled: true,
      type: that.options.parent.type,
      name: that.options.parent.name,
    });

    _.each(that.options.children, function (item) {
      let childrenValue;
      if (item.type === 'host') {
        childrenValue = `<p><img src="assets/images/insight/svg/host.svg">`;
      } else if (item.type === 'vm') {
        childrenValue = `<p><img src="assets/images/insight/svg/VM.svg">`;
      } else if (item.type === 'disk') {
        childrenValue = `<p><img src="assets/images/insight/svg/Volumes.svg">`;
      }
      children.children.push(<TreeModel>{
        value: childrenValue + `<span>` + item.name + `</span></p>`,
        id: item.objectId,
        parent: children,
        enabled: true,
        type: item.type,
        name: item.name,
      });
    });

    _.each(that.options.sibling, function (item) {
      let siblingValue;
      if (item.type === 'host') {
        siblingValue = `<p><img src="assets/images/insight/svg/host.svg">`;
      } else if (item.type === 'vm') {
        siblingValue = `<p><img src="assets/images/insight/svg/VM.svg">`;
      } else if (item.type === 'disk') {
        siblingValue = `<p><img src="assets/images/insight/svg/Volumes.svg">`;
      }
      sibling.children.push(<TreeModel>{
        value: siblingValue + `<span>` + item.name + `</span></p>`,
        id: item.objectId,
        parent: sibling,
        enabled: true,
        type: item.type,
        name: item.name,
      });
    });
    tmp.push(self);
    tmp.push(parent);
    tmp.push(children);
    tmp.push(sibling);

    this.objectTrees = tmp;
    this.objectsSelectedLeaf = self;
  }

  initIndicatorsTrees() {
    _.each(this.indicatorsTrees, function(indicators) {
      _.each(indicators.children, function(indicator) {
        indicator.parent = indicators;
      });
    });
  }

  onObjectNodeSelected(e: NodeEvent) {
    let that = this;
    this.objectsSelectedLeaf = e.node;
    _.each(this.indicatorsTrees, function(indicators) {
      indicators._checkboxFlag = false;
      _.each(indicators.children, function(indicator) {
        indicator._checkboxFlag = false;
      });
    });
    _.each(this.objectsSelectedLeaf.indicators, function(selIndicator) {
      _.each(that.indicatorsTrees, function(indicators) {
        if (selIndicator.parent === indicators) {
          selIndicator.parent._checkboxFlag = true;
          _.each(selIndicator.parent.children, function(indicator) {
            if (indicator === selIndicator) {
              indicator._checkboxFlag = true;
            }
          });
        }
      });
    });
  }

  onIndicatorsNodeChecked(e: NodeEvent) {
    this.setCheckedIndicators(e.node);
  }

  setCheckedIndicators(node: TreeModel) {
    let that = this;
    this.indicatorsLeafs = [];
    this.indicatorsLeafs = this.getIndicatorsLeaf(node);

    if (this.indicatorsLeafs.length === 0) return;
    if (this.indicatorsLeafs[0]._checkboxFlag === true) {
       _.each(this.indicatorsLeafs, function(indicatorsLeaf) {
        that.indicatorsCheckedLeafs = _.union(that.indicatorsCheckedLeafs, [{leaf: indicatorsLeaf, object: that.objectsSelectedLeaf}]);
      });
      this.objectsSelectedLeaf.indicators = _.union(this.objectsSelectedLeaf.indicators, this.indicatorsLeafs);
    } else {
       _.each(this.indicatorsLeafs, function(indicatorsLeaf) {
         _.each(that.indicatorsCheckedLeafs, function(leaf) {
           if (leaf.leaf === indicatorsLeaf && leaf.object === that.objectsSelectedLeaf)
            that.indicatorsCheckedLeafs = _.difference(that.indicatorsCheckedLeafs, [leaf]);
         });
      });
      this.objectsSelectedLeaf.indicators = _.difference(this.objectsSelectedLeaf.indicators, this.indicatorsLeafs);
    }
    this.indicatorsUpdateCheckedOptions();
  }

  getObjectsLeaf(node: TreeModel): Array<TreeModel> {
    const that = this;
    if (node.children === undefined || node.children === null) {
      that.objectsLeafs.push(node);
    } else {
      _.each(node.children, function (child) {
        that.getObjectsLeaf(child);
      });
    }
    return that.objectsLeafs;
  }
  getIndicatorsLeaf(node: TreeModel): Array<TreeModel> {
    const that = this;
    if (node.children === undefined || node.children === null) {
      that.indicatorsLeafs.push(node);
    } else {
      _.each(node.children, function (child) {
        that.getIndicatorsLeaf(child);
      });
    }
    return that.indicatorsLeafs;
  }

  indicatorsUpdateCheckedOptions() {
    const that = this;
    this.selectedIndicators = [];
    _.each(this.indicatorsCheckedLeafs, function (leaf) {
      const one: any = {
        id: leaf.leaf.id,
        value: leaf.leaf.value,
        object: leaf.object
      };
      that.selectedIndicators.push(one);
    });

    this.constructSelectedLists();
  }

  constructSelectedLists() {
    const tmp: Array<any> = [];
    _.each(this.selectedIndicators, function (item) {
      tmp.push(item.object.name + ' ' + item.value);
    });
    this.indicatorsSelectedLists = tmp;
  }

  clearDisplayItem(index: number, item: string) {
    $('#button' + index).parent().remove();
    this.updateCheckedElements(item, index);
  }

  updateCheckedElements(item: string, index: number) {
    this.updateCheckedLeafs(item, index);
    this.indicatorsUpdateCheckedOptions();
  }

  updateCheckedLeafs(item: string, index: number) {
    let that = this;
    // const index = _.findIndex(this.indicatorsCheckedLeafs, function (leaf) {
    //   return leaf.object.name + ' ' + leaf.leaf.value === item;
    // });
    if (index === -1) return;
    if (this.indicatorsCheckedLeafs[index].object === this.objectsSelectedLeaf) {
      this.indicatorsUnCheckedNode.next(this.indicatorsCheckedLeafs[index].leaf);
    }
    _.each(this.objectTrees, function(tree) {
      if (that.indicatorsCheckedLeafs[index].object === tree) {
        tree.indicators = _.difference(tree.indicators, [that.indicatorsCheckedLeafs[index].leaf]);
      }
      _.each(tree.children, function(leaf) {
        if (that.indicatorsCheckedLeafs[index].object === leaf) {
          leaf.indicators = _.difference(leaf.indicators, [that.indicatorsCheckedLeafs[index].leaf]);
        }
      });
    });
    this.indicatorsCheckedLeafs.splice(index, 1);
  }

  clearAllIndicators() {
    let that = this;
    this.indicatorsAllNodeUnChecked.next(true);
    this.indicatorsCheckedLeafs = [];
    this.optionsSelected.emit([]);
    this.indicatorsSelectedLists = [];
    this.selectedIndicators = [];
    _.each(this.objectTrees, function(tree) {
      tree.indicators = [];
      _.each(tree.children, function(leaf) {
        leaf.indicators = [];
      });
    });
  }

  select() {
    // const final = _.map(this.selectedIndicators, function (i) {
    //   const middle = _.omit(i, 'name');
    //   return _.omit(middle, 'parentName');
    // });

    let final = [];
    _.map(this.indicatorsCheckedLeafs, function (leaf) {
      let role;
      final.push({objectId: leaf.object.id, objectType: leaf.object.type, objectName: leaf.object.name, id: leaf.leaf.id});
      //final.push({objectId: leaf.leaf.id, value: leaf.leaf.value, object: leaf.object.value});
    });
    console.log("final_in=", final);
    this.optionsSelected.emit(final);
    $('#indicatorsSelector').modal('hide');
    this.objectsContextCleared.next('');
    this.indicatorsContextCleared.next('');
  }

  dismiss() {
    // const final = _.map(this.selectedIndicators, function (i) {
    //   const middle = _.omit(i, 'name');
    //   return _.omit(middle, 'parentName');
    // });

    // this.optionsSelected.emit(final);
    this.objectsContextCleared.next('');
    this.indicatorsContextCleared.next('');
  }

  searchObjectsContent(e: string) {
    this.searchObjectsContext = e;
  }

  searchIndicatorsContent(e: string) {
    this.searchIndicatorsContext = e;
  }

  getDisplayItem(item: any) {
    return (item.length > this.displayCharacterNum) ? (item.substring(0, this.displayCharacterNum) + '...') : item;
  }

}



