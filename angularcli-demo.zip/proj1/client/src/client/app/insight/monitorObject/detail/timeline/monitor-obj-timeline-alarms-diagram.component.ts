import {Component, OnInit, Input, Output, OnChanges, SimpleChanges, AfterViewInit,EventEmitter } from '@angular/core';

import { ActivatedRoute } from '@angular/router';

import { MonitorObjectService } from '../../monitor-object.service';
import { CommonFunctionService } from '../../../common/common-function.service';
import {TranslateService} from '@ngx-translate/core';
import {StorageService } from '../../../../storage.service';
import { AuthService } from '../../../../core/index';

import {ObjectIcon} from '../../object-const';

@Component({
  moduleId: module.id,
  selector: 'monitor-obj-timeline-alarms-diagram',
  styleUrls: ['../../../css/common.css',
              'monitor-obj-timeline-alarms-diagram.component.less',
              '../../monitor-obj-list.component.less'],
  templateUrl: 'monitor-obj-timeline-alarms-diagram.component.html'
})

export class MonitorObjDetailTimelineDiagramComponent implements OnInit, OnChanges, AfterViewInit{

  @Input() startTime;
  @Input() endTime;
  @Input() currentTime;
  @Input() widthChanged;
  @Input() showType;
  @Input() relatedObjectInfo;
  @Input() selectedObjectInfo;
  @Output() objectInfoSelected = new EventEmitter();

  allAlarms: any;
  recentAlarms: any;
  recentAlarmsFiltered: any;
  currentAlarms: any;

  selfAllAlarms: any;
  relatedAllAlarms: any;

  futureTime = 0;

  objectId: any;
  objectType: any;
  objectName:String;
  objTypeIcon: any = `width:20px;height:20px;margin-right:5px;`;
  initTableFlag = false;
  currentLang = 'zh';

  tipInfo: any;

  window: window = window;

  viewInited = false;

  hasRightGetCurrentAlarms = false;
  hasRightGetHistoryAlarms = false;

  impactTypeList = {
    'health':true,
    'risk':true,
    'efficiency':true
  };

  levelList = {
    'critical':true,
    'major':true,
    'minor':true,
    'warning':true
  };

  objectsSelected = [];
  parentObjectNum = 0;
  siblingObjectNum = 0;
  childrenObjectNum = 0;

  constructor(private monitorObjectService: MonitorObjectService,
              private commonFunctionService: CommonFunctionService,
              private translate: TranslateService,
              private storageService: StorageService,
              private authService: AuthService,
              private activatedRoute: ActivatedRoute) {

    this.activatedRoute.params.subscribe(params => {
      this.objectId = params['objectId'];
      this.objectType = params['type'];
      this.objectName = params['name'];
    });

    this.tipInfo = {
      description: '',
      imgUrl: '',
      objectName: '',
    };

    this.currentLang = this.storageService.getCurrentLang();

    this.recentAlarms = [];
    this.recentAlarmsFiltered = [];
    this.allAlarms = [];
    this.currentAlarms = [];

    this.selfAllAlarms = [];
    this.relatedAllAlarms = [];

    if (this.authService.containEveryRights(['Current Alarm#GET'])) {
      this.hasRightGetCurrentAlarms = true;
    }

    if (this.authService.containEveryRights(['History Alarm#GET'])) {
      this.hasRightGetHistoryAlarms = true;
    }

  }

  ngAfterViewInit() {
    this.viewInited = true;
    this.setCurrentTimeLinePos();
  }


  ngOnChanges(changes: SimpleChanges) {

    if (changes['endTime']) {
      const myDate = new Date(this.endTime);
      this.futureTime = (myDate.getFullYear() + 1000) + '-' + ( myDate.getMonth() + 1) + '-' + myDate.getDate()
          + ' ' +  myDate.getHours() + ':' + myDate.getMinutes();

      this.getAlarmsData();
      this.setCurrentTimeLinePos();
    }

    if (changes['widthChanged']) {
      this.drawAlarms();
    }

    if (changes['currentTime'] || changes['widthChanged']) {
      this.showCurrentAlarms();
    }

    if (changes['showType']) {
      this.showCurrentAlarms();
    }

    if (changes['selectedObjectInfo']) {
      this.objectsSelected = this.selectedObjectInfo;
    }

  }


  getAlarmsData() {

    const that = this;

    if (false === that.hasRightGetCurrentAlarms) {
      return;
    }

    that.allAlarms = [];
    that.selfAllAlarms = [];
    that.relatedAllAlarms = [];

    this.monitorObjectService.getCurrentAlarms(this.objectType, this.objectId)
      .then(res => {

        for (const alarm of res.alarms) {
          alarm.restoreTime = that.futureTime;
          alarm.objectName = alarm.alarmObject;
          alarm.future = true;
          that.allAlarms.push(alarm);
        }

        if (false === that.hasRightGetHistoryAlarms) {

          $.extend(true, that.selfAllAlarms, that.allAlarms);

          that.drawAlarms();
          that.getCurrentAlarms(that.endTime);

          if (that.initTableFlag === false) {
            that.initTableFlag = true;
            that.initTable();
          } else {
            const $table = $('#table-current-alarms');
            $table.bootstrapTable('load', that.currentAlarms);
          }

        } else {

          that.monitorObjectService.getRecentHistoryAlarms(that.objectType, that.objectId , that.startTime, that.endTime)
              .then(res => {

            that.allAlarms = that.allAlarms.concat(res);
            $.extend(true, that.selfAllAlarms, that.allAlarms);

            that.drawAlarms();
            that.getCurrentAlarms(that.endTime);

            if (that.initTableFlag === false) {
              that.initTableFlag = true;
              that.initTable();
            } else {
              const $table = $('#table-current-alarms');
              $table.bootstrapTable('load', that.currentAlarms);
            }

            if(that.objectsSelected.length > 0) {
              that.optionsSelected(that.objectsSelected);
            }

          });

        }

      });

  }


  setCurrentTimeLinePos() {

    if(this.showType !== 'graph' || this.viewInited === false) {
      return;
    }

    const parentLeft = $('#px-timeline-div').offset().left;
    const parentWidth = $('#px-timeline-div').width();
    const timeShowWidth = $('#time-show-div').width();
    const timeShowLeft = $('#time-show-div').offset().left;

    const currentTimeLine = document.getElementById('currentTimeLine');

    let newPos = timeShowLeft - parentLeft + 30 + timeShowWidth / 2;

    if (newPos < 30) {
      newPos = 30;
    } else if (newPos > (parentWidth  + 28)) {
      newPos = parentWidth  + 28;
    }
    currentTimeLine.style.left = newPos + 'px';

  }


  showCurrentAlarms() {

    this.setCurrentTimeLinePos();

    this.getCurrentAlarms(new Date(this.currentTime).getTime());

    if(this.currentAlarms.length > 0) {
      this.showTooltipAlarm();
    } else {
      this.hideTooltipAlarm();
    }

    const $table = $('#table-current-alarms');
    $table.bootstrapTable('load', this.currentAlarms);

  }

  initTable() {
    const that = this;
    const $table = $('#table-current-alarms');
    const gridOptions = {
      undefinedText: ''
    };

    const columnDefs = [
      {
        field: 'level',
        align: 'middle',
        title: this.translate.instant('fm.impact_level'),
        formatter: function (value, row, index) {
          const levelVaule = value.toLowerCase();
          const imgUrl = that.getLevelImgUrl(levelVaule);
          return `<div>
                  <img class="objImg" src="${imgUrl}">
                  <div>`;
        }
      },
      {
        field: 'description',
        align: 'left',
        title: this.translate.instant('fm.description'),
        formatter: function (value, row, index) {
          return value;
        }
      },
      {
        field: 'objectName',
        align: 'left',
        title: this.translate.instant('insight.Objects.Object'),
        formatter: function (value, row, index) {
          const objectTypeArray = [ 'cloudEnv', 'chassis', 'cloud', 'host', 'rack', 'router', 'storage',
                              'server', 'switch', 'vm', 'volume', 'system'];
          const objectType = row.objectType;

          const pos = value.indexOf('vmname=');
          let name = '';
          if (pos >= 0) {
            const length = value.length;
            name = value.slice(pos + 7, length);
          }

          if ($.inArray(objectType, objectTypeArray) >= 0) {
            return `<img src="assets/images/alarmObj/alarm_${objectType}.svg" style="${that.objTypeIcon}" /><span>${name}</span>`;
          } else {
            return `<span>${name}</span>`;
          }
        }
      },
      {
        field: 'alarmTime',
        align: 'left',
        title: this.translate.instant('fm.alarmTime'),
        formatter: function (value, row, index) {
          return that.commonFunctionService.serverTimeToLocalTime(value);
        }
      },
      {
        field: 'restoreTime',
        align: 'left',
        title: this.translate.instant('fm.recoverTime'),
        formatter: function (value, row, index) {
          if (row.future !== undefined && row.future === true) {
            return '--';
          } else {
            return that.commonFunctionService.serverTimeToLocalTime(value);
          }
        }
      }
    ];

    $table.bootstrapTable($.extend(gridOptions, {
      height: 270,
      data: that.currentAlarms,
      escape:true,
      columns: columnDefs
    }));
    $table.bootstrapTable('load', that.currentAlarms);
  }


  drawAlarms() {

    const levelColor = {
      'critical': '#ff322b',
      'major': '#fc803e',
      'minor': '#feb731',
      'warning': '#ffe326',
      'info': '#5cb85c'
    };

    const lineWidth = $('#px-timeline-div').width();

    const minOffset = 30;
    const maxOffset = minOffset + lineWidth;
    const leftOffset = minOffset;

    this.recentAlarms = [];
    this.recentAlarmsFiltered = [];

    for (const alarm of this.allAlarms) {

      if (levelColor[alarm.level] !== undefined) {
        alarm.color = levelColor[alarm.level];
      } else {
        alarm.color = '#c2c6c9';
      }

      let alarmStartTime =  new Date(alarm.alarmTime).getTime();
      let alarmEndTime =  new Date(alarm.restoreTime).getTime();

      if (alarmEndTime >= this.startTime && alarmStartTime <= this.endTime) {

        if (alarmStartTime < this.startTime) {
          alarmStartTime = this.startTime;
        }

        if (alarmEndTime > this.endTime) {
          alarmEndTime = this.endTime;
        }

        alarm.left = leftOffset + (alarmStartTime - this.startTime) * (maxOffset - minOffset) / (this.endTime - this.startTime);
        alarm.width = (alarmEndTime - alarmStartTime) * (maxOffset - minOffset) / (this.endTime - this.startTime);

        this.recentAlarms.push(alarm);

        if((this.impactTypeList[alarm.impact] === true) && (this.levelList[alarm.level] === true)) {
          this.recentAlarmsFiltered.push(alarm);
        }

      }

    }

  }

  getCurrentAlarms(currentTime: any) {

    this.currentAlarms = [];

    for (const alarm of this.recentAlarmsFiltered) {

      const alarmStartTime =  new Date(alarm.alarmTime).getTime();
      const alarmEndTime =  new Date(alarm.restoreTime).getTime();


      if (alarmStartTime <= currentTime && currentTime <= alarmEndTime) {
        if((this.impactTypeList[alarm.impact] === true)  && (this.levelList[alarm.level] === true)) {
          alarm.typeImgUrl = this.getTypeImgUrl(alarm.objectType);
          alarm.levelImgUrl = this.getLevelImgUrl(alarm.level);
          alarm.shortName = this.getShortName(alarm.objectName);
          this.currentAlarms.push(alarm);
        }

      }

    }

  }

  showTooltipAlarm () {

    if(this.showType === 'list') {
      return;
    }

    const currentTimeLine = document.getElementById('currentTimeLine');

    if(null === currentTimeLine.offsetLeft || null === currentTimeLine.offsetParent) {
      return;
    }

    const divCanvas = document.getElementsByClassName('canvas');
    /*const widthCanvas = divCanvas[0].clientWidth;*/

    const tipAlarm = document.getElementById('tip-alarm');

    var leftPos = parseInt(currentTimeLine.offsetLeft);
    var leftPosParent = parseInt(currentTimeLine.offsetParent.offsetLeft);

    if(0 === tipAlarm.clientWidth) {
      leftPos = (leftPosParent + leftPos / 2) +  'px';
    } else {
      if((leftPos + 20 + tipAlarm.clientWidth) > currentTimeLine.offsetParent.clientWidth) {

        if( (leftPos - 20 - tipAlarm.clientWidth) > 0 ) {
          leftPos = leftPos +　leftPosParent - 20 - tipAlarm.clientWidth + 'px';
        } else {
          leftPos = leftPosParent + 'px';
        }

      } else {
        leftPos = leftPos +　leftPosParent + 20 + 'px';
      }
    }



    $('#tip-alarm').css('display', 'flex');
    $('#tip-alarm').css('top', (350) + 'px').css('left', leftPos);

  }

  hideTooltipAlarm () {
    $('#tip-alarm').css('display', 'none');
  }

  mousePosition(ev) {
    ev = ev || window.event;
    if (ev.pageX || ev.pageY) {
      return {x: ev.pageX, y: ev.pageY};
    }
    return {
      x: ev.clientX + document.body.scrollLeft - document.body.clientLeft,
      y: ev.clientY + document.body.scrollTop - document.body.clientTop
    };
  }

  showTooltip (e, type) {

    const stringList = {
      'critical': this.translate.instant('fm.critical'),
      'major': this.translate.instant('fm.major'),
      'minor': this.translate.instant('fm.minor'),
      'warning': this.translate.instant('fm.warning'),

      'health': this.translate.instant('insight.Objects.Health'),
      'risk': this.translate.instant('insight.Objects.Risk'),
      'efficiency': this.translate.instant('insight.Objects.Efficiency')
    };

    if (stringList[type] !== undefined) {
      this.tipInfo = stringList[type];
    } else {
      return;
    }

    $('#tip-SelectedType').css('display', 'block');
    var mousePos = this.mousePosition(e);
    var  xOffset = -10;
    var  yOffset = -10;
    $('#tip-SelectedType').css('top',(mousePos.y - yOffset) + 'px').css('left',(mousePos.x + xOffset) + 'px');

  }

  hideTooltip() {
    $('#tip-SelectedType').css('display', 'none');
  }

  getLevelImgUrl(levelAlarm: any) {
    var level = levelAlarm.toLowerCase();
    return `assets/images/insight/svg/Alert_${level}.svg`;
  }

  getShortName(objectName: any) {
    var substrArray = objectName .split("=");
    return substrArray[substrArray.length - 1];
  }

  getTypeImgUrl(typeObject: any) {
    var type = typeObject.toLowerCase();
    return ObjectIcon[type].url;
  }

  filterRecentAlarms () {

    this.recentAlarmsFiltered = [];

    for (const alarm of this.recentAlarms) {

        if((this.impactTypeList[alarm.impact] === true)  && (this.levelList[alarm.level] === true)) {
          this.recentAlarmsFiltered.push(alarm);
        }

    }

  }

  changeImpactTypeSelected (type: String) {
    let that = this;
    this.impactTypeList[type] = !(this.impactTypeList[type]);

    this.filterRecentAlarms();

    this.showCurrentAlarms();

    setTimeout(function () {
      if(that.currentAlarms.length > 0) {
        that.showTooltipAlarm();
      }
    }, 100);
  }

  changeLevelSelected (level: String) {
    let that = this;
    this.levelList[level] = !(this.levelList[level]);

    this.filterRecentAlarms();

    this.showCurrentAlarms();

    setTimeout(function () {
      if(that.currentAlarms.length > 0) {
        that.showTooltipAlarm();
      }
    }, 100);
  }

  selectObjects() {
    $('#indicatorSelector').modal('show');
  }

  optionsSelected(objects: any) {
    let parentObjectNumTemp = 0;
    let siblingObjectNumTemp = 0;
    let childrenObjectNumTemp = 0;

    this.objectsSelected = objects;
    for ( const index in objects) {
      if(objects[index].role === 'parent') {
        parentObjectNumTemp++;
      } else if (objects[index].role === 'sibling') {
        siblingObjectNumTemp++;
      } else if (objects[index].role === 'children') {
        childrenObjectNumTemp++;
      }
    }

    this.parentObjectNum = parentObjectNumTemp;
    this.siblingObjectNum = siblingObjectNumTemp;
    this.childrenObjectNum = childrenObjectNumTemp;
    console.log("final_out=", this.objectsSelected);

    this.objectInfoSelected.emit(this.objectsSelected);

    this.getRelatedObjectsAlarmsData(objects);
  }

  getRelatedObjectsAlarmsData(objects: any) {

    const that = this;
    const promises = objects.map(function(object) {
      return that.getObjectAlarmsData(object);
    });
    that.relatedAllAlarms = [];

    Promise.all(promises).then(function() {

      that.allAlarms = that.selfAllAlarms.concat(that.relatedAllAlarms);
      that.drawAlarms();

      that.filterRecentAlarms();

      that.showCurrentAlarms();

      setTimeout(function () {
        if(that.currentAlarms.length > 0) {
          that.showTooltipAlarm();
        }
      }, 100);

    });

  }

  getObjectAlarmsData(object: any) : Promise<any> {
    const that = this;
    return new Promise<any> ((resolve, reject) => {

      this.monitorObjectService.getCurrentAlarms(object.type, object.objectId)
          .then(res => {

            for (const alarm of res.alarms) {
              alarm.restoreTime = that.futureTime;
              alarm.objectName = alarm.alarmObject;
              alarm.future = true;
              that.relatedAllAlarms.push(alarm);
            }

            if (false === that.hasRightGetHistoryAlarms) {
              resolve(that.relatedAllAlarms);
            } else {

              that.monitorObjectService.getRecentHistoryAlarms(object.type, object.objectId , that.startTime, that.endTime)
                  .then(res => {

                    that.relatedAllAlarms = that.relatedAllAlarms.concat(res);
                    resolve(that.relatedAllAlarms);

                  })
                  .catch(err => {
                    reject(err);
                  });

            }

          })
          .catch(err => {
            reject(err);
          });

    });

  }


}
