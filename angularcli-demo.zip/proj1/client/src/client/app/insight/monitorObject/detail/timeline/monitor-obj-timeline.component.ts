import {Component, OnInit, Input, OnChanges, SimpleChanges, DoCheck } from '@angular/core';

import { ActivatedRoute } from '@angular/router';

import { MonitorObjectService } from '../../monitor-object.service';
import { CommonFunctionService } from '../../../common/common-function.service';
import {TranslateService} from '@ngx-translate/core';

@Component({
  moduleId: module.id,
  selector: 'monitor-obj-detail-timeline',
  styleUrls: ['../../../css/common.css', 'monitor-obj-timeline.component.less', '../monitor-obj-detail.component.less'],
  templateUrl: 'monitor-obj-timeline.component.html'
})

export class MonitorObjDetailTimelineComponent implements OnInit, OnChanges, DoCheck {
  @Input() aboutMeInfo;
  @Input() startCheck;
  @Input() relatedObjectInfo;

  selectedObjectInfo = [];
  //relatedObjectInfo: any;
  tipName: string;
  tipType: string;
  tipAlarms: number;
  tipHealth: string;
  tipRisk: string;
  tipEfficiency: string;
  iconSelectedType = 'health';

  timeRanges: Array<any>;
  periodType: any;

  startTime: any;
  endTime: any;
  currentTime: any;
  reset = 0;

  objects: any = [];
  objectId: any;
  objectType: any;
  checkFlag = false;
  waitFlag = false;

  widthRatioChangeNum = 0;


  showType = 'graph';

  window: window = window;

  timeRanges = [this.translate.instant('insight.Objects.SixHours'),
                        this.translate.instant('insight.Objects.OneDays'),
                        this.translate.instant('insight.Objects.OneWeeks')];

  constructor(private monitorObjectService: MonitorObjectService,
              private commonFunctionService: CommonFunctionService,
              private translate: TranslateService,
              private activatedRoute: ActivatedRoute) {

    this.activatedRoute.params.subscribe(params => {
      this.objectId = params['objectId'];
      this.objectType = params['type'];
      console.log('objectId:' + this.objectId + ',type:' + this.objectType);
    });

  }

  ngOnInit() {
    const that = this;

    $(window).resize(function(){
      that.calcWidthRatioChangeNum();
    });

    $(document).ready(function() {
      that.calcWidthRatioChangeNum();
    });

    this.periodType = this.timeRanges[0];
    /*this.monitorObjectService.getRelatedObjectInfo(this.objectId)
      .then((res:Response) => {
        let that = this;
        that.relatedObjectInfo = res;
        that.relatedObjectInfo.parent = res.parent;
        that.relatedObjectInfo.sibling = res.sibling;
        that.relatedObjectInfo.children = res.children;
        that.siblingNum = that.relatedObjectInfo.sibling.length;
        that.childrenNum = that.relatedObjectInfo.children.length;
      });*/
  }

  calcWidthRatioChangeNum() {
    this.widthRatioChangeNum ++;
  }

  ngDoCheck() {
    if (this.checkFlag === true) {

      if (this.waitFlag === false) {
        const Width = $('#Timeline-Top').width();
        this.calcWidthRatioChangeNum();

        if (Width > 100) {
          this.waitFlag = true;
          this.changeTime();
        }
      } else {
        this.checkFlag = false;
        this.waitFlag = false;
      }
    }


  }

  ngOnChanges(changes: SimpleChanges) {

    if (changes['startCheck']) {
      this.checkFlag = true;
    }
  }

  changeTime() {

    const myDate = new Date();
    this.endTime = myDate.getTime();

    this.currentTime = myDate.getFullYear() + '-' + this.transformDigitString(( myDate.getMonth() + 1)) + '-' +
      this.transformDigitString(myDate.getDate()) + ' ' +  this.transformDigitString(myDate.getHours()) + ':' +
      this.transformDigitString(myDate.getMinutes());

    if (this.periodType === this.translate.instant('insight.Objects.SixHours')) {

      myDate.setHours(myDate.getHours() - 6);
      this.startTime = myDate.getTime();

    } else if (this.periodType === this.translate.instant('insight.Objects.OneDays')) {

      myDate.setHours(myDate.getHours() - 24);
      this.startTime = myDate.getTime();

    } else if (this.periodType = this.translate.instant('insight.Objects.OneWeeks')) {

      myDate.setDate(myDate.getDate() - 7);
      this.startTime = myDate.getTime();

    }

  }

  changePeriodType() {
    const selectValue = $('#time-range').val();
    this.periodType = selectValue;

    this.changeTime();
  }

  changeSelectTime(newTime: any) {
    this.currentTime = newTime;
  }

  selectIcon(iconType: any) {
    this.iconSelectedType = iconType;
  }

  showImpactTooltip (e, item) {
    $('.tipBox').css('display', 'block');
    $('.tipBox').css('position', 'absolute');
    const mousePos = this.mousePosition(e);
    const  xOffset = 10;
    const  yOffset = 180;
    $('.tipBox').css('top', (mousePos.y - yOffset) + 'px').css('left', (mousePos.x + xOffset) + 'px');

    this.tipName = item.name;
    this.tipType = item.type;
    this.tipAlarms = item.alarms;
    this.tipHealth = item.health;
    this.tipRisk = item.risk;
    this.tipEfficiency = item.efficiency;

  }

  hideImpactTooltip() {
    $('.tipBox').css('display', 'none');
  }

  transformDigitString(str: any) {

    if (str < 10) {
      return '0' + str;
    } else {
      return str;
    }

  }

  gotoEndTime() {

    const myDate = new Date(this.endTime);

    this.reset++;

    this.currentTime = myDate.getFullYear() + '-' + this.transformDigitString(( myDate.getMonth() + 1)) + '-' +
        this.transformDigitString(myDate.getDate()) + ' ' +  this.transformDigitString(myDate.getHours()) + ':' +
        this.transformDigitString(myDate.getMinutes());
  }
  selectIndicator() {
    $('#indicatorSelector').modal('show');
  }

  optionsSelected(objects: any){
    this.objects = objects;
    console.log("final_out=", this.objects);
  }
  
  changeShowType(type) {
    this.showType = type;
  }

  selecteObjectInfo(objects) {
    this.selectedObjectInfo = objects;
  }
}
