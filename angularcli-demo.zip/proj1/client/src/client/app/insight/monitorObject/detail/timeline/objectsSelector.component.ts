import { Component, OnInit, OnChanges, Input, Output, EventEmitter} from '@angular/core';
//import { PmService } from '../../pm.service';
import { TreeStyle, TreeModel, NodeEvent } from '../../../shared/insight-tree/tree.types';
import {Subject} from 'rxjs/Subject';
import {TranslateService} from '@ngx-translate/core';

@Component({
  moduleId: module.id,
  selector: 'objects-select',
  templateUrl: 'objectsSelector.component.html',
  styleUrls: ['objectsSelector.component.less'],
})

export class ObjectsSelectorComponent implements OnInit, OnChanges {
  abstract;
  @Input() options;
  @Output() optionsSelected: EventEmitter<any> = new EventEmitter();

  optionalTrees: Array<TreeModel> = [];
  selectedLists: Array = [];

  //isEmptyObject = false;
  leafs: Array<TreeModel> = [];
  checkedLeafs: Array<TreeModel> = [];
  selectedIndicators: Array = [];
  treeStyle: TreeStyle = {
    isPlusImage: false,
    isCheckBox: true,
    nodeWidth: '300px',
    nodeDisplayCharacter: 45,
  };

  searchContext: string;
  unCheckedNode: Subject<TreeModel> = new Subject<TreeModel>();
  allNodeUnChecked: Subject<boolean> = new Subject<boolean>();
  contextCleared: Subject<string> = new Subject<string>();
  displayCharacterNum: number = 40;

  constructor(private translate: TranslateService) {
  }

  ngOnInit() {
    $('.tableSearch .inputSearch').attr('placeholder', this.translate.instant('pm.searchPlaceholder'));
  }

  ngOnChanges() {
    if(this.options !== undefined) {
      this.selectedIndicators = [];
      this.optionalTrees = [];
      this.selectedLists = [];
      this.checkedLeafs = [];
      this.allNodeUnChecked.next(true);
      this.constructOptionalTrees();
    }

  }
// interface Obj {
//   objectId: string;
//   name: string;
//   type: string;
//   alarms: number;
//   health: string;
//   risk: string;
//   efficiency: string;
//   workload: string;
//   remainCapacity: string;
//   reclaimCapacity: string;
//   stress: string;
// };

// export interface RelatedObjectInfo {
//   parent: Obj;
//   sibling: Obj[];
//   children: Obj[];
// };

  constructOptionalTrees() {
    const that = this;
    const tmp = [];
    let parent = <TreeModel>{
      value: "父级对象",
      id: "parent",
      children: [],
      enabled: true,
    };
    let children = <TreeModel>{
      value: "子级对象",
      id: "children",
      children: [],
      enabled: true,
    };
    let sibling = <TreeModel>{
      value: "兄弟级对象",
      id: "sibling",
      children: [],
      enabled: true,
    };
    let parentValue;
    if (that.options.parent.type === 'host') {
      parentValue = `<p><img src="assets/images/insight/svg/host.svg">`;
    } else if (that.options.parent.type === 'vm') {
      parentValue = `<p><img src="assets/images/insight/svg/VM.svg">`;
    } else if (that.options.parent.type === 'disk') {
      parentValue = `<p><img src="assets/images/insight/svg/Volumes.svg">`;
    }

    parent.children.push(<TreeModel>{
      value: parentValue + `<span>` + that.options.parent.name + `</span></p>`,
      id: that.options.parent.objectId,
      parent: parent,
      enabled: true,
      type: that.options.parent.type,
    });

    _.each(that.options.children, function (item) {
      let childrenValue;
      if (item.type === 'host') {
        childrenValue = `<p><img src="assets/images/insight/svg/host.svg">`;
      } else if (item.type === 'vm') {
        childrenValue = `<p><img src="assets/images/insight/svg/VM.svg">`;
      } else if (item.type === 'disk') {
        childrenValue = `<p><img src="assets/images/insight/svg/Volumes.svg">`;
      }
      children.children.push(<TreeModel>{
        value: childrenValue + `<span>` + item.name + `</span></p>`,
        id: item.objectId,
        parent: children,
        enabled: true,
        type: item.type,
      });
    });

    _.each(that.options.sibling, function (item) {
      let siblingValue;
      if (item.type === 'host') {
        siblingValue = `<p><img src="assets/images/insight/svg/host.svg">`;
      } else if (item.type === 'vm') {
        siblingValue = `<p><img src="assets/images/insight/svg/VM.svg">`;
      } else if (item.type === 'disk') {
        siblingValue = `<p><img src="assets/images/insight/svg/Volumes.svg">`;
      }
      sibling.children.push(<TreeModel>{
        value: siblingValue + `<span>` + item.name + `</span></p>`,
        id: item.objectId,
        parent: sibling,
        enabled: true,
        type: item.type,
      });
    });

    tmp.push(parent);
    tmp.push(children);
    tmp.push(sibling);

    this.optionalTrees = tmp;
  }

  onNodeChecked(e: NodeEvent) {
    this.setCheckedElements(e.node);
  }

  setCheckedElements(node: TreeModel) {
    this.leafs = [];
    this.leafs = this.getLeaf(node);

    if (this.leafs.length === 0) return;
    if (this.leafs[0]._checkboxFlag === true) {
      this.checkedLeafs = _.union(this.checkedLeafs, this.leafs);
    } else {
      this.checkedLeafs = _.difference(this.checkedLeafs, this.leafs);
    }
    this.updateCheckedOptions();
  }

  getLeaf(node: TreeModel): Array<TreeModel> {
    const that = this;
    if (node.children === undefined || node.children === null) {
      that.leafs.push(node);
    } else {
      _.each(node.children, function (child) {
        that.getLeaf(child);
      });
    }
    return that.leafs;
  }

  updateCheckedOptions() {
    const that = this;
    this.selectedIndicators = [];
    _.each(this.checkedLeafs, function (leaf) {
      const one: any = {
        sn: leaf.id,
        name: leaf.value,
        parentSn: leaf.parent.id,
        parentName: leaf.parent.value,
      };
      that.selectedIndicators.push(one);
    });

    this.constructSelectedLists();
  }

  constructSelectedLists() {
    const tmp: Array = [];
    _.each(this.selectedIndicators, function (item) {
      tmp.push(item.parentName + '-' + item.name);
    });
    this.selectedLists = tmp;
  }

  clearDisplayItem(index: number, item: string) {
    $('#button' + index).parent().remove();
    this.updateCheckedElements(item);
  }

  updateCheckedElements(item: string) {
    this.updateCheckedLeafs(item);
    this.updateCheckedOptions();
  }

  updateCheckedLeafs(item: string) {
    const index = _.findIndex(this.checkedLeafs, function (leaf) {
      return leaf.parent.value + '-' + leaf.value === item;
    });
    if (index === -1) return;

    this.unCheckedNode.next(this.checkedLeafs[index]);
    this.checkedLeafs.splice(index, 1);
  }

  clearAll() {
    this.allNodeUnChecked.next(true);
    this.checkedLeafs = [];
    this.optionsSelected.emit([]);
    this.selectedLists = [];
    this.selectedIndicators = [];
  }

  select() {
    // const final = _.map(this.selectedIndicators, function (i) {
    //   const middle = _.omit(i, 'name');
    //   return _.omit(middle, 'parentName');
    // });

    let final = [];
    _.map(this.checkedLeafs, function (leaf) {
      let role;
      final.push({objectId: leaf.id, type: leaf.type, role: leaf.parent.id});
    });
    console.log("final_in=", final);
    this.optionsSelected.emit(final);
    $('#indicatorSelector').modal('hide');
    this.contextCleared.next('');
  }

  dismiss() {
    // const final = _.map(this.selectedIndicators, function (i) {
    //   const middle = _.omit(i, 'name');
    //   return _.omit(middle, 'parentName');
    // });

    // this.optionsSelected.emit(final);
    this.contextCleared.next('');
  }

  searchContent(e: string) {
    this.searchContext = e;
  }

  getDisplayItem(item: any) {
    return (item.length > this.displayCharacterNum) ? (item.substring(0, this.displayCharacterNum) + '...') : item;
  }
}



