import {Component, OnInit, Input,  OnChanges , Output, EventEmitter, SimpleChanges } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

declare var $: any;
@Component({
  moduleId: module.id,
  template: `
             <div class="px-timeline-div" id="px-timeline-div">
                <img src={{imgUrl}}>
             </div>

             <div class="time-show-div" id="time-show-div">
                    <span class="currentTimeString" id="currentTimeString">{{currentTimeString}}</span>
                    <span class="alarmShowType" (click)="changeShowType()" id="alarmShowType">{{changeShowTypeString}}</span>
                    <span class="glyphicon glyphicon-triangle-bottom triangle-bottom"></span>
             </div>

             <div class="time-String-div" id="time-String-div">
               <div style="position: relative">
                    <span class="timeString" *ngFor="let timeStr of timeStrArray">
                    {{timeStr}}
                    </span>
               </div>
             </div>


            `,
  selector: 'px-timeline',
  styles: [
    `
        .px-timeline-div {
            position: absolute;
            width: 1200px;
            height: 60px;
            top: 30px;
            left: 30px;
        }

        .px-timeline-div img {
            width:100%;
            height:60px;
            user-select:none;
        }

        .currentTimeString {
             display: inline-block;
             border: 1px solid #ccc;
             border-radius: 8px;
             width: 120px;
             height: 24px;
             text-align: center;
             line-height: 24px;
             background-color: skyblue;
             /*margin-left: -40px;*/
        }

        .alarmShowType {
            font-size: 12px;
            color: blue;
            white-space: nowrap;
            /* overflow: hidden; */
            /* word-break: break-all; */
            /* word-wrap: break-word; */
            line-height: 24px;
            height: 24px;
            position: absolute;
            top: 0px;
            left: -80px;
        }

        .triangle-bottom {
            height: 20px;
            width: 20px;
            font-size: 16px;
            margin-left: 10px;
            color: skyblue;
            position: absolute;
            top: 20px;
            left: 42px;
        }

        .time-String-div {
            display: flex;
            flex-direction: row;
            position: absolute;
            top: 60px;
            left: 30px;
            width: 1200px;
        }

        .timeString {
            display: inline-block;
            font-size: 12px;
            position: absolute;
            white-space: nowrap;
        }

        .time-show-div {
            /*display: flex;
            flex-direction: column;
            height: 44px;
            width: 40px;*/
            position: absolute;
            top: -10px;
            left: 20px;
            cursor: pointer;
        }
    `
  ]
})


export class PxTimelineComponent implements OnInit, OnChanges {

  @Input() periodType;
  @Input() endTime;
  @Output() timeChanged = new EventEmitter();
  @Output() showTypeChanged = new EventEmitter();
  @Input() widthChanged;
  @Input() reset;

  timeStrArray: Array<any>;

  currentTimeString = '';

  startTime = 0;
  endTime = 0;
  currentTime = 0;

  imgUrl = 'assets/images/insight/svg/sixhours_timeline.svg';

  changeShowTypeString = '查看当前时刻';
  showType = 'graph';

  timePeriodType = this.translate.instant('insight.Objects.SixHours');

  constructor(private translate: TranslateService) {

    this.initTimeStringArray();

  }


  ngOnInit() {


    this.initCurrentTime();
    this.mouseDrag();
  }

  initTimeStringArray() {
    this.timeStrArray = new Array(8);

    for (let i = 0; i < 8; i++) {
      this.timeStrArray[i] = '';
    }
  }

  initCurrentTime() {

    const currrentTime = new Date(this.endTime);

    this.currentTimeString = currrentTime.getFullYear() + '-' + this.transformDigitString(( currrentTime.getMonth() + 1)) + '-' +
      this.transformDigitString(currrentTime.getDate()) + ' ' +  this.transformDigitString(currrentTime.getHours()) + ':' +
      this.transformDigitString(currrentTime.getMinutes());

    const startDate = new Date(this.endTime);
    this.endTime = startDate.getTime();

    if (this.timePeriodType === this.translate.instant('insight.Objects.SixHours')) {
      startDate.setHours(startDate.getHours() - 6);
      this.startTime = startDate.getTime();
    } else if (this.timePeriodType === this.translate.instant('insight.Objects.OneDays')) {
      startDate.setHours(startDate.getHours() - 24);
      this.startTime = startDate.getTime();
    } else if (this.timePeriodType === this.translate.instant('insight.Objects.OneWeeks')) {
      startDate.setDate(startDate.getDate() - 7);
      this.startTime = startDate.getTime();
    }

    this.currentTime = this.endTime;


  }

  drawTimeLine() {

    const timelineDiv = document.getElementById('px-timeline-div');
    const parentWidth = $('#Timeline-Top').width();
    const parentLeft = $('#Timeline-Top').offset().left;
    const parentTop = $('#Timeline-Top').offset().top;

    timelineDiv.style.width = (parentWidth - 60) + 'px';
    timelineDiv.style.left = (parentLeft + 30) + 'px';
    timelineDiv.style.top = (parentTop + 36) + 'px';

    const timeShowDiv = document.getElementById('time-show-div');
    const timeShowDivWidth =  $('#time-show-div').width();

    const currentWidth = (parentWidth - 60) * (this.currentTime - this.startTime) / (this.endTime - this.startTime);

    timeShowDiv.style.left = (parentLeft + 30 + 　currentWidth - ( timeShowDivWidth / 2 )) + 'px';
    timeShowDiv.style.top = (parentTop + 37) + 'px';

    const timeStringDiv = document.getElementById('time-String-div');
    timeStringDiv.style.width = (parentWidth - 10) + 'px';
    timeStringDiv.style.left = (parentLeft + 30) + 'px';
    timeStringDiv.style.top = (parentTop + 70) + 'px';

  }

  showTimeString() {

    const parentWidth = $('#px-timeline-div').width();
    let showNum = 0;
    let leftOffset = 0;
    let strOffset = -4;

    if (this.periodType === this.translate.instant('insight.Objects.SixHours')) {
      showNum = 7;
    } else if (this.periodType === this.translate.instant('insight.Objects.OneDays')) {
      showNum = 7;
    } else if (this.periodType = this.translate.instant('insight.Objects.OneWeeks')) {
      showNum = 8;
      strOffset = 16;
    }

    const timeShowWidth = $('#time-show-div').width();

    $('.timeString').each(function(i) {
      const offset = 16;

      if (i === 0) {
        leftOffset = offset;
        $('.timeString')[i].style.textAlign = 'left';
      } else {
        leftOffset = strOffset + timeShowWidth / 2 ;
        $('.timeString')[i].style.textAlign = 'center';
      }

      $('.timeString')[i].style.left = ((parentWidth * i ) / (showNum - 1)  - leftOffset) + 'px';
      $('.timeString')[i].style.top =  '10px';
      $('.timeString')[i].style.display = 'block';
    });

    $('#time-String-div').css('display', 'flex');

  }

  hideTimeString() {
    $('.timeString').each(function(i) {
      $('.timeString')[i].style.display = 'none';
    });

    $('#time-String-div').css('display', 'none');

  }

  ngOnChanges(changes: SimpleChanges) {
    const that = this;

    if (changes['periodType'] || changes['endTime']) {

      if (changes['periodType']) {
        this.periodTypeChange(changes['periodType'].currentValue);
      }

      this.initCurrentTime();

      this.hideTimeString();
      this.generateTimeString();

      this.drawTimeLine();

      setTimeout(function () {
        that.showTimeString();
      }, 100);
    } else if (changes['widthChanged']) {
      that.drawTimeLine();
      that.showTimeString();
    } else if (changes['reset']) {
        that.initCurrentTime();
        that.drawTimeLine();
    }
  }


  mouseDrag() {

    const that = this;
    $(document).ready(function() {

      $('#currentTimeString').on('mousedown', function (e) {
        $(document.body).on('mousemove', function (e) {

          window.getSelection().removeAllRanges();

          const timeMove  =  that.mouseMove(e);
          /*const width = $('#time-show-div').width();
          const parentWidth = $('#px-timeline-div').width();
          const parentLeft = $('#px-timeline-div').offset().left;*/

          $('#time-show-div').css('left', timeMove + 'px');

          that.adjustShowTypePos();
          /*if((timeMove + width + 30) > (parentLeft +　parentWidth)) {
              if(that.showType === 'graph') {
                  $('#alarmShowType').css('left',  '-80px');
              } else {
                  $('#alarmShowType').css('left',  '-120px');
              }

          }  else {
              $('#alarmShowType').css('left',  '130px');
          }*/


        });
      });


      $(document.body).on('mouseup', function (e) {
        $(document.body).off('mousemove');
      });
    });
  }

  mouseMove(e: any) {

    const lineWidth = $('#px-timeline-div').width();
    const lineLeft = $('#px-timeline-div').offset().left;

    const timeShowWidth = $('#time-show-div').width();

    let circleMove = e.pageX - timeShowWidth / 2;

    const minOffset = lineLeft - timeShowWidth / 2;
    const maxOffset = lineLeft + lineWidth - timeShowWidth / 2;

    if (circleMove < minOffset) {
      circleMove = minOffset;
    } else if (circleMove > maxOffset) {
      circleMove = maxOffset;
    }

    let currrentTime = this.startTime + (this.endTime - this.startTime) * (circleMove - minOffset) / (maxOffset - minOffset);

    currrentTime = new Date(currrentTime);
    this.currentTime = currrentTime;

    this.currentTimeString = currrentTime.getFullYear() + '-' + this.transformDigitString(( currrentTime.getMonth() + 1)) + '-' +
      this.transformDigitString(currrentTime.getDate()) + ' ' +  this.transformDigitString(currrentTime.getHours()) + ':' +
      this.transformDigitString(currrentTime.getMinutes());

    this.timeChanged.emit(this.currentTimeString);

    return circleMove;
  }

  periodTypeChange(periodType: any) {

    this.timePeriodType = periodType;

    if (periodType === this.translate.instant('insight.Objects.SixHours')) {

      this.imgUrl =  'assets/images/insight/svg/sixhours_timeline.svg';

    } else if (periodType === this.translate.instant('insight.Objects.OneDays')) {

      this.imgUrl = 'assets/images/insight/svg/oneday_timeline.svg';

    } else if (periodType = this.translate.instant('insight.Objects.OneWeeks')) {

      this.imgUrl = 'assets/images/insight/svg/oneweek_timeline.svg';

    }

  }


  generateTimeString() {

    const myDate = new Date(this.endTime);

    if (this.timePeriodType === this.translate.instant('insight.Objects.SixHours')) {

      myDate.setHours(myDate.getHours() - 6);

      for (let i = 0; i < 7; i++) {

        if (i === 0) {
          this.timeStrArray[i] = myDate.getFullYear() + '-' + this.transformDigitString(( myDate.getMonth() + 1)) + '-' +
            this.transformDigitString(myDate.getDate()) + ' ' +  this.transformDigitString(myDate.getHours()) + ':' +
            this.transformDigitString(myDate.getMinutes());
        } else {
          this.timeStrArray[i] = this.transformDigitString(myDate.getHours()) + ':' + this.transformDigitString(myDate.getMinutes());
        }

        myDate.setHours(myDate.getHours() + 1);
      }

      this.timeStrArray[7] = '';

    } else if (this.timePeriodType === this.translate.instant('insight.Objects.OneDays')) {

      myDate.setHours(myDate.getHours() - 24);

      for (let i = 0; i < 7; i++) {

        if (i === 0) {
          this.timeStrArray[i] = myDate.getFullYear() + '-' + this.transformDigitString(( myDate.getMonth() + 1)) + '-' +
            this.transformDigitString(myDate.getDate()) + ' ' +  this.transformDigitString(myDate.getHours()) + ':' +
            this.transformDigitString(myDate.getMinutes());
        } else {
          this.timeStrArray[i] = this.transformDigitString(myDate.getHours()) + ':' + this.transformDigitString(myDate.getMinutes());
        }

        myDate.setHours(myDate.getHours() + 4);
      }

      this.timeStrArray[7] = '';

    } else if (this.timePeriodType = this.translate.instant('insight.Objects.OneWeeks')) {

      myDate.setDate(myDate.getDate() - 7);

      for (let i = 0; i < 8; i++) {

        if (i === 0) {
          this.timeStrArray[i] = myDate.getFullYear() + '-' + this.transformDigitString(( myDate.getMonth() + 1)) + '-' +
            this.transformDigitString(myDate.getDate()) + ' ' +  this.transformDigitString(myDate.getHours()) + ':' +
            this.transformDigitString(myDate.getMinutes());
        } else {
          this.timeStrArray[i] = this.transformDigitString((myDate.getMonth() + 1)) + '-' + this.transformDigitString(myDate.getDate())
            + ' ' +  this.transformDigitString(myDate.getHours()) + ':' + this.transformDigitString(myDate.getMinutes());

        }

        myDate.setHours(myDate.getHours() + 24);
      }

    }

  }

  transformDigitString(str: any) {

    if (str < 10) {
      return '0' + str;
    } else {
      return str;
    }

  }

  changeShowType() {

      if(this.showType === 'graph') {

          this.showType = 'list';
          this.changeShowTypeString = '查看时间段关联分析';

      } else {

          this.showType = 'graph';
          this.changeShowTypeString = '查看当前时刻';

      }

      this.adjustShowTypePos();

      this.showTypeChanged.emit(this.showType);

  }

  adjustShowTypePos() {
        const left = $('#time-show-div').offset().left;
        const width = $('#time-show-div').width();
        const parentWidth = $('#px-timeline-div').width();
        const parentLeft = $('#px-timeline-div').offset().left;

        if((left + width + 30) > (parentLeft +　parentWidth)) {
            if(this.showType === 'graph') {
                $('#alarmShowType').css('left',  '-80px');
            } else {
                $('#alarmShowType').css('left',  '-116px');
            }

        }  else {
            $('#alarmShowType').css('left',  '130px');
        }
   }



}



