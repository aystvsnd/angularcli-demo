/**
 * Created by 6092002303 on 2017/3/9.
 */
import { Component , OnInit} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { KyButtonComponent, KyLoadingComponent, KY_RADIO_DIRECTIVES} from '../../shared/kylib/index';
import {TranslateService} from '@ngx-translate/core';
import { SendMessageService } from '../../sendMessage.service';
import {StorageService } from '../../storage.service';

import { MonitorObjectService } from './monitor-object.service';

import { CommonFunctionService } from '../common/common-function.service';

@Component({
  moduleId: module.id,
  selector: 'monitor-obj-list',
  directives: [KyButtonComponent, KyLoadingComponent, KY_RADIO_DIRECTIVES],
  styleUrls: [ '../css/common.css', 'monitor-obj-list.component.less'],
  templateUrl: 'monitor-obj-list.component.html'
})

export class MonitorObjListComponent implements OnInit {

  window: window = window;

  activeString: any;
  hardwareTopologyData: any;
  logicalTopologyData: any;
  topologyData: any;
  iconSelectedType = 'health';
  tipInfo = '';

  headNames: any = [this.translate.instant('insight.Objects.ListView'),
                    this.translate.instant('insight.Objects.LogicalView'), this.translate.instant('insight.Objects.PhysicalView')];
  imgUrls: any = ['assets/images/insight/svg/monitorObject/list_view.svg',
  'assets/images/insight/svg/monitorObject/logic_topo_view.svg',
  'assets/images/insight/svg/monitorObject/material_topo_view.svg'];

  columnDefs : any[] = [
    {
      field: 'name',
      align: 'left',
      title: this.translate.instant('insight.Objects.ObjName'),
      events: 'goDetailEvents',
      formatter: function (value, row, index) {
        const newStr = that.commonFunctionService.unicode2Chr(value);
        if (row.type === 'vm') {
          return `<a href="javascript:void(0);" class="detail">${newStr}</a>`;
        } else if (row.type === 'host') {
          return `<a href="javascript:void(0);" class="detail">${newStr}</a>`;
        }

      }
    },
    {
      field: 'type',
      align: 'left',
      title: this.translate.instant('insight.Objects.Type'),
      formatter: function (value, row, index) {
        if (value === 'host') {
          return `<div>
                  <img class="objImg" src="assets/images/insight/svg/monitorObject/0_host_line.svg">
                  <span class="objSpan">${value}</span>
                  <div>`;
        } else if (value === 'vm') {
          return `<div>
                  <img class="objImg" src="assets/images/insight/svg/monitorObject/0_VM_line.svg">
                  <span class="objSpan">${value}</span>
                  <div>`;
        }
      }
    },
    {
      field: 'power',
      align: 'left',
      title: this.translate.instant('insight.Objects.PowerState'),
      formatter: function (value, row, index) {
        if (value === 'on') {
          return `<div>
                  <img class="objImg"  src="assets/images/insight/svg/monitorObject/2_poweron.svg">
                  <span class="objSpan">${that.translate.instant('insight.Objects.PowerOn')}</span>
                  <div>`;
        } else if (value === 'off') {
          return `<div>
                  <img class="objImg"  src="assets/images/insight/svg/monitorObject/2_poweroff.svg">
                  <span class="objSpan">${that.translate.instant('insight.Objects.PowerOff')}</span>
                  <div>`;
        } else {
          return `<div>
                  <img class="objImg"  src="assets/images/insight/svg/monitorObject/2_unknowable.svg">
                  <span class="objSpan">${that.translate.instant('insight.Objects.Unknown')}</span>
                  <div>`;
        }
      }
    },
    {
      field: 'health',
      align: 'center',
      title: this.translate.instant('insight.Objects.Health'),
      formatter: function (value, row, index) {
        return that.getImgInfo(value, 'health');
      }
    },
    {
      field: 'workload',
      align: 'center',
      title: this.translate.instant('insight.Objects.Workload'),
      formatter: function (value, row, index) {
        return that.getImgInfo(value, 'workload');
      }
    },
    {
      field: 'risk',
      align: 'center',
      title: this.translate.instant('insight.Objects.Risk'),
      formatter: function (value, row, index) {
        return that.getImgInfo(value, 'risk');
      }
    },
    {
      field: 'remainCapacity',
      align: 'center',
      title: this.translate.instant('insight.Objects.RemainCapa'),
      formatter: function (value, row, index) {
        return that.getImgInfo(value, 'remainCapacity');
      }
    },
    {
      field: 'stress',
      align: 'center',
      title: this.translate.instant('insight.Objects.Stress'),
      formatter: function (value, row, index) {
        return that.getImgInfo(value, 'stress');
      }
    },
    {
      field: 'efficiency',
      align: 'center',
      title: this.translate.instant('insight.Objects.Efficiency'),
      formatter: function (value, row, index) {
        return that.getImgInfo(value, 'efficiency');
      }
    },
    {
      field: 'reclaimCapacity',
      align: 'center',
      title: this.translate.instant('insight.Objects.ReclaimCapa'),
      formatter: function (value, row, index) {
        return that.getImgInfo(value, 'reclaimCapacity');
      }
    }
  ];

  gridOptions: any = {
    method: 'get',
    queryParams: params => this.queryParams(params, this),
    columns: this.columnDefs,
    sidePagination: 'server',
    pagination: true, //是否开启分页
    pageSize: 10, //单页数量
    pageNumber: 1,
    pageList: [10, 20],
    paginationDetailHAlign: 'right', //分页详情水平位置
    paginationHAlign: 'right', //分页条水平位置
    clickToSelect: false, //单击行选中
    search: true,
    escape:true
  };

  queryParams(params: any, that: any) {
    const tmp = {
      pageSize: params.limit,
      currentPage: params.offset / params.limit + 1,
      fuzzy: params.search,
    };

    return tmp;
  }

  initTable() {
    $('#objlist').bootstrapTable($.extend(this.gridOptions, {
      url: '/api/v1/smartTopo/monitorObject/list',
      dataField: 'objectList',
      responseHandler: function (res) {

        const objectList = {
          'total': res.total,
          'objectList': res.objectList
        };
        return objectList;
      }

    }));

    $('.bootstrap-table .search input').attr('placeholder', this.translate.instant('fm.importKey'))
      .parent().append(`<span></span>`);
  }


  constructor(private monitorObjectService: MonitorObjectService, private activatedRoute: ActivatedRoute,
              private router: Router, private translate: TranslateService,
              private sendMessageService: SendMessageService,
              private storageService: StorageService,
              private commonFunctionService: CommonFunctionService) {

    if (this.storageService.getCurrentLang() === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }

    const that = this;
    this.window.goDetailEvents = {

      'click .detail': function (e, value, row, index) {
        that.gotoDetail(row);
      },
    };
  }

  ngOnInit() {
    this.initTable();

    this.monitorObjectService.getPhysicalTopology()
      .then(hardwareTopology => {
        this.hardwareTopologyData = this.constructTopoData(hardwareTopology.dcs);
        this.monitorObjectService.getLogicTopology()
          .then(logicalTopology => {
            this.logicalTopologyData = this.constructTopoData(logicalTopology.dcs);
          });
      });
  }

  constructTopoData(input: any) {
    const output = {
      'id': '0',
      'name': this.translate.instant('insight.topology.Resource'),
      'type': 'resource',
      'ownAlarm': 0,
      'ownAlarmId': '',
      'highestLevel': '',
      'childAlarm': 0,
      'children': []
    };

    output.children = input;
    return output;
  }

  gotoDetail(selectItem: any) {
    const objectDetail = {
      'objectId': selectItem.objectId,
      'name': selectItem.name,
      'type': selectItem.type
      /*'health':selectItem.health,
      'risk':selectItem.risk,
      'efficiency':selectItem.efficiency*/
    };
    this.router.navigate(['/main/insight/monitorObject/monitor-obj-detail',
      objectDetail]);
  }

  getImgInfo(level: any, type: any) {

    const levelList = {
      'critical': 4,
      'major': 3,
      'minor': 2,
      'warning': 1,
      'info': 0,

      'high': 1,
      'middle': 2,
      'low': 3
    };

    const cpiTypeList = {
      'workload': 'workload',
      'remainCapacity': 'remainCapacity',
      'reclaimCapacity': 'reclaimCapacity',
      'stress': 'stress'
    };



    let levelValue = 'unknown';

    if (levelList[level] !== undefined) {
      levelValue = levelList[level];
    }

    if ((levelValue === 'unknown') && (cpiTypeList[type] !== undefined)) {
      levelValue = 4;
    }

    if (type === 'health') {
      return `<div>
                  <img class="objImg" src="assets/images/insight/svg/monitorObject/${levelValue}_health_min.svg">
                  <div>`;
    } else if (type === 'risk') {
      return `<div>
                  <img class="objImg" src="assets/images/insight/svg/monitorObject/${levelValue}_risk_min.svg">
                  <div>`;
    } else if (type === 'efficiency') {
      return `<div>
                  <img class="objImg" src="assets/images/insight/svg/monitorObject/${levelValue}_efficiency_min.svg">
                  <div>`;
    } else if (type === 'workload') {
      return `<div>
                  <img class="objImg" src="assets/images/insight/svg/monitorObject/${levelValue}_workload_min.svg">
                  <div>`;
    } else if (type === 'remainCapacity') {
      return `<div>
                  <img class="objImg" src="assets/images/insight/svg/monitorObject/${levelValue}_capacity_min.svg">
                  <div>`;
    } else if (type === 'stress') {
      return `<div>
                  <img class="objImg" src="assets/images/insight/svg/monitorObject/${levelValue}_pressure_min.svg">
                  <div>`;
    } else if (type === 'reclaimCapacity') {
      return `<div>
                  <img class="objImg" src="assets/images/insight/svg/monitorObject/${levelValue}_recyclable_min.svg">
                  <div>`;
    }
  }

  showContent(activeString : any) {
    this.activeString = activeString;

    if (activeString === this.translate.instant('insight.Objects.LogicalView') ) {
      this.topologyData = this.logicalTopologyData;
    } else if (activeString === this.translate.instant('insight.Objects.PhysicalView') ) {
      this.topologyData = this.hardwareTopologyData;
    }

  }

  selectIcon(iconType: any) {
    this.iconSelectedType = iconType;
  }

  showTooltip (e, type) {

    if ('health' === type) {
      this.tipInfo = this.translate.instant('insight.Objects.Health');
    } else if ('risk' === type) {
      this.tipInfo = this.translate.instant('insight.Objects.Risk');
    } else if ('efficiency' === type) {
      this.tipInfo = this.translate.instant('insight.Objects.Efficiency');
    }

    $('#tip-SelectedType').css('display', 'block');
    const mousePos = this.mousePosition(e);
    const  xOffset = -10;
    const  yOffset = -10;
    $('#tip-SelectedType').css('top', (mousePos.y - yOffset) + 'px').css('left', (mousePos.x + xOffset) + 'px');

  }

  hideTooltip() {
    $('#tip-SelectedType').css('display', 'none');
  }

  mousePosition(ev) {
    ev = ev || window.event;
    if (ev.pageX || ev.pageY) {
      return {x: ev.pageX, y: ev.pageY};
    }
    return {
      x: ev.clientX + document.body.scrollLeft - document.body.clientLeft,
      y: ev.clientY + document.body.scrollTop - document.body.clientTop
    };
  }

}
