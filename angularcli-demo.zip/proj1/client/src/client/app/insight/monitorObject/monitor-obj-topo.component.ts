/**
 * Created by 6092002303 on 2017/3/9.
 */
import { Component , OnInit} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { KyButtonComponent, KyLoadingComponent, KY_RADIO_DIRECTIVES} from '../../shared/kylib/index';
import {TranslateService} from '@ngx-translate/core';
import { SendMessageService } from '../../sendMessage.service';
import {StorageService } from '../../storage.service';

import { MonitorObjectService } from './monitor-object.service';

import { CommonFunctionService } from '../common/common-function.service';

@Component({
  moduleId: module.id,
  selector: 'monitor-obj-topo',
  directives: [KyButtonComponent, KyLoadingComponent, KY_RADIO_DIRECTIVES],
  styleUrls: [ '../css/common.css', 'monitor-obj-list.component.less'],
  templateUrl: 'monitor-obj-topo.component.html'
})

export class MonitorObjTopoComponent implements OnInit {

  window: window = window;

  activeString: any;
  hardwareTopologyData: any;
  logicalTopologyData: any;
  topologyData: any;
  iconSelectedType = 'health';
  tipInfo = '';
  headNames: any = [
    this.translate.instant('insight.Objects.LogicalView'),
    this.translate.instant('insight.Objects.PhysicalView')
    ];
  imgUrls: any = [
  'assets/images/insight/svg/monitorObject/logic_topo_view.svg',
  'assets/images/insight/svg/monitorObject/material_topo_view.svg'
  ];

  constructor(private monitorObjectService: MonitorObjectService, private activatedRoute: ActivatedRoute,
              private router: Router, private translate: TranslateService,
              private sendMessageService: SendMessageService,
              private storageService: StorageService,
              private commonFunctionService: CommonFunctionService) {

    if (this.storageService.getCurrentLang() === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }

    const that = this;
  }

  ngOnInit() {
    this.monitorObjectService.getPhysicalTopology()
      .then(hardwareTopology => {
        this.hardwareTopologyData = this.constructTopoData(hardwareTopology.dcs);
        this.monitorObjectService.getLogicTopology()
          .then(logicalTopology => {
            this.logicalTopologyData = this.constructTopoData(logicalTopology.dcs);
            this.topologyData = this.logicalTopologyData;
          });
      });
  }

  constructTopoData(input: any) {
    const output = {
      'id': '0',
      'name': this.translate.instant('insight.topology.Resource'),
      'type': 'resource',
      'ownAlarm': 0,
      'ownAlarmId': '',
      'highestLevel': '',
      'childAlarm': 0,
      'children': []
    };

    output.children = input;
    return output;
  }

  showContent(activeString : any) {
    this.activeString = activeString;

    if (activeString === this.translate.instant('insight.Objects.LogicalView') ) {
      this.topologyData = this.logicalTopologyData;
    } else if (activeString === this.translate.instant('insight.Objects.PhysicalView') ) {
      this.topologyData = this.hardwareTopologyData;
    }

  }

  selectIcon(iconType: any) {
    this.iconSelectedType = iconType;
  }

  showTooltip (e, type) {

    if ('health' === type) {
      this.tipInfo = this.translate.instant('insight.Objects.Health');
    } else if ('risk' === type) {
      this.tipInfo = this.translate.instant('insight.Objects.Risk');
    } else if ('efficiency' === type) {
      this.tipInfo = this.translate.instant('insight.Objects.Efficiency');
    }

    $('#tip-SelectedType').css('display', 'block');
    const mousePos = this.mousePosition(e);
    const  xOffset = -10;
    const  yOffset = -10;
    $('#tip-SelectedType').css('top', (mousePos.y - yOffset) + 'px').css('left', (mousePos.x + xOffset) + 'px');

  }

  hideTooltip() {
    $('#tip-SelectedType').css('display', 'none');
  }

  mousePosition(ev) {
    ev = ev || window.event;
    if (ev.pageX || ev.pageY) {
      return {x: ev.pageX, y: ev.pageY};
    }
    return {
      x: ev.clientX + document.body.scrollLeft - document.body.clientLeft,
      y: ev.clientY + document.body.scrollTop - document.body.clientTop
    };
  }

}
