/**
 * Created by 6092002303 on 2017/3/9.
 */
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../shared/index';
import { KyTreeModule } from '../shared/insight-tree/index';

import { MonitorObjListComponent }   from './monitor-obj-list.component';
import { MonitorObjTopoComponent }   from './monitor-obj-topo.component';
import { MonitorObjDetailComponent } from './detail/monitor-obj-detail.component';
import { MonitorObjDetailOverviewComponent } from './detail/monitor-obj-detail-overview.component';
import { MonitorObjDetailComprehensiveindexComponent } from './detail/cpi/monitor-obj-detail-cpi.component';

import { MonitorObjCpiWorkloadComponent } from './detail/cpi/monitor-obj-cpi-workload.component';
import { MonitorObjCpiWorkloadHostComponent } from './detail/cpi/monitor-obj-cpi-workloadhost.component';
import { MonitorObjCpiRemainComponent } from './detail/cpi/monitor-obj-cpi-remain.component';
import { MonitorObjCpiRemainHostComponent } from './detail/cpi/monitor-obj-cpi-remainhost.component';
import { MonitorObjCpiReclaimComponent } from './detail/cpi/monitor-obj-cpi-reclaim.component';
import { MonitorObjCpiReclaimHostComponent } from './detail/cpi/monitor-obj-cpi-reclaimhost.component';
import { MonitorObjCpiStressComponent } from './detail/cpi/monitor-obj-cpi-stress.component';
import { MonitorObjCpiStressHostComponent } from './detail/cpi/monitor-obj-cpi-stresshost.component';

import { MonitorObjDetailTimelineComponent } from './detail/timeline/monitor-obj-timeline.component';
import { MonitorObjDetailTimelineDiagramComponent } from './detail/timeline/monitor-obj-timeline-alarms-diagram.component';
import { MonitorObjHistoryCurveComponent } from './detail/indicator-history-curve/monitor-obj-historycurve.component';

import { ObjectsSelectorComponent } from './detail/timeline/objectsSelector.component';
import { IndicatorsSelectorComponent } from './detail/timeline/indicatorsSelector.component';

import { MonitorObjectService } from './monitor-object.service';

import { ObjectTopologyComponent } from './obj-topology/obj-topology-component';

import { routing} from './monitor-object.routes';
import { InsightCommonModule } from '../common/common.module';

import { PxSwitchcardComponent } from './detail/px-switchcard.component';
import { PxTimelineComponent } from './detail/timeline/px-timeline.component';

//import { StrategyModule } from '../strategy/strategy.module';
import { PxControlModule } from '../shared/control/index';
import { PxDivTooltipModule } from '../shared/tooltip/tooltip.module';
import { EchartsToolModule } from '../../insight/shared/echarts-tool/echarts-tool.module';
import { PieShowComponent } from './my-pie.component';

@NgModule({
  imports: [SharedModule, KyTreeModule, routing, InsightCommonModule, PxControlModule, PxDivTooltipModule, EchartsToolModule],
  declarations: [MonitorObjListComponent, MonitorObjTopoComponent, MonitorObjDetailComponent, MonitorObjDetailOverviewComponent,
                  MonitorObjDetailComprehensiveindexComponent, MonitorObjCpiWorkloadComponent, MonitorObjCpiRemainComponent,
                  MonitorObjCpiReclaimComponent, MonitorObjCpiStressComponent, ObjectTopologyComponent,
                  PxSwitchcardComponent, MonitorObjDetailTimelineComponent, MonitorObjDetailTimelineDiagramComponent,
                  PxTimelineComponent, MonitorObjHistoryCurveComponent, PieShowComponent, ObjectsSelectorComponent, IndicatorsSelectorComponent,
                  MonitorObjCpiWorkloadHostComponent,MonitorObjCpiRemainHostComponent,MonitorObjCpiReclaimHostComponent,MonitorObjCpiStressHostComponent],
  providers: [MonitorObjectService],
  exports: [PxSwitchcardComponent],
})
export class MonitorObjectModule { }
