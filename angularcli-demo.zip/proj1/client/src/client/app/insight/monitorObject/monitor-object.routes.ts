/**
 * Created by 6092002303 on 2017/3/9.
 */
import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MonitorObjListComponent } from './monitor-obj-list.component';
import { MonitorObjTopoComponent } from './monitor-obj-topo.component';
import { MonitorObjDetailComponent } from './detail/monitor-obj-detail.component';
import { PieShowComponent } from './my-pie.component';

const routes: Routes = [
  {
    path: 'monitorObject',
    children: [
      {path: 'monitor-obj-list', component: MonitorObjListComponent},
      {path: 'monitor-obj-topo', component: MonitorObjTopoComponent},
      {path: 'monitor-obj-detail', component: MonitorObjDetailComponent},
      {path: 'pie', component: PieShowComponent}
    ]
  }

];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
