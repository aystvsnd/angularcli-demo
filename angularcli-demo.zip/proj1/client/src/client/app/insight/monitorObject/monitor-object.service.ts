/**
 * Created by 6092002303 on 2017/3/9.
 */
import { Injectable } from '@angular/core';
import { ApiResourceService as Http } from '../../apiResource.service';
import { Response} from '@angular/http';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class MonitorObjectService {

  constructor(public http: Http) {}

  getWorkLoadInfo(objId: any, objType: any) {
    return this.http.get('/api/v1/smartOm/monitorObject/cpi/workload?objectId=' + objId + '&type=' + objType).toPromise().then((res: Response) => {
      return res.json();
    });
  }

  getRemainCapInfo(objId: any, objType: any) {
    return this.http.get('/api/v1/smartOm/monitorObject/cpi/remainCapacity?objectId=' + objId + '&type=' + objType).toPromise().then((res: Response) => {
      return res.json();
    });
  }

  getReclaimCapInfo(objId: any, objType: any) {
    return this.http.get('/api/v1/smartOm/monitorObject/cpi/reclaimCapacity?objectId=' + objId + '&type=' + objType).toPromise().then((res: Response) => {
      return res.json();
    });
  }

  getStressInfo(objId: any, objType: any) {
    return this.http.get('/api/v1/smartOm/monitorObject/cpi/stress?objectId=' + objId + '&type=' + objType).toPromise().then((res: Response) => {
      return res.json();
    });
  }

  getAboutMeInfo(objId: any, objType: any) {
    return this.http.get('/api/v1/smartOm/monitorObject/aboutMe?objectId=' + objId + '&type=' + objType).toPromise().then((res: Response) => {
      return res.json();
    });
  }

  getRelatedObjectInfo(objId: any) {
    return this.http.get('/api/v1/smartTopo/monitorObject/relatedObject?objectId=' + objId).toPromise().then((res: Response) => {
      return res.json();
    });
  }

  getPhysicalTopology() {
    return this.http.get('/api/v1/smartTopo/physical/dcs')
      .toPromise()
      .then(res => res.json());
  }

  getLogicTopology() {
    return this.http.get('/api/v1/smartTopo/logical/dcs')
      .toPromise()
      .then(res => res.json());
  }

  postAlarmComfirmInfo(alarmConfirm: any) {
    return this.http.put('/api/v1.0/fm/alarmConfirms', alarmConfirm).toPromise().then((res: Response) => {
      return res;
    });
  }

  getOverviewImpact(objId: any, objType: any) {
    return this.http.get('/api/v1/smartOm/monitorObject/overview/impact?objectId=' + objId + '&type=' + objType).toPromise()
      .then((res: Response) => {
      return res.json();
    });
  }

  /*getHistoryAlarmsTest() {
    return this.http.get('/api/v1.0/fm/historyAlarmsWithDetail?alarmTimeType=&onlyHidden=false&pageSize=100&currentPage=1')
      .toPromise()
      .then(res => res.json());
  }*/

  getRecentHistoryAlarms(objType: any, objId: any, startTime: any, endTime: any) {
    const start = new Date(startTime);
    const end = new Date(endTime);
    const startTimeUtc = '"' + start.getUTCFullYear() + '-' + this.transformDigitString(start.getUTCMonth() + 1) + '-'
                        + this.transformDigitString(start.getUTCDate()) + 'T'
                        + this.transformDigitString(start.getUTCHours()) + ':'
                        + this.transformDigitString(start.getUTCMinutes()) + 'Z"';

    const endTimeUtc = '"' + end.getUTCFullYear() + '-' + this.transformDigitString(end.getUTCMonth() + 1) + '-'
      + this.transformDigitString(end.getUTCDate()) + 'T'
      + this.transformDigitString(end.getUTCHours()) + ':'
      + this.transformDigitString(end.getUTCMinutes()) + 'Z"';

    return this.http.get(' /api/v1/smartOm/historyAlarmsWithDetail?objectType=' + objType + '&beginTime=' + startTimeUtc
                          + '&endTime=' + endTimeUtc + '&objectId=' + objId)
      .toPromise()
      .then(res => res.json());
  }

  getCurrentAlarms(objType: any, objId: any) {
    const objectIdToAlarm = JSON.parse(objId).vmId;

    return this.http.get('/api/v1.0/fm/alarmsWithDetail?objectId=' + objectIdToAlarm + '&pageSize=100&currentPage=1')
      .toPromise()
      .then(res => res.json());
  }

  transformDigitString(str: any) {

    if (str < 10) {
      return '0' + str;
    } else {
      return str;
    }

  }

  postObjAndIndex(ObjAndIndex: any) {
    //return this.http.post('http://10.62.96.107:8464/api/v1/smartOm/historyMetersWithDetail', ObjAndIndex).toPromise().then(
    return this.http.post('/api/v1/smartOm/historyMetersWithDetail', ObjAndIndex).toPromise().then(
      (res: Response) => {
        return res.json();
      }
    );
  }

}
