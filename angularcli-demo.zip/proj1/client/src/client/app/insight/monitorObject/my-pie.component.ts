/**
 * Created by 6092002303 on 2017/3/9.
 */
import { Component , OnInit} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { KyButtonComponent, KyLoadingComponent, KY_RADIO_DIRECTIVES} from '../../shared/kylib/index';

import { SendMessageService } from '../../sendMessage.service';
import {StorageService } from '../../storage.service';

import { MonitorObjectService } from './monitor-object.service';

import { CommonFunctionService } from '../common/common-function.service';

@Component({
  moduleId: module.id,
  selector: 'pie',
  styleUrls: [],
  template: `
  <h1>这是一个测试页面</h1>
  <echarts-nest-pie [data]="pieOption"></echarts-nest-pie>`
})

export class PieShowComponent {
    pieOption: any = [
      {
        data: [
          {value: 200, name: '自身开销'},
          {value: 1004, name: '已使用'},
          {value: 1548, name: '空闲'}
          ]
      },
      {
        data: [
          {value: 335, name: 'vm1'},
          {value: 310, name: 'vm2'},
          {value: 234, name: 'vm3'},
          {value: 135, name: '其他'}
        ]
      }
    ];
}
