import {Component, OnInit, OnChanges, Input, SimpleChanges} from '@angular/core';
import { Router } from '@angular/router';

import { CommonFunctionService } from '../../common/common-function.service';

import {ObjectIcon} from '../object-const';

declare const d3;

@Component({
  moduleId: module.id,
  selector: 'object-topology',
  styleUrls: [ '../../css/common.css', 'obj-topology-component.css'],
  templateUrl: 'obj-topology-component.html'
})

export class ObjectTopologyComponent implements OnInit, OnChanges {
  @Input() data;
  @Input() selectedIconType;
  svg;
  tree;
  tooltip;
  tooltipShowInfo;

  constructor (private commonFunctionService: CommonFunctionService, private router: Router, ) {
    this.tooltipShowInfo = {
      name: '',
      type: '',
      ownAlarm: 0,
      childAlarm: 0,
      ownAlarmId: '',

      controllerNodeAlarm: 0,
      computerNodeAlarm: 0,

      imgUrl: '',
      imgUrlHealth: '',
      imgUrlRisk: '',
      imgUrlEfficiency: ''
    };
  }

  ngOnInit() {
    this.svg = d3.select('svg')
      .append('g')
      .attr('transform', d => 'translate(50, 0)');

    this.tree = d3.layout
      .tree()
      .nodeSize([70, 170]);

    this.tooltip = d3.select('.topo-tooltip');

  }


  ngOnChanges(changes: SimpleChanges) {

    if (null !== this.data) {
      if (changes['data']) {
        this.showTopo();
      } else if (changes['selectedIconType']) {
        this.changeIconShow();
      }
    }
  }

  changeIconShow() {

    const component = this;

    component.svg
      .selectAll('g.node')
      .select('image.iconShow')
      .remove();

    component.svg
      .selectAll('g.node')
      .each(function(node){

        const elem = d3.select(this);

        if ('resource' !== node.type) {

          const levelList = {
            'critical': 4,
            'major': 3,
            'minor': 2,
            'warning': 1,
            'info': 0
          };

          let level = 'unknown';

          if (component.selectedIconType === 'health') {
            level = levelList[node.health];
          } else if (component.selectedIconType === 'risk') {
            level = levelList[node.risk];
          } else if (component.selectedIconType === 'efficiency') {
            level = levelList[node.efficiency];
          }

          if (level === undefined) {
            level = 'unknown';
          }

          const imgUrl = `assets/images/insight/svg/monitorObject/${level}_${component.selectedIconType}_min.svg`;

          elem .append('image')
            .attr('xlink:href', imgUrl)
            .attr('class', 'iconShow')
            .attr('width', 16)
            .attr('height', 16)
            .attr('x', `-${ObjectIcon[node.type].width / 2 + 2}`)
            .attr('y', -18);
        }
      });

  }

   showTopo() {
    const component = this;

    function render(nodes) {
      const nodeOnGraph = component.svg.selectAll('g.node');
      const oldNodes = nodeOnGraph.data();
      function findParent(node) {
        if (_.isEmpty(node.parent)) {
          return node;
        } else {
          const p = oldNodes.filter(oldNode => oldNode._id === node.parent._id);
          return _.isEmpty(p) ? findParent(node.parent) : _.first(p);
        }
      }

      function findParentInNew(node) {
        if (_.isEmpty(node.parent)) {
          return node;
        } else {
          const p = nodes.filter(oldNode => oldNode._id === node.parent._id);
          return _.isEmpty(p) ? findParentInNew(node.parent) : _.first(p);
        }
      }


      function removeChildren(node) {
        node.children = null;
      }

      function appendChildren(node) {
        node.children = node._children;
      }

      nodes.forEach(node => {
        const temp = node.x;
        node.x = node.y;
        node.y = temp;
      });
      const links = component.tree.links(nodes);
      const diagonal = d3.svg.diagonal()
        .source(d => ({
          x: d.source.y,
          y: d.source.x + (_.has(ObjectIcon, d.source.type) ? ObjectIcon[d.source.type].width / 2 + 10 : 0),
        }))
        .target(d => ({
          x: d.target.y,
          y: d.target.x - (_.has(ObjectIcon, d.target.type) ? ObjectIcon[d.target.type].width / 2 : 0),
        }))
        .projection(d => [d.y, d.x]);
      const transitionDuration = 1000;
      const linkOnGraph = component.svg.selectAll('path');

      d3.select('svg')
        .transition()
        .duration(transitionDuration)
        .style('height', `${100 + _.max(nodes, node => node.y).y - _.min(nodes, node => node.y).y}px`)
        .style('width', `${_.max(nodes, node => node.depth).depth * 210 + 125}px`);

      component.svg
        .transition()
        .duration(transitionDuration)
        .attr('transform', d => `translate(50, ${50 - _.min(nodes, node => node.y).y})`);

      {
        nodeOnGraph.each(function(circle) {
          if (!nodes.some(node => node._id === circle._id)) {
            const g = d3.select(this)
              .transition()
              .duration(transitionDuration)
              .attr('transform', d => `translate(${findParentInNew(d).x},${findParentInNew(d).y})`)
              .remove();

            g.select('circle')
              .attr('r', 0);

            g.select('text')
              .style('font-size', '0px')
              .style('fill-opacity', 0);

            g.selectAll('image')
              .attr('transform', 'scale(0,0)');
          } else {
            d3.select(this)
              .transition()
              .duration(transitionDuration)
              .attr('transform', d => `translate(${d.x},${d.y})`);

            if (_.has(ObjectIcon, circle.type) && _.has(circle, '_children')) {
              d3.select(this).select('.toggle')
                .attr('xlink:href', `assets/images/insight/svg/topo-${_.isEmpty(circle.children) ? 'un' : ''}zip.svg`);
            }
          }
        });

        linkOnGraph.each(function (path) {
          if (!links.some(link => path.source._id === link.source._id && path.target._id === link.target._id)) {
            d3.select(this)
              .transition()
              .duration(transitionDuration)
              .attr('d', () => {
                const p = findParentInNew(path.target);

                return diagonal({
                  source: {
                    x: p.x + (_.has(ObjectIcon, p.type) ? ObjectIcon[p.type].width / 2 + 10 : 0),
                    y: p.y,
                  },
                  target: {
                    x: p.x + (_.has(ObjectIcon, p.type) ? ObjectIcon[p.type].width / 2 + 10 : 0),
                    y: p.y,
                  }
                });
              })
              .remove();
          } else {
            d3.select(this)
              .datum(_.chain(links)
                .filter(link => path.source._id === link.source._id && path.target._id === link.target._id).first().value())
              .transition()
              .duration(transitionDuration)
              .attr('d', diagonal);
          }
        });
      }

      nodes.forEach(node => {
        if (nodeOnGraph.filter(d => d._id === node._id).empty()) {
          const g = component.svg
            .append('g')
            .datum(node)
            .attr('class', 'node')
            .attr('transform', d => `translate(${findParent(d).previousPosition.x},${findParent(d).previousPosition.y})`);
          g
            .append('text')
            .attr('text-anchor', 'middle')
            .attr('y', 0)
            .style('font-size', '0px')
            .style('fill-opacity', 0)
            .text(function(d) { return component.commonFunctionService.cutStr(d.name, 14); });

          const gTransition = g
            .transition()
            .duration(transitionDuration)
            .attr('transform', d => `translate(${d.x},${d.y})`);

          if (_.has(ObjectIcon, node.type)) {
            g
              .append('image')
              .attr('xlink:href', ObjectIcon[node.type].url)
              .attr('class', 'icon')
              .attr('width', ObjectIcon[node.type].width)
              .attr('height', ObjectIcon[node.type].height)
              .attr('x', `-${ObjectIcon[node.type].width / 2}`)
              .attr('y', `-${ObjectIcon[node.type].height / 2}`);
            if (_.has(node, '_children')) {
              g.append('image')
                .attr('xlink:href', `assets/images/insight/svg/topo-${_.isEmpty(node.children) ? 'un' : ''}zip.svg`)
                .attr('width', 10)
                .attr('height', 10)
                .attr('class', 'toggle')
                .attr('x', `${ObjectIcon[node.type].width / 2}`)
                .attr('y', -5);
            }
            /*if (!_.isEmpty(node.highestLevel)) {
              g.append('image')
                .attr('xlink:href', `assets/images/insight/svg/Alert_${node.highestLevel}.svg`)
                .attr('width', 10)
                .attr('height', 10)
                .attr('x', `${ObjectIcon[node.type].width/2-10}`)
                .attr('y', `${ObjectIcon[node.type].height/2-10}`);
            }*/

            if ('resource' !== node.type) {

              const levelList = {
                'critical': 4,
                'major': 3,
                'minor': 2,
                'warning': 1,
                'info': 0
              };


              let level = 'unknown';

              if (component.selectedIconType === 'health') {
                level = levelList[node.health];
              } else if (component.selectedIconType === 'risk') {
                level = levelList[node.risk];
              } else if (component.selectedIconType === 'efficiency') {
                level = levelList[node.efficiency];
              }

              if (level === undefined) {
                level = 'unknown';
              }

              const imgUrl = `assets/images/insight/svg/monitorObject/${level}_${component.selectedIconType}_min.svg`;

              g .append('image')
                .attr('xlink:href', imgUrl)
                .attr('class', 'iconShow')
                .attr('width', 16)
                .attr('height', 16)
                .attr('x', `-${ObjectIcon[node.type].width / 2 + 2}`)
                .attr('y', -18);

            }


            g.selectAll('image').attr('transform', 'scale(0,0)');

            gTransition
              .select('text')
              .attr('y', ObjectIcon[node.type].height / 2 + 12)
              .style('font-size', '12px')
              .style('fill-opacity', 1);

            gTransition
              .selectAll('image')
              .attr('transform', 'scale(1,1)');
          } else {
            g
              .append('circle')
              .attr('r', 0)
              .style('stroke', '#000');
            gTransition
              .select('circle')
              .attr('r', 5);

            gTransition
              .select('text')
              .style('font-size', 12)
              .style('fill-opacity', 1);
          }
        }
      });

      links.forEach(link => {
        if (linkOnGraph.filter(path => path.source._id === link.source._id && path.target._id === link.target._id).empty()) {
          component.svg
            .append('path')
            .datum(link)
            .attr('d', () => {
              const p = findParent(link.target);

              return diagonal({
                source: {
                  x: p.previousPosition.x + (_.has(ObjectIcon, p.type) ? ObjectIcon[p.type].width / 2 + 10 : 0),
                  y: p.previousPosition.y,
                },
                target: {
                  x: p.previousPosition.x + (_.has(ObjectIcon, p.type) ? ObjectIcon[p.type].width / 2 + 10 : 0),
                  y: p.previousPosition.y,
                }
              });
            })
            .style('stroke', '#ccc')
            .style('fill', 'none')
            .transition()
            .duration(transitionDuration)
            .attr('d', diagonal);
        }
      });

      component.svg.selectAll('g.node').data().forEach(d => {
        d.previousPosition = {
          x: d.x,
          y: d.y,
        };
      });

      component.svg
        .selectAll('g.node')
        .filter(d => _.has(d, '_children'))
        .select('circle,.toggle')
        .style('cursor', 'pointer')
        .on('click', node => {
          if (!_.has(node, 'children')) {
            appendChildren(node);
          } else {
            removeChildren(node);
          }
          render(component.tree(component.data));
        });

      function hideTooltip() {
        component.tooltip.style('display', 'none');
      }

      function showTooltip(node) {
        if ('resource' !== node.type) {
          const div = document.getElementsByClassName('topology-div');
          const width = div[0].clientWidth;
          const height = div[0].clientHeight;
          const d3y = d3.event.pageY;
          let xOffset = 50;
          let yOffset = 50;
          let nameWidth = 0;
          const nameLength = component.commonFunctionService.getStrLength(node.name);

          if (nameLength > 27) {
            nameWidth = (nameLength - 27) * 7;
          }

         if ((node.x + xOffset + 230 + nameWidth) > width) {
            if ((node.x + xOffset - 230 - nameWidth) > 0 ) {
              xOffset = xOffset - 230 - nameWidth;
            }
          }

          if ((d3y + yOffset + 200 - 250 ) > height) {
            if ((d3y + yOffset  - 235 - 250) > 0 ) {
              yOffset = yOffset - 235;

              if ('cloudEnv' === node.type) {
                yOffset = yOffset - 25;
              }
            }
          }

          const imgUrlHealth = component.getImgUrl(node.health, 'health');
          const imgUrlRisk = component.getImgUrl(node.risk, 'risk');
          const imgUrlEfficiency = component.getImgUrl(node.efficiency, 'efficiency');

          component.tooltip
            .style('left', `${node.x + xOffset}px`)
            .style('top', `${node.y + yOffset - _.min(nodes, node => node.y).y + yOffset}px`)
            .style('opacity', 0)
            .style('display', 'block');

          component.tooltipShowInfo.name = node.name;
          component.tooltipShowInfo.type = node.type;
          component.tooltipShowInfo.ownAlarm = node.ownAlarm;
          component.tooltipShowInfo.childAlarm = node.childAlarm;
          component.tooltipShowInfo.ownAlarmId = node.ownAlarmId;

          component.tooltipShowInfo.controllerNodeAlarm = node.controllerNodeAlarm;
          component.tooltipShowInfo.computerNodeAlarm = node.computerNodeAlarm;

          component.tooltipShowInfo.imgUrl = ObjectIcon[node.type].url;
          component.tooltipShowInfo.imgUrlHealth = imgUrlHealth;
          component.tooltipShowInfo.imgUrlRisk = imgUrlRisk;
          component.tooltipShowInfo.imgUrlEfficiency = imgUrlEfficiency;

          component.tooltip
            .transition()
            .duration(750)
            .style('left', `${node.x + xOffset}px`)
            .style('top', `${node.y + yOffset + 10 - _.min(nodes, node => node.y).y}px`)
            .style('opacity', 1)
            .style('display', 'block');
        } else {
          hideTooltip();
        }
      }

      d3.selectAll('g.node image.icon')
        .style('cursor', 'pointer')
        .on('click', node => {
          showTooltip(node);
        })
        .on('mouseover', node => {

          showTooltip(node);

        });

      d3.select('svg')
        .on('click', () => {
          component.tooltip.style('display', 'none');
        });


      component.tooltip
        .select('.topo-close')
        .on('click', () => {
          hideTooltip();
        });
    }

    if (!_.isEmpty(this.data)) {
      component.tooltip.style('display', 'none');
      render(this.init());
    }
  }

  init() {
    const nodes = this.tree(this.data);
    nodes.forEach(node => {
      node._id = _.uniqueId();
    });
    nodes.filter(node => _.has(node, 'children'))
      .forEach(node => node._children = node.children);
    if (!_.isEmpty(nodes)) {
      const first = _.first(nodes);
      first.previousPosition = {
        x: first.x,
        y: first.y,
      };

      if (_.isArray(first.children)) {
        first.children.forEach(node => node.children = null);
      }
    }

    this.svg.selectAll('*').remove();

    return this.tree(this.data);

  }

  getImgUrl(level: any, type: any) {

    const levelList = {
      'critical': 4,
      'major': 3,
      'minor': 2,
      'warning': 1,
      'info': 0
    };

    let levelValue = 'unknown';

    if (levelList[level] !== undefined) {
      levelValue = levelList[level];
    }

    if (type === 'health') {
      return `assets/images/insight/svg/monitorObject/${levelValue}_health_min.svg`;
    } else if (type === 'risk') {
      return `assets/images/insight/svg/monitorObject/${levelValue}_risk_min.svg`;
    } else if (type === 'efficiency') {
      return `assets/images/insight/svg/monitorObject/${levelValue}_efficiency_min.svg`;
    }

    return '0';
  }

  goToAlarms(item: any) {
    const routerPara = {
      'objectType': item.type,
      'objectTopo': item.ownAlarmId
    };

    this.router.navigate(['/main/alarm/currentalarm/gather',
      routerPara]);

  }

}
