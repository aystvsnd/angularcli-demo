
export const ObjectIcon = {
    resource: {
        url: 'assets/images/insight/svg/resource.svg',
        width: 30,
        height: 30,
    },
    dc: {
        url: 'assets/images/insight/svg/dc.svg',
        width: 30,
        height: 30,
    },
    cloudEnv: {
        url: 'assets/images/insight/svg/cloud-environment.svg',
        width: 30,
        height: 30,
    },
    pod: {
        url: 'assets/images/insight/svg/pod.svg',
        width: 30,
        height: 30,
    },
    rack: {
        url: 'assets/images/insight/svg/Rack.svg',
        width: 30,
        height: 30,
    },
    chassis: {
        url: 'assets/images/insight/svg/Shelf.svg',
        width: 30,
        height: 30,
    },
    blade: {
        url: 'assets/images/insight/svg/Blade.svg',
        width: 30,
        height: 30,
    },
    rackServer: {
        url: 'assets/images/insight/svg/Rack-Server.svg',
        width: 30,
        height: 30,
    },
    storage: {
        url: 'assets/images/insight/svg/storage.svg',
        width: 30,
        height: 30,
    },
    router: {
        url: 'assets/images/insight/svg/Router.svg',
        width: 30,
        height: 30,
    },
    'switch': {
        url: 'assets/images/insight/svg/Switch.svg',
        width: 30,
        height: 30,
    },
    az: {
        url: 'assets/images/insight/svg/AZ.svg',
        width: 30,
        height: 30,
    },
    ha: {
        url: 'assets/images/insight/svg/Aggregate.svg',
        width: 30,
        height: 30,
    },
    host: {
        url: 'assets/images/insight/svg/host.svg',
        width: 30,
        height: 30,
    },
    vm: {
        url: 'assets/images/insight/svg/VM.svg',
        width: 30,
        height: 30,
    }
};
