/**
 * Created by 10192595 on 2016/11/9.
 */
import {Component, OnInit} from '@angular/core';
import {Observable} from 'rxjs/Rx';
import {OpsInsightConfigService} from './ops-insight-config.service';
import {CloudEnvironment} from './ops-insight-config.interface';
import {TranslateService} from '@ngx-translate/core';

@Component({
  moduleId: module.id,
  styleUrls: ['../css/common.css', 'cloud-environment-config.component.css'],
  templateUrl: 'cloud-environment-config.component.html',
})
export class CloudEnvironmentConfigComponent implements OnInit {
  currentCloudEnvironment: CloudEnvironment;
  cloudEnvironmentList: CloudEnvironment[];
  model: string;
  changeModelSelectedCloudEnvironment: CloudEnvironment;
  isConfirmDialogueShown: boolean;
  title: string;

  constructor(private service: OpsInsightConfigService, private translate: TranslateService ) {
    this.cloudEnvironmentList = [];
    this.hideConfirmDialogue();
  }

  ngOnInit() {
    this.getNormalCloudEnvironmentList().then((res) => {
      this.cloudEnvironmentList = res;
    }).catch(err => {
      this.model = 'error';
    });

    this.service.getCurrentCloudEnvironment().then((res) => {
      if (res.id === '') {
        this.switchToInitialConfigModel();
      } else {
        this.currentCloudEnvironment = res;
        this.switchToOverviewModel();
      }
    });
  }

  changeCurrentCloudEnvironment() {
    this.hideConfirmDialogue();
    this.switchToLoadingModel();
    this.service.postCurrentCloudEnvironment(this.changeModelSelectedCloudEnvironment).then(() => {
      this.waitForDeployResult();
    });
  }

  switchToChangeModel() {
    this.model = 'change';
    this.title = this.translate.instant('insight.CloudEnvModifyConfigTitle');
    if (this.currentCloudEnvironment.status === 'normal') {
      this.changeModelSelectedCloudEnvironment = this.currentCloudEnvironment;
    } else {
      this.changeModelSelectedCloudEnvironment = this.cloudEnvironmentList[0];
    }
  }

  switchToOverviewModel() {
    this.hideConfirmDialogue();
    if (!this.isCurrentCloudEnvironmentNormal()) {
      this.currentCloudEnvironment.status = 'abnormal';
    }
    this.title = this.translate.instant('insight.EnvConfig');
    this.model = 'overview';
  }

  switchToInitialConfigModel() {
    this.model = 'initial config';
  }

  switchToLoadingModel() {
    this.model = 'loading';
  }

  waitForDeployResult() {
    const interval = Observable.interval(2000).subscribe(() => {
      this.service.getCurrentCloudEnvironmentDeployStatus().then((res) => {
        if (res.status !== 'deploying') {
          interval.unsubscribe();

          if (res.status === 'success') {
            this.service.getCurrentCloudEnvironment().then((res) => {
              this.currentCloudEnvironment = res;
              this.switchToConfigSuccessModel();
            });
          } else {
            this.service.getCurrentCloudEnvironment().then((res) => {
              if (res.id === '') {
                this.switchToInitialConfigModel();
              } else {
                this.switchToChangeModel();
              }
            });
          }
        }
      });
    });
  }

  switchToConfigSuccessModel() {
    this.model = 'config success';
  }

  changeSelectedCloudEnvironment(e) {
    this.changeModelSelectedCloudEnvironment = this.cloudEnvironmentList.filter((item) => {
      return item.name === e.target.value;
    })[0];

  }

  showConfirmDialogue() {
    this.isConfirmDialogueShown = true;
  }

  hideConfirmDialogue() {
    this.isConfirmDialogueShown = false;
  }

  getNormalCloudEnvironmentList(): Promise<CloudEnvironment[]> {
    let list = [];
    return this.service.getCloudEnvironmentList().then((res) => {
      list = res;
      return list.filter((item) => {
        return item.status === 'normal';
      });
    }).catch(err => {
        return Promise.reject(err);
      });
  }

  hasNormalCloudEnvironmentList(): boolean {
    return this.cloudEnvironmentList.length !== 0;
  }

  isCurrentCloudEnvironmentNormal(): boolean {
    return this.cloudEnvironmentList.some((item) => {
      return item.id === this.currentCloudEnvironment.id;
    });

    /*if (index < 0) {
      return false;
    } else {
      if (this.cloudEnvironmentList[index].status === 'abnormal') {
        return false;
      } else {
        return true;
      }
    }*/
  }

}
