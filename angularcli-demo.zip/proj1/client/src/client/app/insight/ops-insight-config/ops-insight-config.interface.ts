/**
 * Created by 10192595 on 2016/11/12.
 */
export interface CloudEnvironment {
  id: string;
  name: string;
  url: string;
  type: string;
  user: string;
  passwd: string;
  status: string;
}
export interface CloudEnvironmentInfo {
  cloudenvs: CloudEnvironment[];
  current: CloudEnvironment;
}

export interface CurrentCloudEnvironmentDeployStatus {
  status: string;
}
