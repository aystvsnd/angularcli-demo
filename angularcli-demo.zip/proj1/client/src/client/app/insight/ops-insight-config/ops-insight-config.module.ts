/**
 * Created by 10192595 on 2016/11/9.
 */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../shared/index';

import { routing } from './ops-insight-config.routes';
import {CloudEnvironmentConfigComponent} from './cloud-environment-config.component';
import {OpsInsightConfigService} from './ops-insight-config.service';

@NgModule({
  declarations: [CloudEnvironmentConfigComponent],
  imports: [CommonModule, SharedModule, routing],
  providers: [OpsInsightConfigService],
})

export class OpsInsightConfigModule { }
