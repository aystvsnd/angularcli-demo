/**
 * Created by 10192595 on 2016/11/9.
 */
import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {CloudEnvironmentConfigComponent} from './cloud-environment-config.component';

const routes: Routes = [
  {
    path: 'ops-insight-config',
    children: [
      {path: 'cloud-environment-config', component: CloudEnvironmentConfigComponent},
    ]
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
