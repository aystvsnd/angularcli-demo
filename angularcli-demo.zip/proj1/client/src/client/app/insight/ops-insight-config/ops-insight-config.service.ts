/**
 * Created by 10192595 on 2016/11/10.
 */
import {Injectable} from '@angular/core';
import { ApiResourceService as Http } from '../../apiResource.service';
import { Response} from '@angular/http';
import 'rxjs/add/operator/toPromise';
import {
  CloudEnvironment,
  CloudEnvironmentInfo,
  CurrentCloudEnvironmentDeployStatus
} from 'ops-insight-config.interface';

@Injectable()
export class OpsInsightConfigService {

  constructor(public http: Http) {
  }

  getCloudEnvironment(): Promise<CloudEnvironmentInfo> {
    return this.http.get('/api/v1/connector/cloudenvs/current').toPromise().then((res: Response) => {
      return res.json();
    }).catch(err => {
        return Promise.reject(err);
      });
  }

  getCurrentCloudEnvironment(): Promise<CloudEnvironment> {
    return this.getCloudEnvironment().then((res: CloudEnvironmentInfo) => {
      return res.current;
    }).catch(err => {
        return Promise.reject(err);
      });
  }

  postCurrentCloudEnvironment(cloudEnvironment: CloudEnvironment) {
    return this.http.post('/api/v1/connector/cloudenvs/current/update',
                      cloudEnvironment).toPromise();
  }

  getCloudEnvironmentList(): Promise<CloudEnvironment[]> {
    return this.getCloudEnvironment().then((res: CloudEnvironmentInfo) => {
      return res.cloudenvs;
    }).catch(err => {
        return Promise.reject(err);
      });
  }

  getCurrentCloudEnvironmentDeployStatus(): Promise<CurrentCloudEnvironmentDeployStatus> {
    return this.http.get('/api/v1/connector/cloudenvs/current/deploy/status').toPromise().then((res) => {
      return res.json();
    });
  }
}
