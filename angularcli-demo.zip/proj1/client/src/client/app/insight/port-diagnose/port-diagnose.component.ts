import {Component, OnInit, ViewChild, AfterViewInit} from '@angular/core';
import { NgModelGroup } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/observable/of';
import { Subject } from 'rxjs/Subject';

import {PortDiagnoseService} from './port-diagnose.service';
import {SendMessageService} from '../../sendMessage.service';
import {ContinuousRequest} from '../common/continuous-request';

import {TranslateService} from '@ngx-translate/core';
import {StorageService} from '../../storage.service';

declare var jQuery: any;

interface VmNetInfo {
  name: string;
  ip: string;
}

@Component({
  moduleId: module.id,
  templateUrl: 'port-diagnose.component.html',
  styleUrls: ['../css/common.css', '../css/table.css', './port-diagnose.component.css']
})
export class PortDiagnoseComponent implements OnInit, AfterViewInit {
  get vm1Id(): string {
    return this._vm1Id;
  }

  set vm1Id(id: string) {
    this._vm1Id = id;
    this.vm1IdSearchStream.next(id);
  }

  get vm2Id(): string {
    return this._vm2Id;
  }

  set vm2Id(id: string) {
    this._vm2Id = id;
    this.vm2IdSearchStream.next(id);
  }

  vm1HostName: string;
  vm2HostName: string;

  _vm1NetSel: string;
  set vm1Net(netIdx: string) {
    this._vm1NetSel = netIdx;
    if (this.vm1NetOptions[netIdx] && this.vm1NetOptions[netIdx].ip) {
      this.vm1Ip = this.vm1NetOptions[netIdx].ip;
      this.vm1IpReadonly = true;
      this.VMNetAddr1 = '';
      this.VMNetMask1 = '';
      this.VMGateway1 = '';
      // don't change focus when users are entering vmId
      if (document.activeElement !== document.querySelector('form input[name=vm1Id]')) {
        this.focusElement('form input[name=vm2Id]');
      }
    } else {
      this.vm1Ip = '';
      this.vm1IpReadonly = false;
      if (document.activeElement !== document.querySelector('form input[name=vm1Id]')) {
        this.focusElement('form input[name=vm1Ip]');
      }
    }
    this.checkIfNeedInputVMNetAddr();
  }

  get vm1Net(): string {
    return this._vm1NetSel;
  }

  @ViewChild('testeeGroup') testeeFormGroup: NgModelGroup;

  vm1NetOptions: Array<VmNetInfo> = [];
  vm1NetDisable = true;
  vm1NetTooltip: string = this.translate.instant('insight.portdiagnose.tipInputVMId');

  _vm2NetSel: string;
  set vm2Net(netIdx: string) {
    this._vm2NetSel = netIdx;
    if (this.vm2NetOptions[netIdx] && this.vm2NetOptions[netIdx].ip) {
      this.vm2Ip = this.vm2NetOptions[netIdx].ip;
      this.vm2IpReadonly = true;
      this.VMNetAddr2 = '';
      this.VMNetMask2 = '';
      this.VMGateway2 = '';
    } else {
      this.vm2Ip = '';
      this.vm2IpReadonly = false;
      // don't change focus when users are entering vmId
      if (document.activeElement !== document.querySelector('form input[name=vm2Id]')) {
        this.focusElement('form input[name=vm2Ip]');
      }
    }
    this.checkIfNeedInputVMNetAddr();
  }

  get vm2Net(): string {
    return this._vm2NetSel;
  }
  vm2NetOptions: Array<VmNetInfo> = [];
  vm2NetDisable = true;
  vm2NetTooltip: string = this.translate.instant('insight.portdiagnose.tipInputVMId');

  duplicateIp = false;

  _vm1Ip: string;
  _vm2Ip: string;
  vm1IpReadonly = false;
  vm2IpReadonly = false;
  get vm1Ip(): string {
    return this._vm1Ip;
  }
  set vm1Ip(ip: string) {
    this._vm1Ip = ip;
  }

  get vm2Ip(): string {
    return this._vm2Ip;
  }
  set vm2Ip(ip: string) {
    this._vm2Ip = ip;
  }

  _VMNetAddr1: string;
  _VMNetMask1: string;
  _VMGateway1: string;
  _VMNetAddr2: string;
  _VMNetMask2: string;
  _VMGateway2: string;

  get VMNetAddr1(): string {
    return this._VMNetAddr1;
  }
  set VMNetAddr1(ip: string) {
    this._VMNetAddr1 = ip;
  }
  get VMNetMask1(): string {
    return this._VMNetMask1;
  }
  set VMNetMask1(ip: string) {
    this._VMNetMask1 = ip;
  }
  get VMGateway1(): string {
    return this._VMGateway1;
  }
  set VMGateway1(ip: string) {
    this._VMGateway1 = ip;
  }

  get VMNetAddr2(): string {
    return this._VMNetAddr2;
  }
  set VMNetAddr2(ip: string) {
    this._VMNetAddr2 = ip;
  }
  get VMNetMask2(): string {
    return this._VMNetMask2;
  }
  set VMNetMask2(ip: string) {
    this._VMNetMask2 = ip;
  }
  get VMGateway2(): string {
    return this._VMGateway2;
  }
  set VMGateway2(ip: string) {
    this._VMGateway2 = ip;
  }

  needTesterVMAddr = false;

  srcIpAddressFormatError: boolean;
  dstIpAddressFormatError: boolean;

  faultCause: string;
  errorCause = '';
  diagReq: any;
  diagnoseResult: any;
  isdiagnosing: boolean;
  showError = false;
  showSuccess = false;
  diagnosePercent = 0;
  processTimer: any;
  stopProcessBar = false;

  private _vm1Id: string;
  private vm1IdSearchStream = new Subject<string>();
  private _vm2Id: string;
  private vm2IdSearchStream = new Subject<string>();

  constructor(private service: PortDiagnoseService,
              private sendMessageService: SendMessageService,
              private translate: TranslateService,
              private storageService: StorageService) {

    if (this.storageService.getCurrentLang() === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }

    this.isdiagnosing = false;
    this.showError = false;
    this.showSuccess = false;
  }

  debugButton(v1NetDisable: boolean,
              v2NetDisable: boolean,
              vmNetAddr1: any,
              vmNetMask1: any,
              vmGetway1: any,
              vmNetAddr2: any,
              vmNetMask2: any,
              vmGetway2: any) {
    console.log('v1NetDisable is ' + v1NetDisable);
    console.log('v2NetDisable is ' + v2NetDisable);
    console.log('vmNetAddr1.invalid is ' + vmNetAddr1.invalid);
    console.log('vmNetMask1.invalid is ' + vmNetMask1.invalid);
    console.log('vmGetway1.invalid is ' + vmGetway1.invalid);
    console.log('vmNetAddr2.invalid is ' + vmNetAddr2.invalid);
    console.log('vmNetMask2.invalid is ' + vmNetMask2.invalid);
    console.log('vmGetway2.invalid is ' + vmGetway2.invalid);

    // this.requestDiagnose();
  }
  ngOnInit() {
    this.vm1IdSearchStream
      .debounceTime(300).distinctUntilChanged()
      .filter((id: string) => {
        this.vm1NetDisable = true;  // enabled by the response to getVmInfo request
        this.vm1Net = '-1'; // clear the display content in select
        if (id.trim() === '') {
          this.vm1NetTooltip = this.translate.instant('insight.portdiagnose.tipInputVMId');
          return false;
        } else {
          return true;
        }
      })
      .switchMap((id: string) => {
        this.vm1NetTooltip = this.translate.instant('insight.portdiagnose.tipQueryNet');
        return this.service.getVmNetAndHostInfo(id).catch(
            err => {
              this.vm1NetTooltip = this.translate.instant('insight.portdiagnose.tipQueryNetFailed');
              // dont't use throw as it would end the observable
              return Observable.of(new Error(err)); });
        })
      .subscribe(
        (data: any) => {
          if (data instanceof Error) {
            console.log('端口诊断：查询虚机信息失败 ' + data);
          } else if (data.status === 'error') {
            this.vm1NetTooltip = this.translate.instant('insight.portdiagnose.tipQueryNetFailed');
            console.log('端口诊断：查询虚机信息失败 ' + data.cause);
          } else {
            this.vm1NetOptions = data.vm_ports;
            this.vm1HostName = data.host_name;
            this.vm1NetDisable = false;
            this.vm1Net = '0';  // select the first option as the default
          }
        });

    this.vm2IdSearchStream
      .debounceTime(300).distinctUntilChanged()
      .filter((id: string) => {
        this.vm2NetDisable = true;  // enabled by the response to getVmInfo request
        this.vm2Net = '-1'; // clear the display content in select
        if (id.trim() === '') {
          this.vm2NetTooltip = this.translate.instant('insight.portdiagnose.tipInputVMId');
          return false;
        } else {
          return true;
        }
      })
      .switchMap((id: string) => {
        this.vm2NetTooltip = this.translate.instant('insight.portdiagnose.tipQueryNet');
        return this.service.getVmNetAndHostInfo(id).catch(
            err => {
              this.vm2NetTooltip = this.translate.instant('insight.portdiagnose.tipQueryNetFailed');
              // dont't use throw as it would end the observable
              return Observable.of(new Error(err)); });
        })
      .subscribe(
        (data: any) => {
          if (data instanceof Error) {
            console.log('端口诊断：查询虚机信息失败 ' + data);
          } else if (data.status === 'error') {
            this.vm2NetTooltip = this.translate.instant('insight.portdiagnose.tipQueryNetFailed');
            console.log('端口诊断：查询虚机信息失败 ' + data.cause);
          } else {
            this.vm2NetOptions = data.vm_ports;
            this.vm2HostName = data.host_name;
            this.vm2NetDisable = false;
            this.vm2Net = '0';
          }
        });
  }

  ngAfterViewInit() {
    if (this.service.lastDiagInfo && !this.isdiagnosing) {
      this.diagnoseResult = this.service.lastDiagInfo;
    }
  }

  vmIpInputBlur() {
    this.duplicateIp = (this.vm1Ip === this.vm2Ip);
  }

  vmIpInputFocus() {
    this.duplicateIp = false;
  }

  setLastDiagInfo(diagInfo: any) {
    this.service.lastDiagInfo = diagInfo;
  }

  focusElement(selector: string) {
    let elem: HTMLElement;
    elem = document.querySelector(selector) as HTMLInputElement;
    if (elem) {
      elem.focus();
    }
  }

  checkIfNeedInputVMNetAddr() {
    if ((!this.vm1NetDisable) && (!this.vm2NetDisable)) {
      if ((this.vm1NetOptions[this.vm1Net].ip === '')
        || (this.vm2NetOptions[this.vm2Net].ip === '')) {
            this.needTesterVMAddr = true;
          } else {
            this.needTesterVMAddr = false;
          }
    } else {
      this.needTesterVMAddr = false;
    }
  }

  clearDiagResult() {
    this.diagnoseResult = null;
    this.service.lastDiagInfo = null;
  }

  requestDiagnose() {
    this.showError = false;
    this.showSuccess = false;

    let clientId;

    this.diagReq = { 'srcVmPort': { 'vm_id': this.vm1Id, 'network_name': this.vm1NetOptions[this.vm1Net].network_name,
                                    'vm_port_ip': this.vm1Ip, 'test_vm_ip': (this.VMNetAddr1 || ''),
                                    'gate_way': (this.VMGateway1 || ''), 'subnet_mask': (this.VMNetMask1 || '') },
                     'dstVmPort': { 'vm_id': this.vm2Id, 'network_name': this.vm2NetOptions[this.vm2Net].network_name,
                                    'vm_port_ip': this.vm2Ip, 'test_vm_ip': (this.VMNetAddr2 || ''),
                                    'gate_way': (this.VMGateway2 || ''), 'subnet_mask': (this.VMNetMask2 || '') },
                   };
    this.service.postPortDiagnoseTest(this.diagReq)
      .subscribe(
        res => {
          this.diagnosePercent = 0;
          this.stopProcessBar = false;
          if (res.status === 'ok') {
            clientId = res.client_id;
            if (clientId) {
              this.isdiagnosing = true;
              this.getDiagnoseInfoTimeout();
              this.getDiagnoseResult(clientId).then(() => {
                this.sendMessageService.portDiagnoseComplete();
              }).catch(err => {
                this.sendMessageService.sendResponseMsg(err);
              });
            } else {
              console.error('Port Diagnose Error: no client_id in response!');
              return;
            }
          } else {
            this.showError = true;
            this.errorCause = res.cause;
            this.clearDiagResult();
            console.log('start diagnose error: ' + res.cause);
          }},
        err => {  this.showError = true;
                  this.clearDiagResult();
                  console.log('start diagnose error: ' + err); });
  }

  getDiagnoseInfoTimeout() {
    this.processTimer = window.setInterval(() => {
      // this.diagnosePercent = parseFloat((this.diagnosePercent + 0.1).toFixed(1));
      if (this.stopProcessBar === true) {
        return;
      }
      this.diagnosePercent += 1;
      if (this.diagnosePercent >= 100) {
        window.clearInterval(this.processTimer);
        this.diagnosePercent = 100;
        this.isdiagnosing = false;
        this.showSuccess = false;
        this.showError = true;
        this.errorCause = 'Timeout!';
      }
    }, 3000);
  }
  getDiagnoseResult(clientId: string) {
    const that = this;
    that.clearDiagResult();
    const cr = new ContinuousRequest(
      that.service,
      res => {
        return res.status === 'waiting';
      },
      that.service.postPortDiagnoseTestResult,
      clientId
    );
    cr.setDelay(3000);
    cr.setTimeout(100);   // 100 * 3s = 300 s, wait 5 minutes at most.
    return cr.toPormise()
      .then(res => {
        if (res.status === 'ok') {
          that.diagnosePercent = 100;
          window.clearInterval(that.processTimer);
          that.stopProcessBar = true;
          window.setTimeout(() => {
            that.isdiagnosing = false;
            }, 1000
          );
          // that.isdiagnosing = false;
          if (res.result.length === 0) {
            that.showSuccess = true;
            that.showError = false;
          } else if (res.result.length !== 0) {
            that.showSuccess = false;
            that.showError = false;
            that.diagnoseResult = {'diagReq': that.diagReq, 'host1Id': that.vm1HostName,
              'host2Id': that.vm2HostName, 'diagResp': res};
            that.setLastDiagInfo(that.diagnoseResult);
          }
        } else if (res.status === 'error') {
          that.isdiagnosing = false;
          that.diagnosePercent = 100;
          window.clearInterval(that.processTimer);
          that.stopProcessBar = true;
          that.showSuccess = false;
          that.showError = true;
          that.errorCause = res.cause;
        }
      });
  }

}
