import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { CommonModule } from '@angular/common';
import {SharedModule} from '../../shared/index';

import { PortDiagnoseComponent }   from './port-diagnose.component';
import {PortDiagnoseService} from './port-diagnose.service';
import {routing} from './port-diagnose.routes';
import {InsightCommonModule} from '../common/common.module';
import {PortStateGraphComponent} from './port-state-graph/port-state-graph.component';

@NgModule({
    imports: [SharedModule, routing, FormsModule, CommonModule, InsightCommonModule],
    declarations: [PortDiagnoseComponent, PortStateGraphComponent],
    providers: [PortDiagnoseService],
})
export class PortDiagnoseModule { }
