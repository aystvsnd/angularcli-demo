import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {PortDiagnoseComponent} from './port-diagnose.component';

const routes: Routes = [
  {
    path: 'port-diagnose',
    component: PortDiagnoseComponent,
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
