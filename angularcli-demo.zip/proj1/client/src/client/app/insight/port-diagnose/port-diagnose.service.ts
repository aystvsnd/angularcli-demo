﻿import {Injectable} from '@angular/core';
import { Response } from '@angular/http';
import { ApiResourceService as Http } from '../../apiResource.service';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class PortDiagnoseService {
  lastDiagInfo: any;

  constructor(private http: Http) {
    this.lastDiagInfo = null;
  }

  postPortDiagnoseTest(data) {
    return this.http.post('/api/v1/nid/netDiagReq', data)
            .map((res: Response) => {
                if (res.status < 400) {
                  return res.json();
                } else {
                  throw res.text();
                }
            });
  }

  postPortDiagnoseTestResult(clientId: string) {
    return this.http.post('/api/v1/nid/netDiagQuery', {'client_id': clientId})
      .toPromise()
      .then(res => {
        const reqRes = res.json();
        return reqRes;

        ///*if (reqRes.status != 'error') {
        //
        //} else {
        //  return Promise.reject(reqRes.result);
        //}*/
      })
      .catch();
  }

  getVmNetAndHostInfo(vmId: string) {
    // the current uri is a only a placeholder, it need to be updated later.
    return this.http.post('/api/v1/nid/vmPortQuery', {'vmId': vmId}).map(
      (res: Response) => {
        if (res.status < 400) {
          return res.json();
        } else {
          throw res.text();
        }
      }
    );
  }

}
