export const CONST_STR = {
  inside_host: 'Inside host',
  inside_chassis: 'Inside chassis',
  between_chassis: 'Between chassis',
  dvs: 'Dvs',
  sriov: 'Sriov',
  ovs: 'Ovs',
  default_port: 'port',
  port_type_phy: 'phy_ports',
  port_type_up: 'up_port',
  port_type_down: 'down_port',
  port_type_vm: 'vm_port',
  port_type_inner_sw: 'inner_switch',
  port_type_inter_sw: 'inter_switch'
};

export const constTopoLabel = {
  dvsdvs: 'dvsdvs',
  dvssrv: 'dvssrv',
  srvdvs: 'srvdvs',
  srvsrv: 'srvsrv'
};
