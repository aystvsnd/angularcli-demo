import { CONST_STR } from './common';
import { getOneHostTopo } from './one-host-topo';
import { getOneChassisTopo } from './one-chassis-topo';
import { getTwoChassisTopo } from './two-chassis-topo';


export function cons_topo_data(diagReq: any, host1Id: string, host2Id: string, diagResp: any): PathTopoData {

  if (diagResp.vm_relation === CONST_STR.inside_host) {
    return getOneHostTopo(diagReq, host1Id, host2Id, diagResp);
  } else if (diagResp.vm_relation === CONST_STR.inside_chassis) {
    return getOneChassisTopo(diagReq, host1Id, host2Id, diagResp);
  } else if (diagResp.vm_relation === CONST_STR.between_chassis) {
    return getTwoChassisTopo(diagReq, host1Id, host2Id, diagResp);
  } else {
    console.log('Port diagnose error: diagResp.vm_relation is ' + diagResp.vm_relation);
    return null;
  }
}

