/**
 * @param entityInfo: all entity info
 * @param width: total width available for there entites
 * @param height: total height available for there entites
*/
const outerMargin = 30;
const switchWidth = 160;
export function computeLayout(entityInfo: NetEntitySet, width: number, height: number): boolean {

  const chassis = entityInfo.chassis;
  const hosts = entityInfo.hosts;
  if (hosts) {
    if (hosts.length === 1) {
      return layoutOneHost(entityInfo, width, height);
    } else if (hosts.length === 2) {
      if (chassis && chassis.length === 1) {
        return layoutOneChassisTwoHosts(entityInfo, width, height);
      } else if (chassis && chassis.length === 2) {
        return layoutTwoChassis(entityInfo, width, height);
      } else {
        console.error('Port diagnose computeLayout: entityInfo.chassis is invalid - chassis is '
                    + JSON.stringify(entityInfo.chassis));
        return false;
      }
    } else {
      console.error('Port diagnose computeLayout: entityInfo.hosts is invalid - hosts is '
                    + JSON.stringify(entityInfo.hosts));
      return false;
    }
  } else {
    console.error('Port diagnose computeLayout: entityInfo.hosts is invalid - hosts is '
                    + JSON.stringify(entityInfo.hosts));
    return false;
  }
}


const ratioForFillMissingDvs = 0.2;

function layoutOneChassisTwoHosts(entityInfo: NetEntitySet, width: number, height: number): boolean {
  const chassis = entityInfo.chassis[0];
  const chassisHeightRatio = (entityInfo.switchOutChassis ? 0.75 : 1);
  chassis.x = outerMargin;
  chassis.y = outerMargin;
  chassis.width = width  - outerMargin * 2;
  chassis.height = height * chassisHeightRatio - outerMargin * 2;

  const sideGap = 55, middleGap = 65;

  const hosts = entityInfo.hosts, hostLeft = entityInfo.hosts[0], hostRight = entityInfo.hosts[1];

  const hostHeightRatio = (entityInfo.switchInChassis ? 0.75 : 1);
  const hWidth = (chassis.width - sideGap * 2 - middleGap) * 0.5;
  const hHeight =  (chassis.height - sideGap * 2) * hostHeightRatio;

  for (const h of hosts) {
    h.width = hWidth;
    h.height = hHeight;
    h.y = chassis.y + sideGap;
  }
  hostLeft.x = chassis.x + sideGap;
  hostRight.x = hostLeft.x + hWidth + middleGap;

  if (entityInfo.vms.length !== 2) {
    console.error('path-topo/layout.ts/function computeLayout: entityInfo is invalid - VM numbers should be 2.');
    return false;
  }

  // vm layout
  for (const vm of entityInfo.vms) {
    vm.x = vm.host.x + sideGap;
    vm.y = vm.host.y + sideGap + (vm.host.hasDvs ? 0 : vm.host.height * ratioForFillMissingDvs);
    vm.width = vm.host.width - sideGap * 2;
    vm.height = vm.host.height * 0.2;
  }

  if (entityInfo.dvs) {
    for (const dvs of entityInfo.dvs) {
      dvs.x = dvs.host.x + sideGap;
      dvs.y = dvs.host.y + dvs.host.height * 0.6;
      dvs.width = dvs.host.width - sideGap * 2;
      dvs.height = dvs.host.height * 0.1;
    }
  }

  if (entityInfo.switchInChassis) {
    // At present, there seems no need for more than one switches
    const sw = entityInfo.switchInChassis[0];
    sw.width = switchWidth;
    sw.height = 40;
    sw.x = chassis.x + chassis.width * 0.5 - sw.width * 0.5;
    sw.y = chassis.y + chassis.height - chassis.height * (1 - hostHeightRatio) * 0.5;
  }

  if (entityInfo.switchOutChassis) {
    //there should be no more than one switch out of chassis
    const sw = entityInfo.switchOutChassis[0];
    sw.width = switchWidth;
    sw.height = 40;
    sw.x = width * 0.5 - sw.width * 0.5;
    sw.y = height - height * (1 - chassisHeightRatio) * 0.5;
  }

  layoutPort(entityInfo.ports);

  return true;
}


function layoutPort(ports: Array<PathTopoPort>) {
  const pWidth = 40, pHeight = 15;

  for (const p of ports) {
    p.width = pWidth;
    p.height = pHeight;
    const offset = 2;  // offset  make the prot looks more intimate to its parent

     // leftPoart/rightPort indicate: There is only one dvs and  both ports of the dvs are on the upper side.
    if (p.isLeftPort) {
      p.x = p.parent.x + p.parent.width * 0.2;
      p.y = p.parent.y - pHeight + offset;
    } else if (p.isRightPort) {
      p.x = p.parent.x + p.parent.width * 0.8 - pWidth;
      p.y = p.parent.y - pHeight + offset;
    } else if (p.isUpPort) {
      p.x = p.parent.x + p.parent.width * 0.5 - pWidth * 0.5;
      p.y = p.parent.y - pHeight + offset;
    } else {
      p.x = p.parent.x + p.parent.width * 0.5 - pWidth * 0.5;
      p.y = p.parent.y + p.parent.height - offset;
    }
  }
}


/*
 Adjust the attach point of the link, as the x,y of source/target is the top-left coordinate which make the links
looks wierd.
*/
export function layoutLinks(links: PathTopoLinks) {

  /**
   * To place the attach-point on either side but not the center
   * @param objWidth
   * @param selfX should be the x-coordinate of the center
   * @param peerX should be the x-coordinate of the center
   */

  for (const link of links) {
    /* Attach-points on a port should always be at center horizontally.
    */
    link.x0 = link.source.x + link.source.width * 0.5;
    link.y0 = link.source.y;

    link.x1 = link.target.x + link.target.width * 0.5;
    link.y1 = link.target.y;

    if (link.y1 > link.y0) {
      link.y0 += link.source.height;
    } else if (link.y0 > link.y1) {
      link.y1 += link.target.height;
    } else {
      /* when source and target at the same height, place the attach point at center vertically */
      link.y0 += link.source.height * 0.5;
      link.y1 += link.target.height * 0.5;
    }

    // adjust the attach-point for switch, here we use width as a criteria for switch as there is no type info
    const breakWidth = 50;
    /* There may be 3 switches at most on the graph, but only one switch needs to adjust its attach point, and this
      switch's position has two characteristic: 1. below its peer 2. not on a vertical line with its peer*/
    const minDistance = 10;   // set a minDistance to eliminate any computational diviation
    if (link.source.width >= breakWidth) {
      if ((link.y0 - link.y1 > minDistance) && (link.x1 - link.x0 > minDistance)) {
        link.x0 = link.source.x + link.source.width;
        link.y0 = link.source.y + link.source.height * 0.5;
      }
    }

    if (link.target.width >= breakWidth) {
      if ((link.y1 - link.y0 > minDistance) && (link.x1 - link.x0 > minDistance)) {
        link.x1 = link.target.x;
        link.y1 = link.target.y + link.target.height * 0.5;
      }
    }

    if (link.isCurve) {
      link.controlPoint = {x: 0, y: 0};
      switch (link.curveType) {
        case 1:
          link.controlPoint.x = link.x0;
          link.controlPoint.y = link.y1;
          break;
        case 2:
          link.controlPoint.x = (link.x0 + link.x1) * 0.5;
          link.controlPoint.y = link.source.y + (<PathTopoPort>link.source).parent.height * 1.3;
          // usually the attachpoint at the center when the source and target has the same y-coordinate,
          // but when the link is curve, it would be better to place the attach point on the side of the source/target.
          link.y0 += link.source.height * 0.5;
          link.y1 += link.target.height * 0.5;
          break;
        case 3:
          link.controlPoint.x = link.x1;
          link.controlPoint.y = link.y0;
          break;
        default:
          console.error(`layout Error: link.curveType(${link.curveType}) is unknown!`);
          break;
      }
    }
  }
}


function layoutOneHost(entityInfo: NetEntitySet, width: number, height: number): boolean {
  const chassis = (entityInfo.chassis ? entityInfo.chassis[0] : null);
  const host = entityInfo.hosts[0];
  const sideGap = 55;
  const hostHeightRatio =  0.75; // At present, there is always a switch in a chassis.
  const chassisHeightRatio = 0.85;

  if (chassis) {
    chassis.x = outerMargin;
    chassis.y = outerMargin;
    chassis.width = width - outerMargin * 2;
    chassis.height = height * chassisHeightRatio - outerMargin * 2;
    host.width = host.chassis.width - sideGap * 2;
    host.height = (host.chassis.height - sideGap * 2) * hostHeightRatio;
    host.x = host.chassis.x + sideGap;
    host.y = host.chassis.y + sideGap;
  } else {
    host.x = outerMargin;
    host.y = outerMargin;
    host.width = width - outerMargin * 2;
    host.height = height - outerMargin * 2;
  }

  if (entityInfo.vms.length !== 2) {
    console.error('path-topo/layout.ts/function computeLayout: entityInfo is invalid - VM numbers should be 2.');
    return false;
  }

  for (const vm of entityInfo.vms) {
    vm.x = vm.host.x + sideGap;
    vm.y = vm.host.y + sideGap + (entityInfo.dvs ? 0 : sideGap * 2);
    vm.width = vm.host.width * 0.5 - sideGap * 2;
    vm.height = vm.host.height * 0.2;
  }
  entityInfo.vms[1].x += entityInfo.vms[1].host.width * 0.5; // move to the right

  if (entityInfo.dvs) {
    for (const dvs of entityInfo.dvs) {
      dvs.x = dvs.host.x + sideGap + (dvs.position === 'right' ? (dvs.host.width * 0.5) : 0);
      dvs.y = dvs.host.y + dvs.host.height * (dvs.position === 'middle' ? 0.7 : 0.6);
      dvs.width = dvs.host.width * (dvs.position === 'middle' ? 1 : 0.5) - sideGap * 2;
      dvs.height = dvs.host.height * 0.15;
    }
  }

  if (entityInfo.switchInChassis) {
    for (const sw of entityInfo.switchInChassis) {
      sw.width = switchWidth;
      sw.height = 40;
      sw.x = sw.chassis.x + sw.chassis.width * 0.5 - sw.width * 0.5;
      sw.y = sw.chassis.y + sw.chassis.height - sw.chassis.height * (1 - hostHeightRatio) * 0.5;
    }
  }

  if (entityInfo.switchOutChassis) {
    //there should be no more than one switch out of chassis
    const sw = entityInfo.switchOutChassis[0];
    sw.width = switchWidth;
    sw.height = 40;
    sw.x = width * 0.5 - sw.width * 0.5;
    sw.y = height - height * (1 - chassisHeightRatio) * 0.5;
  }

  layoutPort(entityInfo.ports);

  // make ovs leftPort and rightPort vertically align with vm port
  for (const p of entityInfo.ports) {
     // leftPoart/rightPort indicate: There is only one dvs and  both ports of the dvs are on the upper side.
    if (p.isLeftPort) {
      for (const tmpPort of entityInfo.ports) {
        // there is only two port on the left part of the host
        if ((tmpPort !== p) && (tmpPort.x < width * 0.5) ) {
          p.x = tmpPort.x;
          break;
        }
      }
    } else if (p.isRightPort) {
      for (const tmpPort of entityInfo.ports) {
        // there is only two port on the right part of the host
        if ((tmpPort !== p) && (tmpPort.x > width * 0.5) ) {
          p.x = tmpPort.x;
          break;
        }
      }
    }
  }

  return true;
}


function layoutTwoChassis(entityInfo: NetEntitySet, width: number, height: number): boolean {
  const chassisHeightRatio = 0.8;
  for (const chassis of entityInfo.chassis) {
    chassis.x = outerMargin;
    chassis.y = outerMargin;
    chassis.width = width * 0.5 - outerMargin * 2;
    chassis.height = (height - outerMargin * 2) * chassisHeightRatio;
  }
  entityInfo.chassis[1].x += width * 0.5; // shift the second chassis

  const sideGap = 55;

  const hostHeightRatio =  0.7; // At present, there is always a switch in a chassis.

  const hosts = entityInfo.hosts;
  for (const h of hosts) {
    h.width = h.chassis.width - sideGap * 2;
    h.height = (h.chassis.height - sideGap * 2) * hostHeightRatio;
    h.x = h.chassis.x + sideGap;
    h.y = h.chassis.y + sideGap;
  }

  if (entityInfo.vms.length !== 2) {
    console.error('path-topo/layout.ts/function computeLayout: entityInfo is invalid - VM numbers should be 2.');
    return false;
  }

  // vm layout
  for (const vm of entityInfo.vms) {
    vm.x = vm.host.x + sideGap;
    // when there is no dvs, move the vm a little downward
    vm.y = vm.host.y + sideGap + (vm.host.hasDvs ? 0 : vm.host.height * ratioForFillMissingDvs);
    vm.width = vm.host.width - sideGap * 2;
    vm.height = vm.host.height * 0.2;
  }

  if (entityInfo.dvs) {
    for (const dvs of entityInfo.dvs) {
      dvs.x = dvs.host.x + sideGap;
      dvs.y = dvs.host.y + dvs.host.height * 0.6;
      dvs.width = dvs.host.width - sideGap * 2;
      dvs.height = dvs.host.height * 0.1;
    }
  }

  if (entityInfo.switchInChassis) {
    for (const sw of entityInfo.switchInChassis) {
      sw.width = switchWidth;
      sw.height = 40;
      sw.x = sw.chassis.x + sw.chassis.width * 0.5 - sw.width * 0.5;
      sw.y = sw.chassis.y + sw.chassis.height - sw.chassis.height * (1 - hostHeightRatio) * 0.5;
    }
  }

  if (entityInfo.switchOutChassis) {
    //there should be no more than one switch out of chassis
    const sw = entityInfo.switchOutChassis[0];
    sw.width = switchWidth;
    sw.height = 40;
    sw.x = width * 0.5 - sw.width * 0.5;
    sw.y = height - height * (1 - chassisHeightRatio) * 0.5;
  }

  layoutPort(entityInfo.ports);

  return true;
}
