import { CONST_STR, constTopoLabel } from './common';

const chassis1: PathTopoNetEntity = {id: 'chassis1' };
const host1: PathTopoHost = {id: 'host11', hasDvs: true};

const vm1: PathTopoVM = {id: 'vm1', host: host1};
const vm2: PathTopoVM = {id: 'vm2', host: host1};
const dvs1: PathTopoDvs = {id: 'dvs1', host: host1};
const portHost1: PathTopoPort = {id: 'port', parent: host1},
    portVm1: PathTopoPort = {id: 'port', parent: vm1},
    portVm2: PathTopoPort = {id: 'port', parent: vm2},
    portDvs1: PathTopoPort = {id: 'port', parent: dvs1},
    portDvs1Up: PathTopoPort = {id: 'port', parent: dvs1, isUpPort: true},
    portDvs1Left: PathTopoPort = {id: 'port', parent: dvs1, isLeftPort: true},
    portDvs1Right: PathTopoPort = {id: 'port', parent: dvs1, isRightPort: true};
const sw1: PathTopoSwitch = {id: 'inner_switch', inChassis: true, chassis: chassis1};
const sw3: PathTopoSwitch = {id: 'inter_switch', inChassis: false};

export function getOneHostTopo(diagReq: any, host1Id: string, host2Id: string, diagResp: any): PathTopoData {
  vm1.id = diagReq.srcVmPort.vm_id;
  vm2.id = diagReq.dstVmPort.vm_id;
  vm1.detail = {'ip': diagReq.srcVmPort.vm_port_ip};
  vm2.detail = {'ip': diagReq.dstVmPort.vm_port_ip};
  host1.id = host1Id;

  host1.hasDvs = (diagResp.src_vm_vnic_type !== CONST_STR.sriov);

  portVm1.id = diagReq.srcVmPort.vm_port_ip;
  portVm2.id = diagReq.dstVmPort.vm_port_ip;

  // id of up_port and phy_port may be modified, hence they need to be restored every time
  portDvs1Up.id = portDvs1Left.id = portDvs1Right.id = portHost1.id = 'port';

  dvs1.state  = sw1.state = sw3.state = 'good';

  let topoLabel: string;
  if (diagResp.src_vm_vnic_type === CONST_STR.sriov) {
    host1.chassis = chassis1;   // have chassis when one of the vnic_type is sriov
    if (diagResp.dst_vm_vnic_type === CONST_STR.sriov) {
      topoLabel = constTopoLabel.srvsrv;
    } else {
      topoLabel = constTopoLabel.srvdvs;
      dvs1.id = diagResp.dst_vm_vnic_type;
    }
  } else {
    dvs1.id = diagResp.src_vm_vnic_type;
    if (diagResp.dst_vm_vnic_type === CONST_STR.sriov) {
      topoLabel = constTopoLabel.dvssrv;
      host1.chassis = chassis1;
    } else {
      topoLabel = constTopoLabel.dvsdvs;
      delete host1.chassis;
    }
  }

  const data = consData(topoLabel);
  if (data) {
    const dvsAtMiddle = (data.entityInfo.dvs && (data.entityInfo.dvs[0].position === 'middle'));
    (diagResp.result as any[]).forEach(path => markLink(path, data.links, dvsAtMiddle));
  }
  return data;
}

function consData(label: string): PathTopoData {
  let data: PathTopoData;
  switch (label) {
    case constTopoLabel.dvsdvs:
      dvs1.position = 'middle';
      data = {
        entityInfo: { hosts: [host1], vms: [vm1, vm2], dvs: [dvs1],
                    ports: [portDvs1Left, portDvs1Right, portVm1, portVm2] },
        links: [{source: portVm1, target: portDvs1Left}, {source: portDvs1Right, target: portVm2}]
      };
      break;
    case constTopoLabel.dvssrv:
      dvs1.position = 'left';
      data = {
        entityInfo: { hosts: [host1], vms: [vm1, vm2], dvs: [dvs1], chassis: [chassis1],
                    switchInChassis: [sw1], switchOutChassis: [sw3],
                    ports: [portDvs1Up, portDvs1, portVm1, portVm2, portHost1] },
        links: [{source: portVm1, target: portDvs1Up}, {source: portDvs1, target: portHost1},
                {source: portHost1, target: sw1}, {source: sw1, target: sw3},
                {source: portHost1, target: portVm2}]
      };
      break;
    case constTopoLabel.srvdvs:
      dvs1.position = 'right';
      data = {
        entityInfo: { hosts: [host1], vms: [vm1, vm2], dvs: [dvs1], chassis: [chassis1],
                      switchInChassis: [sw1], switchOutChassis: [sw3],
                    ports: [portDvs1Up, portDvs1, portVm1, portVm2, portHost1] },
        links: [{source: portVm1, target: portHost1}, {source: portHost1, target: portDvs1},
                {source: portHost1, target: sw1}, {source: sw1, target: sw3},
                  {source: portDvs1Up, target: portVm2}]
      };
      break;
    case constTopoLabel.srvsrv:
      data = {
        entityInfo: { hosts: [host1], vms: [vm1, vm2], chassis: [chassis1],
                      switchInChassis: [sw1], switchOutChassis: [sw3],
                    ports:  [ portVm1, portVm2, portHost1] },
        links: [{source: portVm1, target: portHost1}, {source: portHost1, target: portVm2},
                {source: portHost1, target: sw1}, {source: sw1, target: sw3}]
      };
      break;
    default:
      console.log('Port Diagnose: error in constructing topo data, label is ' + label);
      return null;
  }
  return data;
}

function findPortPair(src: any, dst: any, dvsAtMiddle: boolean): PathTopoNetEntity[] {

  /**
   * Get the port of endPoints whose type is not port_type_up since the port can not be determined only by the
   * endPoint if its type is port_type_up.
   * @param endPoint
   */
  function getPort(endPoint: any): PathTopoNetEntity {
    switch (endPoint.type) {
      case CONST_STR.port_type_phy:
        portHost1.id = endPoint.id;
        return portHost1;
      case CONST_STR.port_type_vm:
        return (endPoint.id === portVm1.id) ? portVm1 : portVm2;
      case CONST_STR.port_type_down:
        return portDvs1;
      case CONST_STR.port_type_inner_sw:
        return sw1;
      case CONST_STR.port_type_inter_sw:
        return sw3;
      default:
        console.log('Diagnose topo error: endpoint.type is ' + endPoint.type);
        return null;
    }
  }

  let srcEntity: PathTopoNetEntity = null, dstEntity: PathTopoNetEntity = null;
  /* There are 3 ports that match port_type_up : portDvs1Up, portDvs1Left, portDvs1Right.
    So it may not be possible to determine the port without the peer port information.
  */
  if (src.type !== CONST_STR.port_type_up) {
    srcEntity = getPort(src);
    if (!srcEntity) {
      return [null, null];
    }
  }

  if (dst.type !== CONST_STR.port_type_up) {
    dstEntity = getPort(dst);
    if (!dstEntity) {
      return [null, null];
    }
  }

  if (srcEntity && dstEntity) {
    return [srcEntity, dstEntity];
  } else {
    if (dvsAtMiddle) {
      // when dvs is at middle position: there are two up_ports: portDvs1Left, portDvs1Right
      if (src.type === CONST_STR.port_type_up) {
        if (dst.type === CONST_STR.port_type_up) {
          srcEntity = portDvs1Left;
          portDvs1Left.id = src.id;
          dstEntity = portDvs1Right;
          portDvs1Right.id = dst.id;
        } else {
          if (dstEntity === portVm1) {
            srcEntity = portDvs1Left;
            portDvs1Left.id = src.id;
          } else {
            srcEntity = portDvs1Right;
            portDvs1Right.id = src.id;
          }
        }
      } else {
        if (srcEntity === portVm1) {
          dstEntity = portDvs1Left;
          portDvs1Left.id = dst.id;
        } else {
          dstEntity = portDvs1Right;
          portDvs1Right.id = dst.id;
        }
      }
    } else {
      // when dvs is not at middle position, there is only one up_port: portDvs1Up
      srcEntity = (srcEntity || portDvs1Up);
      dstEntity = (dstEntity || portDvs1Up);
      portDvs1Up.id = (portDvs1Up === srcEntity) ? src.id : dst.id;
    }

    return [srcEntity, dstEntity];
  }
}

function markLink(path: any, links: PathTopoLinks, dvsAtMiddle: boolean) {
  let portPair: PathTopoNetEntity[];

  portPair = findPortPair(path.src, path.dst, dvsAtMiddle);

  if ((portPair[0] === null) || (portPair[1] === null)) {
    return;
  }

  function setStateAndSuggection(netEntity: PathTopoNetEntity, suggestion: any) {
    netEntity.state = 'bad';
    netEntity.detail = Object.assign((netEntity.detail || {}), {suggestion});
  }

  if (portPair[0] === portPair[1]) {  // problem on sw
    setStateAndSuggection(portPair[0], path.suggestion);
    return;
  }

  const port0: PathTopoPort = (portPair[0] as PathTopoPort),
      port1: PathTopoPort = (portPair[1] as PathTopoPort);

  if (port0.parent && (port0.parent === port1.parent)) { // problem on dvs
    setStateAndSuggection(port0.parent, path.suggestion);
    return;
  }

  for (const link of links) {
    if (((link.source === portPair[0]) && (link.target === portPair[1]))
      || ((link.target === portPair[0]) && (link.source === portPair[1]))) {
        link.state = 'bad';
        link.detail = {'suggestion': path.suggestion};
        return;
      }
  }

  console.log('Port Diagnose error: cannot find a link which match the result.');
  console.log('path is ' + JSON.stringify(path));
  console.log('links is ' + JSON.stringify(links));
}

