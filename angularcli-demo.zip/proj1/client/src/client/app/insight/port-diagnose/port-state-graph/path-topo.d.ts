interface PathTopoNetEntity {
  id: string;
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  detail?: any;
  state?: 'good'|'bad';
}

interface PathTopoHost extends PathTopoNetEntity {
  hasDvs: boolean;
  chassis?: PathTopoNetEntity;
}

interface PathTopoVM extends PathTopoNetEntity {
  host: PathTopoHost;
}

interface PathTopoDvs extends PathTopoNetEntity {
  host: PathTopoHost;
  // 'position' is only useful when two vms are in the same host where dvs may at the left/right part of the host
  position?: 'left'|'right'|'middle'; 
}

interface PathTopoPort extends PathTopoNetEntity {
  parent: PathTopoNetEntity;
  // there is no flag isDonwPort as down is the default position
  isUpPort?: boolean;
  isLeftPort?: boolean; //leftPoart/rightPort indicate: There is only one dvs and  both ports of the dvs are on the upper side.
  isRightPort?: boolean;
}

interface PathTopoSwitch extends PathTopoNetEntity {
  inChassis?: boolean;
  chassis?: PathTopoNetEntity;
}

interface NetEntitySet {
  chassis?: Array<PathTopoNetEntity>;
  hosts?: Array<PathTopoHost>;
  vms: Array<PathTopoVM>;
  dvs?: Array<PathTopoDvs>;
  switchInChassis?: Array<PathTopoSwitch>;
  switchOutChassis?: Array<PathTopoSwitch>;
  ports: Array<PathTopoPort>;
}

interface PathTopoLink {
  source: PathTopoNetEntity;
  target: PathTopoNetEntity;
  state?: 'good' | 'bad';
  // A link links source and target, but we cannot use the (x,y) of source and target as the start and end of a link
  // as the attach-point is often need to be adjusted a little to achive a better presentation. Therefore, we use (x0, y0)
  // to store the start of the link and (x1,y1) to store the end of the link.
  x0?: number; 
  y0?: number;
  x1?: number;
  y1?: number;
  isCurve?: boolean;
  curveType?: 1|2|3; // 1 - host->switch, 2 - in dvs, 3 - switch -> host
  controlPoint?: {x:number; y:number};
  detail?: any;
}

type PathTopoLinks = Array<PathTopoLink>;

interface PathTopoData {
  entityInfo: NetEntitySet;
  links: PathTopoLinks;
}
