import {Component, Input, ElementRef, ViewChild} from '@angular/core';

import { cons_topo_data } from './cons-topo-data';
import { computeLayout, layoutLinks } from './layouts';

declare const d3;
const d3select = d3.select;

@Component({
  moduleId: module.id,
  selector: 'port-state-graph',
  templateUrl: './port-state-graph.component.html',
  styleUrls: ['./port-state-graph.component.css']
})
export class PortStateGraphComponent {

  viewBoxWidth= 1000;
  viewBoxHeight= 1000;
  location: any;
  hiddenHoverInfo = true;
  additonDiagInfo:any = [];

  @Input() set diagInfo(value: any) {
    console.log('diagInfo is ' + JSON.stringify(value));
    if (!value) {
      return;
    }

    if (value.diagReq && value.host1Id && value.host2Id && value.diagResp) {
      const topoInfo = cons_topo_data(value.diagReq, value.host1Id, value.host2Id, value.diagResp);
      if (topoInfo) {
        this.draw(topoInfo.entityInfo, topoInfo.links);
        this.additonDiagInfo = value.diagResp.addition_diag_info;
        this.getAdditionDiagInfo(this.additonDiagInfo);

      } else {
        console.log('Port Diagnose Error: construct topo info error!');
      }
    } else {
      console.log('Port Diagnose Draw error: diagnose info is incomplete.');
      console.log('diagInfo is ' + JSON.stringify(value));
    }
  }

  @ViewChild('svgHoverInfo') svgHoverInfo: ElementRef;

  constructor() {
    this.location = location;   // location would be used in the template expression
  }
  getAdditionDiagInfo(additonDiagInfo:any) {
    let elem = document.getElementById('addition-paragraph');
    elem.innerHTML = '';
    for (let i = 0; i < additonDiagInfo.length; i++) {
      if (additonDiagInfo[i] !== []) {
        elem.innerHTML += (additonDiagInfo[i][0] + '<br>');
        elem.innerHTML += ('&nbsp;&nbsp;' + additonDiagInfo[i][1] + '<br><br>');
      }
    }
  }

  draw(entityInfo: NetEntitySet, links: PathTopoLinks) {
    const svg  =  d3select('div.topo-container svg');
    if (!svg) {
      console.error('draw error: cannot find svg elements!');
      return;
    }

    const angComponent: PortStateGraphComponent = this;

    function onMouseEnter(data: PathTopoNetEntity|PathTopoLink) {
      function isNetEntity(obj: PathTopoNetEntity | PathTopoLink): obj is PathTopoNetEntity {
        return (<PathTopoNetEntity>obj).id !== undefined;
      }
      // hide hover info first
      angComponent.hiddenHoverInfo = true;

      let elemInfo: any;
      if (isNetEntity(data)) {
        elemInfo = {'id' : data.id};
      } else {
        elemInfo = {};
      }

      if (data.detail) {
        Object.assign(elemInfo, data.detail);
      }

      angComponent.setHoverInfo(elemInfo);
      angComponent.hiddenHoverInfo = false;
    }

    svg.selectAll('g.topoNode').remove();
    svg.selectAll('g.link').remove();

    if (!computeLayout(entityInfo, this.viewBoxWidth, this.viewBoxHeight)) {
      console.error('draw error: layout failed!');
      return;
    }

    layoutLinks(links);

    const rectRadius = 5;

    /**
     * caption is placed at the center.
     * @param sel
     * @param classAttr
     * @param addCaption
     * @param r
     */
    function drawRect(sel: any, classAttr: string, addMouseHover: boolean = true, addCaption: boolean = true, fontSize: string = '18pt',
                      r: number= rectRadius) {
      const rectSel = sel.append('rect').attr('class', classAttr)
      .attr('x', 0).attr('y', 0)
      .attr('width', d => d.width).attr('height', d => d.height)
      .attr('rx', r).attr('ry', r);

      if (addMouseHover) {
        rectSel.on('mouseenter', onMouseEnter)
               .on('mouseleave', angComponent.onMouseLeaveSvg.bind(angComponent));
      }

      if (addCaption) {
        sel.append('text').text(d => d.id)
          .attr('x', d => d.width * 0.5).attr('y', d => d.height * 0.5).attr('dy', '0.35em')
          .attr('font-size', fontSize)
          .attr('text-anchor', 'middle');
      }
    }

    function genLinkLine(link: PathTopoLink): string {
      if (link.isCurve) {
        return  `M ${link.x0}, ${link.y0} Q ${link.controlPoint.x}, ${link.controlPoint.y} ${link.x1}, ${link.y1}`;
      } else {
        return `M ${link.x0}, ${link.y0} L ${link.x1}, ${link.y1}`;
      }
    /*
      + "C" + source.x + "," + (source.y + target.y) / 2
      + " " + target.x + "," + (source.y + target.y) / 2
      + " " + target.x + "," + target.y; */
    }

    function getNodesEnter(classAttr: string, data: any) {
      return svg.selectAll('g.topoNode ' + classAttr).data(data).enter()
                    .append('g')
                    .attr('class', 'topoNode ' + (classAttr || ''))
                    .attr('transform', d => `translate(${d.x}, ${d.y})`);
    }

    let nodesEnter: any;

    if (entityInfo.chassis) {
      nodesEnter = getNodesEnter('chassis', entityInfo.chassis);
      drawRect(nodesEnter, 'chassis', false, false); // don't place the caption at the center
      nodesEnter.append('text').text(d => d.id).attr('font-size', '18pt')
        .attr('x', '0.3em').attr('y', d => d.height).attr('dy', '-0.4em')
        .attr('text-anchor', 'start');
    }

    nodesEnter = getNodesEnter('host', entityInfo.hosts);
    drawRect(nodesEnter, 'host', false, false); // don't place the caption at the center
    nodesEnter.append('text').text(d => d.id).attr('font-size', '18pt')
      .attr('x', '0.3em').attr('y', d => d.height).attr('dy', '-0.4em')
      .attr('text-anchor', 'start');

    nodesEnter = getNodesEnter('vm', entityInfo.vms);
    drawRect(nodesEnter, 'vm', true, false);
    let vmNum = 0;
    nodesEnter.append('text').text(d => {vmNum++; return 'VM-' + vmNum; })
          .attr('x', d => d.width * 0.5).attr('y', d => d.height * 0.5).attr('dy', '0.35em')
          .attr('font-size', '18pt')
          .attr('text-anchor', 'middle');

    if (entityInfo.dvs) {
      nodesEnter = getNodesEnter('dvs', entityInfo.dvs);
      drawRect(nodesEnter, 'dvs');
      nodesEnter.each(function(d) {
        if (d.state === 'bad') {
          d3select(this).attr('class', this.className + ' bad')
            .append('use')
            .attr('xlink:href', location.href + '#warning-sign')
            .attr('transform', `translate(5, -35)`)
            .on('mouseenter', onMouseEnter)
            .on('mouseleave', angComponent.onMouseLeaveSvg.bind(angComponent));
        }
      });
    }

    nodesEnter = getNodesEnter('port', entityInfo.ports);
    drawRect(nodesEnter, 'port', true, false, '', 0);

    if (entityInfo.switchInChassis || entityInfo.switchOutChassis) {
      let tmpChassis: Array<PathTopoSwitch> = [];
      if (entityInfo.switchInChassis) {
        tmpChassis = tmpChassis.concat(entityInfo.switchInChassis);
      }
      if (entityInfo.switchOutChassis) {
        tmpChassis = tmpChassis.concat(entityInfo.switchOutChassis);
      }

      nodesEnter = getNodesEnter('switch', tmpChassis);
      drawRect(nodesEnter, 'switch');
      nodesEnter.each(function(d) {
        if (d.state === 'bad') {
          d3select(this).attr('class', this.className + ' bad').append('use')
            .attr('xlink:href', location.href + '#warning-sign')
            .attr('transform', `translate(5, -35)`)
            .on('mouseenter', onMouseEnter)
            .on('mouseleave', angComponent.onMouseLeaveSvg.bind(angComponent));
        }
      });
    }

    const linksEnter = svg.selectAll('path.link').data(links).enter()
                        .append('g').attr('class', 'link');
    linksEnter.append('path')
      .attr('class', (d: any) => 'link ' + (d.state || ''))
      .attr('d', d => genLinkLine(d));
    linksEnter.each(function(d) {
      if (d.state === 'bad') {
        d3select(this).append('use')
          .attr('xlink:href', location.href + '#warning-sign')
          .attr('transform', (d: PathTopoLink) => {
            let yOffset = 0;
            // The number 10 can be any number big enough to tolerate computional error.
            if ((d.y1 - d.y0) > 10 && (d.x1 - d.x0) > 10) {
              yOffset = -20;
            }
            return `translate(${(d.x0 + d.x1) * 0.5 + 5}, ${(d.y0 + d.y1) * 0.5 + yOffset})`; })
          .on('mouseenter', onMouseEnter)
          .on('mouseleave', angComponent.onMouseLeaveSvg.bind(angComponent));
      }
    });
  }

  setHoverInfo(info: any) {
    const elem = (this.svgHoverInfo.nativeElement as HTMLElement);

    elem.innerHTML  = '';
    for (const prop in info) {
      if (prop === 'suggestion') {
        elem.innerHTML += prop + ': ' + '<br>';
        for (let i = 0; i < info[prop].length; i++) {
          elem.innerHTML += (String(i + 1) + '. ' + info[prop][i]  + '<br>');
        }

      } else {
        elem.innerHTML += (prop + ': ' + JSON.stringify(info[prop]) + '<br>');
      }

    }

    elem.style.top = d3.event.clientY + 'px';
    elem.style.left =  d3.event.clientX + 'px';
  }

  onMouseLeaveSvg() {
    this.hiddenHoverInfo = true;
  }
}

