import { CONST_STR, constTopoLabel } from './common';

const chassis1: PathTopoNetEntity = {id: 'chassis1' };
const chassis2: PathTopoNetEntity = {id: 'chassis2' };
const host1: PathTopoHost = {id: 'host1', hasDvs: true, chassis: chassis1};
const host2 = {id: 'host2', hasDvs: true, chassis: chassis2};

const vm1: PathTopoVM = {id: 'vm1', host: host1};
const vm2: PathTopoVM = {id: 'vm2', host: host2};
const dvs1: PathTopoDvs = {id: 'dvs1', host: host1};
const dvs2: PathTopoDvs = {id: 'dvs2', host: host2};
const portHost1: PathTopoPort = {id: 'port', parent: host1},
    portHost2: PathTopoPort = {id: 'port', parent: host2},
    portVm1: PathTopoPort = {id: 'port', parent: vm1},
    portVm2: PathTopoPort = {id: 'port', parent: vm2},
    portDvs1: PathTopoPort = {id: 'port', parent: dvs1},
    portDvs2: PathTopoPort = {id: 'port', parent: dvs2},
    portDvs1Up: PathTopoPort = {id: 'port', parent: dvs1, isUpPort: true},
    portDvs2Up: PathTopoPort = {id: 'port', parent: dvs2, isUpPort: true};
const sw1: PathTopoSwitch = {id: 'inner_switch', inChassis: true, chassis: chassis1};
const sw2: PathTopoSwitch = {id: 'inner_switch', inChassis: true, chassis: chassis2};
const sw3: PathTopoSwitch = {id: 'inter_switch', inChassis: false};

export function getTwoChassisTopo(diagReq: any, host1Id: string, host2Id: string, diagResp: any): PathTopoData {
  vm1.id = diagReq.srcVmPort.vm_id;
  vm2.id = diagReq.dstVmPort.vm_id;
  vm1.detail = {'ip': diagReq.srcVmPort.vm_port_ip};
  vm2.detail = {'ip': diagReq.dstVmPort.vm_port_ip};
  host1.id = host1Id;
  host2.id = host2Id;
  host1.hasDvs = (diagResp.src_vm_vnic_type !== CONST_STR.sriov);
  host2.hasDvs = (diagResp.dst_vm_vnic_type !== CONST_STR.sriov);

  portVm1.id = diagReq.srcVmPort.vm_port_ip;
  portVm2.id = diagReq.dstVmPort.vm_port_ip;
  // id of up_port and phy_port may be modified, hence they need to be restored every time
  portDvs1Up.id = portDvs2Up.id = portHost1.id = portHost2.id = 'port';

  dvs1.state = dvs2.state = sw1.state = sw2.state = sw3.state = 'good';

  let topoLabel: string;
  if (diagResp.src_vm_vnic_type === CONST_STR.sriov) {
    if (diagResp.dst_vm_vnic_type === CONST_STR.sriov) {
      topoLabel = constTopoLabel.srvsrv;
    } else {
      topoLabel = constTopoLabel.srvdvs;
      dvs2.id = diagResp.dst_vm_vnic_type;
    }
  } else {
    dvs1.id = diagResp.src_vm_vnic_type;
    if (diagResp.dst_vm_vnic_type === CONST_STR.sriov) {
      topoLabel = constTopoLabel.dvssrv;
    } else {
      dvs2.id = diagResp.dst_vm_vnic_type;
      topoLabel = constTopoLabel.dvsdvs;
    }
  }

  const data = consData(topoLabel);
  if (data) {
    (diagResp.result as any[]).forEach(path => markLink(path, data.links));
  }
  return data;
}

function consData(label: string) {
  let data: PathTopoData;
  switch (label) {
    case constTopoLabel.dvsdvs:
      data = {
        entityInfo: { chassis: [chassis1, chassis2], hosts: [host1, host2], vms: [vm1, vm2],
            dvs: [dvs1, dvs2],
            ports: [portHost1, portVm1, portDvs1Up, portDvs1, portDvs2, portDvs2Up, portHost2, portVm2],
            switchInChassis: [sw1, sw2], switchOutChassis: [sw3]},
        links: [{source: portVm1, target: portDvs1Up }, {source: portDvs1 , target: portHost1},
            {source: portHost1, target: sw1}, {source: sw1, target: sw3}, {source: sw3, target: sw2}, {source: sw2, target: portHost2},
            {source: portHost2, target: portDvs2}, {source: portDvs2Up, target: portVm2} ]
      };
      break;
    case constTopoLabel.dvssrv:
      data = {
        entityInfo: { chassis: [chassis1, chassis2], hosts: [host1, host2], vms: [vm1, vm2],
              dvs: [dvs1], switchInChassis: [sw1, sw2], switchOutChassis: [sw3],
              ports: [portHost1, portVm1, portDvs1Up, portDvs1, portHost2, portVm2]},
        links: [{source: portVm1, target: portDvs1Up }, {source: portDvs1 , target: portHost1},
            {source: portHost1, target: sw1}, {source: sw1, target: sw3}, {source: sw3, target: sw2}, {source: sw2, target: portHost2},
            {source: portHost2, target: portVm2} ]
      };
      break;
    case constTopoLabel.srvdvs:
      data = {
        entityInfo: { chassis: [chassis1, chassis2], hosts: [host1, host2], vms: [vm1, vm2],
              dvs: [dvs2], switchInChassis: [sw1, sw2], switchOutChassis: [sw3],
              ports: [portHost1, portVm1, portDvs2, portDvs2Up, portHost2, portVm2]},
        links: [{source: portVm1, target: portHost1}, {source: portHost1, target: sw1},
            {source: sw1, target: sw3}, {source: sw3, target: sw2}, {source: sw2, target: portHost2},
            {source: portHost2, target: portDvs2}, {source: portDvs2Up, target: portVm2} ]
      };
      break;
    case constTopoLabel.srvsrv:
      data = {
        entityInfo: {chassis: [chassis1, chassis2], hosts: [host1, host2], vms: [vm1, vm2],
              switchInChassis: [sw1, sw2], switchOutChassis: [sw3],
              ports: [portHost1, portVm1, portHost2, portVm2]},
        links: [{source: portVm1, target: portHost1}, {source: portHost1, target: sw1}, {source: sw1, target: sw3},
               {source: sw3, target: sw2}, {source: sw2, target: portHost2}, {source: portHost2, target: portVm2} ]
      };
      break;
    default:
      console.log('Port Diagnose: error in constructing topo data, label is ' + label);
      return null;
  }
  return data;
}

function findPortPair(src: any, dst: any): PathTopoNetEntity[] {

  function getPort(endPoint: any): PathTopoNetEntity {
    switch (endPoint.type) {
      case CONST_STR.port_type_phy:
        return (endPoint.hostname === host1.id) ? (portHost1.id = endPoint.id, portHost1) : (portHost2.id = endPoint.id, portHost2);
      case CONST_STR.port_type_vm:
        return (endPoint.id === portVm1.id) ? portVm1 : portVm2;
      case CONST_STR.port_type_down:
        return (endPoint.hostname === host1.id) ? portDvs1 : portDvs2;
      case CONST_STR.port_type_up:
        return (endPoint.hostname === host1.id) ? (portDvs1Up.id = endPoint.id, portDvs1Up) : (portDvs2Up.id = endPoint.id, portDvs2Up);
      case CONST_STR.port_type_inner_sw:
        return (endPoint.hostname === host1.id) ? sw1 : sw2;
      case CONST_STR.port_type_inter_sw:
        return sw3;
      default:
        console.log('Diagnose topo error: endpoint.type is ' + endPoint.type);
        return null;
    }
  }

  return [getPort(src), getPort(dst)];
}

function markLink(path: any, links: PathTopoLinks) {
  let portPair: PathTopoNetEntity[];

  portPair = findPortPair(path.src, path.dst);

  if ((portPair[0] === null) || (portPair[1] === null)) {
    return;
  }

  function setStateAndSuggection(netEntity: PathTopoNetEntity, suggestion: any) {
    netEntity.state = 'bad';
    netEntity.detail = Object.assign((netEntity.detail || {}), {suggestion});
  }

  if (portPair[0] === portPair[1]) {  // problem on sw
    setStateAndSuggection(portPair[0], path.suggestion);
    return;
  }

  const port0: PathTopoPort = (portPair[0] as PathTopoPort),
      port1: PathTopoPort = (portPair[1] as PathTopoPort);

  if (port0.parent && (port0.parent === port1.parent)) { // problem on dvs
    setStateAndSuggection(port0.parent, path.suggestion);
    return;
  }

  for (const link of links) {
    if (((link.source === portPair[0]) && (link.target === portPair[1]))
      || ((link.target === portPair[0]) && (link.source === portPair[1]))) {
        link.state = 'bad';
        link.detail = {'suggestion': path.suggestion};
        return;
      }
  }

  console.log('Port Diagnose error: cannot find a link which match the result.');
  console.log('path is ' + JSON.stringify(path));
  console.log('links is ' + JSON.stringify(links));
}

