import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {NotificationService} from './notification.service';
import {KyBreadcrumbComponent, KyTabsetComponent, KyTabHeadingDirective, KyTabDirective, KyButtonComponent} from '../../shared/kylib/index';


@Component({
  moduleId: module.id,
  selector: 'notification-setting',
  directives: [KyBreadcrumbComponent, KyTabsetComponent, KyTabHeadingDirective, KyTabDirective, KyButtonComponent],
  templateUrl: 'notification.component.html',
  providers: [NotificationService],
  styleUrls: ['../css/common.css']
})

export class NotificationComponent implements OnInit  {
  itemList: Array<any>;
  dialogueTitle: String;
  idSelected: any;
  isBeingEdited = false;

  constructor(private notificationService: NotificationService, private router: Router) {

  }

  ngOnInit() {
    this.itemList = [];

    this.notificationService.getReportDeliveryInfo().then((res: any) => {
      this.itemList = res;

      this.itemList.sort(function(a, b) {
        const data1 = Date.parse(a.modifyTime);
        const data2 = Date.parse(b.modifyTime);
        return (data2 - data1);
      });


      for (const item of this.itemList) {
        item['selectType'] = '编辑';
        item['deliveryTimeStr'] = '每天' + item['deliveryTime'];
      }

      $('p.total').append(this.itemList.length.toString());

    });

  }

  goToDetail(id: any, name: any, operation: any) {
    this.router.navigate(['/main/insight/setting/reportdeliverydetail', id, name, operation]);
  }

  showDialogue = function(id: any, name: any) {
    this.dialogueTitle = name;
    this.idSelected = id;

    $('.dialogue-background').css('display', 'block');
  };

  closeDialogue() {
    $('.dialogue-background').css('display', 'none');
  }

  deal(item: any, method: string) {
    item.selectType = method;
    if (item.selectType === '删除') {
      this.showDialogue(item.reportDeliveryId, item.name);
    } else {
      this.goToDetail(item.reportDeliveryId, item.name, 'edit');
    }

  }

  delReportDelivery() {
    this.closeDialogue();

    this.notificationService.delReportDeliveryInfo(this.idSelected).then((res: any) => {
      if ('OK' === res) {
        this.notificationService.getReportDeliveryInfo().then((res: any) => {
          this.itemList = res;

          this.itemList.sort(function(a, b) {
            const data1 = Date.parse(a.modifyTime);
            const data2 = Date.parse(b.modifyTime);
            return (data2 - data1); });

          for (const item of this.itemList) {
            item['selectType'] = '编辑';
            item['deliveryTimeStr'] = '每天' + item['deliveryTime'];
          }

          $('p.total').text('总数：' + this.itemList.length.toString());

        });
      }
    });
  }

  createReportDelivery() {
    this.router.navigate(['/main/insight/setting/reportdeliverycreate']);
  }

  goToModify() {
    this.isBeingEdited = true;
  }

  goToCancel() {
    this.isBeingEdited = false;
  }

  goToSave() {
    this.isBeingEdited = false;
  }

}
