import { Injectable } from '@angular/core';
import {Headers, Http} from '@angular/http';

@Injectable()
export class NotificationService {
   headers = new Headers({'Content-Type': 'application/json'});
  constructor(public http: Http) {

  }

  getReportDeliveryInfo() {
    return this.http.get('/api/v1/reporter/reportDeliveryInfo').toPromise().then((res: any) => {
      const str = JSON.stringify(res.json().reportDeliveryInfo);
      return JSON.parse(str);
    });
  }

  getReportDeliveryDetailInfo(id: any) {
    return this.http.get('/api/v1/reporter/reportDeliveryInfo/' + id).toPromise().then((res: any) => {
      return res.json();
    });
  }

  postReportDeliveryInfoModify(reportdeliverydetailinfo: any) {
   this.http.post('/api/v1/reporter/reportDeliveryInfo/modify',
     reportdeliverydetailinfo, {headers: this.headers}).toPromise().then((res: any) => {
      return res;
    });
  }

  postReportDeliveryInfoCreate(reportdeliverydetailinfo: any) {
    return this.http.post('/api/v1/reporter/reportDeliveryInfo/create',
      reportdeliverydetailinfo, {headers: this.headers}).toPromise().then((res: any) => {
      if (200 === res.status) {
        return 'OK';
      } else {
        return 'FAIL';
      }
    });
  }

  delReportDeliveryInfo(id: any) {
    return this.http.delete('/api/v1/reporter/reportDeliveryInfo/' + id).toPromise().then((res: any) => {
      if (200 === res.status) {
        return 'OK';
      } else {
        return 'FAIL';
      }
    });
  }

  getNowFormatDate() {
    const date = new Date();
    const seperator1 = '-';
    const seperator2 = ':';
    const monthValue = date.getMonth() + 1;
    const dayValue = date.getDate();
    let month = '0';
    let day = '0';
    if (monthValue >= 1 && monthValue <= 9) {
      month = month + monthValue.toString();
    } else {
      month = monthValue.toString();
    }

    if (dayValue >= 0 && dayValue <= 9) {
      day = day + dayValue.toString();
    } else {
      day = dayValue.toString();
    }

    const currentdate = date.getFullYear() + seperator1 + month + seperator1 + day
      + ' ' + date.getHours() + seperator2 + date.getMinutes()
      + seperator2 + date.getSeconds();

    //var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate;
    return currentdate;
  }


  getNowFormatTime() {
    const date = new Date();
    const seperator2 = ':';

    const currentdate = date.getHours() + seperator2 + date.getMinutes();

    return currentdate;
  }

  translateStatusStr(status: any) {
    if (status === 'normal') {
      return '正常';
    } else {
      return '暂停';
    }

  }

}
