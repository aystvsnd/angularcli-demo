import {Component} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {StorageService} from '../../storage.service';
import {NotificationService} from './notification.service';
import {KyButtonComponent, KyBreadcrumbComponent, TimeComponent, KY_RADIO_DIRECTIVES} from '../../shared/kylib/index';
import {KyUniqueSelectionDispatcher} from '../../shared/kylib/core/unique-selection-dispatcher.server';

@Component({
  directives: [KyButtonComponent, KyBreadcrumbComponent, TimeComponent, KY_RADIO_DIRECTIVES],
  moduleId: module.id,
  providers: [NotificationService, KyUniqueSelectionDispatcher],
  selector: 'report-delivery-create',
  styleUrls: ['report-delivery-create.component.css'],
  templateUrl: 'reportdeliverycreate.component.html',
})

export class ReportDeliveryCreateComponent {
  links: any;
  name = '';
  deliveryTime: string;
  inputTime: string;
  status: string;
  mailListStr: string;
  checkMailIsError = false;
  checkNameIsError = false;
  checkMailErrorStr = '';
  checkNameErrorStr = '';
  isLoadingPreView = false;
  preViewUrl: any;

  reportdeliverydetailinfo: any;

  status_options = [{
    label: '正常',
    value: 'normal'
  }, {
    label: '暂停',
    value: 'suspend'
  }];

  constructor(private notificationService: NotificationService, private activatedRoute: ActivatedRoute,
              private router: Router, private storageService: StorageService) {

    this.activatedRoute.params.subscribe(params => {

      this.deliveryTime = this.notificationService.getNowFormatTime();
      this.inputTime = this.deliveryTime;
      this.status = 'normal';
      this.mailListStr = '';

      this.reportdeliverydetailinfo = {
        'name': '',
        'deliveryTime': '',
        'mailList': '',
        'modifyTime': '',
        'modifier': '',
        'status': ''
      };

      this.links = [{name: '报告投递', url: '/main/insight/setting/notification'}, {name: '创建运维报告'}];

    });
  }
  /*ngOnInit() {

  }*/

  goToSave() {
    if (this.checkName() === false) {
      return;
    }

    if (this.checkEmail() === false) {
      return;
    }


    this.deliveryTime = this.inputTime;

    this.reportdeliverydetailinfo.name = this.name;
    this.reportdeliverydetailinfo.deliveryTime = this.deliveryTime;
    this.reportdeliverydetailinfo.mailList = this.mailListStr;
    this.reportdeliverydetailinfo.status = this.status;
    this.reportdeliverydetailinfo.modifyTime = this.notificationService.getNowFormatDate();
    this.reportdeliverydetailinfo.modifier = this.storageService.getUserName();

    this.notificationService.postReportDeliveryInfoCreate(JSON.stringify(this.reportdeliverydetailinfo)).then((res: any) => {

      if ('OK' === res) {
        this.router.navigate(['/main/insight/setting/reportdeliveryinfo']);
      }

    });


  }

  onHandle(event: any) {
    this.inputTime = event.target.value;
  }

  checkName() {
    let nameSrc = this.name;
    nameSrc = nameSrc.replace(/\s/ig, '');

    if (nameSrc === '') {
      this.checkNameIsError = true;
      this.checkNameErrorStr = '报告名称不得为空！';
      return false;
    } else {
      this.checkNameIsError = false;
      this.checkNameErrorStr = '';
      return true;
    }
  }

  checkEmail() {
    let mailError = false;
    let strSrc = this.mailListStr;
    strSrc = strSrc.replace(/\s/ig, '');

    if ('' === strSrc) {
      this.checkMailIsError = true;
      this.checkMailErrorStr = '请输入邮箱地址！';
      return false;
    }

    let strArray = new Array();
    strArray = strSrc.split(',');
    for (let i = 0; i < strArray.length; i++) {
      if ('' === strArray[i]) {
        continue;
      }
      if (strArray[i].match(/\w+@(\w+\.)+\w+/) === null) {
        mailError = true;
        break;
      }
    }

    if (mailError === true) {
      this.checkMailIsError = true;
      this.checkMailErrorStr = '邮箱地址输入错误！';
      return false;
    } else {
      this.checkMailIsError = false;
      this.checkMailErrorStr = '';
      return true;
    }

  }

  goToCancel() {
    //this.router.navigate(['/main/reportdeliveryinfo']);
    window.history.back();
  }

  PushEmail() {
    const currentEmail = this.mailListStr.split(',').pop();
    if (currentEmail.match(/\w+@(\w+\.)+\w+/) !== null) {
      console.log('match success');
      this.mailListStr += ', ';
    }
  }

  preView() {
    /*var pdfFile = this.getPdfFile();
    var link = document.createElement('a');
    link.setAttribute('href', pdfFile);
    link.setAttribute('download', '报告预览.pdf');

    document.body.appendChild(link);
    link.click();*/

    this.openPreViewDialogue();
    this.isLoadingPreView = true;
    setTimeout(() => this.Test2S(), 2000);

  }

  getPdfFile() {
    const  pdfFileURI = 'app/markdown.pdf';

    return pdfFileURI;
  }


  openPreViewDialogue() {
    $('.dialogue-background').css('display', 'block');
  }


  closeDialogue() {
    $('.dialogue-background').css('display', 'none');
  }

  Test2S() {
    this.preViewUrl = 'http://10.63.244.55:9999/daily.html';
    this.isLoadingPreView = false;
  }


}
