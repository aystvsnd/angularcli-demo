import {Component, OnInit} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {StorageService} from '../../storage.service';
import {NotificationService} from './notification.service';
import {KyButtonComponent, KyBreadcrumbComponent, TimeComponent, KY_RADIO_DIRECTIVES} from '../../shared/kylib/index';
import {KyUniqueSelectionDispatcher} from '../../shared/kylib/core/unique-selection-dispatcher.server';

@Component({
  moduleId: module.id,
  selector: 'report-delivery-detail',
  directives: [KyButtonComponent, KyBreadcrumbComponent, TimeComponent, KY_RADIO_DIRECTIVES],
  templateUrl: 'reportdeliverydetail.component.html',
  styleUrls: ['reportdeliverydetail.component.css'],
  providers: [NotificationService, KyUniqueSelectionDispatcher]
})

export class ReportDeliveryDetailComponent implements OnInit {
  links: any;
  name: any;
  id: any;
  isBeingEdited = false;
  deliveryTime: string;
  inputTime: string;
  status: string;
  mailListStr: string;
  mailUserList: Array<any>;
  operation = 'read';
  checkMailIsError = false;
  checkNameIsError = false;
  checkMailErrorStr = '';
  checkNameErrorStr = '';

  reportdeliverydetailinfo: any;

  old_name: any;
  old_deliveryTime: string;
  old_status: string;
  old_mailListStr: string;

  status_options = [{
    label: '正常',
    value: 'normal'
  }, {
    label: '暂停',
    value: 'suspend'
  }];

  constructor(private notificationService: NotificationService, private activatedRoute: ActivatedRoute,
              private router: Router, private storageService: StorageService) {

    this.activatedRoute.params.subscribe(params => {
      this.name = decodeURI(params['name']);
      this.id = params['id'];
      this.operation = params['operation'];

      this.deliveryTime = '00:00:00';
      this.status = 'normal';
      this.mailListStr = 'an.an@zte.com.cn,an.an2@zte.com.cn,an.an3@zte.com.cn';
      this.mailUserList = [];

      this.reportdeliverydetailinfo = {
        'reportDeliveryId': '',
        'name': '',
        'templateType': '',
        'deliveryCycle': '',
        'deliveryTime': '',
        'mailList': '',
        'modifyTime': '',
        'modifer': '',
        'status': ''
      };

      if (this.operation === 'edit') {
        this.isBeingEdited = true;
      }
      this.links = [{name: '报告投递', url: '/main/insight/setting/notification'}, {name: this.name}];

    });
  }

  ngOnInit() {

    this.notificationService.getReportDeliveryDetailInfo(this.id).then((res: any) => {
      this.name = res.name;
      this.deliveryTime = res.deliveryTime;
      this.status = res.status;
      this.mailListStr = res.mailList;
      this.inputTime = this.deliveryTime;

      this.old_name = this.name;
      this.old_deliveryTime = this.deliveryTime;
      this.old_status = this.status;
      this.old_mailListStr = this.mailListStr;

      this.getMailUsers(this.mailListStr);
    });

  }

  goToEdit() {
    this.isBeingEdited = true;
    this.old_name = this.name;
    this.old_deliveryTime = this.deliveryTime;
    this.old_status = this.status;
    this.old_mailListStr = this.mailListStr;
  }

  goToSave() {
    if (this.checkName() === false) {
      return;
    }

    if (this.checkEmail() === false) {
      return;
    }

    this.isBeingEdited = false;
    this.deliveryTime = this.inputTime;

    this.getMailUsers(this.mailListStr);

    this.reportdeliverydetailinfo.reportDeliveryId = this.id;
    this.reportdeliverydetailinfo.name = this.name;
    this.reportdeliverydetailinfo.deliveryTime = this.deliveryTime;
    this.reportdeliverydetailinfo.mailList = this.mailListStr;
    this.reportdeliverydetailinfo.status = this.status;
    this.reportdeliverydetailinfo.modifyTime = this.notificationService.getNowFormatDate();
    this.reportdeliverydetailinfo.modifier = this.storageService.getUserName();

    this.notificationService.postReportDeliveryInfoModify(JSON.stringify(this.reportdeliverydetailinfo));


  }

  goToCancel() {
    this.isBeingEdited = false;
    this.name = this.old_name;
    this.deliveryTime = this.old_deliveryTime;
    this.status = this.old_status;
    this.mailListStr = this.old_mailListStr;
  }

  onHandle(event: any) {
    this.inputTime = event.target.value;
  }

  getMailUsers(mailListStr: any) {
    this.mailUserList = mailListStr.split(',');
  }

  checkName() {
    let nameSrc = this.name;
    nameSrc = nameSrc.replace(/\s/ig, '');

    if (nameSrc === '') {
      this.checkNameIsError = true;
      this.checkNameErrorStr = '运营报告名称不得为空！';
      return false;
    } else {
      this.checkNameIsError = false;
      this.checkNameErrorStr = '';
      return true;
    }
  }

  checkEmail() {
    let mailError = false;
    let strSrc = this.mailListStr;
    strSrc = strSrc.replace(/\s/ig, '');

    if ('' === strSrc) {
      this.checkMailIsError = true;
      this.checkMailErrorStr = '请输入邮箱地址！';
      return false;
    }

    let strArray = new Array();
    strArray = strSrc.split(',');
    for (let i = 0; i < strArray.length; i++) {
      if ('' === strArray[i]) {
        continue;
      }
      if (strArray[i].match(/\w+@(\w+\.)+\w+/) === null) {
        mailError = true;
        break;
      }
    }

    if (mailError === true) {
      this.checkMailIsError = true;
      this.checkMailErrorStr = '邮箱地址输入错误！';
      return false;
    } else {
      this.checkMailIsError = false;
      this.checkMailErrorStr = '';
      return true;
    }

  }

  PushEmail() {
    const currentEmail = this.mailListStr.split(',').pop();
    if (currentEmail.match(/\w+@(\w+\.)+\w+/) !== null) {
      //console.log('match success');
      this.mailListStr += ', ';
    }
  }


}
