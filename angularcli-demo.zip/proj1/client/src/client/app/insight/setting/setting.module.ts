import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/index';

import { routing } from './setting.routes';

import { ReportDeliveryCreateComponent } from './reportdeliverycreate.component';
import { ReportDeliveryDetailComponent } from './reportdeliverydetail.component';
import { NotificationComponent } from './notification.component';

import { NotificationService } from './notification.service';
import { SettingService } from './setting.service';

@NgModule({
  imports: [SharedModule, routing],
  declarations: [ReportDeliveryCreateComponent, ReportDeliveryDetailComponent, NotificationComponent],
  providers: [NotificationService, SettingService]
})

export class SettingModule { }




