import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NotificationComponent } from './notification.component';
import { ReportDeliveryCreateComponent } from './reportdeliverycreate.component';
import { ReportDeliveryDetailComponent } from './reportdeliverydetail.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {path: 'notification', component: NotificationComponent},
      {path: 'reportdeliverycreate', component: ReportDeliveryCreateComponent},
      {path: 'reportdeliverydetail/:id/:name/:operation', component: ReportDeliveryDetailComponent},
    ]
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);

