/**
 * Created by 10192595 on 2016/10/17.
 */

import { Injectable } from '@angular/core';
import { ApiResourceService as Http } from '../../apiResource.service';
import { Response} from '@angular/http';

import 'rxjs/add/operator/toPromise';

@Injectable()
export class SettingService {

  constructor(public http: Http) {
  }

  getAlarmPostSetting() {
    return this.http.get('/api/v1/smartFm/alarmDeliverSetting').toPromise().then((res: Response) => {
      return res.json();
    });
  }

  postAlarmPostSetting(alarmPostSetting) {
    return this.http.post('/api/v1/smartFm/alarmDeliverSetting',
      JSON.stringify(alarmPostSetting)).toPromise().then((res: any) => {
      return res.json();
    });
  }
}
