/**
 * Created by 6092002302 on 2017/3/11.
 */
import {Component, OnInit, Input, Output, EventEmitter, HostListener, ElementRef} from '@angular/core';

@Component({
  moduleId: module.id,
  template: `
            <div class="button-display">
                <button class="button-common" (click)="displayOrHide()">
                {{"insight.Policy.TypeChosen" | translate:{types: checkboxChoosed.length} }}
                  <!--已选择{{checkboxChoosed.length}}项-->
                  <span class="caret right"></span>
                </button>
            </div>
            <ul class="ul-common-style" *ngIf="isDisplay">
                <li class="li-common-style" *ngFor="let object of checkboxChoose">
                    <px-checkbox   [(ngModel)]="object.value"  (change)="checkSelect()">
                      {{object.name}}
                    </px-checkbox>
                </li>
                <div class="button-bottom">
                    <button class="button-sure" (click)="confirmSelect()"><span class="spanButton">
                    {{"insight.health.Confirm" | translate}}</span></button>
                     <button class="button-sure button-cancel" (click)="cancel()"><span class="spanButton">
                     {{"insight.health.Cancel" | translate}}</span></button>
                </div>
            </ul>

            `,
  selector: 'px-checkbutton',
  styles: [`
     .button-display{
        display: inline-block;
     }
     .button-common {
        background: white;
        width: 400px;
        height: 30px;
        display: inline-block;
        border: 1px solid #ccc;
        color: #4d5761;
        text-align: left;
        padding-left: 10px;
     }
     .button-dropdown{
        background: white;
        width:40px;
        height: 30px;
        display: inline-block;
        border: 1px solid #ccc;
        border-radius: 3px;
     }
     .ul-common-style {
        width: 400px;
        list-style: none;
        border: 1px solid #ccc;
        border-top: none;
        font-size: 15px;
        line-height: 25px;
        padding-top: 10px;
        position: absolute;
        background: #fff;
     }
     .li-common-style {
        margin-left: 10px;
        margin-bottom: 10px;
     }
     .button-bottom{
        display: flex;
     }
     .button-sure {
        width: 50%;
        height: 30px;
        border: 1px solid #ccc;
        border-right:none;
        border-left: none;
        border-bottom: none;
        background: none;
     }
     .button-cancel{
        border-left: 1px solid #ccc;
     }
     .right {
        float: right;
        margin-top: 5px;
        margin-right: 10px;
     }

     .spanButton {
        font-size: 14px;
        color: #00abff;
     }

     .button-sure:hover, .button-cancel:hover {
        background: #f2f2f2;
    }
  `],
})

export class PxCheckbuttonComponent implements OnInit {
  @Input() allObject;
  @Output() objectsModified = new EventEmitter();

  isDisplay : boolean;
  checkboxChoose : any= [];
  checkboxChoosed : any= [];

  @HostListener('document: click', ['$event.target'])
  onClick(target: HTMLElement) {

    if (!this.isDisplay) return;
    let parentFound = false;
    while (target !== null && !parentFound) {
      if (target === this.element.nativeElement) {
        parentFound = true;
      }
      target = target.parentElement;
    }
    if (!parentFound) {
      this.isDisplay = false;
    }
  }

  constructor(private element: ElementRef) {
    this.isDisplay = false;
  }
  ngOnInit() {
    for (const object of this.allObject) {
      const singleCheckbox = {name: object, value: false};
      this.checkboxChoose.push(singleCheckbox);
    }
  }

  displayOrHide() {
    this.isDisplay === false ? this.isDisplay = true : this.isDisplay = false;
  }

  confirmSelect() {
    this.isDisplay = false;
    this.checkboxChoosed = [];
    for (const single of this.checkboxChoose) {
      if (single.value === true) {
        this.checkboxChoosed.push(single.name);
      }
    }
    this.objectsModified.emit(this.checkboxChoosed);
  }

  checkSelect() {
    this.checkboxChoosed = [];
    for (const single of this.checkboxChoose) {
      if (single.value === true) {
        this.checkboxChoosed.push(single.name);
      }
    }

    this.objectsModified.emit(this.checkboxChoosed);
  }

  cancel() {
    this.isDisplay = false;
    this.checkboxChoosed = [];
    for (const single of this.checkboxChoose) {
      single.value = false;
    }
    this.objectsModified.emit(this.checkboxChoosed);

  }
}



