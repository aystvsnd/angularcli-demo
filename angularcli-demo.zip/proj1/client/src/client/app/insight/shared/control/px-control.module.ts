/**
 * Created by 6092002302 on 2017/3/8.
 */
import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import { RouterModule} from '@angular/router';

import {SharedModule} from '../../../shared/index';
import {InsightCommonModule} from '../../common/common.module';

import {PxStepbarComponent} from  './px-stepbar.component';
import {PxCheckbuttonComponent} from './px-checkbutton.component';
import {CmsSliderComponent} from './px-slider.component';
import {PxSlideblockComponent} from './px-slideblock.component';
import {TimeSelectorComponent} from './time-selector.component';
import {PxCardsComponent} from './px-cards.component';

@NgModule({
  imports: [CommonModule, SharedModule, InsightCommonModule, FormsModule],

  declarations: [PxStepbarComponent, PxCheckbuttonComponent, CmsSliderComponent,
    PxSlideblockComponent, TimeSelectorComponent, PxCardsComponent],

  exports: [PxStepbarComponent, PxCheckbuttonComponent, CmsSliderComponent, PxSlideblockComponent, TimeSelectorComponent,
    PxCardsComponent, RouterModule]
})
export class PxControlModule {}

