/**
 * Created by 6092002302 on 2017/3/9.
 */
import {Component, OnInit, Input} from '@angular/core';

@Component({
  moduleId: module.id,
  template: `<div *ngFor="let step of stepsDesc let i=index">
                <div>
                    <span *ngIf="i+1 >= currentStep" class="ng-step-number" [class.greatter-current-step]="i+1 > currentStep">
                    {{i + 1}}
                    </span>
                    <span *ngIf="i+1 < currentStep" class="ng-step-number ng-step-finished">√ </span>
                    <span class="word-style" [class.current-word-style]="i + 1 === currentStep">{{step}}</span>
                </div>
                <div class="ng-step-line" [class.ng-step-long-line]="i + 1 === currentStep" *ngIf="stepsDesc.length !== i + 1">
                </div>
             </div>`,
  selector: 'px-stepbar',
  styles: [
    `
        .ng-step-number{
            border-radius: 50%;
            background: #00abff;
            display: inline-block;
            height: 24px;
            width: 24px;
            text-align: center;
            padding: 5px;
            font-size: 14px;
            color: white;
        }
        .ng-step-finished{
            background: white;
            border: 2px solid #00abff;
            color: #00abff;
        }
        .greatter-current-step {
            color: white;
            background:#ccc;
        }
        .ng-step-line{
            width: 2px;
            height: 30px;
            background: #00abff;
            margin-left: 12px;
            transition: height 0.5s;
        }
        .ng-step-long-line{
            background: #cccccc;
            height: 450px;
        }
        .word-style{
            font-size: 14px;
            color: #7c868d;
            white-space: nowrap;
        }
        .current-word-style{
            color: #4d5761;
        }
    `
  ]
})

export class PxStepbarComponent implements OnInit {

  @Input() stepsDesc;
  @Input() currentStep;
  ngOnInit() {
    console.log(this.stepsDesc);
  }
}


