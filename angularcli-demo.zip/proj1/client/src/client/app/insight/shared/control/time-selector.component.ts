/**
 * Created by 6092002302 on 2017/3/20.
 */
import {Component, OnInit, Input, Output, EventEmitter, HostListener, ElementRef} from '@angular/core';
@Component({
  moduleId: module.id,
  template: `
             <div class="time-selector">
                <span class="time-display">
                    <span class="writing">{{defaultTime}}</span>
                    <span class="glyphicon glyphicon-calendar calendar"  (click)="displayAllTime()"></span>
                </span>
                <div class="time-expand" *ngIf="isDisplay">
                    <div *ngFor="let item of timeQuantum" class="single-time" (click)="chooseTime(item)">
                    {{item}}
                    </div>
                </div>
             </div>
            `,
  selector: 'time-selector',
  styles: [
    `
       .time-selector {
             position: relative;
       }
       .time-display {
            display: inline-block;
            height: 30px;
            width: 90px;
            border: 1px solid #ccc;
       }
       .writing {
            display: inline-block;
            margin-left: 10px;
            margin-top: 10px;
       }
       .calendar {
            font-size: 15px;
            float: right;
            margin-top: 6px;
            margin-right: 10px;
            color: #00abff;
       }
       .calendar:hover{
            cursor: pointer;
            color: #00ABFF;
       }
       
       .time-expand {
            height: 150px;
            width:  90px;
            border: 1px solid #ccc;
            overflow-y: scroll;
            position: absolute;
            border-top: none;
            background: #fff;
            z-index: 100;
       }
       .single-time{
            height: 30px;
            padding-top: 10px;
            padding-left: 10px;
       }
       .time-expand div:hover {
            background: #1898eb;
            cursor: pointer;
       }
    `
  ]
})

export class TimeSelectorComponent implements OnInit {
  @Input() defaultTime;
  @Input() defaultName;
  @Input() disable = true;
  @Output() chosenTime = new EventEmitter();

  timeQuantum : any;
  isDisplay   : any;

  @HostListener('document: click', ['$event.target'])
  onClick(target: HTMLElement) {

    if (!this.isDisplay) return;
    let parentFound = false;
    while (target !== null && !parentFound) {
      if (target === this.element.nativeElement) {
        parentFound = true;
      }
      target = target.parentElement;
    }
    if (!parentFound) {
      this.isDisplay = false;
    }
  }

  constructor(private element: ElementRef) {

    this.isDisplay = false;
  }

  ngOnInit() {
    if (this.defaultName === 'begin') {
      this.timeQuantum = ['00:00', '01:00', '02:00', '03:00', '04:00', '05:00', '06:00',
        '07:00', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00',
        '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00'];
    } else if (this.defaultName === 'end') {
      this.timeQuantum = [ '01:00', '02:00', '03:00', '04:00', '05:00', '06:00',
        '07:00', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00',
        '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '24:00'];
    }

  }
  displayAllTime() {

    if (this.disable === true) {

      this.isDisplay === true ? this.isDisplay = false : this.isDisplay = true;
    }
  }

  chooseTime(chosenTime : any) {
    this.defaultTime = chosenTime;
    this.isDisplay = false;
    this.chosenTime.emit(chosenTime);
  }
}


