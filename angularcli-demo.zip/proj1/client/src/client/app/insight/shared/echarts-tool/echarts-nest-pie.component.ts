import {Component, AfterViewInit, OnDestroy, Input,OnInit} from '@angular/core';
import { UUID } from 'angular2-uuid';
import { LegendData, SeriesData, Option, PieOption } from './echarts.types';
import { TranslateService } from '@ngx-translate/core';

@Component({
    moduleId: module.id,
    template: `<div id="{{id}}" class="ky-pie" style="height: 230px;width: 280px"></div>
            `,
    selector: 'echarts-nest-pie',
    styleUrls: ['ky-pie.component.css']
})

export class EchartsNestPie implements OnInit,AfterViewInit, OnDestroy{
    @Input() height : string = null;
    @Input() width : string = null;
    @Input()
    set data(newData: PieOption[]) {
        if (!newData) {
            console.log('!newData');
            return;
        }
        this.pieData = newData;
        console.log(this.pieData);
    }
    myChart: any;
    id: string;
    pieData: PieOption[];
    radius = ['45%', '60%'];
    constructor(private translate: TranslateService) {
        this.id = UUID.UUID();
    }

  ngOnInit() {

    console.log("ggggggg"+ this.pieData);
  }

    ngAfterViewInit() {
      this.setDataToOption();
        this.createNestPie();
    }
    ngOnDestroy() {
        this.myChart.clear();
        this.myChart.dispose();
    }
    option: any = {
        legend: {
            selectedMode: false,
            orient: 'horizontal',
            left: 'center',
            top: 0,
            itemWidth: 12,
            itemHeight: 12,
            itemGap: 20,
            tooltip: {
                show: false
            },
            data: []
        },
        series: [
            {
                color: ['#6e6'],
                name: '访问来源',
                type: 'pie',
                radius: '35%',
                hoverAnimation: false,
                label: {
                    normal: {
                        position: 'inner',
                        textStyle: {
                            fontSize: 8
                        }
                    }
                },
                labelLine: {
                    normal: {
                        show: false
                    }
                },
                data: []
            },
            {
                color: ['#aaa'],
                name: '访问来源',
                type: 'pie',
                radius: '40%',
                hoverAnimation: false,
                label: {
                    normal: {
                        position: 'inner',
                        textStyle: {
                            fontSize: 8
                        }
                    }
                },
                labelLine: {
                    normal: {
                        show: false
                    }
                },
                data: []
            },
            {
                //color: ['#080', '#6e6'],
                name: '访问来源',
                type: 'pie',
                radius: this.radius,
                label: {
                    normal: {
                        textStyle: {
                            fontSize: 8
                        }
                    }
                },
                itemStyle: {
                    normal: {
                        borderColor: '#fff',
                        borderWidth: 1,
                        color: '#aaa'
                    }
                },
                data: [
                    {
                        value: 0,
                        labelLine: {
                            normal: {
                                show: false
                            },
                            emphasis: {
                                show: false
                            }
                        },
                        itemStyle: {
                            normal: {
                                borderColor: '#000',
                                opacity: 0
                            }
                        },
                        tooltip: {
                            show: false
                        }
                    },
                    {
                        value: 0,
                        labelLine: {
                            normal: {
                                show: false
                            },
                            emphasis: {
                                show: false
                            }
                        },
                        itemStyle: {
                            normal: {
                                borderColor: '#000',
                                opacity: 0
                            }
                        },
                        tooltip: {
                            show: false
                        }
                    }
                ]
            },
            {
                type: 'pie',
                radius: '0%',
                hoverAnimation: false,
                label: {
                    normal: {
                        show: false
                    }
                },
                labelLine: {
                    normal: {
                        show: false
                    }
                },
                data: []
            },
        ]
    };
    changeOptionPosition(width: number, height: number) {
        //let minWidth = 180;
        // let minHeight = this.radius[1].replace(/%/, '') / 100 * width * 2 + 20 * 2;
        // if (width < 150 || minHeight > height) {
        //     return;
        // }
        this.option.legend.top = height / 2 + this.radius[1].replace(/%/, '') / 100 * width / 2 + 10;
        //this.option.title[0].y = height / 2 - 20;
        //this.option.title[1].y = height / 2 - this.radius[1].replace(/%/, '') / 100 * width - 20 - 20;
    }
    totalValue(data) {
        let ret = 0;
        _.each(data, function (item: any) {
            ret = ret + item.value;
        });
        return ret;
    }
    setSerieName(name: string) {return name; }
    setDataToOption() {
        const that = this;
        const total1 = this.totalValue(this.pieData[0].data);
        const total2 = this.totalValue(this.pieData[1].data);
        let colors = ['#00abff', '#5cb85c', '#c5c6c9'];
        let i = 0;
        _.each(this.pieData[0].data, function (item: SeriesData) {
            const legend = <LegendData>{};
            legend.name = that.setSerieName(item.name+':'+Math.round(item.value * 100 / total1)+'%');
            legend.icon = 'circle';
            that.option.legend.data.push(legend);

            const series = <SeriesData>{};
            series.name = that.setSerieName(item.name+':'+Math.round(item.value * 100 / total1)+'%');
            series.value = 0;
            series.itemStyle = {normal: {color: colors[i++]}};
            that.option.series[3].data.push(series);
        });
        const series01 = <SeriesData>{};
        series01.name = that.setSerieName(this.pieData[0].data[0].name);
        series01.value = this.pieData[0].data[0].value;
        series01.itemStyle = {normal: {color: '#00abff'}};
        const series02 = <SeriesData>{};
        series02.name = '';//that.setSerieName(this.pieData[0].data[0].name);
        series02.value = this.pieData[0].data[0].value;
        series02.itemStyle = {normal: {opacity: 0}};
        that.option.series[0].data.push(series01);
        that.option.series[1].data.push(series02);

        const series11 = <SeriesData>{};
        series11.name = '';//that.setSerieName(this.pieData[0].data[1].name);
        series11.value = this.pieData[0].data[1].value;
        series11.itemStyle = {normal: {opacity: 0}};
        const series12 = <SeriesData>{};
        series12.name = that.setSerieName(this.pieData[0].data[1].name);
        series12.value = this.pieData[0].data[1].value;
        series12.itemStyle = {normal: {color: '#5cb85c'}};
        that.option.series[0].data.push(series11);
        that.option.series[1].data.push(series12);

        const series21 = <SeriesData>{};
        series21.name = that.setSerieName(this.pieData[0].data[2].name);
        series21.value = this.pieData[0].data[2].value;
        series21.itemStyle = {normal: {color: '#c5c6c9'}};
        const series22 = <SeriesData>{};
        series22.name = '';//that.setSerieName(this.pieData[0].data[2].name);
        series22.value = this.pieData[0].data[2].value;
        series22.itemStyle = {normal: {opacity: 0}};
        that.option.series[0].data.push(series21);
        that.option.series[1].data.push(series22);

        const seriesEmpty1 = that.option.series[2].data[0];
        const seriesEmpty2 = that.option.series[2].data[1];
        that.option.series[2].data = [];
        seriesEmpty1.value = total2 * this.pieData[0].data[0].value / this.pieData[0].data[1].value;
        that.option.series[2].data.push(seriesEmpty1);
        _.each(this.pieData[1].data, function (item: SeriesData) {
            // const legend = <LegendData>{};
            // legend.name = that.setSerieName(item.name);
            // legend.icon = 'square';
            // that.option.legend.data.push(legend);

            const series = <SeriesData>{};
            series.name = that.setSerieName(item.name);
            series.value = item.value;
            that.option.series[2].data.push(series);
        });
        seriesEmpty2.value = total2 * this.pieData[0].data[2].value / this.pieData[0].data[1].value;
        that.option.series[2].data.push(seriesEmpty2);
    }
    createNestPie() {
        const dom: any = document.getElementById(this.id);
        let width = dom.clientWidth;
        let height = dom.clientHeight;
        if (this.height !== null) {
            height = this.height;
        }
        if (this.width !== null) {
            width = this.width;
        }
        this.changeOptionPosition(width, height);
        this.myChart = echarts.init(dom, 'macarons');
        this.myChart.setOption(this.option);
    }

}
