import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {EchartsNestPie} from './echarts-nest-pie.component';

@NgModule({
  imports: [CommonModule],
  declarations: [EchartsNestPie],
  exports: [EchartsNestPie]
})

export class EchartsToolModule {
}
