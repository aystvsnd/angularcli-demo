export interface LegendData {
  name: string;
  icon: string;
};

export interface SeriesData {
  value: number;
  name: string;
  itemStyle?: {
    normal?: {
      color?: string,
      opacity?: number
    }, emphasis?: {
      color: string
    }
  };
};

export interface PieOption {
  data: SeriesData[];
};

export interface Option {
  legend: {
    data: LegendData[];
  };
  series: {
    data: SeriesData[];
  };
  title: {
    text: string,
    textStyle: {
      color: string
    },
    subtextStyle: {
      color: string
    },
    subtext: string
  }[];

};
