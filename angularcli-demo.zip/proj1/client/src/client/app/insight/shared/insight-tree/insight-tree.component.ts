import {Input, Component, OnInit, EventEmitter, Output, ElementRef, ViewChild} from '@angular/core';
import {TreeStyle, TreeModel, FoldingType, NodeEvent, NodeSelectedEvent} from './tree.types';
import {TreeService} from './tree.service';
import {isLeftButtonClicked} from './common/utils/event.utils';
//import {applyNewValueToRenamable, isRenamable, isValueEmpty} from './common/utils/type.utils';
import {KyCheckbox} from '../ky-checkbox/index';
import {Subject} from 'rxjs/Subject';

/* tslint:disable */
@Component({
  moduleId: module.id,
  selector: 'tree-internal',
  styleUrls: ['insight-tree.component.css'],
  templateUrl: 'insight-tree.component.html'
})
export class TreeInternalComponent implements OnInit {
  @Input() tree:TreeModel;
  @Input() treeStyle:TreeStyle;
  @Input() parentTree:TreeModel;
  @Input() indexInParent:number;
  @Input() unCheckedNode:Subject<TreeModel>;
  @Input() nodeSelectedSubject:Subject<NodeSelectedEvent>;
  @Input() nodeCheckedSubject:Subject<NodeSelectedEvent>;
  @Input() allNodeUnChecked:Subject<boolean>;
  @ViewChild('input') checkboxE:KyCheckbox;

  isLeaf:boolean = false;
  isSelected:boolean = false;
  plusImage:boolean = true;
  checkBox:boolean = false;

  constructor(private treeService:TreeService, private element:ElementRef) {
  }

  ngOnInit():void {
    this.indexInParent = 0;
    if (this.tree.children === undefined || this.tree.children === null) {
      this.isLeaf = true;
    }
    this.tree._indexInParent = this.indexInParent;
    this.setUpNodeSelectedEventHandler();

    if (this.allNodeUnChecked === undefined) return;
    this.allNodeUnChecked.subscribe((value) => {
      if (value === true) {
        this._setAllChildren(this.tree, false);
      }
    });


    if (this.unCheckedNode === undefined || this.unCheckedNode === null ) return;
    this.unCheckedNode.subscribe((value) => {
      this.findElementInTree(value);
    });

    $('.plus-minus').click(function (e) {
      e.stopPropagation();
    });
  }

  //@Input()
  //set unCheckedNode(node:TreeModel) {
  //  console.log('Tree Internal recv');
  //  console.log(node);
  //  if (node === undefined || node === null) return;
  //  this.findElementInTree(node);
  //}

  @Input()
  set searchContext(context:string) {
    if (context === undefined) return;
    this.clearHighLightStyle(this.tree);
    if (context === '') return;
    this.foldNode(this.tree);
    this.searchInTree(this.tree, context);
  }

  clearHighLightStyle(node:TreeModel) {
    if (node.highLight === true) {
      node.highLight = false;
    }

    if (node.children !== undefined && node.children !== null && node.children.length > 0) {
      node.children.forEach(child => {
        this.clearHighLightStyle(child);
      });
    }
  }

  foldNode(node:TreeModel) {
    node._foldingType = FoldingType.Collapsed;
    if (node.children !== undefined && node.children !== null && node.children.length > 0) {
      node.children.forEach(child => {
        this.foldNode(child);
      });
    }
  }

  searchInTree(node:TreeModel, context:string) {
    if (node.value.toLocaleLowerCase().indexOf(context) !== -1 || node.value.indexOf(context) !== -1 ) {
      node.highLight = true;
      let tmp = node;
      while(tmp.parent!== undefined && tmp.parent!== null) {
        tmp = tmp.parent;
        if (tmp._foldingType === undefined || tmp._foldingType === FoldingType.Collapsed) {
          tmp._foldingType = FoldingType.Expanded;
        }
      }
    }
    if (node.children !== undefined && node.children !== null && node.children.length > 0) {
      node.children.forEach(child => {
        this.searchInTree(child, context);
      });
    }
  }

  findElementInTree(node:TreeModel) {
    node._checkboxFlag = false;
    this._setParent(node, false);
  }

  getTreeValue() {
    // if (this.treeStyle.nodeDisplayCharacter) {
    //   if (this.tree.value.length > this.treeStyle.nodeDisplayCharacter) {
    //     return this.tree.value.substring(0, this.treeStyle.nodeDisplayCharacter) + '...';
    //   }
    // }
    return this.tree.value;
  }

  _click() {
    // document.getElementsByClassName("chk");
    this._setAllChildren(this.tree, this.checkboxE.checked);
    this.setParentWhenNodeUnchecked();
    this.setParentWhenNodeChecked();
    if (this.nodeCheckedSubject === undefined) return;
    this.nodeCheckedSubject.next({node: this.tree});
  }

  _setAllChildren(head:TreeModel, flag:boolean) {
    head._checkboxFlag = flag;
    if (head.children !== undefined && head.children !== null && head.children.length > 0) {
      head.children.forEach(child=> {
        this._setAllChildren(child, flag);
      });
    }
  }

  _setParent(node: TreeModel, flag:boolean) {
    let tmp = node;
    while (tmp.parent !== undefined && tmp.parent !== null) {
      for (let child of tmp.parent.children) {
        if (child._checkboxFlag === !flag) return;
      }
      tmp.parent._checkboxFlag = flag;
      tmp = tmp.parent;
    }
  }

  setParentWhenNodeUnchecked() {
    if (this.checkboxE.checked === false) {
      this._setParent(this.tree, false);
    }
  }

  setParentWhenNodeChecked() {
    if (this.checkboxE.checked === true) {
      this._setParent(this.tree, true);
    }
  }

  setUpNodeSelectedEventHandler() {
    this.nodeSelectedSubject
      .filter((e:NodeSelectedEvent) => this.tree !== e.node)
      .subscribe(_ => this.isSelected = false);
  }

  isPlusImage():boolean {
    if (this.treeStyle) {
      return this.treeStyle.isPlusImage;
    }
    return this.plusImage;
  }

  isCheckBox() {
    if(!this.tree.enabled) {
      return false;
    }
    if (this.treeStyle) {
      return this.treeStyle.isCheckBox;
    }
    return this.checkBox;
  }

  isFolder() {
    return !this.isLeaf;
  }

  // FOLDING -----------------------------------------------------------------------------------------------------------

  isNodeExpanded():boolean {
    return this.tree._foldingType === FoldingType.Expanded;
  }

  switchFoldingType(e:any, tree:TreeModel):void {
    this.handleFoldingType(e.target.parentNode.parentNode, tree);
  }

  getFoldingTypeCssClass(node:TreeModel):string {
    if (!node._foldingType) {
      if (node.children) {
        node._foldingType = FoldingType.Collapsed;
      } else {
        node._foldingType = FoldingType.Leaf;
      }
    }

    return node._foldingType.cssClass;
  }

  getFoldingImageTypeCssClass(node:TreeModel):string {
    if (node.children) {
      node._foldingImageType = FoldingType.NodeImage;
    } else {
      node._foldingImageType = FoldingType.LeafImage;
    }

    return node._foldingImageType.cssClass;
  }

  getNextFoldingType(node:TreeModel):FoldingType {
    if (node._foldingType === FoldingType.Expanded) {
      return FoldingType.Collapsed;
    }

    return FoldingType.Expanded;
  }

  handleFoldingType(parent:TreeModel, node:TreeModel) {
    if (node._foldingType === FoldingType.Leaf) {
      return;
    }

    node._foldingType = this.getNextFoldingType(node);
  }

  onNodeSelected(e:MouseEvent) {
    if (isLeftButtonClicked(e)) {
      if (this.tree.children === undefined || this.tree.children === null)
        this.isSelected = true;
      this.nodeSelectedSubject.next({node: this.tree});
    }
  }

  getComponentType() {
    let isPlusImage = this.treeStyle.isPlusImage;
    let isCheckBox = this.treeStyle.isCheckBox;
    if (isPlusImage === true && isCheckBox === false) {
      return 'file_no_chk';
    } else if (isPlusImage === true && isCheckBox === true) {
      return 'file_chk';
    } else if (isPlusImage === false && isCheckBox === false) {
      return 'no_file_no_chk';
    } else if (isPlusImage === false && isCheckBox === true) {
      return 'no_file_chk';
    }
    return 'null';
  }
}

@Component({
  selector: 'insight-tree',
  template: `<tree-internal [tree]="tree" [treeStyle]="treeStyle"
            [nodeSelectedSubject]="nodeSelectedSubject"
            [nodeCheckedSubject]="nodeCheckedSubject"
            [unCheckedNode]="unCheckedNode"
            [allNodeUnChecked]="allNodeUnChecked"
            [searchContext]="searchContext"></tree-internal>`,
})
export class KyTreeComponent implements OnInit {
  @Input() tree:TreeModel;
  @Input() unCheckedNode:Subject<TreeModel>;
  @Input() treeStyle:TreeStyle;
  @Input() searchContext:string;
  @Input() allNodeUnChecked:Subject<boolean>;
  @Output() nodeSelected:EventEmitter<any> = new EventEmitter();
  @Output() nodeChecked:EventEmitter<any> = new EventEmitter();

  nodeSelectedSubject:Subject<NodeSelectedEvent> = new Subject<NodeSelectedEvent>();
  nodeCheckedSubject:Subject<NodeSelectedEvent> = new Subject<NodeSelectedEvent>();

  constructor(private treeService:TreeService) {
  }

  ngOnInit():void {
    this.nodeSelectedSubject.subscribe((e:NodeEvent) => {
      this.nodeSelected.emit(e);
    });

    this.nodeCheckedSubject.subscribe((e:NodeEvent) => {
      this.nodeChecked.emit(e);
    })
  }

  elements:Array<TreeModel> = [];

  _isCheckBox() {
    if (this.treeStyle) {
      return this.treeStyle.isCheckBox;
    }
    return false;
  }

  public getSelectedElements():Array<TreeModel> {
    this.elements = [];
    if (this._isCheckBox()) {
      this.elements = [];
      this._getSelectedElements(this.tree);
    }
    return this.elements;
  }

  _getSelectedElements(head:TreeModel) {
    if (head._checkboxFlag === true) {
      this.elements.push(head);
    }
    if (head.children !== null && head.children.length > 0) {
      head.children.forEach(child=> {
        this._getSelectedElements(child);
      });
    }
  }

  getTree() {
    return this.tree;
  }

}
export const KY_TREE_DIRECTIVES = [KyTreeComponent];
/* tslint:enable */
