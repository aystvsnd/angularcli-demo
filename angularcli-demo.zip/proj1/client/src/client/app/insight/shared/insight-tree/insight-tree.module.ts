import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { KyTreeComponent, TreeInternalComponent } from './insight-tree.component';
import { KyCheckboxModule } from '../ky-checkbox/index';
import { TreeService } from './tree.service';

@NgModule({
    imports: [CommonModule, KyCheckboxModule],
    declarations: [KyTreeComponent, TreeInternalComponent],
    providers: [TreeService],
    exports: [KyTreeComponent, TreeInternalComponent]
})

export class KyTreeModule {}
