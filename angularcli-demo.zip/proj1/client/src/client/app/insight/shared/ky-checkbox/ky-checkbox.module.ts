import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { KyCheckbox } from './ky-checkbox.component';

@NgModule({
    imports: [CommonModule],
    declarations: [KyCheckbox],
    exports: [KyCheckbox]
})

export class KyCheckboxModule { }
