/**
 * Created by 6092002302 on 2017/5/16.
 */
import { NgModule } from '@angular/core';
import {SwitchModule} from './switch/switch.module';
import { PxDivTooltipModule } from './tooltip/tooltip.module';
const KY_LIB_MODULES = [

  SwitchModule,
  PxDivTooltipModule

];

@NgModule({
  imports: KY_LIB_MODULES,
  providers: [],
  exports: KY_LIB_MODULES
})

export class SharedModule { }
