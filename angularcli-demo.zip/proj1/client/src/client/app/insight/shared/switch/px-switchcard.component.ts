
/**
 * Created by 6092002302 on 2017/3/23.
 */
import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
declare var $: any;
@Component({
  moduleId: module.id,
  template: `
           
                <div class="switchcard" #swithCard>
                    <span *ngFor="let item of headNames; let i=index" 
                    data-toggle="tooltip" data-placement="top" title="{{item}}"
                    [class.active]="currentName===item" (click) ="onClickMe(item)">{{item}}
                    </span>
                </div>
            
            `,
  selector: 'px-switchcard',
  styles: [
    `
        .switchcard {
          display: flex;
          height: 30px;
          border-radius: 3px;
        }

         .switchcard span {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 120px;
            border: solid 1px #bbb;
            border-right: none;
            color: #7c868d;
            overflow: hidden;
         }

          .switchcard span:hover {
            background: #f8f8f8;
          }

         .switchcard  span:last-of-type {
            border-right: solid 1px #bbb;
         }

          .switchcard span.active {
            background: #eeeeee;
            color: #4d5761;
          }

          .switchcard span:not(.active) {
            cursor: pointer;
          }
    `
  ]
})


export class PxSwitchcardComponent implements OnInit {
  @Input() imgUrls;
  @Input() headNames;
  @Input() currentName;
  @Output() headActive = new EventEmitter();

  ngOnInit() {
    const that = this;
    $(document).ready(function() {
      if(that.currentName && that.currentName !== '') {
        let isExistName = that.isExist(that.currentName, that.headNames);
        isExistName === true ? that.onClickMe(that.currentName) : that.onClickMe(that.headNames[0]);
      } else {
        that.onClickMe(that.headNames[0]);
      }

    });
  }


  onClickMe(item:any) {
    this.currentName = item;
    this.headActive.emit(item);
    console.log(item);
  }

  isExist(currentName, headNames) {
    for(let headName of headNames) {
      if(headName === currentName) {
        return true;
      }
    }
    return false;
  }
}
