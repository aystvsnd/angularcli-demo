/**
 * Created by 6092002302 on 2017/5/16.
 */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PxSwitchcardComponent } from './px-switchcard.component';

@NgModule({
  imports: [CommonModule],
  declarations: [PxSwitchcardComponent],
  exports: [PxSwitchcardComponent]
})

export class SwitchModule { }
