
import {Directive, ElementRef, HostListener, Input, AfterViewInit, Renderer } from '@angular/core';

@Directive({selector: '[pxDivTooltip]'})

export class PxDivTooltipDirective implements AfterViewInit {

  elemPosition: any;
  tooltipOffset = 8;
  element: any;
  div: any;
  elemArray = true;

  @Input('pxDivTooltip') pxDivTooltip = '';
  @Input() placement = 'top';
  @Input() delay = 0;
  @Input() tooltipType = 'iconType';
  @HostListener('mouseenter')
  onMouseEnter() {
    this.getElemPosition();
    if (this.element) {
      removeClass(this.element, 'tooltip-disappear');
      if (this.tooltipType === 'textType') {
        this.createHelpElem();
      } else {
        this.createElem();
      }
      this.setPosition();
      if (this.elemArray === false) {
        if (this.tooltipType === 'textType') {
          this.removeHelpElem();
          this.createHelpElemPure();
        } else {
          this.removeElem();
          this.createElemPure();
        }
      }
    }
  }

  @HostListener('mouseleave')
  onMouseLeave() {
    if (this.element) {
      addClass(this.element, 'tooltip-disappear');
      if (this.elemArray === true) {
        if (this.tooltipType === 'textType') {
          this.removeHelpElem();
        } else {
          this.removeElem();
        }
      } else {
        if (this.tooltipType === 'textType') {
          this.removeHelpElemPure();
        } else {
          this.removeElemPure();
        }
      }
    }
  }

  constructor(private elementRef: ElementRef, private renderer: Renderer) {}

  ngAfterViewInit() {
    this.element = document.getElementById(this.pxDivTooltip);
    if (this.element) {
      if (this.element.className.indexOf('tooltip-disappear') < 0) {
        addClass(this.element, 'tooltip-disappear');
      }
    }
  }

  getElemPosition() {
    this.elemPosition = this.elementRef.nativeElement.getBoundingClientRect();
  }

  createElem() {
    addClass(this.element, 'px-tooltip');
    addClass(this.element, 'px-tooltip-' + this.placement);
    addClass(this.element, 'px-tooltip-show');
  }

  createElemPure() {
    addClass(this.element, 'px-tooltip-pure');
    addClass(this.element, 'px-tooltip-show');
  }

  removeElem() {
    removeClass(this.element, 'px-tooltip');
    removeClass(this.element, 'px-tooltip-' + this.placement);
    removeClass(this.element, 'px-tooltip-show');
  }

  removeElemPure() {
    removeClass(this.element, 'px-tooltip-pure');
    removeClass(this.element, 'px-tooltip-show');
  }

  createHelpElem() {
    addClass(this.element, 'px-tooltip-help');
    addClass(this.element, 'tip-' + this.placement);
    addClass(this.element, 'help-tooltip-show');
  }

  createHelpElemPure() {
    addClass(this.element, 'px-tooltip-help-pure');
    addClass(this.element, 'help-tooltip-show');
  }

  removeHelpElem() {
    removeClass(this.element, 'px-tooltip-help');
    removeClass(this.element, 'tip-' + this.placement);
    removeClass(this.element, 'help-tooltip-show');
  }

  removeHelpElemPure() {
    removeClass(this.element, 'px-tooltip-help-pure');
    removeClass(this.element, 'help-tooltip-show');
  }

  setPosition() {
    const elemHeight = this.elementRef.nativeElement.offsetHeight;
    const elemWidth = this.elementRef.nativeElement.offsetWidth;
    const tooltipHeight = this.element.offsetHeight;
    const tooltipWidth = this.element.offsetWidth;
    const winWidth = document.body.clientWidth;
    const winHeight = document.body.clientHeight;
    let elemLeft;
    let elemRight;
    let elemTop;
    let elemBottom;
    this.elemArray = true;

    if (this.placement === 'top') {
      elemTop = this.elemPosition.top -
          (tooltipHeight + this.tooltipOffset); // - window.scrollY
    }

    if (this.placement === 'bottom') {
      elemTop = this.elemPosition.top + elemHeight +
          this.tooltipOffset; // + window.scrollY
    }

    if (this.placement === 'top' || this.placement === 'bottom') {
      elemLeft =
          (this.elemPosition.left + elemWidth / 2) - tooltipWidth / 2;
    }

    if (this.placement === 'left') {
      elemLeft =
          this.elemPosition.left - tooltipWidth - this.tooltipOffset;
    }

    if (this.placement === 'right') {
      elemLeft =
          this.elemPosition.left + elemWidth + this.tooltipOffset;
    }

    if (this.placement === 'left' || this.placement === 'right') {
      elemTop = this.elemPosition.top +
          elemHeight / 2 - this.element.clientHeight / 2; // + window.scrollY
    }

    elemRight = elemLeft + tooltipWidth;
    elemBottom = elemTop + tooltipHeight;
/*
    console.log('elemHeight=' + elemHeight);
    console.log('elemWidth=' + elemWidth);
    console.log('tooltipHeight=' + tooltipHeight);
    console.log('tooltipWidth=' + tooltipWidth);
    console.log('winWidth=' + winWidth);
    console.log('winHeight=' + winHeight);
    console.log('this.elemPosition.left=' + this.elemPosition.left);
    console.log('this.elemPosition.top=' + this.elemPosition.top);

    console.log('elemLeft=' + elemLeft);
    console.log('elemRight=' + elemRight);
    console.log('elemTop=' + elemTop);
    console.log('elemBottom=' + elemBottom);
*/
    if (elemLeft < 0) {
      elemLeft = this.elemPosition.left + elemWidth + this.tooltipOffset;
      this.elemArray = false;
    }

    if (elemRight > winWidth) {
      elemLeft = this.elemPosition.left - tooltipWidth - this.tooltipOffset;
      this.elemArray = false;
    }

    if (elemTop < 0) {
      elemTop = this.elemPosition.top + elemHeight + this.tooltipOffset; // + window.scrollY;
      this.elemArray = false;
    }

    if (elemBottom > winHeight) {
      elemTop = this.elemPosition.top - (tooltipHeight + this.tooltipOffset); // - window.scrollY
      this.elemArray = false;
    }

    this.element.style.left = elemLeft + window.scrollX + 'px';
    this.element.style.top = elemTop + window.scrollY + 'px';
  }
}

function addClass(elements, cName) {
  elements.className += ' ' + cName;
}

function removeClass(elements, cName) {
  elements.className =
  elements.className.replace( new RegExp( '(\\s|^)' + cName + '(\\s|$)' ), ' ');
  elements.className = elements.className.replace(/\s+/g, ' ');
  elements.className = elements.className.replace(/(^\s+)|(\s+$)/g, '');
}
