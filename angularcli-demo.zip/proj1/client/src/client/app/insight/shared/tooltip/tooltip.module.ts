import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';

import {PxDivTooltipDirective} from './tooltip.directive';

@NgModule({
  imports: [CommonModule],
  declarations: [PxDivTooltipDirective],
  exports: [PxDivTooltipDirective]
})

export class PxDivTooltipModule {
}
