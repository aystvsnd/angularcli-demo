/**
 * Created by 6092002302 on 2017/6/14.
 */
import {Component, OnChanges, SimpleChanges, Input, Output, EventEmitter} from '@angular/core';

declare var $: any;

@Component({
  moduleId: module.id,
  selector: 'observe-window-add',
  templateUrl: 'observe-window-add.component.html',
  styleUrls: ['../../../css/common.css', '../strategy-add.component.less'],
})

export class ObserveWindowAddComponent implements OnChanges {
  @Input() obsvWnd: any;

  @Input() objectType: string;
  @Output() obsWndEerror = new EventEmitter();

  ngOnChanges(sChanges: SimpleChanges) {
    if (this.obsvWnd && this.objectType) {
      this.config();
    }
  }

  public config() {

    this.obsvWnd.observerRange = this.obsvWnd.dayRange;
    this.obsvWnd.observerTime = this.getObserverTime(this.obsvWnd);

    this.obsvWnd.checkChosen = this.obsvWnd.days.length;
  }

  public getCheckLen() {
    const len = this.checkSelect(this.obsvWnd.observerTime.srcDaysChosen);
    this.obsvWnd.checkChosen = len;
    console.log(len);
  }

  public checkChosenTime(srcTime : any, chosenTime : any, name : any) {
    let maxEndTime = '00:00';
    let minBeginTime = '24:00';

    this.obsvWnd.changed = true;
    if (name === 'startTime') {

      srcTime.begin = chosenTime;

      if (srcTime.begin >= srcTime.end) {

        srcTime.showTimeError = true;
      } else {

        srcTime.showTimeError = false;
      }
      //判断end时间是否正确
      for (const time of this.obsvWnd.observerTime.times) {

        if (_.isEqual(time, srcTime)) {

          continue;
        }
        if (Number(srcTime.end.split(':')[0]) >  Number(time.begin.split(':')[0]) &&
          Number(srcTime.end.split(':')[0]) <= Number(time.end.split(':')[0])) {

          srcTime.showTimeError = true;
          break;
        }
      }

      for (const time of this.obsvWnd.observerTime.times) {

        if (time.end < srcTime.end) {

          if (time.end > 　maxEndTime) {

            maxEndTime = time.end;
          }
        }
      }
      //begin time 大于其他小于当前endtime的最大end时间
      if (srcTime.begin < maxEndTime) {

        srcTime.showTimeError = true;
      }
    } else if (name === 'endTime') {

      srcTime.end = chosenTime;

      if (srcTime.begin >= srcTime.end) {

        srcTime.showTimeError = true;
      } else {

        srcTime.showTimeError = false;
      }
      //先判断begin时间是否正确
      for (const time of this.obsvWnd.observerTime.times) {

        if (_.isEqual(time, srcTime)) {

          continue;
        }
        if (Number(srcTime.begin.split(':')[0]) >=  Number(time.begin.split(':')[0]) &&
          Number(srcTime.begin.split(':')[0]) < Number(time.end.split(':')[0])) {

          srcTime.showTimeError = true;
          break;
        }
      }

      for (const time of this.obsvWnd.observerTime.times) {

        if (time.begin > srcTime.begin) {

          if (time.begin < minBeginTime) {

            minBeginTime = time.begin;
          }
        }
      }
      //endtime小于其他大于begintime的最小begintime
      if (srcTime.end > minBeginTime) {

        srcTime.showTimeError = true;
      }
    }
    /*this.isSave = this.isAllowSave();*/
    /*this.obsvWnd.inputError = this.isInputError();*/

    //判断是否允许添加时间
    if (srcTime.showTimeError === true) {
      this.obsvWnd.observerTime.isAdd = false;
    } else {
      this.obsvWnd.observerTime.isAdd = this.isAllowAdd(this.obsvWnd.observerTime.times);
    }
    this.emitEditStatus();
  }

  public addTime() {
    this.obsvWnd.changed = true;

    const beginTimes = ['00:00', '01:00', '02:00', '03:00', '04:00', '05:00', '06:00',
      '07:00', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00',
      '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00'];
    const time = {begin: '', end: ''};
    for (const beginTime of beginTimes) {

      let isAllow = true;
      for (const chosenTime of this.obsvWnd.observerTime.times) {

        if (Number(beginTime.split(':')[0]) >=  Number(chosenTime.begin.split(':')[0]) &&
          Number(beginTime.split(':')[0]) < Number(chosenTime.end.split(':')[0])) {

          isAllow = false;
          break;
        }
      }
      if (isAllow === true) {
        time.begin = beginTime;

        time.end = Number(time.begin.split(':')[0]) + 1 + ':00';
        if (time.end.split(':')[0].length < 2) {
          time.end = '0' + 　time.end.split(':')[0] + ':00';
        }
        break;
      }
    }
    this.obsvWnd.observerTime.times.push(time);
    this.obsvWnd.observerTime.isAdd = this.isAllowAdd(this.obsvWnd.observerTime.times);
    this.emitEditStatus();
  }

  public delete(index: number) {
    this.obsvWnd.changed = true;

    this.obsvWnd.observerTime.times.splice(index, 1);

    const timeErrorList = [];
    for (const time of this.obsvWnd.observerTime.times) {

      if (time.showTimeError === true) {
        timeErrorList.push(time);
      }
    }
    for (const errorTime of timeErrorList) {
      let isError = false;

      if (Number(errorTime.end.split(':')[0]) < Number(errorTime.begin.split(':')[0])) {
        errorTime.showTimeError = true;
        break;
      }

      for (const time of this.obsvWnd.observerTime.times) {
        //
        if (errorTime.begin === time.begin && errorTime.end === time.end) {
          continue;
        }
        //删除时间后判断end时间是否正确
        if (Number(errorTime.end.split(':')[0]) >  Number(time.begin.split(':')[0]) &&
          Number(errorTime.end.split(':')[0]) <= Number(time.end.split(':')[0])) {
          isError = true;
          break;
        }
        //删除时间后判断start时间是否正确
        if (Number(errorTime.begin.split(':')[0]) >=  Number(time.begin.split(':')[0]) &&
          Number(errorTime.begin.split(':')[0]) < Number(time.end.split(':')[0])) {
          isError = true;
          break;
        }
      }
      if (isError === false) {
        errorTime.showTimeError = false;
      }
    }

    this.obsvWnd.observerTime.isAdd = !this.isExistTimeError(this.obsvWnd.observerTime.times) &&
      this.isAllowAdd(this.obsvWnd.observerTime.times);

    this.emitEditStatus();
  }

  public changed(checkName? : any, checkValue? : any) {
    this.obsvWnd.changed = true;

    if (checkName === 'all') {

      this.obsvWnd.checkChosen = 7;
    } else if (checkName === 'special') {

      this.obsvWnd.checkChosen = this.getDaysChosen(this.obsvWnd.observerTime.srcDaysChosen);
    } else if (checkName === 'dataRange') {

      /*this.inputCheck(checkName, checkValue);*/
      this.obsvWnd.showDataRangeError = this.isShowError(checkValue, 1, 180);
      this.emitEditStatus();
    }
  }

  private isShowError(inputValue : any, minThreshold : any, maxThreshold : any) {

    if (inputValue === '') {
      return true;
    }

    for (const ch of inputValue) {
      if (ch < '0' || ch > '9') {

        return true;
      }
    }

    if (minThreshold !== '' && maxThreshold !== '') {
      if (maxThreshold < Number(inputValue) || Number(inputValue) < minThreshold) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }

  }

  private isExistTimeError(times : any) {
    for (const time of times) {
      if (time.showTimeError === true) {
        return true;
      }
    }
    return false;
  }

  private emitEditStatus() {
    let timeError = false;
    for (const time of this.obsvWnd.observerTime.times) {
      if (time.showTimeError === true) {
        timeError = true;
      }
    }
    if (this.obsvWnd.showDataRangeError !== true && timeError !== true) {
      this.obsWndEerror.emit(false);
    } else {
      this.obsWndEerror.emit(true);
    }
  }

  private isAllowAdd(times : any) {
    let timeTotal = 0;
    //判断时间总和
    for (const time of times) {

      timeTotal = Number(time.end.split(':')[0]) - Number(time.begin.split(':')[0])  + timeTotal;
    }

    if (timeTotal >= 24) {

      return false;
    } else {

      return true;
    }
  }

  private getObserverTime(obsvWnd : any) {

    const observeTime = {name : '', srcDaysChosen: [], days: [], times: [], isAdd: true};

    if (obsvWnd.days.length === 7 && obsvWnd.times[0].begin === '00:00'
      && obsvWnd.times[0].end === '24:00') {
      observeTime.name = 'all';
    } else {
      observeTime.name = 'special';
    }
    this.initWeek(observeTime, obsvWnd.days);

    /*this.translateLocalTime(obsvWnd.times);
    observeTime.times = obsvWnd.times;*/
    observeTime.times = this.translateLocalTime(obsvWnd.times);
    observeTime.days = obsvWnd.days;
    observeTime.isAdd = this.isAllowAdd(observeTime.times);
    return observeTime;
  }

  private initWeek(observeTime: any, days) {
    observeTime.srcDaysChosen = [];
    observeTime.srcDaysChosen.push({name: 'Sunday', value: this.isExit(days, 'Sunday')});
    observeTime.srcDaysChosen.push({name: 'Monday', value: this.isExit(days, 'Monday')});
    observeTime.srcDaysChosen.push({name: 'Tuesday', value: this.isExit(days, 'Tuesday')});
    observeTime.srcDaysChosen.push({name: 'Wednesday', value: this.isExit(days, 'Wednesday')});
    observeTime.srcDaysChosen.push({name: 'Thursday', value: this.isExit(days, 'Thursday')});
    observeTime.srcDaysChosen.push({name: 'Friday', value: this.isExit(days, 'Friday')});
    observeTime.srcDaysChosen.push({name: 'Saturday', value: this.isExit(days, 'Saturday')});
  }

  private isExit(days : any, name : any) {
    for (const day of days) {
      if (day === name) {
        return true;
      }
    }
    return false;
  }

  private checkSelect(checks: any) {

    let len = 0;
    for (const single of checks) {

      if (single.value === true) {
        len++;
      }
    }
    return len;
  }

  private getDaysChosen(days : any) {
    let len = 0;
    days.forEach((day) => {
      if (day.value === true) {
        len++;
      }
    });
    return len;
  }

  private translateLocalTime(srcTimes : any) {
    const currentTime = new Date();
    const timeOffset = currentTime.getTimezoneOffset();
    const translateTime: {begin: string, end: string}[] = [];

    if (srcTimes.length === 1 && srcTimes[0].begin === '00:00' && srcTimes[0].end === '24:00') {
      translateTime.push({begin: '00:00', end: '24:00'});
      return translateTime;
    }
    srcTimes.forEach((time) => {
      let localBeginTime = Number(time.begin.split(':')[0]) - timeOffset / 60;
      let localEndTime = Number(time.end.split(':')[0]) - timeOffset / 60;

      localBeginTime = localBeginTime >= 24 ? localBeginTime - 24 : localBeginTime;
      localEndTime = localEndTime > 24 ? localEndTime - 24 : localEndTime;

      localBeginTime = localBeginTime < 0 ?  localBeginTime + 24 : localBeginTime;
      localEndTime = localEndTime <= 0 ? localEndTime + 24 : localEndTime;

      time.begin = localBeginTime < 10 ? '0' + localBeginTime + ':00' : localBeginTime + ':00';
      time.end = localEndTime < 10 ? '0' + localEndTime + ':00' : localEndTime + ':00';
      //UTC时间转为本地时间跨天时，将时间段分为两段
      if (Number(time.begin.split(':')[0]) > Number(time.end.split(':')[0])) {
        translateTime.push({begin: '00:00', end: time.end});

        time.end = '24:00';
      }
      translateTime.push({begin: time.begin, end: time.end});
    });
    return this.combine(translateTime);
  }

  private combine(translateTime: any) {
    translateTime.sort((time1, time2) => {
      return  Number(time1.begin.split(':')[0]) - Number(time2.begin.split(':')[0]);
    });

    const combineTimes : {begin?: string, end?: string}[] = [];
    let tempTime = translateTime[0];
    //bindTimes.push(translateTime[0]);

    for (let i = 1; i < translateTime.length; i++) {
      if (tempTime.end === translateTime[i].begin) {
        tempTime.end = translateTime[i].end;
      } else {
        combineTimes.push(tempTime);
        tempTime = translateTime[i];
      }
    }
    combineTimes.push(tempTime);
    return combineTimes;
  }
}
