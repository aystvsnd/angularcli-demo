/**
 * Created by 6092002302 on 2017/6/13.
 */

import {Component, OnChanges, SimpleChanges, Input, EventEmitter, Output, } from '@angular/core';

declare var $: any;
@Component({
  moduleId: module.id,
  selector: 'reclaim-capacity-add',
  templateUrl: 'reclaim-capacity-add.component.html',
  styleUrls: ['../../../css/common.css', '../strategy-add.component.less', '../../../css/tooltip.less'],
})

export class ReclaimCapacityAddComponent implements OnChanges {
  @Input() reclaimCapacity: any;

  @Input() objectType: string;
  @Output() reclaimCapacityError = new EventEmitter();

  ngOnChanges(sChanges: SimpleChanges) {
    if (this.reclaimCapacity && this.objectType) {
      this.config();
    }
  }
  public config() {

    this.reclaimCapacity.sliderThreshold = [this.reclaimCapacity.threshold.lower, this.reclaimCapacity.threshold.upper];
    this.reclaimCapacity.modifyOversized = this.reclaimCapacity.oversized.threshold;
    this.reclaimCapacity.idlePeriod = this.reclaimCapacity.idle.period;
    this.reclaimCapacity.powerOffPeriod = this.reclaimCapacity.poweroff.period;
    this.reclaimCapacity.checkChosen = this.reclaimCapacity.idle.checks.length;
  }

  public getChosenRange(range : number[] | string) {
    if (range === 'error') {
      this.reclaimCapacity.sliderError = true;
    } else {
      this.reclaimCapacity.sliderError = false;
      this.reclaimCapacity.sliderThreshold = range;
    }
    this.emitEditStatus();
  }

  public getCheckLen() {
    const len = this.checkSelect(this.reclaimCapacity.idle.checks);
    this.reclaimCapacity.checkChosen = len;

    this.emitEditStatus();
  }

  public inputChanged(checkName : any, checkValue : any) {
    this.inputCheck(checkName, checkValue);
    this.emitEditStatus();
  }

  private changeInputStatus(checkName ?: any, checkValue ?: any) {
    if (checkValue === true) {

      if (checkName === 'cpuOccup') {

        this.reclaimCapacity.showCpuOccupError = false;
      } else if (checkName === 'avgNetworkIOUsedRate') {

        this.reclaimCapacity.showNetIOUsageRateError = false;
      } else if (checkName === 'avgDataStorageIORWRate') {

        this.reclaimCapacity.showDiskRWRateError = false;
      }
    } else {

      for (const input of this.reclaimCapacity.idle.checks) {
        if (checkName === input.name) {

          if (checkName === 'cpuOccup') {
            if (input.value === '') {
              input.value = 5;                   //默认值
            } else {
              this.inputCheck(checkName, input.value);
            }
          } else if (checkName === 'avgNetworkIOUsedRate') {
            if (input.value === '') {
              input.value = 1;                   //默认值
            } else {
              this.inputCheck(checkName, input.value);
            }
          } else if (checkName === 'avgDataStorageIORWRate') {
            if (input.value === '') {
              input.value = 1;                   //默认值
            } else {
              this.inputCheck(checkName, input.value);
            }
          }
        }
      }
    }
  }

  private inputCheck(checkName: string, inputValue: number) {
    if (checkName === 'reclaim') {

      this.reclaimCapacity.showReclaimError = this.isShowError(inputValue, 10, 100);
    } else if (checkName === 'cpuOccup') {

      this.reclaimCapacity.showCpuOccupError = this.isShowError(inputValue, 1, 50);
    } else if (checkName === 'avgNetworkIOUsedRate') {

      this.reclaimCapacity.showNetIOUsageRateError = this.isShowError(inputValue, '', '');
    } else if (checkName === 'avgDataStorageIORWRate') {

      this.reclaimCapacity.showDiskRWRateError = this.isShowError(inputValue, '', '');
    } else if (checkName === 'idle') {

      this.reclaimCapacity.showIdleError = this.isShowError(inputValue, 50, 100);
    } else if (checkName === 'powerOff') {

      this.reclaimCapacity.showPowerOffError = this.isShowError(inputValue, 50, 100);
    }
  }

  private isShowError(inputValue : any, minThreshold : any, maxThreshold : any) {

    if (inputValue === '') {
      return true;
    }

    for (const ch of inputValue) {
      if (ch < '0' || ch > '9') {

        return true;
      }
    }

    if (minThreshold !== '' && maxThreshold !== '') {
      if (maxThreshold < Number(inputValue) || Number(inputValue) < minThreshold) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }

  }

  private checkSelect(checks: any) {

    let len = 0;
    for (const single of checks) {

      if (single.checked === true) {
        len++;
      }
    }
    return len;
  }

  private emitEditStatus() {
    if (this.reclaimCapacity.showReclaimError !== true &&
      this.reclaimCapacity.showCpuOccupError !== true &&
      this.reclaimCapacity.showNetIOUsageRateError !== true &&
      this.reclaimCapacity.showDiskRWRateError !== true &&
      this.reclaimCapacity.showIdleError !== true &&
      this.reclaimCapacity.showPowerOffError !== true &&
      this.reclaimCapacity.sliderError !== true &&
      this.reclaimCapacity.checkChosen > 0) {
      return this.reclaimCapacityError.emit(false);
    } else {
      return this.reclaimCapacityError.emit(true);
    }
  }
}
