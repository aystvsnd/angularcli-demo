/**
 * Created by 6092002302 on 2017/6/13.
 */
import {Component, OnChanges, SimpleChanges, Input, Output, EventEmitter} from '@angular/core';


@Component({
  moduleId: module.id,
  selector: 'remain-capacity-add',
  templateUrl: 'remain-capacity.add.component.html',
  styleUrls: ['../strategy-add.component.less', '../../../css/tooltip.less'],
})

export class RemainCapacityAddComponent implements OnChanges {
  @Input() remainCapacity: any;
  @Input() objectType: string;
  @Output() remainCapacityError = new EventEmitter();

  ngOnChanges(sChanges: SimpleChanges) {
    if (this.remainCapacity && this.objectType) {
      this.config();
    }
  }
  public config() {
    this.remainCapacity.checkChosen = this.remainCapacity.checks.length;
    if (this.remainCapacity.algo.name === 'peakStress') {
      this.remainCapacity.isPeakStress = true;
      this.remainCapacity.algo.name = 'peakOnly';
    } else {
      this.remainCapacity.isPeakStress = false;
    }
    this.remainCapacity.sliderThreshold = [this.remainCapacity.threshold.lower, this.remainCapacity.threshold.upper];
  }


  public getChosenRange(range: number[] | string) {
    if (range === 'error') {
      this.remainCapacity.sliderError = true;
    } else {
      this.remainCapacity.sliderError = false;
      this.remainCapacity.sliderThreshold = range;
    }
    this.emitEditStatus();
  }

  public getCheckLen() {
    const len = this.checkSelect(this.remainCapacity.checks);
    this.remainCapacity.checkChosen = len;
    this.emitEditStatus();
  }

  private emitEditStatus() {
    if (!this.remainCapacity.sliderError && this.remainCapacity.checkChosen > 0) {
      this.remainCapacityError.emit(false);
    } else {
      this.remainCapacityError.emit(true);
    }
  }

  private checkSelect(checks: any) {

    let len = 0;
    for (const single of checks) {

      if (single.checked === true) {
        len++;
      }
    }
    return len;
  }

  private getCorrectAlgo(algoName : any, isPeakStress : any) {
    if (algoName === 'peakStress' || algoName === 'peakOnly') {

      if (isPeakStress === true) {

        return 'peakStress';
      } else {

        return 'peakOnly';
      }
    } else if (algoName === 'average') {

      return 'average';
    }
  }

}
