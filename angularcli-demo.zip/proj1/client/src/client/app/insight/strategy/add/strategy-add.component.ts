/**
 * Created by 6092002302 on 2017/3/8.
 */
import { Component, OnInit, ViewChild} from '@angular/core';
import { Router } from '@angular/router';
import {StrategyService} from '../strategy.service';
import {StorageService} from '../../../storage.service';
import {SendMessageService} from '../../../sendMessage.service';
import {TranslateService} from '@ngx-translate/core';

import {Subject} from 'rxjs/Subject';
declare var $: any;
@Component({
  moduleId: module.id,
  templateUrl: 'strategy-add.component.html',
  styleUrls: [ '../../css/common.css', 'strategy-add.component.less'],
})

export class StrategyAddComponent implements OnInit {

  @ViewChild('popup') popup: any;
  stepDesc: any;
  currentStep: number;
  objectsModified: any;
  allObject: any;

  strategyName = '';
  strategyNameExist = false;
  strategyNameChecked = false;
  strategyNameSourceSubmitted = false;
  strategyNameEmpty = false;
  strategyDescription = '';
  strategySource: any;

  strategySourceData: any;
  strategySaveData: any;

  hostStrategyDetail: any;
  vmStrategyDetail: any;

  absoluteLinks: any;

  isSave: any;
  isSendSuccess: any = false;
  isLeavel = false;

  sub = new Subject<any>();
  constructor(private router: Router, private strategyService: StrategyService,
              private storageService: StorageService,
              private sendMessageService: SendMessageService,
              private translate: TranslateService) {

    this.allObject = [this.translate.instant('insight.Policy.Host'), this.translate.instant('insight.Policy.Vm')];
    this.stepDesc = [this.translate.instant('insight.Policy.Naming'), this.translate.instant('insight.Policy.CPIConfiguration')];
    this.currentStep = 1;
    this.objectsModified = [];


    this.strategySource = [];

    this.strategySourceData = {};
    this.strategySaveData = {};

    this.hostStrategyDetail = {};
    this.vmStrategyDetail = {};

    this.isSave = true;
    this.absoluteLinks = [
      {name: this.translate.instant('insight.Policy.Policies'), url: 'main/insight/strategy/strategy-library'},
      {name: this.translate.instant('insight.Policy.AddPolicy'), url: ''}
    ];
  }


  ngOnInit() {

    const that = this;

    this.strategyService.getStrategyNames()
      .then((res: any) => {
        that.strategySource = res;
      });

  }

  jumpNextStep() {
    this.currentStep++;
  }

  jumpPrevstep() {
    this.currentStep--;
  }

  objectsChosen(objects: any) {
    this.objectsModified = objects;
    console.log(objects);
  }

  goBack() {
    this.router.navigate(['main/insight/strategy/strategy-library']);
  }

  checkName() {

    const that = this;
    /*this.strategyName = this.strategyName.replace(/(^s*)|(s*$)/g,'');*/
    this.strategyName = $.trim(this.strategyName);
    const tempStr = this.strategyName;

    if ('' === tempStr) {
      this.strategyNameEmpty = true;
      $('#name').css('border', '2px solid #ff0000');
    } else {
      this.strategyNameEmpty = false;
      this.strategyService.checkStrategyName(this.strategyName)
        .then((res: any) => {

          that.strategyNameChecked = true;

          if (true === res) {
            that.strategyNameExist = true;
            $('#name').css('border', '2px solid #ff0000');
          } else if (false === res) {
            that.strategyNameExist = false;

            if (that.strategyNameSourceSubmitted === true) {

              this.strategyNameSourceSubmitted = false;

              $('#submitStrategyNamewithSource').attr('disabled', 'disabled');

              const selectName = $('.strategy-source-select').val();
              this.strategyService.getStrategyDetail(selectName)
                .then((res: any) => {

                  that.strategySourceData = res;
                  $.extend(that.strategySaveData, that.strategySourceData);

                  that.readData();

                  that.jumpNextStep();
                  $('#submitStrategyNamewithSource').removeAttr('disabled');

                });
            }
          }

        });
    }

  }

  setFocus() {
    this.strategyNameChecked = false;
    this.strategyNameEmpty = false;
    $('#name').css('border', '');
  }

  SubmitStrategyNameSource() {

    this.strategyNameSourceSubmitted = true;

    this.checkName();

  }

  SubmitSaveData() {

    this.strategySaveData.name = this.strategyName;
    this.strategySaveData.default = false;
    this.strategySaveData.creator = this.storageService.getUserName();
    this.strategySaveData.changer = this.storageService.getUserName();
    this.strategySaveData.desc = this.strategyDescription;

    for(let type of this.objectsModified) {
      if(type === 'host' || type === '主机') {
        this.updateWorkLoad(this.hostStrategyDetail.workload, this.strategySaveData.hostCPI.workload);
        this.updateRemainCapa(this.hostStrategyDetail.remainCapacity, this.strategySaveData.hostCPI.remainCapacity);
        this.updatereclaimCapa(this.hostStrategyDetail.reclaimCapacity, this.strategySaveData.hostCPI.reclaimCapacity);
        this.updateStress(this.hostStrategyDetail.stress, this.strategySaveData.hostCPI.stress);
        this.updateObsvWnd(this.hostStrategyDetail.obsvWnd, this.strategySaveData.hostCPI.obsvWnd);
      } if(type === 'vm' || type === '虚机') {
        this.updateWorkLoad(this.vmStrategyDetail.workload, this.strategySaveData.vmCPI.workload);
        this.updateRemainCapa(this.vmStrategyDetail.remainCapacity, this.strategySaveData.vmCPI.remainCapacity);
        this.updatereclaimCapa(this.vmStrategyDetail.reclaimCapacity, this.strategySaveData.vmCPI.reclaimCapacity);
        this.updateStress(this.vmStrategyDetail.stress, this.strategySaveData.vmCPI.stress);
        this.updateObsvWnd(this.vmStrategyDetail.obsvWnd, this.strategySaveData.vmCPI.obsvWnd);
      }
    }

    this.strategyService.addNewStrategy(this.strategySaveData)
      .then((res: any) => {

        if ('ok' === res) {
          this.isSendSuccess = true;

          this.sendMessageService.insightSendSucMsg(this.translate.instant('insight.Policy.SaveSuccess'));
          this.router.navigate(['main/insight/strategy/strategy-library']);
        } else {
          this.sendMessageService.sendResponseMsg(this.translate.instant('insight.Policy.FailReason') + res);
        }

      });

  }

  readData() {
    this.hostStrategyDetail = {};
    this.vmStrategyDetail = {};
    $.extend(true, this.hostStrategyDetail, this.strategySaveData.hostCPI);
    $.extend(true, this.vmStrategyDetail, this.strategySaveData.vmCPI);
  }

  isExistError(isError: boolean, badge) {
    let isHostWorkLoadError = false;
    let isVmWorkLoadError = false;

    let isHostRemainCapaError = false;
    let isVmRemainCapaError = false;

    let isHostReclaimCapaError = false;
    let isVmReclaimCapaError = false;

    let isHostStressError = false;
    let isVmStressError = false;

    let isHostObsvWndError = false;
    let isVmObsvWndError = false;

    switch (badge) {
      case 'hostWorkLoad':
        isHostWorkLoadError = isError;
        break;

      case 'vmWorkLoad':
        isVmWorkLoadError = isError;
        break;

      case 'hostRemainCapacity':
        isHostRemainCapaError = isError;
        break;

      case 'vmRemainCapacity':
        isVmRemainCapaError = isError;
        break;

      case 'hostReclaimCapacity':
        isHostReclaimCapaError = isError;
        break;

      case 'vmReclaimCapacity':
        isVmReclaimCapaError = isError;
        break;

      case 'hostStressError':
        isHostStressError = isError;
        break;

      case 'vmStressError':
        isVmStressError = isError;
        break;

      case 'hostObsvWndError':
        isHostObsvWndError = isError;
        break;

      case 'vmObsvWndError':
        isVmObsvWndError = isError;
        break;
    }

    this.isSave = !isHostWorkLoadError && !isVmWorkLoadError && !isHostRemainCapaError && !isVmRemainCapaError
      && !isHostReclaimCapaError && !isVmReclaimCapaError && !isHostStressError && !isVmStressError && !isHostObsvWndError && !isVmObsvWndError;
  }

  updateWorkLoad(srcWorkLoad: any, saveWorkLoad: any) {

    const checks = JSON.parse(JSON.stringify(srcWorkLoad.checks));

    saveWorkLoad.checks = checks;
    saveWorkLoad.threshold = {
      'lower': srcWorkLoad.sliderThreshold[0],
      'upper': srcWorkLoad.sliderThreshold[1]
    };
  }

  updateRemainCapa(srcRemainCapacity, saveRemainCapacity) {
    const checks = JSON.parse(JSON.stringify(srcRemainCapacity.checks));

    saveRemainCapacity.checks = checks;

    saveRemainCapacity.threshold = {
      'lower': srcRemainCapacity.sliderThreshold[0],
      'upper': srcRemainCapacity.sliderThreshold[1]
    };
    saveRemainCapacity.algo.name =
      this.getCorrectAlgo(srcRemainCapacity.algo.name,
        srcRemainCapacity.isPeakStress);
  }

  updatereclaimCapa(srcReclaimCapacity, saveReclaimCapacity) {
    let checks = JSON.parse(JSON.stringify(srcReclaimCapacity.idle.checks));
    checks.forEach((check)=> {
      check.value = Number(check.value);
    });
    saveReclaimCapacity.idle.checks = checks;

    saveReclaimCapacity.idle.period = parseInt(srcReclaimCapacity.idlePeriod);
    saveReclaimCapacity.threshold = {
      'lower': srcReclaimCapacity.sliderThreshold[0],
      'upper': srcReclaimCapacity.sliderThreshold[1]
    };
    saveReclaimCapacity.oversized.threshold = parseInt(srcReclaimCapacity.modifyOversized);
    saveReclaimCapacity.poweroff.period = parseInt(srcReclaimCapacity.powerOffPeriod);

  }

  updateStress(srcStress, saveStress) {
    let checks = JSON.parse(JSON.stringify(srcStress.checks));
    checks.forEach((check)=>{
      check.value = Number(check.value);
    });
    saveStress.checks = checks;

    saveStress.threshold = {
      'lower': srcStress.sliderThreshold[0],
      'upper': srcStress.sliderThreshold[1]
    };
  }

  updateObsvWnd(srcObsvWnd, saveObsvWnd) {
    this.getChosenDays(srcObsvWnd);

    saveObsvWnd.days = srcObsvWnd.days;
    saveObsvWnd.dayRange = Number(srcObsvWnd.observerRange);
    srcObsvWnd.observerTime.times =
      this.combine(srcObsvWnd.observerTime.times);
    /*this.translateUTCTime(this.obsvWnd.observerTime.times);
     this.strategySaveData.vmCPI.obsvWnd.times = this.obsvWnd.observerTime.times;*/
    saveObsvWnd.times = this.translateUTCTime(srcObsvWnd.observerTime.times);
  }

  getChosenDays(obsvWnd: any) {
    obsvWnd.days = [];
    if (obsvWnd.observerTime.name === 'all') {
        obsvWnd.days = ['Sunday',
        'Monday',
        'Tuesday',
        'Wednesday',
        'Thursday',
        'Friday',
        'Saturday'];
      obsvWnd.observerTime.times = [{begin: '00:00', end: '24:00'}];
    } else {
      for (const day of obsvWnd.observerTime.srcDaysChosen) {
        if (day.value === true) {
          obsvWnd.days.push(day.name);
        }
      }
    }
  }

  translateUTCTime(srcTimes: any) {
    const currentTime = new Date();
    const timeOffset = currentTime.getTimezoneOffset();
    const translateTime: {begin: string, end: string}[] = [];

    if (srcTimes.length === 1 && srcTimes[0].begin === '00:00' && srcTimes[0].end === '24:00') {
      translateTime.push({begin: '00:00', end: '24:00'});
      return translateTime;
    }
    srcTimes.forEach((time) => {
      let UTCBeginTime = Number(time.begin.split(':')[0]) + (timeOffset / 60);
      let UTCEndTime = Number(time.end.split(':')[0]) + (timeOffset / 60);

      UTCBeginTime = UTCBeginTime < 0 ? UTCBeginTime + 24 : UTCBeginTime;
      UTCEndTime = UTCEndTime <= 0 ? UTCEndTime + 24 : UTCEndTime;

      UTCBeginTime = UTCBeginTime >= 24 ? UTCBeginTime - 24 : UTCBeginTime;
      UTCEndTime = UTCEndTime > 24 ? UTCEndTime - 24 : UTCEndTime;

      time.begin = UTCBeginTime < 10 ? '0' + UTCBeginTime + ':00' : UTCBeginTime + ':00';
      time.end = UTCEndTime < 10 ? '0' + UTCEndTime + ':00' : UTCEndTime + ':00';

      //UTC时间转为本地时间跨天时，将时间段分为两段
      if (Number(time.begin.split(':')[0]) > Number(time.end.split(':')[0])) {
        translateTime.push({begin: '00:00', end: time.end});

        time.end = '24:00';
      }
      translateTime.push({begin: time.begin, end: time.end});
    });
    return translateTime;
  }

  combine(translateTime: any) {
    translateTime.sort((time1, time2) => {
      return Number(time1.begin.split(':')[0]) - Number(time2.begin.split(':')[0]);
    });

    const combineTimes: {begin?: string, end?: string}[] = [];
    let tempTime = translateTime[0];
    //bindTimes.push(translateTime[0]);

    for (let i = 1; i < translateTime.length; i++) {
      if (tempTime.end === translateTime[i].begin) {
        tempTime.end = translateTime[i].end;
      } else {
        combineTimes.push(tempTime);
        tempTime = translateTime[i];
      }
    }
    combineTimes.push(tempTime);
    return combineTimes;
  }

  getCorrectAlgo(algoName: any, isPeakStress: any) {
    if (algoName === 'peakStress' || algoName === 'peakOnly') {

      if (isPeakStress === true) {

        return 'peakStress';
      } else {

        return 'peakOnly';
      }
    } else if (algoName === 'average') {

      return 'average';
    }
  }

  canDeactivate(): Promise<boolean> | boolean {

    if (this.strategyName === '' || this.isSendSuccess === true) {
      return true;
    } else {
      $('#confirm-leave').modal('show');
      return this.sub;
    }
  }

  confirmLeave() {
    $('#confirm-leave').modal('hide');
    this.sub.next(true);
  }

  cancel() {
    $('#confirm-leave').modal('hide');
    this.sub.next(false);
  }
}
