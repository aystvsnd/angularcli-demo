/**
 * Created by 6092002302 on 2017/6/14.
 */

import {Component, OnChanges, SimpleChanges, Input, Output, EventEmitter} from '@angular/core';
declare var $: any;

@Component({
  moduleId: module.id,
  selector: 'stress-add',
  templateUrl: 'stress-add.component.html',
  styleUrls: ['../../../css/common.css', '../strategy-add.component.less', '../../../css/tooltip.less'],
})

export class StressAddComponent implements OnChanges {
  @Input() stress: any;
  @Input() objectType: string;
  @Output() stressError = new EventEmitter();


  ngOnChanges(sChanges: SimpleChanges) {
    if (this.stress && this.objectType) {
      this.config();
    }
  }

  public config() {

    this.stress.sliderThreshold = [this.stress.threshold.lower, this.stress.threshold.upper];
    this.stress.checkChosen = this.stress.checks.length;
  }

  public getChosenRange(range : number[] | string) {
    if (range === 'error') {
      this.stress.sliderError = true;
    } else {
      this.stress.sliderError = false;
      this.stress.sliderThreshold = range;
    }
    this.emitEditStatus();
  }

  /*public checkChanged(checkName ?: string, checkValue?: boolean) {
    this.changeInputStatus(checkName, checkValue);
    this.stress.inputError = this.isInputError();
  }*/

  public getCheckLen() {
    const len = this.checkSelect(this.stress.checks);
    this.stress.checkChosen = len;

    this.emitEditStatus();
  }

  public inputChanged(checkName?: any, checkValue?: any) {

    this.inputCheck(checkName, checkValue);

    this.emitEditStatus();
  }

  private inputCheck(checkName : string, inputValue: number) {
    if (checkName === 'cpuOccup') {

      this.stress.showCpuOccupError = this.checkInputValue(inputValue, 50, 100);
    } else if (checkName === 'memOccup') {

      this.stress.showMemOccupError = this.checkInputValue(inputValue, 50, 100);
    } else if (checkName === 'networkIncomingRate') {

      this.stress.showNetworkInError =  this.checkInputValue(inputValue, 50, 100);
    } else if (checkName === 'networkOutgoingRate') {

      this.stress.showNetworkOutError = this.checkInputValue(inputValue, 50, 100);
    } else if (checkName === 'networkBidirectRate') {

      this.stress.showNetworkBiError =  this.checkInputValue(inputValue, 50, 100);
    }
  }

  checkSelect(checks: any) {
    let len = 0;
    for (const single of checks) {
      if (single.checked === true) {
        len++;
      }
    }
    return len;
  }

  checkInputValue(inputValue: any, minThreshold: any, maxThreshold: any) {

    if (inputValue === '') {
      return true;
    }

    for (const ch of inputValue) {
      if (ch < '0' || ch > '9') {

        return true;
      }
    }

    if (minThreshold !== '' && maxThreshold !== '') {
      if (maxThreshold < Number(inputValue) || Number(inputValue) < minThreshold) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  private changeInputStatus(checkName : string, checkValue: boolean) {
    if (checkValue === true) {

      if (checkName === 'cpuOccup') {

        this.stress.showCpuOccupError = false;
      } else if (checkName === 'memOccup') {

        this.stress.showMemOccupError = false;
      } else if (checkName === 'networkIncomingRate') {

        this.stress.showNetworkInError = false;
      } else if (checkName === 'networkOutgoingRate') {

        this.stress.showNetworkOutError = false;
      } else if (checkName === 'networkBidirectRate') {

        this.stress.showNetworkBiError = false;
      }
    } else {

      for (const input of this.stress.checks) {
        if (checkName === input.name) {
          if (input.value === '') {
            input.value = 70;
          } else {
            this.inputCheck(checkName, input.value);
          }
        }
      }
    }
  }

  private emitEditStatus() {
    if ( this.stress.showCpuOccupError !== true && this.stress.showMemOccupError !== true &&
      this.stress.showNetworkInError !== true && this.stress.showNetworkOutError !== true &&
      this.stress.showNetworkBiError !== true && this.stress.sliderError !== true &&
      this.stress.checkChosen > 0) {
      this.stressError.emit(false);
    } else {
      this.stressError.emit(true);
    }
  }
}
