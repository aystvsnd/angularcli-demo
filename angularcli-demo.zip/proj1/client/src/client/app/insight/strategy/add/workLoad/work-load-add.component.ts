/**
 * Created by 6092002302 on 2017/6/13.
 */
import {Component, OnChanges, SimpleChanges, Input, Output, EventEmitter} from '@angular/core';

declare var $: any;
@Component({
  moduleId: module.id,
  selector: 'work-load-add',
  templateUrl: 'work-load-add.component.html',
  styleUrls: ['../strategy-add.component.less', '../../../css/tooltip.less'],
})

export class WorkLoadAddComponent implements OnChanges {
  @Input() workLoad: any;
  @Input() objectType: string;

  @Output() workLoadError = new EventEmitter();

  ngOnChanges(sChanges: SimpleChanges) {
    if (this.workLoad && this.objectType) {
      this.config();
    }
  }

  public config() {
    this.workLoad.checkChosen = this.workLoad.checks.length;
    this.workLoad.sliderThreshold = [this.workLoad.threshold.lower, this.workLoad.threshold.upper];
    this.workLoad.sliderError = false;
  }

  public getChosenRange(range : number[] | string) {
    if (range === 'error') {
      this.workLoad.sliderError = true;
    } else {
      this.workLoad.sliderError = false;
      this.workLoad.sliderThreshold = range;
    }
    this.emitEditStatus();
  }

  public getCheckLen() {
    const len = this.checkSelect(this.workLoad.checks);
    this.workLoad.checkChosen = len;
    this.emitEditStatus();
  }

  private checkSelect(checks: any) {
    let len = 0;
    for (const single of checks) {

      if (single.checked === true) {
        len++;
      }
    }
    return len;
  }

  private emitEditStatus() {
    if (!this.workLoad.sliderError && this.workLoad.checkChosen > 0) {
      this.workLoadError.emit(false);
    } else {
      this.workLoadError.emit(true);
    }
  }
}
