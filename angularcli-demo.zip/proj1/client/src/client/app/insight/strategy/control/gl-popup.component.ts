/**
 * Created by 6092002302 on 2017/7/5.
 */
import {Component, OnInit,} from '@angular/core';
import {Subject} from 'rxjs/Subject';

@Component({
  moduleId: module.id,
  template: `
             
    <div class="dialogue-background-power" *ngIf="isDisplay">
            <div class="dialogue-power">
            <h4>确定</h4>
            <div class="content">
            <p>
                <span><img src="assets/images/insight/pop_alarm.png"></span>
                确定要离开当前页面吗？
            </p>
           
            <div class="button-group">
                <ky-button [type]="'normal'" (click)='leavePage()'>{{"insight.Confirm" | translate}}</ky-button>
                <ky-button [type]="'cancel'" (click)='cancel()'>{{"insight.Cancel" | translate}}</ky-button>
            </div>
            </div>
        </div>
    </div>
            `,
  selector: 'dialog-pop',
  styles:[
    `
    .dialogue-background-power{
    background: rgba(0, 0, 0, 0.4);
    color: black;
    position: absolute;
    width: 100%;
    height: 100%;
    z-index: 2000;
    top: 0%;
    left: 0%;
    }
    .dialogue-power{
        background: white;
        position: absolute;
        width: 560px;
        height: 240px;
        top: 40%;
        left: 50%;
        margin-left: -260px;
        margin-top: -120px;
    }
    .dialogue-power h4{
    border-bottom: 1px solid #dddddd;
    color: #333333;
    font-size: 18px;
    line-height:47px;
    margin-bottom: 0 !important;
    margin-top: 0 !important;
    padding-left: 30px;
    padding-right: 20px;
    }
    .dialogue-power h4 span{
    background-image: url("../../../assets/images/insight/popup_btn_close.png");
    cursor: pointer;
    float: right;
    width: 16px;
    height: 16px;
    margin-top: 16px;   
    }
    .dialogue-power h4 span:hover{
    background-image: url("../../../assets/images/insight/popup_btn_close_hover.png");
    }
    .dialogue-power .content{
    height: 192px;
    position: relative;
    text-align: center; 
    }
    .dialogue-power .content p{
    font-size: 14px;
    color: #333333;
    position: absolute;
    width: 100%;
    top: 40px;  
    }
    .dialogue-power .content p span{
    margin-right: 10px;
    }
    .dialogue-power .button-group{
     position: absolute;
    bottom: 30px;
    width: 100%;
    }
    .dialogue-power .button-group button:first-child{
    margin-right: 10px;
    }
    `
  ]
})

export class GlPopup implements OnInit {

  isDisplay : boolean = false;
  sub = new Subject<any>();

  ngOnInit() {

  }

  leavePage() {
    this.isDisplay = false;
    this.sub.next(true);
  }

  cancel() {
    this.isDisplay = false;
    this.sub.next(false);
  }
}

