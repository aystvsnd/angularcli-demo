/**
 * Created by 6092002302 on 2017/3/13.
 */
import {Component, OnInit, Input} from '@angular/core';
declare var $: any;
@Component({
  moduleId: module.id,
  template: `
                <div class="card-not-expand" id="card-not-expand-{{elementId}}" (click)="displayOrHide(elementId)">
                    <span>{{objectName}}</span>
                    <img src="assets/images/insight/svg/3_double_angle_down.svg" id="sword-style-{{elementId}}">
                </div>
                <div class="card-expand" id="card-expand-{{elementId}}">
                    <ng-content></ng-content>
                </div>

            `,
  selector: 'px-cards',
  styles: [`
        img{
            display: inline-block;
            height: 16px;
            width: 16px;
            float: right;
            margin-right: 20px;
        }
        .card-not-expand {
            height:40px;
            width:100%;
            border:1px solid #ccc;
            padding: 10px 0 0 20px;
        }
        .card-not-expand:hover{
            cursor: pointer;
            background: #f8f8f8;
        }
       
        .card-not-expand span{
            font-size: 16px;
            color: #4d5761;
        }
        .card-expand{
            display: none;
            border: 1px solid #ccc;
            border-top: none;
        }
        
    `],
})

export class PxCardsComponent implements OnInit {
  @Input() objectName;

  elementId : any;
  constructor() {
    console.log('todo');
  }

  ngOnInit() {
    this.elementId = this.objectName.replace(/\s+/g, '');
  }

  displayOrHide(objectName : any) {
    const url = document.getElementById('sword-style-' + objectName);
    if (url.attributes['src'].nodeValue === 'assets/images/insight/svg/3_double_angle_down.svg') {
      url.src = 'assets/images/insight/svg/3_double_angle_up.svg';
      $('#card-not-expand-' + objectName).css('border-bottom', 'none');
    } else {
      url.src = 'assets/images/insight/svg/3_double_angle_down.svg';
      $('#card-not-expand-' + objectName).css('border-bottom', '1px solid #ccc');
    }
    $('#card-expand-' + objectName).slideToggle('slow');
  }
}
