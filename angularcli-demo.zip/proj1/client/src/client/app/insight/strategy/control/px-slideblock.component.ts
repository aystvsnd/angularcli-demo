/**
 * Created by root on 3/14/17.
 */

import {Component, OnInit, Input} from '@angular/core';


@Component({
  moduleId: module.id,
  template: `
  <div class="sliderBlock" [style.width.px] = "len">
    <span class="min-display" [style.left.%]="data[0] - 3">{{data[0]}}</span>
    <span class="min-display" [style.left.%]="data[1]">{{data[1]}}</span>
    <div *ngIf="isReversal === true" [style.width.%]="data[0]" class="serious-color"></div>
    <div *ngIf="isReversal !== true" [style.width.%]="data[0]" class="minStatus"></div>
    <div *ngIf="isReversal === true" [style.width.%]="100 - data[1]" class="common-color"></div>
    <div *ngIf="isReversal !== true" [style.width.%]="100 - data[1]" class="maxStatus"></div>
   
  </div>`,
  selector: 'px-slideblock',
  styles: [`
    .sliderBlock{
      height: 6px;
      background: #f7c515;
      position: relative;
      display: inline-block;
      border-radius: 6px;
    }
    .min-display {
        position: absolute;
        top: -20px;
    }
    .minStatus {
      height: 6px;
      float: left;
      top: 0px;
      background: #73cf22;
      border-radius: 6px 0 0 6px;
    }
    .serious-color{
        height: 6px;
        float: left;
        top: 0px;
        border-radius: 6px 0 0 6px;
        background: #ff5b55;
    }
    .common-color{
        background: #73cf22;
        float: right;
        height: 6px;
        top: 0px;
        border-radius: 0 6px 6px 0;
    }
    .maxStatus {
        float: right;
        height: 6px;
        top: 0px;
        background: #ff5b55;
        border-radius: 0 6px 6px 0;
    }
    `
  ],
})


export class PxSlideblockComponent implements OnInit {
  /* tslint:disable */
  @Input() private resourceName;
  @Input() private data;
  @Input() private isReversal = false;
  @Input() private len = 400;
  /* tslint:enable*/

  ngOnInit() {
    console.log(this.data);
    console.log(this.resourceName);
  }
}
