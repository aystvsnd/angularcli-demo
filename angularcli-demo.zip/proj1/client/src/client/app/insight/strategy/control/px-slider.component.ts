/**
 * Created by 6092002302 on 2017/3/15.
 */
import {Component, OnInit, Input, Output, EventEmitter, OnChanges} from '@angular/core';
declare var $: any;
@Component({
  moduleId: module.id,
  template: `
             <div class="px-slider">
               <div class="px-line" id="px-line-{{sliderName}}">
                    <div class="leftArea" [class.leftColor]="isReversal===false"
                     [class.rightColor]="isReversal===true" id="leftArea-{{sliderName}}"></div>
                    <div class="rightArea" [class.rightColor]="isReversal===false"
                     [class.leftColor]="isReversal===true" id="rightArea-{{sliderName}}"></div>
               </div>
               
               <div class="left-show" id="circle-min-{{sliderName}}">
                    <span class="glyphicon glyphicon-triangle-top triangle-top" 
                    [class.top-color]="isReversal===false" [class.bottom-color]="isReversal==true"></span>
                    <span class="min-display">{{minThreshold}}</span> 
               </div>
               <div class="right-show" id="circle-max-{{sliderName}}">
                    <span class="max-display" >{{maxThreshold}}</span>
                    <span class="glyphicon glyphicon-triangle-bottom triangle-bottom" 
                    [class.bottom-color]="isReversal===false" [class.top-color]="isReversal==true"></span>
               </div>
             </div>

             <div class="input-form">
                <span class="glyphicon glyphicon-triangle-top triangle-top-display"
                    [class.top-color]="isReversal===false" [class.bottom-color]="isReversal==true"></span>
                <div class="input-and-errortip">
                    <input name="minInput" type="text"  placeholder="{{minThreshold}}"  class="input-style" 
                    id="min-input-{{sliderName}}" #thresholdInput (keyup)="onEnter(thresholdInput.value, 'min')">
                    <span class="errorTip" *ngIf="isShowMinError == true">error</span>
                </div>
                <span class="glyphicon glyphicon-triangle-bottom triangle-bottom-display"
                    [class.bottom-color]="isReversal===false" [class.top-color]="isReversal==true"></span>
                <div class="input-and-errortip">
                    <input type="text" name="maxInput" placeholder="{{maxThreshold}}"  class="input-style" 
                    id="max-input-{{sliderName}}" #thresholdMaxInput (keyup)="onEnter(thresholdMaxInput.value, 'max')">
                    <span class="errorTip" *ngIf="isShowMaxError == true">error</span>
                </div>
             </div>

            `,
  selector: 'cms-slider',
  styleUrls: [ '../../css/common.css', 'px-slider.component.css'],
})


export class CmsSliderComponent implements OnInit, OnChanges {
  @Input() defaultValue;
  @Input() sliderName;
  @Input() isReversal = false;
  @Output() choosedReturn = new EventEmitter();

  leftCircleMove : any;
  rightCircleMove: any;
  isShowMinError : any;
  isShowMaxError : any;

  $leftCircle    : any;
  $rightCircle   : any;
  $minInput      : any;
  $maxInput      : any;
  $leftArea      : any;
  $rightArea     : any;
  $pxLine        : any;

  minThreshold   : number;
  maxThreshold   : number;

  sliderReturn   : any;

  constructor() {
    this.isShowMinError = false;
    this.isShowMaxError = false;
  }

  ngOnInit() {
    console.log(this.sliderName);
    const that = this;

    this.sliderName = this.sliderName.replace(/\s+/g, '');

    this.dataInit(that);
    this.mouseDrag(that);

  }

  ngOnChanges() {
    const that = this;
    this.dataInit(that);
  }

  dataInit(that : any) {
    $(document).ready(function() {
      that.$minInput     = $('#min-input-'   + that.sliderName);
      that.$maxInput     = $('#max-input-'   + that.sliderName);
      that.$leftArea     = $('#leftArea-'    + that.sliderName);
      that.$rightArea    = $('#rightArea-'   + that.sliderName);
      that.$leftCircle   = $('#circle-min-'  + that.sliderName);
      that.$rightCircle  = $('#circle-max-'  + that.sliderName);
      that.$pxLine       = $('#px-line-'     + that.sliderName);
      that.defaultConfigure(that.defaultValue, that);
    });
  }

  defaultConfigure(defaultValue : any, that : any) {
      that.minThreshold    = defaultValue[0];
      that.maxThreshold    = defaultValue[1];

      that.leftCircleMove  = 4 * defaultValue[0] - 20;
      that.rightCircleMove = 4 * defaultValue[1] - 20;

      that.$leftCircle.css('left', that.leftCircleMove + 'px');
      that.$rightCircle.css('left', that.rightCircleMove + 'px');

      that.$leftArea.css('width', 4 * defaultValue[0]);
      that.$rightArea.css('left', that.rightCircleMove + 20 + 'px');
      that.$rightArea.css('width', 4 * (100 - defaultValue[1]));

  }

  mouseDrag(that) {
    $(document).ready(function() {

      that.$leftCircle.on('mousedown', function (e) {
        $(document.body).on('mousemove', function (e) {

          window.getSelection().removeAllRanges();

          that.leftCircleMove = that.mouseMove(e, 'leftCircle');
          that.minThreshold = Math.floor((that.leftCircleMove + 20) / 4);

          that.$minInput[0].value = '';

          that.$leftCircle.css('left', that.leftCircleMove + 'px');

          that.$leftArea.css('width', that.leftCircleMove + 20 + 'px');
          console.log(that.leftCircleMove);
          console.log(that.minThreshold);

          that.isShowMinError = false;

          that.rangeReturn(that.minThreshold, that.maxThreshold);
        });
      });

      that.$rightCircle.on('mousedown', function (e) {
        $(document.body).on('mousemove', function (e) {

          window.getSelection().removeAllRanges();

          that.rightCircleMove = that.mouseMove(e, 'rightCircle');
          that.maxThreshold = Math.floor((that.rightCircleMove + 20) / 4);

          that.$maxInput[0].value = '';

          that.$rightCircle.css('left', that.rightCircleMove + 'px');

          that.$rightArea.css('left', that.rightCircleMove + 20 + 'px');
          that.$rightArea.css('width', 380 - that.rightCircleMove);

          that.isShowMaxError = false;

          that.rangeReturn(that.minThreshold, that.maxThreshold);
        });
      });

      $(document.body).on('mouseup', function (e) {
        $(document.body).off('mousemove');
        /*that.rangeReturn(that.minThreshold, that.maxThreshold);*/
      });
    });
  }

  mouseMove(e : any, circle : any) {

    const lineLeft = this.$pxLine.offset().left;
    console.log('lineLeft' + lineLeft);

    let circleMove = e.pageX - lineLeft - 20;
    if (circle === 'leftCircle') {

      if (circleMove < -20) {

        circleMove = -20;
      } else if (circleMove > this.rightCircleMove) {

        circleMove = this.rightCircleMove - 4;
      }
    }
    if (circle === 'rightCircle') {

      if (circleMove > 380) {

        circleMove = 380;
      } else if (circleMove < this.leftCircleMove) {

        circleMove = this.leftCircleMove + 4;
      }
    }
    return circleMove;
  }

  onEnter(keyUpValue : any, minOrMax : any) {

    this.maxThreshold = Number(this.maxThreshold);
    this.minThreshold = Number(this.minThreshold);

    if (keyUpValue === '') {
      this.isShowMinError = false;
      this.isShowMaxError = false;

      this.choosedReturn.emit([this.minThreshold, this.maxThreshold]);
      return;
    }

    switch (minOrMax) {
      case 'min':

        if (this.isInputError(keyUpValue, 'min') === true) {

          this.$minInput[0].value = '';
          this.rangeReturn(this.minThreshold, this.maxThreshold);
          return;
        } else {
          keyUpValue = Number(keyUpValue);
        }

        if (keyUpValue < 0 || keyUpValue >= this.maxThreshold) {

          this.isShowMinError = true;
          this.choosedReturn.emit('error');
        } else {

          this.$maxInput[0].value = '';

          this.isShowMinError = false;
          this.isShowMaxError = false;

          this.minThreshold = keyUpValue;
          this.leftCircleMove = 4 * keyUpValue - 20;

          this.$leftCircle.css('left', this.leftCircleMove + 'px');
          this.$leftArea.css('width', this.leftCircleMove + 20 + 'px');

          this.rangeReturn(this.minThreshold, this.maxThreshold);
        }
        break;

      case 'max':

        if (this.isInputError(keyUpValue, 'max') === true) {

          this.$maxInput[0].value = '';
          this.rangeReturn(this.minThreshold, this.maxThreshold);
          return;
        } else {
          keyUpValue = Number(keyUpValue);
        }

        if (keyUpValue > 100 || keyUpValue <= this.minThreshold) {

          this.isShowMaxError = true;
          this.choosedReturn.emit('error');
        } else {

          this.$minInput[0].value = '';

          this.isShowMinError = false;
          this.isShowMaxError = false;

          this.maxThreshold = keyUpValue;
          this.rightCircleMove = 4 * keyUpValue - 20;

          this.$rightCircle.css('left', this.rightCircleMove + 'px');

          this.$rightArea.css('left', this.rightCircleMove + 20 + 'px');
          this.$rightArea.css('width', (100 - this.maxThreshold) * 4);

          this.rangeReturn(this.minThreshold, this.maxThreshold);
        }
        break;
    }
  }


  isInputError(keyUpValue : any, minOrMax : any) {

    for (const ch of keyUpValue) {
      if (ch < '0' || ch > '9') {
        return true;
      }
    }
    return false;
  }

  rangeReturn(min: any, max : any) {
    const range = [min, max];
    this.choosedReturn.emit(range);
  }
}



