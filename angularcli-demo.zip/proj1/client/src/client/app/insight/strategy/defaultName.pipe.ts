
import { Pipe, PipeTransform } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Pipe({name: 'defaultName'})
export class DefaultNamePipe implements PipeTransform {

  constructor(private translate: TranslateService) {

  }

  transform(name: string): string {

      let showname = name;

      if ('cpuOccup' === showname) {
        showname = this.translate.instant('insight.Policy.CPUUsed');
      }
      if ('memOccup' === showname) {
        showname = this.translate.instant('insight.Policy.MemoryUsed');
      }
      if ('diskSpaceOccup' === showname) {
        showname = this.translate.instant('insight.Policy.DiskspaceUsed');
      }
      if ('avgNetworkIOUsedRate' === showname) {
        showname = this.translate.instant('insight.Policy.AverageNetworkIOUsedRate');
      }
      if ('avgDataStorageIORWRate' === showname) {
        showname = this.translate.instant('insight.Policy.AverageDataStorageIOReadorWriteRate');
      }
      if ('peakStress' === showname) {
        showname = this.translate.instant('insight.Policy.PeakValueUsingStress');
      }
      if ('peakOnly' === showname) {
        showname = this.translate.instant('insight.Policy.PeakValue');
      }
      if ('average' === showname) {
        showname = this.translate.instant('insight.Policy.AverageValue');
      }
      if ('networkIncomingRate' === showname) {
        showname = this.translate.instant('insight.Policy.NetworkIncomingRate');
      }
      if ('networkOutgoingRate' === showname) {
        showname = this.translate.instant('insight.Policy.NetworkOutgoingRate');
      }
      if ('networkBidirectRate' === showname) {
        showname = this.translate.instant('insight.Policy.NetworkBidirectionalTransmittedRate');
      }
      return showname;

  }
}
