import {CanDeactivate, ActivatedRouteSnapshot, RouterStateSnapshot} from '@angular/router';
import {Observable} from 'rxjs';
import {StrategyDetailComponent} from './detail/strategy-detail.component';

export class DetailDeactivateGuard implements CanDeactivate<StrategyDetailComponent> {
  canDeactivate(
    strategyDetail: StrategyDetailComponent,
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean>|boolean {

    if (strategyDetail.hostWorkLoad.changed === true || strategyDetail.vmWorkLoad.changed === true ||
      strategyDetail.remainCapacity.changed === true || strategyDetail.reclaimCapacity.changed === true ||
      strategyDetail.stress.changed === true || strategyDetail.obsvWnd.changed === true) {
      return confirm('当前页面还没保存,确定离开吗?');
    }
    return true;

  }
}
