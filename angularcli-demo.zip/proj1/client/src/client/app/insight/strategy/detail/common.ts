/**
 * Created by 6092002302 on 2017/6/13.
 */
import { Injectable } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
declare var $: any;
@Injectable()
export class Common {

  constructor(private translate : TranslateService) {

  }
  checkSelect(checks: any) {
    let len = 0;
    for (const single of checks) {
      if (single.checked === true) {
        len++;
      }
    }
    return len;
  }

  checkInputValue(inputValue: any, minThreshold: any, maxThreshold: any) {

    if (inputValue === '') {
      return true;
    }

    for (const ch of inputValue) {
      if (ch < '0' || ch > '9') {

        return true;
      }
    }

    if (minThreshold !== '' && maxThreshold !== '') {
      if (maxThreshold < Number(inputValue) || Number(inputValue) < minThreshold) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }
}



