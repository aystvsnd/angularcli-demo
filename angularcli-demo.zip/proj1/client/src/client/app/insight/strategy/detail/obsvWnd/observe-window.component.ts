/**
 * Created by 6092002302 on 2017/6/14.
 */
import {Component, OnChanges, SimpleChanges, Input, } from '@angular/core';
import {StrategyService} from '../../strategy.service';
import {ObserveWindow, Strategy} from '../strategy-detail.interface';
import {ObsvWnd} from '../strategy-detail.function';
import {TranslateService} from '@ngx-translate/core';

declare var $: any;

@Component({
  moduleId: module.id,
  selector: 'observe-window',
  templateUrl: 'observe-window.component.html',
  styleUrls: ['../../../css/common.css', '../strategy-detail.component.less'],
})

export class ObserveWindowComponent implements OnChanges, ObsvWnd {
  @Input() status: string;
  @Input() obsvWnd: ObserveWindow;

  @Input() changer: string;
  @Input() srcStrategyDetail: Strategy;
  @Input() objectType: string;

  public buttonLabel: any = {
    cancel: this.translate.instant('insight.Policy.Cancel'),
    edit: this.translate.instant('insight.Policy.Edit'),
    save: this.translate.instant('insight.Policy.Save')
  };

  constructor(private service: StrategyService, private translate: TranslateService) {

  }

  ngOnChanges(sChanges: SimpleChanges) {
    if (this.obsvWnd && this.changer && this.objectType && this.status) {
      this.config();
    }
  }

  public config() {
    this.obsvWnd.status = this.status;

    this.obsvWnd.changed = false;
    this.obsvWnd.inputError = false;

    this.obsvWnd.srcObserverRange = this.obsvWnd.dayRange;
    this.obsvWnd.editedObserverRange = this.obsvWnd.srcObserverRange;

    this.obsvWnd.srcCheckChosen = this.obsvWnd.days.length;
    this.obsvWnd.editedCheckChosen = this.obsvWnd.srcCheckChosen;

    this.obsvWnd.srcObserverTime = this.getObserverTime(this.obsvWnd);
    this.obsvWnd.editedObserverTime = JSON.parse(JSON.stringify(this.obsvWnd.srcObserverTime));
  }

  public statusChange() {
    this.obsvWnd.status = 'edit';
  }

  public editCancel() {
    this.obsvWnd.status = 'detail';
    this.obsvWnd.changed = false;
    this.obsvWnd.inputError = false;

    this.obsvWnd.editedCheckChosen = this.obsvWnd.srcCheckChosen;
    this.obsvWnd.editedObserverRange = this.obsvWnd.srcObserverRange;

    this.obsvWnd.showDataRangeError = false;

    this.obsvWnd.editedObserverTime = JSON.parse(JSON.stringify(this.obsvWnd.srcObserverTime));
  }

  public preserve() {
    this.obsvWnd.status = 'detail';
    this.obsvWnd.srcObserverRange = this.obsvWnd.editedObserverRange;

    this.obsvWnd.changed = false;
    this.obsvWnd.srcCheckChosen = this.obsvWnd.editedCheckChosen;
    this.obsvWnd.editedObserverTime.times = this.combine(this.obsvWnd.editedObserverTime.times);
    /* $.extend(true, this.obsvWnd.currentObserverTime, this.obsvWnd.observerTime);*/
    this.obsvWnd.srcObserverTime = JSON.parse(JSON.stringify(this.obsvWnd.editedObserverTime));
    this.getChosenDays();
    this.objectType === 'host' ?
      this.updateObsvWnd(this.obsvWnd, this.srcStrategyDetail.hostCPI.obsvWnd) :
      this.updateObsvWnd(this.obsvWnd, this.srcStrategyDetail.vmCPI.obsvWnd);
    this.srcStrategyDetail.changer = this.changer;
    this.service.updateStrategy(this.srcStrategyDetail, this.srcStrategyDetail.name);
  }

  public checkChanged() {
    this.obsvWnd.changed = true;
  }

  public getCheckLen() {
    const len = this.checkSelect(this.obsvWnd.editedObserverTime.srcDaysChosen);
    this.obsvWnd.editedCheckChosen = len;
    console.log(len);

  }

  public checkChosenTime(srcTime : any, chosenTime : any, name : any) {
    let maxEndTime = '00:00';
    let minBeginTime = '24:00';

    this.obsvWnd.changed = true;
    if (name === 'startTime') {

      srcTime.begin = chosenTime;

      if (srcTime.begin >= srcTime.end) {

        srcTime.showTimeError = true;
      } else {

        srcTime.showTimeError = false;
      }
      //判断end时间是否正确
      for (const time of this.obsvWnd.editedObserverTime.times) {

        if (_.isEqual(time, srcTime)) {

          continue;
        }
        if (Number(srcTime.end.split(':')[0]) >  Number(time.begin.split(':')[0]) &&
          Number(srcTime.end.split(':')[0]) <= Number(time.end.split(':')[0])) {

          srcTime.showTimeError = true;
          break;
        }
      }

      for (const time of this.obsvWnd.editedObserverTime.times) {

        if (time.end < srcTime.end) {

          if (time.end > 　maxEndTime) {

            maxEndTime = time.end;
          }
        }
      }
      //begin time 大于其他小于当前endtime的最大end时间
      if (srcTime.begin < maxEndTime) {

        srcTime.showTimeError = true;
      }
    } else if (name === 'endTime') {

      srcTime.end = chosenTime;

      if (srcTime.begin >= srcTime.end) {

        srcTime.showTimeError = true;
      } else {

        srcTime.showTimeError = false;
      }
      //先判断begin时间是否正确
      for (const time of this.obsvWnd.editedObserverTime.times) {

        if (_.isEqual(time, srcTime)) {

          continue;
        }
        if (Number(srcTime.begin.split(':')[0]) >=  Number(time.begin.split(':')[0]) &&
          Number(srcTime.begin.split(':')[0]) < Number(time.end.split(':')[0])) {

          srcTime.showTimeError = true;
          break;
        }
      }

      for (const time of this.obsvWnd.editedObserverTime.times) {

        if (time.begin > srcTime.begin) {

          if (time.begin < minBeginTime) {

            minBeginTime = time.begin;
          }
        }
      }
      //endtime小于其他大于begintime的最小begintime
      if (srcTime.end > minBeginTime) {

        srcTime.showTimeError = true;
      }
    }
    /*this.isSave = this.isAllowSave();*/
    this.obsvWnd.inputError = this.isInputError();

    //判断是否允许添加时间
    if (srcTime.showTimeError === true) {
      this.obsvWnd.editedObserverTime.isAdd = false;
    } else {
      this.obsvWnd.editedObserverTime.isAdd = this.isAllowAdd(this.obsvWnd.editedObserverTime.times);
    }
  }

  public addTime() {
    this.obsvWnd.changed = true;

    const beginTimes = ['00:00', '01:00', '02:00', '03:00', '04:00', '05:00', '06:00',
      '07:00', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00',
      '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00'];
    const time = {begin: '', end: ''};
    for (const beginTime of beginTimes) {

      let isAllow = true;
      for (const chosenTime of this.obsvWnd.editedObserverTime.times) {

        if (Number(beginTime.split(':')[0]) >=  Number(chosenTime.begin.split(':')[0]) &&
          Number(beginTime.split(':')[0]) < Number(chosenTime.end.split(':')[0])) {

          isAllow = false;
          break;
        }
      }
      if (isAllow === true) {
        time.begin = beginTime;

        time.end = Number(time.begin.split(':')[0]) + 1 + ':00';
        if (time.end.split(':')[0].length < 2) {
          time.end = '0' + 　time.end.split(':')[0] + ':00';
        }
        break;
      }
    }
    this.obsvWnd.editedObserverTime.times.push(time);
    this.obsvWnd.editedObserverTime.isAdd = this.isAllowAdd(this.obsvWnd.editedObserverTime.times);
  }

  public delete(index: number) {
    this.obsvWnd.changed = true;

    this.obsvWnd.editedObserverTime.times.splice(index, 1);

    const timeErrorList = [];
    for (const time of this.obsvWnd.editedObserverTime.times) {

      if (time.showTimeError === true) {
        timeErrorList.push(time);
      }
    }
    for (const errorTime of timeErrorList) {
      let isError = false;

      if (Number(errorTime.end.split(':')[0]) < Number(errorTime.begin.split(':')[0])) {
        errorTime.showTimeError = true;
        break;
      }

      for (const time of this.obsvWnd.editedObserverTime.times) {
        //
        if (errorTime.begin === time.begin && errorTime.end === time.end) {
          continue;
        }
        //删除时间后判断end时间是否正确
        if (Number(errorTime.end.split(':')[0]) >  Number(time.begin.split(':')[0]) &&
          Number(errorTime.end.split(':')[0]) <= Number(time.end.split(':')[0])) {
          isError = true;
          break;
        }
        //删除时间后判断start时间是否正确
        if (Number(errorTime.begin.split(':')[0]) >=  Number(time.begin.split(':')[0]) &&
          Number(errorTime.begin.split(':')[0]) < Number(time.end.split(':')[0])) {
          isError = true;
          break;
        }
      }
      if (isError === false) {
        errorTime.showTimeError = false;
      }
    }

    this.obsvWnd.editedObserverTime.isAdd = !this.isExistTimeError(this.obsvWnd.editedObserverTime.times) &&
      this.isAllowAdd(this.obsvWnd.editedObserverTime.times);
    /* this.isSave = this.isAllowSave();*/
    this.obsvWnd.inputError = this.isInputError();

  }

  public changed(checkName? : any, checkValue? : any) {
    this.obsvWnd.changed = true;

    if (checkName === 'all') {

      this.obsvWnd.editedCheckChosen = 7;
    } else if (checkName === 'special') {

      this.obsvWnd.editedCheckChosen = this.getDaysChosen(this.obsvWnd.editedObserverTime.srcDaysChosen);
    } else if (checkName === 'dataRange') {

      /*this.inputCheck(checkName, checkValue);*/
      this.obsvWnd.showDataRangeError = this.isShowError(checkValue, 1, 180);
      this.obsvWnd.inputError = this.isInputError();
    }
  }

  private isShowError(inputValue : any, minThreshold : any, maxThreshold : any) {

    if (inputValue === '') {
      return true;
    }

    for (const ch of inputValue) {
      if (ch < '0' || ch > '9') {

        return true;
      }
    }

    if (minThreshold !== '' && maxThreshold !== '') {
      if (maxThreshold < Number(inputValue) || Number(inputValue) < minThreshold) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }

  }

  private getChosenDays() {
    this.obsvWnd.days = [];
    if (this.obsvWnd.srcObserverTime.name === 'all') {
      this.obsvWnd.days = ['Sunday',
        'Monday',
        'Tuesday',
        'Wednesday',
        'Thursday',
        'Friday',
        'Saturday'];
      this.obsvWnd.srcObserverTime.times = [{begin: '00:00', end: '24:00'}];
    } else {
      for (const day of this.obsvWnd.srcObserverTime.srcDaysChosen) {
        if (day.value === true) {
          this.obsvWnd.days.push(day.name);
        }
      }
    }
  }

  private updateObsvWnd(srcObsvWnd, saveObsvWnd) {

    saveObsvWnd.days = this.obsvWnd.days;
    saveObsvWnd.dayRange = Number(srcObsvWnd.srcObserverRange);

    const times = JSON.parse(JSON.stringify(srcObsvWnd.srcObserverTime.times));
    /*this.translateUTCTime(times);
    this.srcStrategyDetail.vmCPI.obsvWnd.times = times;*/
    saveObsvWnd.times = this.translateUTCTime(times);
  }

  private isExistTimeError(times : any) {
    for (const time of times) {
      if (time.showTimeError === true) {
        return true;
      }
    }
    return false;
  }

  private isInputError() {
    let timeError = false;
    for (const time of this.obsvWnd.editedObserverTime.times) {
      if (time.showTimeError === true) {
        timeError = true;
      }
    }
    if (this.obsvWnd.showDataRangeError !== true && timeError !== true) {
      return false;
    } else {
      return true;
    }
  }

  private isAllowAdd(times : any) {
    let timeTotal = 0;
    //判断时间总和
    for (const time of times) {

      timeTotal = Number(time.end.split(':')[0]) - Number(time.begin.split(':')[0])  + timeTotal;
    }

    if (timeTotal >= 24) {

      return false;
    } else {

      return true;
    }
  }

  private getObserverTime(obsvWnd : ObserveWindow) {

    const observeTime = {name : '', srcDaysChosen: [], days: [], times: [], isAdd: true};

    if (obsvWnd.days.length === 7 && obsvWnd.times[0].begin === '00:00'
      && obsvWnd.times[0].end === '24:00') {
      observeTime.name = 'all';
    } else {
      observeTime.name = 'special';
    }
    this.initWeek(observeTime, obsvWnd.days);

    /*this.translateLocalTime(obsvWnd.times);
    observeTime.times = obsvWnd.times;*/
    observeTime.times = this.translateLocalTime(obsvWnd.times);
    observeTime.days = obsvWnd.days;
    observeTime.isAdd = this.isAllowAdd(observeTime.times);
    return observeTime;
  }

  private initWeek(observeTime: any, days) {
    observeTime.srcDaysChosen = [];
    observeTime.srcDaysChosen.push({name: 'Sunday', value: this.isExit(days, 'Sunday')});
    observeTime.srcDaysChosen.push({name: 'Monday', value: this.isExit(days, 'Monday')});
    observeTime.srcDaysChosen.push({name: 'Tuesday', value: this.isExit(days, 'Tuesday')});
    observeTime.srcDaysChosen.push({name: 'Wednesday', value: this.isExit(days, 'Wednesday')});
    observeTime.srcDaysChosen.push({name: 'Thursday', value: this.isExit(days, 'Thursday')});
    observeTime.srcDaysChosen.push({name: 'Friday', value: this.isExit(days, 'Friday')});
    observeTime.srcDaysChosen.push({name: 'Saturday', value: this.isExit(days, 'Saturday')});
  }

  private isExit(days : any, name : any) {
    for (const day of days) {
      if (day === name) {
        return true;
      }
    }
    return false;
  }

  private checkSelect(checks: any) {

    let len = 0;
    for (const single of checks) {

      if (single.value === true) {
        len++;
      }
    }
    return len;
  }

  private getDaysChosen(days : any) {
    let len = 0;
    days.forEach((day) => {
      if (day.value === true) {
        len++;
      }
    });
    return len;
  }

  private translateLocalTime(srcTimes : any) {
    const currentTime = new Date();
    const timeOffset = currentTime.getTimezoneOffset();
    const translateTime: {begin: string, end: string}[] = [];

    if (srcTimes.length === 1 && srcTimes[0].begin === '00:00' && srcTimes[0].end === '24:00') {
      translateTime.push({begin: '00:00', end: '24:00'});
      return translateTime;
    }
    srcTimes.forEach((time) => {
      let localBeginTime = Number(time.begin.split(':')[0]) - timeOffset / 60;
      let localEndTime = Number(time.end.split(':')[0]) - timeOffset / 60;

      localBeginTime = localBeginTime >= 24 ? localBeginTime - 24 : localBeginTime;
      localEndTime = localEndTime > 24 ? localEndTime - 24 : localEndTime;

      localBeginTime = localBeginTime < 0 ?  localBeginTime + 24 : localBeginTime;
      localEndTime = localEndTime <= 0 ? localEndTime + 24 : localEndTime;

      time.begin = localBeginTime < 10 ? '0' + localBeginTime + ':00' : localBeginTime + ':00';
      time.end = localEndTime < 10 ? '0' + localEndTime + ':00' : localEndTime + ':00';
      //UTC时间转为本地时间跨天时，将时间段分为两段
      if (Number(time.begin.split(':')[0]) > Number(time.end.split(':')[0])) {
        translateTime.push({begin: '00:00', end: time.end});

        time.end = '24:00';
      }
      translateTime.push({begin: time.begin, end: time.end});
    });
    return this.combine(translateTime);
  }

  private translateUTCTime(srcTimes : any) {
    const currentTime = new Date();
    const timeOffset = currentTime.getTimezoneOffset();
    const translateTime: {begin: string, end: string}[] = [];

    if (srcTimes.length === 1 && srcTimes[0].begin === '00:00' && srcTimes[0].end === '24:00') {
      translateTime.push({begin: '00:00', end: '24:00'});
      return translateTime;
    }
    srcTimes.forEach((time) => {
      let UTCBeginTime = Number(time.begin.split(':')[0]) + (timeOffset / 60);
      let UTCEndTime = Number(time.end.split(':')[0]) + (timeOffset / 60);

      UTCBeginTime = UTCBeginTime < 0 ?  UTCBeginTime + 24 : UTCBeginTime;
      UTCEndTime = UTCEndTime <= 0 ? UTCEndTime + 24 : UTCEndTime;

      UTCBeginTime = UTCBeginTime >= 24 ? UTCBeginTime - 24 : UTCBeginTime;
      UTCEndTime = UTCEndTime > 24 ? UTCEndTime - 24 : UTCEndTime;

      time.begin = UTCBeginTime < 10 ? '0' + UTCBeginTime + ':00' : UTCBeginTime + ':00';
      time.end = UTCEndTime < 10 ? '0' + UTCEndTime + ':00' : UTCEndTime + ':00';

      //UTC时间转为本地时间跨天时，将时间段分为两段
      if (Number(time.begin.split(':')[0]) > Number(time.end.split(':')[0])) {
        translateTime.push({begin: '00:00', end: time.end});

        time.end = '24:00';
      }
      translateTime.push({begin: time.begin, end: time.end});
    });
    return translateTime;
  }

  private combine(translateTime: any) {
    translateTime.sort((time1, time2) => {
      return  Number(time1.begin.split(':')[0]) - Number(time2.begin.split(':')[0]);
    });

    const combineTimes : {begin: string, end: string}[] = [];
    let tempTime = translateTime[0];
    //bindTimes.push(translateTime[0]);

    for (let i = 1; i < translateTime.length; i++) {
      if (tempTime.end === translateTime[i].begin) {
        tempTime.end = translateTime[i].end;
      } else {
        combineTimes.push(tempTime);
        tempTime = translateTime[i];
      }
    }
    combineTimes.push(tempTime);
    return combineTimes;
  }
}
