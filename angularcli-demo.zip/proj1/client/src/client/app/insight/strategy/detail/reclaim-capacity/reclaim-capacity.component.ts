/**
 * Created by 6092002302 on 2017/6/13.
 */

import {Component, OnChanges, SimpleChanges, Input, } from '@angular/core';
import {StrategyService} from '../../strategy.service';
import {ReclaimCapacity, Strategy} from '../strategy-detail.interface';
import {Reclaim} from '../strategy-detail.function';
import {TranslateService} from '@ngx-translate/core';
import {Common} from '../common';
declare var $: any;
//noinspection TypeScriptUnresolvedVariable
@Component({
  moduleId: module.id,
  selector: 'reclaim-capacity',
  templateUrl: 'reclaim-capacity.component.html',
  styleUrls:['../../../css/common.css','../strategy-detail.component.less', '../../../css/tooltip.less'],
})

export class ReclaimCapacityComponent implements OnChanges, Reclaim {
  @Input() status: string;
  @Input() reclaimCapacity: ReclaimCapacity;

  @Input() changer: string;
  @Input() srcStrategyDetail: Strategy;
  @Input() objectType: string;

  public buttonLabel: any = {
    cancel: this.translate.instant('insight.Policy.Cancel'),
    edit: this.translate.instant('insight.Policy.Edit'),
    save: this.translate.instant('insight.Policy.Save')
  };

  constructor(private service: StrategyService, private translate: TranslateService, public common: Common) {

  }

  ngOnChanges(sChanges: SimpleChanges) {
    if (this.reclaimCapacity && this.changer && this.objectType && this.status) {
      this.config();
    }
  }
  public config() {
    this.reclaimCapacity.status = this.status;

    this.reclaimCapacity.changed = false;
    this.reclaimCapacity.inputError = false;
    this.reclaimCapacity.reclaimError = {};

    this.reclaimCapacity.srcThreshold = [this.reclaimCapacity.threshold.lower, this.reclaimCapacity.threshold.upper];
    this.reclaimCapacity.editedThreshold = this.reclaimCapacity.srcThreshold;

    this.reclaimCapacity.srcOversize = this.reclaimCapacity.oversized.threshold;
    this.reclaimCapacity.editedOversize = this.reclaimCapacity.srcOversize;

    this.reclaimCapacity.srcIdlePeriod = this.reclaimCapacity.idle.period;
    this.reclaimCapacity.editedIdlePeriod = this.reclaimCapacity.srcIdlePeriod;

    this.reclaimCapacity.srcPowerOffPeriod = this.reclaimCapacity.poweroff.period;
    this.reclaimCapacity.editedPowerOffPeriod = this.reclaimCapacity.srcPowerOffPeriod;

    this.reclaimCapacity.srcCheckChosen = this.reclaimCapacity.idle.checks.length;
    this.reclaimCapacity.editedCheckChosen = this.reclaimCapacity.srcCheckChosen;

    this.reclaimCapacity.srcIdleChecks = this.reclaimCapacity.idle.checks;
    this.reclaimCapacity.editedIdleChecks = JSON.parse(JSON.stringify(this.reclaimCapacity.srcIdleChecks));
  }

  public statusChange() {
    this.reclaimCapacity.status = 'edit';
  }

  public editCancel() {
    this.reclaimCapacity.status = 'detail';
    this.reclaimCapacity.editedThreshold = this.reclaimCapacity.srcThreshold;

    this.reclaimCapacity.changed = false;
    this.reclaimCapacity.inputError = false;

    this.reclaimCapacity.editedCheckChosen = this.reclaimCapacity.srcCheckChosen;

    this.reclaimCapacity.editedOversize = this.reclaimCapacity.srcOversize;
    this.reclaimCapacity.editedIdlePeriod = this.reclaimCapacity.srcIdlePeriod;
    this.reclaimCapacity.editedPowerOffPeriod = this.reclaimCapacity.srcPowerOffPeriod;


    this.reclaimCapacity.reclaimError.showReclaimError = false;
    this.reclaimCapacity.reclaimError.showCpuOccupError = false;
    this.reclaimCapacity.reclaimError.showNetIOUsageRateError = false;
    this.reclaimCapacity.reclaimError.showDiskRWRateError = false;
    this.reclaimCapacity.reclaimError.showIdleError = false;
    this.reclaimCapacity.reclaimError.showPowerOffError = false;

    this.reclaimCapacity.editedIdleChecks = JSON.parse(JSON.stringify(this.reclaimCapacity.srcIdleChecks));
    //this.reclaimCapacity.editedIdleValue = JSON.parse(JSON.stringify(this.reclaimCapacity.srcIdleValue));
  }

  public preserve() {

    this.reclaimCapacity.status = 'detail';
    this.reclaimCapacity.srcThreshold = this.reclaimCapacity.editedThreshold;

    this.reclaimCapacity.srcOversize = this.reclaimCapacity.editedOversize;
    this.reclaimCapacity.srcIdlePeriod = this.reclaimCapacity.editedIdlePeriod;
    this.reclaimCapacity.srcPowerOffPeriod = this.reclaimCapacity.editedPowerOffPeriod;

    this.reclaimCapacity.changed = false;
    this.reclaimCapacity.srcCheckChosen = this.reclaimCapacity.editedCheckChosen;

    this.reclaimCapacity.srcIdleChecks = JSON.parse(JSON.stringify(this.reclaimCapacity.editedIdleChecks));
    //this.reclaimCapacity.srcIdleValue = JSON.parse(JSON.stringify(this.reclaimCapacity.editedIdleValue));

    this.objectType === 'host' ?
      this.updatereclaimCapa(this.reclaimCapacity, this.srcStrategyDetail.hostCPI.reclaimCapacity) :
      this.updatereclaimCapa(this.reclaimCapacity, this.srcStrategyDetail.vmCPI.reclaimCapacity);
    this.srcStrategyDetail.changer = this.changer;

    this.service.updateStrategy(this.srcStrategyDetail, this.srcStrategyDetail.name);
  }

  public getChosenRange(range : number[] | string) {
    if (range === 'error') {
      this.reclaimCapacity.sliderError = true;
    } else {
      this.reclaimCapacity.sliderError = false;
      this.reclaimCapacity.changed = true;
      this.reclaimCapacity.editedThreshold = range;
    }
    this.reclaimCapacity.inputError = this.isInputError();
  }

  public checkChanged(checkName ?: any, checkValue ?: any) {
    this.reclaimCapacity.changed = true;
    this.changeInputStatus(checkName, checkValue);

    this.reclaimCapacity.inputError = this.isInputError();
  }

  public getCheckLen() {
    const len = this.checkSelect(this.reclaimCapacity.editedIdleChecks);
    this.reclaimCapacity.editedCheckChosen = len;
  }

  public inputChanged(checkName : any, checkValue : any) {
    this.reclaimCapacity.changed = true;
    this.inputCheck(checkName, checkValue);
    this.reclaimCapacity.inputError = this.isInputError();
  }

  private changeInputStatus(checkName ?: any, checkValue ?: any) {
    if (checkValue === true) {

      if (checkName === 'cpuOccup') {

        this.reclaimCapacity.reclaimError.showCpuOccupError = false;
      } else if (checkName === 'avgNetworkIOUsedRate') {

        this.reclaimCapacity.reclaimError.showNetIOUsageRateError = false;
      } else if (checkName === 'avgDataStorageIORWRate') {

        this.reclaimCapacity.reclaimError.showDiskRWRateError = false;
      }
    } else {

      for (const input of this.reclaimCapacity.editedIdleChecks) {
        if (checkName === input.name) {

          if (checkName === 'cpuOccup') {
            if (String(input.value) === '') {
              input.value = 5;                   //默认值
            } else {
              this.inputCheck(checkName, input.value);
            }
          } else if (checkName === 'avgNetworkIOUsedRate') {
            if (String(input.value) === '') {
              input.value = 1;                   //默认值
            } else {
              this.inputCheck(checkName, input.value);
            }
          } else if (checkName === 'avgDataStorageIORWRate') {
            if (String(input.value) === '') {
              input.value = 1;                   //默认值
            } else {
              this.inputCheck(checkName, input.value);
            }
          }
        }
      }
    }
  }

  private inputCheck(checkName: string, inputValue: number) {
    if (checkName === 'reclaim') {

      this.reclaimCapacity.reclaimError.showReclaimError = this.isShowError(inputValue, 10, 100);
    } else if (checkName === 'cpuOccup') {

      this.reclaimCapacity.reclaimError.showCpuOccupError = this.isShowError(inputValue, 1, 50);
    } else if (checkName === 'avgNetworkIOUsedRate') {

      this.reclaimCapacity.reclaimError.showNetIOUsageRateError = this.isShowError(inputValue, '', '');
    } else if (checkName === 'avgDataStorageIORWRate') {

      this.reclaimCapacity.reclaimError.showDiskRWRateError = this.isShowError(inputValue, '', '');
    } else if (checkName === 'idle') {

      this.reclaimCapacity.reclaimError.showIdleError = this.isShowError(inputValue, 50, 100);
    } else if (checkName === 'powerOff') {

      this.reclaimCapacity.reclaimError.showPowerOffError = this.isShowError(inputValue, 50, 100);
    }
  }

  private isShowError(inputValue : any, minThreshold : any, maxThreshold : any) {

    if (inputValue === '') {
      return true;
    }

    for (const ch of inputValue) {
      if (ch < '0' || ch > '9') {

        return true;
      }
    }

    if (minThreshold !== '' && maxThreshold !== '') {
      if (maxThreshold < Number(inputValue) || Number(inputValue) < minThreshold) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }

  }

  private checkSelect(checks: any) {

    let len = 0;
    for (const single of checks) {

      if (single.checked === true) {
        len++;
      }
    }
    return len;
  }

  private updatereclaimCapa(srcReclaim, saveReclaim) {

    let reclaimCapaChecks = JSON.parse(JSON.stringify(srcReclaim.editedIdleChecks));

    reclaimCapaChecks.forEach((check)=> {
      check.value = Number(check.value);
    });

    saveReclaim.idle.checks = reclaimCapaChecks;
    saveReclaim.idle.period = parseInt(srcReclaim.srcIdlePeriod);
    saveReclaim.threshold = {
      'lower': srcReclaim.srcThreshold[0],
      'upper': srcReclaim.srcThreshold[1]
    };

    saveReclaim.oversized.threshold = parseInt(srcReclaim.srcOversize);
    saveReclaim.poweroff.period = parseInt(srcReclaim.srcPowerOffPeriod);
  }

  private isInputError() {
    if (this.reclaimCapacity.reclaimError.showReclaimError !== true &&
      this.reclaimCapacity.reclaimError.showCpuOccupError !== true &&
      this.reclaimCapacity.reclaimError.showNetIOUsageRateError !== true &&
      this.reclaimCapacity.reclaimError.showDiskRWRateError !== true &&
      this.reclaimCapacity.reclaimError.showIdleError !== true &&
      this.reclaimCapacity.reclaimError.showPowerOffError !== true &&
      this.reclaimCapacity.sliderError !== true) {
      return false;
    } else {
      return true;
    }
  }
}
