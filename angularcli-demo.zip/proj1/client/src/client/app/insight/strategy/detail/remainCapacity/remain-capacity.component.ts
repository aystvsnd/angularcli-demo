/**
 * Created by 6092002302 on 2017/6/13.
 */
import {Component, OnChanges, SimpleChanges, Input, } from '@angular/core';
import {StrategyService} from '../../strategy.service';
import {Strategy, RemainCapacity} from '../strategy-detail.interface';
import {Remain} from '../strategy-detail.function';
import {TranslateService} from '@ngx-translate/core';
import {Common} from '../common';

@Component({
  moduleId: module.id,
  selector: 'remain-capacity',
  templateUrl: 'remain-capacity.component.html',
  styleUrls:['../strategy-detail.component.less', '../../../css/tooltip.less'],
})

export class RemainCapacityComponent implements OnChanges, Remain {
  @Input() status: string;
  @Input() remainCapacity: RemainCapacity;

  @Input() changer: string;
  @Input() srcStrategyDetail: Strategy;
  @Input() objectType: string;

  public buttonLabel: any = {
    cancel: this.translate.instant('insight.Policy.Cancel'),
    edit: this.translate.instant('insight.Policy.Edit'),
    save: this.translate.instant('insight.Policy.Save')
  };

  constructor(private service: StrategyService, private translate: TranslateService, public common: Common) {

  }

  ngOnChanges(sChanges: SimpleChanges) {
    if (this.remainCapacity && this.changer && this.objectType && this.status) {
      this.config();
    }
  }

  public config() {
    this.remainCapacity.status = this.status;

    this.remainCapacity.changed = false;
    this.remainCapacity.inputError = false;

    this.remainCapacity.srcCheckChosen = this.remainCapacity.checks.length;
    this.remainCapacity.editedCheckChosen = this.remainCapacity.srcCheckChosen;

    this.remainCapacity.srcChecks = this.remainCapacity.checks;
    this.remainCapacity.editedChecks = JSON.parse(JSON.stringify(this.remainCapacity.srcChecks));

    this.remainCapacity.srcPeakStress = false;
    if(this.remainCapacity.algo.name === 'peakStress') {
      this.remainCapacity.srcPeakStress = true;
      this.remainCapacity.algo.name = 'peak';
    } else if(this.remainCapacity.algo.name === 'peakOnly'){
      this.remainCapacity.algo.name = 'peak';
      this.remainCapacity.srcPeakStress = false;
    }
    this.remainCapacity.srcAlgo = this.remainCapacity.algo.name;
    this.remainCapacity.editedAlgo = this.remainCapacity.srcAlgo;
    this.remainCapacity.editedPeakStress = this.remainCapacity.srcPeakStress;

    this.remainCapacity.srcThreshold = [this.remainCapacity.threshold.lower, this.remainCapacity.threshold.upper];
    this.remainCapacity.editedThreshold = this.remainCapacity.srcThreshold;
  }

  public statusChange() {
    this.remainCapacity.status = 'edit';
  }

  public editCancel() {
    this.remainCapacity.status = 'detail';
    this.remainCapacity.editedThreshold = this.remainCapacity.srcThreshold;

    this.remainCapacity.changed = false;
    this.remainCapacity.inputError = false;

    this.remainCapacity.editedCheckChosen = this.remainCapacity.srcCheckChosen;
    this.remainCapacity.editedAlgo = this.remainCapacity.srcAlgo;
    this.remainCapacity.editedPeakStress = this.remainCapacity.srcPeakStress;

    this.remainCapacity.editedChecks = JSON.parse(JSON.stringify(this.remainCapacity.srcChecks));
  }

  public preserve() {
    this.remainCapacity.status = 'detail';
    this.remainCapacity.srcThreshold = this.remainCapacity.editedThreshold;

    this.remainCapacity.srcAlgo = this.remainCapacity.editedAlgo;
    this.remainCapacity.srcPeakStress = this.remainCapacity.editedPeakStress;

    this.remainCapacity.changed = false;
    this.remainCapacity.srcCheckChosen = this.remainCapacity.editedCheckChosen;
    this.remainCapacity.srcChecks = JSON.parse(JSON.stringify(this.remainCapacity.editedChecks));

    this.objectType === 'host' ?
      this.updateRemainCapa(this.remainCapacity, this.srcStrategyDetail.hostCPI.remainCapacity) :
      this.updateRemainCapa(this.remainCapacity, this.srcStrategyDetail.vmCPI.remainCapacity);

    this.srcStrategyDetail.changer = this.changer;
    this.service.updateStrategy(this.srcStrategyDetail, this.srcStrategyDetail.name);
  }

  public getChosenRange(range: number[] | string) {
    if (range === 'error') {
      this.remainCapacity.sliderError = true;
    } else {
      this.remainCapacity.sliderError = false;
      this.remainCapacity.changed = true;
      this.remainCapacity.editedThreshold = range;
    }
    this.remainCapacity.inputError = this.isInputError();
  }

  public checkChanged() {
    this.remainCapacity.changed = true;
  }

  public getCheckLen() {
    const len = this.checkSelect(this.remainCapacity.editedChecks);
    this.remainCapacity.editedCheckChosen = len;
  }

  public changed() {
    this.remainCapacity.changed = true;
  }

  private isInputError() {
    if (this.remainCapacity.sliderError !== true) {
      return false;
    } else {
      return true;
    }
  }

  private checkSelect(checks: any) {

    let len = 0;
    for (const single of checks) {

      if (single.checked === true) {
        len++;
      }
    }
    return len;
  }

  private updateRemainCapa(srcRemainCapacity, saveRemainCapacity) {
    let  remainCapaChecks = JSON.parse(JSON.stringify(srcRemainCapacity.srcChecks));

    saveRemainCapacity.checks = remainCapaChecks;

    saveRemainCapacity.threshold = {
      'lower': srcRemainCapacity.srcThreshold[0],
      'upper': srcRemainCapacity.srcThreshold[1]
    };
    if(srcRemainCapacity.srcAlgo === 'peak' && srcRemainCapacity.srcPeakStress === true) {
      saveRemainCapacity.algo.name = 'peakStress';
    } else if(srcRemainCapacity.srcAlgo === 'peak' && srcRemainCapacity.srcPeakStress === false){
      saveRemainCapacity.algo.name = 'peakOnly';
    } else if(srcRemainCapacity.srcAlgo === 'average') {
      saveRemainCapacity.algo.name = 'average';
    }
  }
}
