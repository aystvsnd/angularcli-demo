/**
 * Created by 6092002302 on 2017/3/21.
 */
import { Component, OnInit, } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {StrategyService} from '../strategy.service';
import {TranslateService} from '@ngx-translate/core';
import {StorageService} from '../../../storage.service';
import * as strategyDetail from './strategy-detail.interface';

declare var $: any;
@Component({
  moduleId: module.id,
  templateUrl: 'strategy-detail.component.html',
  styleUrls: [ '../../css/common.css', 'strategy-detail.component.less'],
})

export class StrategyDetailComponent implements OnInit {
  hostStrategyDetail : any;
  vmStrategyDetail   : any;

  strategyName   : string;
  strategyStatus = 'detail';

  srcChanger     : string;
  localChanger   : string;

  srcStrategyDetail : strategyDetail.Strategy;

  absoluteLinks: any;

  objectName : any = {
    host: this.translate.instant('insight.Policy.Host'),
    vm: this.translate.instant('insight.Policy.Vm')
  };

  buttonLabel : any = {
    cancel: this.translate.instant('insight.Policy.Cancel'),
    edit: this.translate.instant('insight.Policy.Edit'),
    save: this.translate.instant('insight.Policy.Save')
  };

  constructor(private service : StrategyService, private activatedRoute : ActivatedRoute,
  private translate : TranslateService, private storageService : StorageService) {

    const that = this;
    this.activatedRoute.params.subscribe(params => {
      that.strategyName = params.strategyName;
      that.strategyStatus = params.strategyStatus;

      const linkName = that.strategyName;

      this.absoluteLinks = [
        {name: this.translate.instant('insight.Policy.Policies'), url: 'main/insight/strategy/strategy-library'},
        {name: linkName, url: ''}
      ];
    });
  }

  ngOnInit() {
    this.readData();
  }

  readData() {
    const that = this;
    this.service.getStrategyDetail(this.strategyName).then((res) => {

      that.srcStrategyDetail = JSON.parse(JSON.stringify(res));

      that.srcChanger = res.changer;
      that.hostStrategyDetail = res.hostCPI;
      that.vmStrategyDetail = res.vmCPI;

      that.localChanger = that.storageService.getUserName();
    });
  }
}

