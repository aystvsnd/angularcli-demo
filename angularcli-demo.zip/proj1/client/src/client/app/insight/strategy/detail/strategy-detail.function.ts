/**
 * Created by 6092002302 on 2017/5/24.
 */
export interface SmartConfig {

  changer : string;
  /**
   *
   * init strategy detail
   */
  config ();

  /**
   *
   * back to detail
   */
  editCancel();

  /**
   *
   * change policy status
   */
  statusChange();


  /**
   * edit preserve
   * @param objectName
   */
  preserve(objectName?: string);

  /**
   * function used when checkbox or radio changed
   */
  checkChanged();

  /**
   * get checks len
   */
  getCheckLen();
}
export interface WorkLoadStrategy extends SmartConfig {
  /**
   *   get slider range chosen
   *  @param range
   */
  getChosenRange(range: number[] | string);
}

export interface Remain extends SmartConfig {
  /**
   *  get slider range chosen
   * @param range
   */
  getChosenRange(range: number[] | string);

}

export interface Reclaim extends SmartConfig {
  /**
   *
   *  get slider range chosen
   *  @param range
   */
  getChosenRange(range: number[] | string);

  /**
   * function used when input value changed
   * @param checkName, checkValue
   */
  inputChanged(checkName? : any, checkValue? : any);
}

export interface StressStrategy extends SmartConfig {
  /**
   *
   *  get slider range chosen
   *  @param range
   */
  getChosenRange(range: number[] | string);

  /**
   * function used when input value changed
   * @param checkName, checkValue
   */
  inputChanged(checkName? : any, checkValue? : any);
}

export interface ObsvWnd extends SmartConfig {
  /**
   * add special observe time
   */
  addTime();
  /**
   * delete special observe time
   * @param index
   */
  delete(index: number);
  /**
   * check time is correct
   * @param srcTime, chosenTime, name
   */
  checkChosenTime(srcTime : any, chosenTime : any, name : any);
  /**
   * function used when radio value changed
   * @param checkName, checkValue
   */
  changed(checkName? : any, checkValue? : any);
}
