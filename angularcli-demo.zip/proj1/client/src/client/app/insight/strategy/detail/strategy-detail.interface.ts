/**
 * Created by 6092002302 on 2017/5/23.
 */
interface Threshold {
  lower : number;
  upper : number;
}

interface SrcCheck {
  name: string;
  value: number;
}

interface LocalCheck {
  name: string;
  value : boolean;
}

interface Check {
  name: string;
  value: number;
  checked: boolean;

}
export interface Workload {
  threshold : Threshold;

  checks: Check[];
  status?: string;
  changed?: boolean;
  sliderError?: boolean;
  inputError?: boolean;
  srcCheckChosen?: number;
  editedCheckChosen?: number;
  srcChecks?: Check[];
  editedChecks?: Check[];
  srcThreshold?: number[];
  editedThreshold?: number[];
}

export interface RemainCapacity extends Workload {
  algo : {
    name : string;
  };
  editedAlgo? : string;
  srcAlgo?: string;
  isPeakStress?: boolean;
}

interface ReclaimError {
  showReclaimError?: boolean;
  showCpuOccupError?: boolean;
  showNetIOUsageRateError?: boolean;
  showDiskRWRateError?: boolean;
  showIdleError?: boolean;
  showPowerOffError?: boolean;
}

export interface ReclaimCapacity {
  status?: string;
  changed?: boolean;
  inputError?: boolean;
  srcThreshold?: number[];
  editedThreshold?: number[];
  srcOversize?: number;
  editedOversize?: number;
  srcIdlePeriod?: number;
  editedIdlePeriod?: number;
  srcPowerOffPeriod?: number;
  editedPowerOffPeriod?: number;
  srcCheckChosen?: number;
  editedCheckChosen?: number;
  srcIdleChecks?: Check[];
  editedIdleChecks?: Check[];
  reclaimError?: ReclaimError;
  sliderError?: boolean;
  threshold : Threshold;
  oversized: {threshold: number};
  idle: {
    period: number,
    checks: Check[],
  };
  poweroff: {
    period: number,
  };
}

export interface StressError {
  sliderError?: boolean;
  showCpuOccupError?: boolean;
  showMemOccupError?: boolean;
  inputError?: boolean;
  showNetworkInError?: boolean;
  showNetworkOutError?: boolean;
  showNetworkBiError?: boolean;
}


export interface Stress {
  threshold : Threshold;
  checks: Check[];
  status?: string;
  changed?: boolean;
  srcThreshold?: number[];
  editedThreshold?: number[];
  srcCheckChosen?: number;
  editedCheckChosen?: number;
  srcStressChecks?: Check[];
  editedStressChecks?: Check[];
  stressError?: StressError;
}

interface Time {
  begin: string;
  end: string;
  showTimeError?: boolean;
}

interface ObserveTime {
  name : string;
  srcDaysChosen: SrcCheck[];
  days: string[];
  times: Time[];
  isAdd?: boolean;
}

export interface  ObserveWindow {
  dayRange : number;
  days: string[];
  times: Time[];
  status?: string;
  changed?: boolean;
  inputError?: boolean;
  showDataRangeError?: boolean;
  srcObserverRange?: number;
  editedObserverRange?: number;
  srcCheckChosen?: number;
  editedCheckChosen?: number;
  srcObserverTime?: ObserveTime;
  editedObserverTime?: ObserveTime;
}

export interface HostCPI {
  workload : Workload;
  remainCapacity : RemainCapacity;
  reclaimCapacity : ReclaimCapacity;
  stress : Stress;
  obsvWnd : ObserveWindow;
}

export interface VmCPI {
  workload : Workload;
  remainCapacity : RemainCapacity;
  reclaimCapacity : ReclaimCapacity;
  stress : Stress;
  obsvWnd : ObserveWindow;
}

export interface Strategy {
  name : string;
  status : string;
  updated : string;
  created : string;
  changer: string;
  creator : string;
  desc : string;
  default: boolean;
  hostCPI : HostCPI;
  vmCPI : VmCPI;
}
