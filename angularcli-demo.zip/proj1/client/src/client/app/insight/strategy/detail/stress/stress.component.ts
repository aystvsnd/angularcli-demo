/**
 * Created by 6092002302 on 2017/6/14.
 */

import {Component, OnChanges, SimpleChanges, Input, } from '@angular/core';
import {StrategyService} from '../../strategy.service';
import {Stress, Strategy} from '../strategy-detail.interface';
import {StressStrategy} from '../strategy-detail.function';
import {TranslateService} from '@ngx-translate/core';
import {Common} from '../common';
declare var $: any;

@Component({
  moduleId: module.id,
  selector: 'stress-strategy',
  templateUrl: 'stress.component.html',
  styleUrls:['../../../css/common.css','../strategy-detail.component.less', '../../../css/tooltip.less'],
})

export class StressComponent implements OnChanges, StressStrategy {
  @Input() status: string;
  @Input() stress: Stress;

  @Input() changer: string;
  @Input() srcStrategyDetail: Strategy;
  @Input() objectType: string;

  public buttonLabel: any = {
    cancel: this.translate.instant('insight.Policy.Cancel'),
    edit: this.translate.instant('insight.Policy.Edit'),
    save: this.translate.instant('insight.Policy.Save')
  };

  constructor(private service: StrategyService, private translate: TranslateService, public common: Common) {

  }

  ngOnChanges(sChanges: SimpleChanges) {
    if (this.stress && this.changer && this.objectType && this.status) {
      this.config();
    }
  }

  public config() {
    this.stress.stressError = {};
    this.stress.status = this.status;

    this.stress.changed = false;
    this.stress.stressError.inputError = false;

    this.stress.srcThreshold = [this.stress.threshold.lower, this.stress.threshold.upper];
    this.stress.editedThreshold =  this.stress.srcThreshold;

    this.stress.srcCheckChosen = this.stress.checks.length;
    this.stress.editedCheckChosen = this.stress.srcCheckChosen;

    this.stress.srcStressChecks = this.stress.checks;
    this.stress.editedStressChecks = JSON.parse(JSON.stringify(this.stress.srcStressChecks));
  }

  public statusChange() {
    this.stress.status = 'edit';
  }

  public editCancel() {
    this.stress.status = 'detail';
    this.stress.editedThreshold =  this.stress.srcThreshold;

    this.stress.changed = false;
    this.stress.stressError.inputError = false;

    this.stress.editedCheckChosen = this.stress.srcCheckChosen;

    this.stress.stressError.showCpuOccupError = false;
    this.stress.stressError.showMemOccupError = false;

    this.stress.editedStressChecks = JSON.parse(JSON.stringify(this.stress.srcStressChecks));
    //this.stress.editedStressValue = JSON.parse(JSON.stringify(this.stress.srcStressValue));
  }

  public preserve() {
    this.stress.status = 'detail';
    this.stress.srcThreshold = this.stress.editedThreshold;

    this.stress.changed = false;
    this.stress.srcCheckChosen = this.stress.editedCheckChosen;

    this.stress.srcStressChecks = JSON.parse(JSON.stringify(this.stress.editedStressChecks));
    //this.stress.srcStressValue = JSON.parse(JSON.stringify(this.stress.editedStressValue));

    this.objectType === 'host' ?
      this.updateStress(this.stress, this.srcStrategyDetail.hostCPI.stress) :
      this.updateStress(this.stress, this.srcStrategyDetail.vmCPI.stress);
    this.srcStrategyDetail.changer = this.changer;
    this.service.updateStrategy(this.srcStrategyDetail, this.srcStrategyDetail.name);
  }

  public getChosenRange(range : number[] | string) {
    if (range === 'error') {
      this.stress.stressError.sliderError = true;
    } else {
      this.stress.stressError.sliderError = false;
      this.stress.changed = true;
      this.stress.editedThreshold = range;
    }
    this.stress.stressError.inputError = this.isInputError();
  }

  public checkChanged(checkName ?: string, checkValue?: boolean) {
    this.stress.changed = true;
    this.changeInputStatus(checkName, checkValue);
    this.stress.stressError.inputError = this.isInputError();
  }

  public getCheckLen() {
    const len = this.common.checkSelect(this.stress.editedStressChecks);
    this.stress.editedCheckChosen = len;
  }

  public inputChanged(checkName?: any, checkValue?: any) {
    this.stress.changed = true;
    this.inputCheck(checkName, checkValue);
    this.stress.stressError.inputError = this.isInputError();
  }

  private updateStress(srcStress, saveStress) {

    let stressChecks = JSON.parse(JSON.stringify(srcStress.editedStressChecks));
    stressChecks.forEach((check)=> {
      check.value = Number(check.value);
    });

    saveStress.checks = stressChecks;
    saveStress.threshold = {
      'lower': srcStress.srcThreshold[0],
      'upper': srcStress.srcThreshold[1]
    };
  }

  private inputCheck(checkName : string, inputValue: number) {
    if (checkName === 'cpuOccup') {

      this.stress.stressError.showCpuOccupError = this.common.checkInputValue(inputValue, 50, 100);
    } else if (checkName === 'memOccup') {

      this.stress.stressError.showMemOccupError = this.common.checkInputValue(inputValue, 50, 100);
    } else if (checkName === 'networkIncomingRate') {

      this.stress.stressError.showNetworkInError =  this.common.checkInputValue(inputValue, 50, 100);
    } else if (checkName === 'networkOutgoingRate') {

      this.stress.stressError.showNetworkOutError = this.common.checkInputValue(inputValue, 50, 100);
    } else if (checkName === 'networkBidirectRate') {

      this.stress.stressError.showNetworkBiError =  this.common.checkInputValue(inputValue, 50, 100);
    }
  }

  private changeInputStatus(checkName : string, checkValue: boolean) {
    if (checkValue === true) {

      if (checkName === 'cpuOccup') {

        this.stress.stressError.showCpuOccupError = false;
      } else if (checkName === 'memOccup') {

        this.stress.stressError.showMemOccupError = false;
      } else if (checkName === 'networkIncomingRate') {

        this.stress.stressError.showNetworkInError = false;
      } else if (checkName === 'networkOutgoingRate') {

        this.stress.stressError.showNetworkOutError = false;
      } else if (checkName === 'networkBidirectRate') {

        this.stress.stressError.showNetworkBiError = false;
      }
    }
  }

  private isInputError() {
    if ( this.stress.stressError.showCpuOccupError !== true && this.stress.stressError.showMemOccupError !== true &&
      this.stress.stressError.showNetworkInError !== true && this.stress.stressError.showNetworkOutError !== true &&
      this.stress.stressError.showNetworkBiError !== true && this.stress.stressError.sliderError !== true) {
      return false;
    } else {
      return true;
    }
  }
}
