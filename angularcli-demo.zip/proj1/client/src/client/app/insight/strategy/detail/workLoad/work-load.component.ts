/**
 * Created by 6092002302 on 2017/6/13.
 */
import {Component, OnChanges, SimpleChanges, Input, } from '@angular/core';
import {StrategyService} from '../../strategy.service';
import {Workload, Strategy} from '../strategy-detail.interface';
import {WorkLoadStrategy} from '../strategy-detail.function';
import {TranslateService} from '@ngx-translate/core';
import {Common} from '../common';
declare var $: any;
//noinspection TypeScriptUnresolvedVariable
@Component({
  moduleId: module.id,
  selector: 'work-load',
  templateUrl: 'work-load.component.html',

  styleUrls:['../strategy-detail.component.less', '../../../css/tooltip.less'],
})

export class WorkLoadComponent implements OnChanges, WorkLoadStrategy {
  @Input() status: string;
  @Input() workLoad: Workload;

  @Input() changer: string;
  @Input() srcStrategyDetail: Strategy;
  @Input() objectType: string;

  public buttonLabel : any = {
    cancel: this.translate.instant('insight.Policy.Cancel'),
    edit: this.translate.instant('insight.Policy.Edit'),
    save: this.translate.instant('insight.Policy.Save')
  };
  constructor(private service: StrategyService, private translate: TranslateService, public common: Common) {
  }

  ngOnChanges(sChanges: SimpleChanges) {
    if (this.workLoad && this.changer && this.objectType && this.status) {
      this.config();
    }
  }

  public config() {
    this.workLoad.status = this.status;

    this.workLoad.changed = false;
    this.workLoad.inputError = false;

    this.workLoad.srcCheckChosen = this.workLoad.checks.length;
    this.workLoad.editedCheckChosen = this.workLoad.srcCheckChosen;

    /*this.workLoad.srcChecks = this.getChecks(this.workLoad.checks, 'hostWorkLoad');*/
    this.workLoad.srcChecks = this.workLoad.checks;
    this.workLoad.editedChecks = JSON.parse(JSON.stringify(this.workLoad.srcChecks));

    this.workLoad.srcThreshold = [this.workLoad.threshold.lower, this.workLoad.threshold.upper];
    this.workLoad.editedThreshold = this.workLoad.srcThreshold;

  }

  public statusChange() {
    this.workLoad.status = 'edit';
  }

  public editCancel() {
    this.workLoad.status = 'detail';

    this.workLoad.changed = false;
    this.workLoad.inputError = false;

    this.workLoad.editedThreshold = this.workLoad.srcThreshold;
    this.workLoad.editedCheckChosen = this.workLoad.srcCheckChosen;

    this.workLoad.editedChecks = JSON.parse(JSON.stringify(this.workLoad.srcChecks));
  }

  public preserve() {
    this.workLoad.status = 'detail';
    this.workLoad.srcThreshold = this.workLoad.editedThreshold;

    this.workLoad.changed = false;
    this.workLoad.srcCheckChosen = this.workLoad.editedCheckChosen;
    this.workLoad.srcChecks = JSON.parse(JSON.stringify(this.workLoad.editedChecks));

    this.updateWorkLoad(this.workLoad.srcChecks, this.objectType);
    this.service.updateStrategy(this.srcStrategyDetail, this.srcStrategyDetail.name);
  }

  public getChosenRange(range : number[] | string) {
    if (range === 'error') {
      this.workLoad.sliderError = true;
    } else {
      this.workLoad.sliderError = false;
      this.workLoad.changed = true;
      this.workLoad.editedThreshold = range;
    }
    this.workLoad.inputError = this.isInputError();
  }

  public checkChanged() {
    this.workLoad.changed = true;
  }

  public getCheckLen() {
    const len = this.checkSelect(this.workLoad.editedChecks);
    this.workLoad.editedCheckChosen = len;
  }

  checkSelect(checks: any) {

    let len = 0;
    for (const single of checks) {

      if (single.checked === true) {
        len++;
      }
    }
    return len;
  }

  private isInputError() {

    if (this.workLoad.sliderError !== true) {
      return false;
    } else {
      return true;
    }
  }

  private updateWorkLoad(srcChecks : any, objectName : string) {

    let checks  = JSON.parse(JSON.stringify(srcChecks));

    this.srcStrategyDetail.changer = this.changer;

    if (objectName === 'host') {

      this.srcStrategyDetail.hostCPI.workload.checks = checks;
      this.srcStrategyDetail.hostCPI.workload.threshold = {
        'lower' : this.workLoad.srcThreshold[0],
        'upper' : this.workLoad.srcThreshold[1]
      };
    } else if (objectName === 'vm') {
      this.srcStrategyDetail.vmCPI.workload.checks = checks;
      this.srcStrategyDetail.vmCPI.workload.threshold = {
        'lower' : this.workLoad.srcThreshold[0],
        'upper' : this.workLoad.srcThreshold[1]
      };
    }
  }
}
