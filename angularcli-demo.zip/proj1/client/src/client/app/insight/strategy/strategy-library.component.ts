/**
 * Created by 6092002302 on 2017/3/8.
 */
import { Component, ViewChild, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {StrategyService} from './strategy.service';
import {TranslateService} from '@ngx-translate/core';

import {StorageService } from '../../storage.service';

import { CommonFunctionService } from '../common/common-function.service';
import { AuthService } from '../../core/index';

@Component({
  moduleId: module.id,
  templateUrl: 'strategy-library.component.html',
  styleUrls: [ '../css/common.css', 'strategy-library.component.less'],
})

export class StrategyLibraryComponent implements OnInit {
  @ViewChild('modalDelConfirm') modalDelConfirm: any;
  window: window = window;
  deleteName = '';

  buttonDelete = {
    title : this.translate.instant('insight.Policy.Delete'),
    content: this.translate.instant('insight.Policy.DeleteConfirm')
  };
  columnDefs : any[] = [
    {
      field: 'No',
      align: 'left',
      title: this.translate.instant('insight.Policy.Sequence'),
      formatter: function (value, row, index) {
        return  index + 1;
      }
    },
    {
      field: 'name',
      align: 'left',
      title: this.translate.instant('insight.Policy.Name'),
      events: 'operateEvents',
      formatter: function (value, row, index) {
        return `<a href="javascript:void(0);" class="detail">${value}</a>`;
      }
    },
    {
      field: 'desc',
      align: 'left',
      title: this.translate.instant('insight.Policy.Description'),
      formatter: function (value, row, index) {
        const newValue = that.commonFunctionService.cutStr(value, 60);
        return `<pre data-toggle="tooltip" data-placement="top" title="${value}">${newValue}</pre>`;
      }
    },
    {
      field: 'status',
      align: 'left',
      title: this.translate.instant('insight.Policy.Status')
    },
    {
      field: 'updated',
      align: 'left',
      title: this.translate.instant('insight.Policy.LastModifiedTime'),
      formatter: function (value, row, index) {
        return that.commonFunctionService.getDateDiff(value);
      }
    },
    {
      field: 'creator',
      align: 'left',
      title: this.translate.instant('insight.Policy.Creator'),
    },
    {
      field: 'changer',
      align: 'left',
      title: this.translate.instant('insight.Policy.Modifier'),
    },

    {
      field: 'default',
      align: 'left',
      title: this.translate.instant('insight.Policy.Actions'),
      events: 'operateEvents',
      formatter: function (value, row, index) {

        if (false === value) {

          if (that.authService.containEveryRights(['Smart Config#Modify', 'Smart Config#Delete'])) {
            return `<div class="btn-group ">
                         <button class="btn btn-default edit ">${that.translate.instant('insight.Policy.Edit')}</button>
                         <button class="btn btn-default dropdown-toggle" data-toggle="dropdown"><span class="caret"></span>
                         </button>
                         <ul class="dropdown-menu dropdown-menu-top">
                            <li>
                            <a  data-toggle="modal" class="delete">${that.translate.instant('insight.Policy.Delete')}</a>
                            </li>
                         </ul>
                   </div>`;
          }
          if (that.authService.containEveryRights(['Smart Config#Modify'])) {
            return `<div class="btn-group">
                <button  data-toggle="modal" class="btn btn-default edit">
                ${that.translate.instant('insight.Policy.Edit')}</button>
                </div>`;
          }
          if (that.authService.containEveryRights(['Smart Config#Delete'])) {
            return `<div class="btn-group">
                <button  data-toggle="modal" class="btn btn-default delete">
                ${that.translate.instant('insight.Policy.Delete')}</button>
                </div>`;
          }
          return `<div class="btn-group">
                <button  data-toggle="modal" class="btn btn-default edit" disabled>
                ${that.translate.instant('insight.Policy.Edit')}</button>
                </div>`;
        } else {
          if (that.authService.containEveryRights(['Smart Config#Modify'])) {
            return `<div class="btn-group">
                <button  data-toggle="modal" class="btn btn-default edit">
                ${that.translate.instant('insight.Policy.Edit')}</button>
                </div>`;
          } else {
            return `<div class="btn-group">
                <button  data-toggle="modal" class="btn btn-default edit" disabled>
                ${that.translate.instant('insight.Policy.Edit')}</button>
                </div>`;
          }

        }

      }
    }

  ];

  gridOptions: any = {
    method: 'get',
    queryParams: params => this.queryParams(params, this),
    columns: this.columnDefs,
    sidePagination: 'server',
    pagination: true,
    pageSize: 10,
    pageNumber: 1,
    pageList: [10, 20],
    paginationDetailHAlign: 'right',
    paginationHAlign: 'right',
    clickToSelect: false,
    search: true,
    escape:true,
    toolbar: '#toolbar1'
  };

  queryParams(params: any, that: any) {
    const tmp = {
      pageSize: params.limit,
      currentPage: params.offset / params.limit + 1,
      fuzzy: params.search,
    };

    return tmp;
  }

  initTable() {
    $('#table-policy-library').bootstrapTable($.extend(this.gridOptions, {
      url: '/api/v1/smartConfig/strategies',
      dataField: 'strategies',
      responseHandler: function (res) {
        const strategyList = {
          'total': res.total,
          'strategies': res.strategies
        };
        return strategyList;
      }
    }));

    $('.bootstrap-table .search input').attr('placeholder', this.translate.instant('fm.importKey'))
      .parent().append(`<span></span>`);
  }

  constructor(private translate: TranslateService, private router : Router,
              private storageService: StorageService, private commonFunctionService : CommonFunctionService,
              private strategyService: StrategyService, private authService: AuthService) {

    const that = this;

    if (this.storageService.getCurrentLang() === 'en') {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['en-US']);
    } else {
      $.extend($.fn.bootstrapTable.defaults, $.fn.bootstrapTable.locales['zh-CN']);
    }

    this.window.operateEvents = {

      'click .detail': function (e, value, row, index) {
        that.gotoDetail(row);
      },

      'click .edit': function (e, value, row, index) {
        that.gotoEdit(row);
      },

      'click .delete': function (e, value, row, index) {
        that.gotoDelete(row);
      },
    };
  }

  ngOnInit() {
    this.initTable();
  }

  gotoDetail(selectItem: any) {
    this.router.navigate(['/main/insight/strategy/strategy-detail',
      {strategyName: selectItem.name, strategyStatus: 'detail'}]);
  }

  gotoEdit(selectItem: any) {
    this.router.navigate(['/main/insight/strategy/strategy-detail',
      {strategyName: selectItem.name, strategyStatus: 'edit'}]);
  }

  gotoDelete(selectItem: any) {
    this.deleteName = selectItem.name;
    this.modalDelConfirm.open = true;
  }

  delByName() {
    this.strategyService.delStrategyByName(this.deleteName)
      .then((res: any) => {
        if ('ok' === res) {
          $('#table-policy-library').bootstrapTable('refresh');
        }
      });
  }

  addStrategy() {
    this.router.navigate(['main/insight/strategy/strategy-add']);
  }
}
