/**
 * Created by 6092002302 on 2017/3/8.
 */
import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import { RouterModule} from '@angular/router';
import {routing} from './strategy.routes';
import {SharedModule} from '../../shared/index';
import {InsightCommonModule} from '../common/common.module';
import {StrategyService} from './strategy.service';
import {StrategyLibraryComponent} from './strategy-library.component';
import {StrategyAddComponent} from './add/strategy-add.component';
import {PxStepbarComponent} from  './control/px-stepbar.component';
import {PxCheckbuttonComponent} from './control/px-checkbutton.component';
import {CmsSliderComponent} from './control/px-slider.component';
import {PxSlideblockComponent} from './control/px-slideblock.component';
import {TimeSelectorComponent} from './control/time-selector.component';
import {StrategyDetailComponent} from './detail/strategy-detail.component';

import {DefaultNamePipe} from './defaultName.pipe';
import {PxCardsComponent} from './control/px-cards.component';

import {WorkLoadAddComponent} from './add/workLoad/work-load-add.component';
import {RemainCapacityAddComponent} from './add/remainCapacity/remain-capacity.add.component';
import {ReclaimCapacityAddComponent} from './add/reclaimCapacity/reclaim-capacity-add.component';
import {StressAddComponent} from './add/stress/stress-add.component';
import {ObserveWindowAddComponent} from './add/obsvWnd/observe-window-add.component';

import {WorkLoadComponent} from './detail/workLoad/work-load.component';
import {RemainCapacityComponent} from './detail/remainCapacity/remain-capacity.component';
import {ReclaimCapacityComponent} from './detail/reclaim-capacity/reclaim-capacity.component';
import {StressComponent} from './detail/stress/stress.component';
import {ObserveWindowComponent} from './detail/obsvWnd/observe-window.component';
import {Common} from './detail/common';

import {PxDivTooltipModule} from '../shared/tooltip/index';

import {GlPopup} from './control/gl-popup.component';
import {AddDeactivateGuard} from './add-deactivate-guard.service';

  @NgModule({
  imports: [CommonModule, routing, SharedModule, InsightCommonModule, FormsModule, routing, PxDivTooltipModule],

  declarations: [StrategyLibraryComponent, StrategyAddComponent, PxStepbarComponent, PxCheckbuttonComponent, CmsSliderComponent,
    PxSlideblockComponent, TimeSelectorComponent, StrategyDetailComponent,DefaultNamePipe, PxCardsComponent, WorkLoadComponent,
    RemainCapacityComponent, ReclaimCapacityComponent, StressComponent,ObserveWindowComponent, WorkLoadAddComponent,
    RemainCapacityAddComponent, ReclaimCapacityAddComponent, StressAddComponent, ObserveWindowAddComponent, GlPopup],


  exports: [PxStepbarComponent, PxCheckbuttonComponent, CmsSliderComponent, PxSlideblockComponent, TimeSelectorComponent,
    PxCardsComponent, RouterModule],

  providers: [StrategyService, Common, AddDeactivateGuard],
})
export class StrategyModule {}

