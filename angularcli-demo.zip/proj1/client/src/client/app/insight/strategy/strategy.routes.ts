/**
 * Created by 6092002302 on 2017/3/8.
 */
import {ModuleWithProviders} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {StrategyLibraryComponent} from './strategy-library.component';
import {StrategyAddComponent} from './add/strategy-add.component';
import {StrategyDetailComponent} from './detail/strategy-detail.component';


import { AddDeactivateGuard }    from './add-deactivate-guard.service';
const routes: Routes = [
    {
        path: 'strategy',
        children: [
            {
                path: 'strategy-library',
                component: StrategyLibraryComponent,
            },
            {
                path: 'strategy-add',
                component: StrategyAddComponent,
              canDeactivate: [AddDeactivateGuard]
            },
            {
                path: 'strategy-detail',
                component: StrategyDetailComponent,
            }
        ]
    }
];


export const routing: ModuleWithProviders = RouterModule.forChild(routes);

