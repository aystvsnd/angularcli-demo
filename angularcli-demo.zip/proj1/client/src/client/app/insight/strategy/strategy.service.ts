/**
 * Created by 6092002302 on 2017/3/8.
 */
import { Injectable } from '@angular/core';
import { ApiResourceService as Http } from '../../apiResource.service'; ;
import {TranslateService} from '@ngx-translate/core';

@Injectable()
export class StrategyService {

  constructor(public http: Http, private translate: TranslateService) {
  }

  delStrategyByName(name: any) {
    return this.http.delete('/api/v1/smartConfig/strategies/delete?name=' + name).toPromise().then(res => res.json().error);
  }

  getStrategyDetail(name : any) {
    return this.http.get('/api/v1/smartConfig/strategies/query?name=' + name).toPromise().then(
      (res) => {
        return res.json();
      }
    );
  }

  /* return true :exist the name */
  checkStrategyName(name: any) {
    return this.http.get('/api/v1/smartConfig/strategies/has?name=' + name).toPromise().
      then(res => {
        if (res.status === 200) {
          return res.json().result;
        } else {
          return true;
        }
      }
    );
  }

  getStrategyNames() {
    return this.http.get('/api/v1/smartConfig/strategies/names/list').toPromise().then(
      (res) => {
        if (res.status === 200) {
          return res.json().names;
        } else {
          return [];
        }
      }
    );
  }

  addNewStrategy(strategy: any) {
    return this.http.post('/api/v1/smartConfig/strategies/new', strategy).toPromise().then(
      (res) => {
        if (res.status === 200 || res.status === 400 ) {
          return res.json().error;
        } else {
          return 'fail';
        }
      }
    );
  }

  updateStrategy(strategy: any, name : any) {
    return this.http.put('/api/v1/smartConfig/strategies/update?name=' + name, strategy).toPromise().then(
      (res) => {
        if (res.status === 200 || res.status === 400 ) {
          return res.json().error;
        } else {
          return 'fail';
        }
      }
    );
  }
}
