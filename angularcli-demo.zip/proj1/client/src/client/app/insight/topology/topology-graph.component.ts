import {Component, OnInit, OnChanges, Input} from '@angular/core';

import { CommonFunctionService } from '../common/common-function.service';

declare const d3;

const icon = {
  dc: {
    url: 'assets/images/insight/svg/dc.svg',
    width: 50,
    height: 50,
  },
  cloudEnv: {
    url: 'assets/images/insight/svg/cloud-environment.svg',
    width: 40,
    height: 40,
  },
  pod: {
    url: 'assets/images/insight/svg/pod.svg',
    width: 40,
    height: 40,
  },
  rack: {
    url: 'assets/images/insight/svg/Rack.svg',
    width: 30,
    height: 30,
  },
  chassis: {
    url: 'assets/images/insight/svg/Shelf.svg',
    width: 30,
    height: 30,
  },
  blade: {
    url: 'assets/images/insight/svg/Blade.svg',
    width: 30,
    height: 30,
  },
  rackServer: {
    url: 'assets/images/insight/svg/Rack-Server.svg',
    width: 30,
    height: 30,
  },
  storage: {
    url: 'assets/images/insight/svg/storage.svg',
    width: 30,
    height: 30,
  },
  router: {
    url: 'assets/images/insight/svg/Router.svg',
    width: 30,
    height: 30,
  },
  'switch': {
    url: 'assets/images/insight/svg/Switch.svg',
    width: 30,
    height: 30,
  },
  az: {
    url: 'assets/images/insight/svg/AZ.svg',
    width: 30,
    height: 30,
  },
  aggregate: {
    url: 'assets/images/insight/svg/Aggregate.svg',
    width: 30,
    height: 30,
  },
  host: {
    url: 'assets/images/insight/svg/host.svg',
    width: 30,
    height: 30,
  },
  vm: {
    url: 'assets/images/insight/svg/VM.svg',
    width: 30,
    height: 30,
  }
};

@Component({
  moduleId: module.id,
  template: `<div id="topology-div" style="width: 100%; height: 550px; overflow: scroll; position: relative">
  <svg style="width: 100%; min-height: 98%;"></svg>

  <div class="topo-tooltip">
    <div class="topo-close"><img src="assets/images/insight/popup_btn_close.png"></div>
    <p><img [src]="(tooltip?.datum())?.imgUrl">{{(tooltip?.datum())?.name}}</p>
    <p *ngIf="(tooltip?.datum())?.ownAlarm !== 0"><a [routerLink]="['/main/alarm/currentalarm/gather/'+(tooltip?.datum())?.ownAlarmId]">
      <span class="topo-label">{{"insight.topology.ownAlarm" | translate}}</span>{{(tooltip?.datum())?.ownAlarm}}</a>
    </p>
    <p *ngIf="(tooltip?.datum())?.ownAlarm === 0">
    <span class="topo-label">{{"insight.topology.ownAlarm" | translate}}</span>{{(tooltip?.datum())?.ownAlarm}}
    </p>
    <p><span class="topo-label">{{"insight.topology.childrenAlarm" | translate}}</span>{{(tooltip?.datum())?.childAlarm}}</p>
  </div>
</div>`,
  selector: 'topo-graph',
  styles: [`.topo-tooltip {
  background: #fff;
  position: absolute;
  border: solid 1px;
  padding: 10px;
  opacity: 0;
  display: none;
  white-space: nowrap;
}

.topo-tooltip .topo-close {
  position: absolute;
  right: 5px;
  top: 5px;
  background: #fff;
  border: solid 1px #bbb;
}

.topo-tooltip .topo-close:hover {
  cursor: pointer;
  transform: scale(1.2, 1.2);
}

.topo-tooltip p:first-of-type {
  margin-bottom: 14px;
}

.topo-tooltip p img {
  width: 24px;
  vertical-align: bottom;
  margin-right: 6px;
}

.topo-label {
  margin-left: 30px;
  display: inline-block;
  width: 150px;
}`],
})
export class TopologyGraphComponent implements OnInit, OnChanges {

  @Input() data;

  svg;
  tree;
  tooltip;

  private static removeChildren(node) {
    node.children = null;
  }

  constructor (private commonFunctionService: CommonFunctionService) {}



  ngOnInit() {
    this.svg = d3.select('svg')
      .append('g')
      .attr('transform', d => 'translate(50, 0)');

    this.tree = d3.layout
      .tree()
      .nodeSize([70, 210]);

    this.tooltip = d3.select('.topo-tooltip');
  }

  ngOnChanges() {
    const component = this;

    function render(nodes) {
      const nodeOnGraph = component.svg.selectAll('g.node');
      const oldNodes = nodeOnGraph.data();
      function findParent(node) {
        if (_.isEmpty(node.parent)) {
          return node;
        } else {
          const p = oldNodes.filter(oldNode => oldNode._id === node.parent._id);
          return _.isEmpty(p) ? findParent(node.parent) : _.first(p);
        }
      }

      function findParentInNew(node) {
        if (_.isEmpty(node.parent)) {
          return node;
        } else {
          const p = nodes.filter(oldNode => oldNode._id === node.parent._id);
          return _.isEmpty(p) ? findParentInNew(node.parent) : _.first(p);
        }
      }


      function removeChildren(node) {
        node.children = null;
      }

      function appendChildren(node) {
        node.children = node._children;
      }

      nodes.forEach(node => {
        const temp = node.x;
        node.x = node.y;
        node.y = temp;
      });
      const links = component.tree.links(nodes);
      const diagonal = d3.svg.diagonal()
        .source(d => ({
          x: d.source.y,
          y: d.source.x + (_.has(icon, d.source.type) ? icon[d.source.type].width / 2 + 10 : 0),
        }))
        .target(d => ({
          x: d.target.y,
          y: d.target.x - (_.has(icon, d.target.type) ? icon[d.target.type].width / 2 : 0),
        }))
        .projection(d => [d.y, d.x]);
      const transitionDuration = 1000;
      const linkOnGraph = component.svg.selectAll('path');

      d3.select('svg')
        .transition()
        .duration(transitionDuration)
        .style('height', `${100 + _.max(nodes, node => node.y).y - _.min(nodes, node => node.y).y}px`)
        .style('width', `${_.max(nodes, node => node.depth).depth * 210 + 125}px`);

      component.svg
        .transition()
        .duration(transitionDuration)
        .attr('transform', d => `translate(50, ${50 - _.min(nodes, node => node.y).y})`);

      {
        nodeOnGraph.each(function(circle) {
          if (!nodes.some(node => node._id === circle._id)) {
            const g = d3.select(this)
              .transition()
              .duration(transitionDuration)
              .attr('transform', d => `translate(${findParentInNew(d).x},${findParentInNew(d).y})`)
              .remove();

            g.select('circle')
              .attr('r', 0);

            g.select('text')
              .style('font-size', '0px')
              .style('fill-opacity', 0);

            g.selectAll('image')
              .attr('transform', 'scale(0,0)');
          } else {
            d3.select(this)
              .transition()
              .duration(transitionDuration)
              .attr('transform', d => `translate(${d.x},${d.y})`);

            if (_.has(icon, circle.type) && _.has(circle, '_children')) {
              d3.select(this).select('.toggle')
                .attr('xlink:href', `assets/images/insight/svg/topo-${_.isEmpty(circle.children) ? 'un' : ''}zip.svg`);
            }
          }
        });

        linkOnGraph.each(function (path) {
          if (!links.some(link => path.source._id === link.source._id && path.target._id === link.target._id)) {
            d3.select(this)
              .transition()
              .duration(transitionDuration)
              .attr('d', () => {
                const p = findParentInNew(path.target);

                return diagonal({
                  source: {
                    x: p.x + (_.has(icon, p.type) ? icon[p.type].width / 2 + 10 : 0),
                    y: p.y,
                  },
                  target: {
                    x: p.x + (_.has(icon, p.type) ? icon[p.type].width / 2 + 10 : 0),
                    y: p.y,
                  }
                });
              })
              .remove();
          } else {
            d3.select(this)
              .datum(_.chain(links)
                .filter(link => path.source._id === link.source._id && path.target._id === link.target._id).first().value())
              .transition()
              .duration(transitionDuration)
              .attr('d', diagonal);
          }
        });
      }

      nodes.forEach(node => {
        if (nodeOnGraph.filter(d => d._id === node._id).empty()) {
          const g = component.svg
            .append('g')
            .datum(node)
            .attr('class', 'node')
            .attr('transform', d => `translate(${findParent(d).previousPosition.x},${findParent(d).previousPosition.y})`);
          g
            .append('text')
            .attr('text-anchor', 'middle')
            .attr('y', 0)
            .style('font-size', '0px')
            .style('fill-opacity', 0)
            .text(function(d) { return component.commonFunctionService.cutStr(d.name, 14); });

          const gTransition = g
            .transition()
            .duration(transitionDuration)
            .attr('transform', d => `translate(${d.x},${d.y})`);

          if (_.has(icon, node.type)) {
            g
              .append('image')
              .attr('xlink:href', icon[node.type].url)
              .attr('class', 'icon')
              .attr('width', icon[node.type].width)
              .attr('height', icon[node.type].height)
              .attr('x', `-${icon[node.type].width / 2}`)
              .attr('y', `-${icon[node.type].height / 2}`);
            if (_.has(node, '_children')) {
              g.append('image')
                .attr('xlink:href', `assets/images/insight/svg/topo-${_.isEmpty(node.children) ? 'un' : ''}zip.svg`)
                .attr('width', 10)
                .attr('height', 10)
                .attr('class', 'toggle')
                .attr('x', `${icon[node.type].width / 2}`)
                .attr('y', -5);
            }
            if (!_.isEmpty(node.highestLevel)) {
              g.append('image')
                .attr('xlink:href', `assets/images/insight/svg/Alert_${node.highestLevel}.svg`)
                .attr('width', 10)
                .attr('height', 10)
                .attr('x', `${icon[node.type].width / 2 - 10}`)
                .attr('y', `${icon[node.type].height / 2 - 10}`);
            }
            g.selectAll('image').attr('transform', 'scale(0,0)');

            gTransition
              .select('text')
              .attr('y', icon[node.type].height / 2 + 12)
              .style('font-size', '12px')
              .style('fill-opacity', 1);

            gTransition
              .selectAll('image')
              .attr('transform', 'scale(1,1)');
          } else {
            g
              .append('circle')
              .attr('r', 0)
              .style('stroke', '#000');
            gTransition
              .select('circle')
              .attr('r', 5);

            gTransition
              .select('text')
              .style('font-size', 12)
              .style('fill-opacity', 1);
          }
        }
      });

      links.forEach(link => {
        if (linkOnGraph.filter(path => path.source._id === link.source._id && path.target._id === link.target._id).empty()) {
          component.svg
            .append('path')
            .datum(link)
            .attr('d', () => {
              const p = findParent(link.target);

              return diagonal({
                source: {
                  x: p.previousPosition.x + (_.has(icon, p.type) ? icon[p.type].width / 2 + 10 : 0),
                  y: p.previousPosition.y,
                },
                target: {
                  x: p.previousPosition.x + (_.has(icon, p.type) ? icon[p.type].width / 2 + 10 : 0),
                  y: p.previousPosition.y,
                }
              });
            })
            .style('stroke', '#ccc')
            .style('fill', 'none')
            .transition()
            .duration(transitionDuration)
            .attr('d', diagonal);
        }
      });

      component.svg.selectAll('g.node').data().forEach(d => {
        d.previousPosition = {
          x: d.x,
          y: d.y,
        };
      });

      component.svg
        .selectAll('g.node')
        .filter(d => _.has(d, '_children'))
        .select('circle,.toggle')
        .style('cursor', 'pointer')
        .on('click', node => {
          if (!_.has(node, 'children')) {
            appendChildren(node);
          } else {
            removeChildren(node);
          }
          render(component.tree(component.data));
        });

      d3.selectAll('g.node image.icon')
        .style('cursor', 'pointer')
        .on('mouseover', node => {
            const div = document.getElementById('topology-div');
            const width = div.clientWidth;
            const height = div.clientHeight;
            const d3y = d3.event.pageY;
            let xOffset = 50;
            let yOffset = 50;
            let nameWidth = 0;
            const nameLength = component.commonFunctionService.getStrLength(node.name);

            /* 7像素，有误差，从隐藏到显示div宽度获取是上次的，暂时如此计算解决 */
            if (nameLength > 26) {
              nameWidth = (nameLength - 26) * 7;
            }

            /* 210 、250 是X轴测量数值，有误差 */
            if ((node.x + xOffset + 250 + nameWidth) > width) {
              if ((node.x + xOffset - 210 - nameWidth) > 0 ) {
                xOffset = xOffset - 210 - nameWidth;
              }
            }

            /* 200、100、120 是Y轴测量数值，有误差 */
            if ((d3y + yOffset + 100 - 200 ) > height) {
              if ((d3y + yOffset - 120 - 200) > 0 ) {
                yOffset = yOffset - 120;
              }
            }

            component.tooltip
              .style('left', `${node.x + xOffset}px`)
              .style('top', `${node.y + yOffset - _.min(nodes, node => node.y).y + yOffset}px`)
              .style('opacity', 0)
              .style('display', 'block');

            component.tooltip
              .datum(_.chain(node)
                .pick(['name', 'ownAlarm', 'childAlarm', 'ownAlarmId'])
                .extend({imgUrl: icon[node.type].url})
                .value())
              .transition()
              .duration(750)
              .style('left', `${node.x + xOffset}px`)
              .style('top', `${node.y + yOffset + 10 - _.min(nodes, node => node.y).y}px`)
              .style('opacity', 1)
              .style('display', 'block');
        });

      d3.select('svg')
        .on('click', () => {
          component.tooltip.style('display', 'none');
        });


      component.tooltip
        .select('.topo-close')
        .on('click', () => {
          component.tooltip.style('display', 'none');
        });
    }

    if (!_.isEmpty(this.data)) {
      component.tooltip
        .style('display', 'none');
      render(this.init());
    }
  }

  init() {
    const nodes = this.tree(this.data);
    nodes.forEach(node => {
      node._id = _.uniqueId();
    });
    nodes.filter(node => _.has(node, 'children'))
      .forEach(node => node._children = node.children);
    if (!_.isEmpty(nodes)) {
      const first = _.first(nodes);
      first.previousPosition = {
        x: first.x,
        y: first.y,
      };

      if (_.isArray(first.children)) {
        first.children.forEach(node => TopologyGraphComponent.removeChildren(node));
      }
    }

    this.svg.selectAll('*').remove();

    return this.tree(this.data);

  }

}
