import {Component, OnChanges, Input, Output, EventEmitter} from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'topo-tab',
  template: `<div>
  <span *ngFor="let item of data" (click)="activeTab = item.id;clickTab.emit(item.id)" 
        [class.active]="activeTab === item.id">{{item.name}}</span>
</div>`,
  styles: [`div {
  display: flex;
  flex-direction: row;
  border-bottom: solid 1px #bbb;
  margin-top: 20px;
}

span {
  width: 120px;
  height: 40px;
  font-size: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-top: solid 2px transparent;
  position: relative;
  top: 1px;
  z-index: 5;
  border-bottom: solid 1px transparent;
}

span.active {
  border-top-color: #1898eb;
  border-bottom-color: #fff;
  border-right: solid 1px #bbb;
  border-left: solid 1px #bbb;
}

span:not(.active) {
  cursor: pointer;
}
`]
})
export class TopologyTabComponent implements OnChanges {
  @Input() data;
  @Output() clickTab;
  activeTab;

  constructor() {
    this.clickTab = new EventEmitter();
  }

  ngOnChanges() {
    if (_.isArray(this.data) && !_.isEmpty(this.data)) {
      this.activeTab = _.first(this.data).id;
      this.clickTab.emit(_.first(this.data).id);
    }
  }
}
