import {Component, OnInit} from '@angular/core';

import {TopologyService} from './topology.service';

@Component({
  moduleId: module.id,
  templateUrl: 'topology.component.html',
  styleUrls: ['topology.component.less']
})
export class PhysicalTopologyComponent implements OnInit {
  hardwareTopologyData;
  logicalTopologyData;
  tabs;
  shownData;
  showModel = 'physical';
  data;

  constructor (
    private topologyService: TopologyService,
  ) {}

  ngOnInit () {
    this.topologyService.getPhysicalTopology()
      .then(hardwareTopology => {
        this.hardwareTopologyData = hardwareTopology.dcs;
        this.topologyService.getLogicTopology()
          .then(logicalTopology => {
            this.data = intersection(hardwareTopology.dcs, logicalTopology.dcs).map(its => ({physical: its[0], logical: its[1]}));

            this.tabs = this.data.map(item => ({id: item.physical.id, name: item.physical.name}));
          });
      });

    function intersection(a, b, ...func) {
      return a.filter(_a => !_.isEmpty(b.filter(_b => _a.id === _b.id)))
        .map(_a => [_a, _.first(b.filter(_b => _a.id === _b.id))]);
    }
  }

  switchDc(id) {
    this.shownData = _.chain(this.data)
      .filter(item => item.physical.id === id)
      .first()
      .value();
  }
}
